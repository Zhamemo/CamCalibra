#!/bin/bash

echo "===== ROS XFCE Autostart ====="

#################################################
# 等待 X server ready
#################################################

export DISPLAY=:0

echo "Waiting for DISPLAY..."

until xdpyinfo >/dev/null 2>&1; do
    sleep 1
done

echo "DISPLAY ready"

#################################################
# 等待 DBUS ready
#################################################

echo "Waiting for DBUS..."

while [ -z "$DBUS_SESSION_BUS_ADDRESS" ]; do
    sleep 1
done

echo "DBUS ready"

#################################################
#  加载 ROS 环境
#################################################

source /opt/ros/noetic/setup.bash
source /home/orangepi/mobile_arm_demo/devel/setup.bash

#################################################
# 启动 ROS
#################################################

echo "Starting ROS launch..."

roscore &
sleep 2

roslaunch --wait mobile_arm_bringup piper_real_launch.launch
