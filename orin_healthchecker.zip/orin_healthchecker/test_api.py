import os
import xmlrpclib
caller_id = "/simple_node"
m = xmlrpclib.ServerProxy(os.environ['ROS_MASTER_URI'])

print(os.environ['ROS_MASTER_URI'])

#while (True): 
    #code, msg, val = m.lookupNode(caller_id, caller_id)
    #if code == 1:
      ##pubs, subs, srvs = val
      #print ("1")
    #else:
      #print ("call failed", code, msg)
