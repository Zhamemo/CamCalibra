
#include "reporter/FileReporter.h"
#include "orin_healthchecker/File.h"
#include "orin_healthchecker/orinFileStatus.h"
#include <ros/ros.h>

namespace OrinHealthChecker {

std::shared_ptr<FileReporter> FileReporter::instance = nullptr;

void FileReporter::initialize (std::vector<File> file_vec) {
    file_vec_ = file_vec;
    return;
}

void FileReporter::updateFileStatus (std::string file_name, bool file_status) {
    std::lock_guard<std::mutex> lg (lock);
    for (auto& file : file_vec_) {
        if (file.file_path != file_name) {
            continue;
        }
        file.status = file_status;
        return;
    }
}

void FileReporter::pubFileStatus () {
    std::lock_guard<std::mutex> lg (lock);
    static ros::NodeHandle nh;
    static auto file_pub =
    nh.advertise<orin_healthchecker::orinFileStatus> ("/orin_file_status", 1);

    orin_healthchecker::orinFileStatus orin_file_msg;
    for (const auto& file : file_vec_) {
        orin_healthchecker::File file_msg;
        file_msg.file_name = file.file_path;
        file_msg.status    = file.status;
        orin_file_msg.file_statuc_vec.push_back (file_msg);
    }
    file_pub.publish (orin_file_msg);
    return;
};


} // namespace OrinHealthChecker
