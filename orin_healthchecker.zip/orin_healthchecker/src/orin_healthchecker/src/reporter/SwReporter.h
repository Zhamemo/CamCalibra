#pragma once

#include "orin_healthchecker/NodeStatus.h"
#include "orin_healthchecker/TopicStatus.h"
#include "orin_healthchecker/orinSwStatus.h"
#include "ros/node_handle.h"
#include "ros/publisher.h"

#include <cstddef>
#include <memory>
#include <mutex>
#include <ros/ros.h>
#include <string>
#include <unordered_map>


namespace OrinHealthChecker {

struct TopicStatus {
    std::string topic_name;
    std::string node_name;
    int warning_hz;
    int error_hz;
    int fatal_error_hz;


    TopicStatus (std::string topic_name, std::string node_name, int warning_hz, int error_rate, int fatal_error_rate) {
        this->topic_name     = topic_name;
        this->node_name      = node_name;
        this->warning_hz     = warning_hz;
        this->error_hz       = error_hz;
        this->fatal_error_hz = fatal_error_hz;
    }

    bool operator== (const TopicStatus& rhs) const {
        return ((this->topic_name == rhs.topic_name) && (this->node_name == rhs.node_name) &&
               (this->warning_hz == rhs.warning_hz)) ?
        true :
        false;
    }

    struct CustomHash {
        size_t operator() (const TopicStatus& lhs) const {
            return (std::hash<std::string> () (lhs.topic_name) ^
            std::hash<std::string> () (lhs.node_name) ^ std::hash<int> () (lhs.warning_hz));
        }
    };
};

struct NodeStatus {
    std::string node_name;

    NodeStatus (std::string node_name) {
        this->node_name = node_name;
    }

    bool operator== (const NodeStatus& rhs) const {
        return (this->node_name == rhs.node_name) ? true : false;
    }

    struct CustomHash {
        size_t operator() (const NodeStatus& lhs) const {
            return (std::hash<std::string> () (lhs.node_name));
        }
    };
};

struct SwReporter : public std::enable_shared_from_this<SwReporter> {

    private:
    static std::shared_ptr<SwReporter> instance;
    SwReporter () {
    }
    SwReporter* self;
    ros::NodeHandle nh_;
    ros::Publisher sw_pub_;
    int topic_size_;
    std::unordered_map<TopicStatus, float /*calculated frequency*/, TopicStatus::CustomHash> topic_status_map_;
    std::unordered_map<NodeStatus, bool /*flag for is_node_found*/, NodeStatus::CustomHash> node_status_map_;
    std::mutex lock;

    private:
    orin_healthchecker::orinSwStatus getRosMsg ();

    public:
    void initialize (ros::NodeHandle nh,
    std::vector<TopicStatus> monitor_topics,
    std::vector<NodeStatus> monitor_nodes);
    void pubSwStatus ();
    void updateTopicStatusMap (TopicStatus topic_status, float actual_rate);
    void updateNodeStatusMap (NodeStatus node_status, bool is_existd);

    bool checkStatusMap ();

    static std::shared_ptr<SwReporter> getInstance () {
        // Create the singleton instance if it doesn't exist
        if (!instance) {
            instance = std::shared_ptr<SwReporter> (new SwReporter ());
        }
        return instance;
    }
};


} // namespace OrinHealthChecker