#pragma once

#include "orin_healthchecker/orinStatus.h"


namespace OrinHealthChecker {
class SysStatusReporter {
    // Assmble Orin Status & Pub

    // private:
    //     orin_healthchecker
};
} // namespace OrinHealthChecker
