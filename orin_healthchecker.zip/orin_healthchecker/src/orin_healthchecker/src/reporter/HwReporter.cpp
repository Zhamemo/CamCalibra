
#include "reporter/HwReporter.h"
#include "log/loguru.hpp"
#include "orin_healthchecker/orinHwStatus.h"
#include <mutex>
#include <vector>


namespace OrinHealthChecker {

// Initialize the static member variable
std::shared_ptr<HwReporter> HwReporter::instance = nullptr;

orin_healthchecker::orinHwStatus HwReporter::getRosMsg () {
    orin_healthchecker::orinHwStatus msg;
    if (cam_status_vec_.size () != 8) {
        LOG_F (WARNING, "invalid number of camera config.");
        return msg;
    }

    if (lidar_status_vec_.size () != 4) {
        LOG_F (WARNING, "invalid number of lidar config.");
        return msg;
    }

    /* monitor camera */
    for (int i = 0; i < 4; i++) {
        msg.perception_cam_status.push_back (cam_status_vec_[i].status);
    }

    /* perception camera */
    for (int i = 4; i < 8; i++) {
        msg.monitor_cam_status.push_back (cam_status_vec_[i].status);
    }

    /* blind_lidar */
    for (int i = 0; i < 4; i++) {
        msg.blind_lidar_status.push_back (lidar_status_vec_[i].status);
    }

    return msg;
}

void HwReporter::initialize (ros::NodeHandle nh,
std::vector<OrinHealthChecker::Camera> cam_status_vec,
std::vector<OrinHealthChecker::Lidar> lidar_status_vec) {
    cam_status_vec_   = cam_status_vec;
    lidar_status_vec_ = lidar_status_vec;

    hw_pub_ =
    nh_.advertise<orin_healthchecker::orinHwStatus> ("/orin_hw_status", 1);
    return;
}


void HwReporter::pubHwStatus () {
    std::lock_guard<std::mutex> lg (lock);
    static ros::NodeHandle nh;
    // static auto hw_pub =
    // nh.advertise<orin_healthchecker::orinHwStatus> ("/orin_hw_status", 1);
    // hw_pub.publish (getRosMsg ());
    hw_pub_.publish (getRosMsg ());
    return;
}

void HwReporter::updateCamStatus (OrinHealthChecker::Camera cam_ins, bool status) {
    std::lock_guard<std::mutex> lg (lock);
    for (auto& cam : cam_status_vec_) {
        if (cam.cam_name != cam_ins.cam_name) {
            continue;
        }
        cam.status = status;
    }
    return;
}

void HwReporter::updateLidarStatus (OrinHealthChecker::Lidar lidar_ins, bool status) {
    std::lock_guard<std::mutex> lg (lock);
    for (auto& lidar : lidar_status_vec_) {
        if (lidar.lidar_name != lidar_ins.lidar_name) {
            continue;
        }
        lidar.status = status;
    }
    return;
}


} // namespace OrinHealthChecker
