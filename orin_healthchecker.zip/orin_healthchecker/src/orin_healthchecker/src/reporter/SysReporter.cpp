
#include "reporter/SysReporter.h"
#include "components/SysChecker.h"
// #include "components/all.h"
#include "orin_healthchecker/orinSysStatus.h"
#include "ros/node_handle.h"
#include <cstddef>
#include <memory>
#include <mutex>
#include <ros/ros.h>

namespace OrinHealthChecker {

std::shared_ptr<SysReporter> SysReporter::instance = nullptr;

void SysReporter::initialize (ros::NodeHandle nh) {
    nh_ = nh;

    sys_pub_ =
    nh_.advertise<orin_healthchecker::orinSysStatus> ("/orin_sys_status", 1);
    return;
}

void SysReporter::updateSysStatus (OrinHealthChecker::SysCheckResult sys_check_result) {
    std::lock_guard<std::mutex> lg (lock);
    sys_status_.disk_usage       = sys_check_result.disk_usage;
    sys_status_.disk_error_level = sys_check_result.disk_status;

    sys_status_.mem_usage       = sys_check_result.mem_usage;
    sys_status_.mem_error_level = sys_check_result.mem_status;

    sys_status_.cpu_usage       = sys_check_result.cpu_usage;
    sys_status_.cpu_error_level = sys_check_result.cpu_status; 
    return;
}


void SysReporter::pubSysStatus () {
    std::lock_guard<std::mutex> lg (lock);
    sys_pub_.publish (sys_status_);
    return;
};


} // namespace OrinHealthChecker
