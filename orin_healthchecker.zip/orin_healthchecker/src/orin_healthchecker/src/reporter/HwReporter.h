#pragma once

#include "components/HWChecker.h"
#include "orin_healthchecker/orinHwStatus.h"
#include <memory>
#include <mutex>
#include <ros/ros.h>
#include <vector>

namespace OrinHealthChecker {

struct HwReporter : public std::enable_shared_from_this<HwReporter> {

    private:
    static std::shared_ptr<HwReporter> instance;
    HwReporter () {
    }
    ros::NodeHandle nh_;
    ros::Publisher hw_pub_;
    int topic_size_;
    std::vector<OrinHealthChecker::Camera> cam_status_vec_;
    std::vector<OrinHealthChecker::Lidar> lidar_status_vec_;
    std::mutex lock;

    private:
    orin_healthchecker::orinHwStatus getRosMsg ();

    public:
    void initialize (ros::NodeHandle nh,
    std::vector<OrinHealthChecker::Camera> cam_status_vec,
    std::vector<OrinHealthChecker::Lidar> lidar_status_vec);

    void pubHwStatus ();
    void updateCamStatus (OrinHealthChecker::Camera cam_ins, bool status);
    void updateLidarStatus (OrinHealthChecker::Lidar lidar_ins, bool status);

    static std::shared_ptr<HwReporter> getInstance () {
        // Create the singleton instance if it doesn't exist
        if (!instance) {
            instance = std::shared_ptr<HwReporter> (new HwReporter ());
        }
        return instance;
    }
};


} // namespace OrinHealthChecker
