#include "reporter/SwReporter.h"
#include "orin_healthchecker/ErrorLevel.h"
#include "orin_healthchecker/NodeStatus.h"
#include "orin_healthchecker/TopicStatus.h"
#include "orin_healthchecker/orinSwStatus.h"
#include "components/all.h"
#include "ros/node_handle.h"
#include "ros/rate.h"
#include <chrono>
#include <sstream>
#include <thread>


namespace OrinHealthChecker {

// Initialize the static member variable
std::shared_ptr<SwReporter> SwReporter::instance = nullptr;

void SwReporter::initialize (ros::NodeHandle nh,
std::vector<TopicStatus> monitor_topics,
std::vector<NodeStatus> monitor_nodes) {
    nh_ = nh;
    sw_pub_ =
    nh_.advertise<orin_healthchecker::orinSwStatus> ("/orin_sw_status", 1);

    /* initialize default map */
    for (const auto& topic : monitor_topics) {
        topic_status_map_[topic] = 0;
    }


    for (const auto& node : monitor_nodes) {
        node_status_map_[node] = false;
    }

    return;
}

orin_healthchecker::orinSwStatus SwReporter::getRosMsg () {
    orin_healthchecker::orinSwStatus msg;
    for (const auto& [node, status] : node_status_map_) {
        orin_healthchecker::NodeStatus node_status_msg;
        node_status_msg.node_name = node.node_name;
        node_status_msg.status    = status;
        msg.node_status.push_back (node_status_msg);
    }

    for (const auto& [topic_stauts, freq] : topic_status_map_) {
        orin_healthchecker::TopicStatus topic_status_msg;
        topic_status_msg.topic_name = topic_stauts.topic_name;
        topic_status_msg.node_name  = topic_stauts.node_name;
        topic_status_msg.topic_hz   = freq;

        /* Set Error Level in Here */
        if (topic_stauts.fatal_error_hz > freq) {
            OrinHealthChecker::StandByController::is_sw_pass = false;
            std::stringstream ss;
            ss << "[sw component] node: " << topic_stauts.node_name
               << "topic: " << topic_stauts.topic_name
               << "actual rate " << freq 
               << "is lower than topic fatal error hz" << topic_stauts.fatal_error_hz
               << std::endl;
            OrinHealthChecker::StandByController::updateReason(ss.str(), "sw");
            topic_status_msg.ERROR_LEVEL = orin_healthchecker::ErrorLevel::FATAL_ERROR;
            msg.topic_status.push_back (topic_status_msg);
            continue;
        }

        if (topic_stauts.error_hz > freq) {
            OrinHealthChecker::StandByController::is_sw_pass = false;
            std::stringstream ss;
            ss << "[sw component] node: " << topic_stauts.node_name
               << "topic: " << topic_stauts.topic_name
               << "actual rate " << freq 
               << "is lower than topic error hz" << topic_stauts.error_hz
               << std::endl;
            OrinHealthChecker::StandByController::updateReason(ss.str(), "sw");
            topic_status_msg.ERROR_LEVEL = orin_healthchecker::ErrorLevel::ERROR;
            msg.topic_status.push_back (topic_status_msg);
            continue;
        }

        if (topic_stauts.warning_hz > freq) {
            OrinHealthChecker::StandByController::is_sw_pass = false;
            std::stringstream ss;
            ss << "[sw component] node: " << topic_stauts.node_name
               << "topic: " << topic_stauts.topic_name
               << "actual rate " << freq 
               << "is lower than topic warning hz" << topic_stauts.warning_hz
               << std::endl;
            OrinHealthChecker::StandByController::updateReason(ss.str(), "sw");
            topic_status_msg.ERROR_LEVEL = orin_healthchecker::ErrorLevel::WARNING;
            msg.topic_status.push_back (topic_status_msg);
            continue;
        }

        OrinHealthChecker::StandByController::is_sw_pass = true;
        topic_status_msg.ERROR_LEVEL = orin_healthchecker::ErrorLevel::OK;
    }
    return msg;
}

bool SwReporter::checkStatusMap () {
    /*
     *  check if topic_status_map is filled.
     */
    for (auto& [topic, freq] : topic_status_map_) {
        if (freq == -1) {
            return false;
        }
    }
    return true;
}

void SwReporter::pubSwStatus () {
    auto now = std::chrono::duration_cast<std::chrono::seconds> (
    std::chrono::system_clock::now ().time_since_epoch ())
               .count ();

    /* if not all status are not set, wait 500ms */
    if (!checkStatusMap ()) {
        std::this_thread::sleep_for (std::chrono::seconds (2));
    }

    /* all topics are setted */
    std::lock_guard<std::mutex> lg (lock);
    sw_pub_.publish (getRosMsg ());

    /* reset flag when publish is finished */
    for (auto& [_, flag] : topic_status_map_) {
        flag = -1.0;
    }
    return;
}

void SwReporter::updateTopicStatusMap (TopicStatus topic_status, float actual_rate) {
    std::lock_guard<std::mutex> lg (lock);
    topic_status_map_[topic_status] = actual_rate;
    return;
}

void SwReporter::updateNodeStatusMap (NodeStatus node_status, bool is_existd) {
    std::lock_guard<std::mutex> lg (lock);
    node_status_map_[node_status] = is_existd;
    return;
}


} // namespace OrinHealthChecker