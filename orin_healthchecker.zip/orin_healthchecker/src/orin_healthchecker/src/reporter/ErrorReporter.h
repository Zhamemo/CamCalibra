#pragma once

#include "orin_healthchecker/orinStatus.h"
#include "ros/node_handle.h"
#include "ros/time.h"
#include <ros/ros.h>


namespace OrinHealthChecker {

struct OrinStatusReporter {
    private:
    orin_healthchecker::orinStatus msg;

    public:
    static void pubErrorStatus (const std::string module_name, const std::string& error_msg) {
        static orin_healthchecker::orinStatus msg;

        // internal status
        if (module_name == "sw") {
            msg.module      = "sw";
            msg.ERROR_LEVEL = orin_healthchecker::orinStatus::ERROR;
        }
        if (module_name == "hw") {
            msg.module      = "hw";
            msg.ERROR_LEVEL = orin_healthchecker::orinStatus::FATAL_ERROR;
        }
        if (module_name == "file") {
            msg.module      = "file";
            msg.ERROR_LEVEL = orin_healthchecker::orinStatus::FATAL_ERROR;
        }
        if (module_name == "sys") {
            msg.module      = "sys";
            msg.ERROR_LEVEL = orin_healthchecker::orinStatus::FATAL_ERROR;
        }
        msg.reason = error_msg;
        msg.ts     = ros::Time::now ();

        static ros::NodeHandle nh;
        static auto pub =
        nh.advertise<orin_healthchecker::orinStatus> ("/orin_status", 1, false);
        pub.publish (msg);
        return;
    };
};

} // namespace OrinHealthChecker
