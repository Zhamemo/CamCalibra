#pragma once

#include "orin_healthchecker/orinSysStatus.h"
#include <memory>
#include <mutex>
#include <ros/ros.h>

#include <components/SysChecker.h>

namespace OrinHealthChecker {

struct SysReporter : public std::enable_shared_from_this<SysReporter> {

    private:
    static std::shared_ptr<SysReporter> instance;
    SysReporter () {
    }
    ros::NodeHandle nh_;
    ros::Publisher sys_pub_;
    orin_healthchecker::orinSysStatus sys_status_;
    std::mutex lock;

    public:
    void initialize (ros::NodeHandle nh);
    void updateSysStatus (OrinHealthChecker::SysCheckResult sys_check_result);
    void pubSysStatus ();

    static std::shared_ptr<SysReporter> getInstance () {
        // Create the singleton instance if it doesn't exist
        if (!instance) {
            instance = std::shared_ptr<SysReporter> (new SysReporter ());
        }
        return instance;
    }
};


} // namespace OrinHealthChecker