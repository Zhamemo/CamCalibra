#pragma once

#include "components/FileChecker.h"
#include "orin_healthchecker/File.h"
#include "orin_healthchecker/orinFileStatus.h"
#include <memory>
#include <mutex>
#include <ros/ros.h>

namespace OrinHealthChecker {

struct FileReporter {

    private:
    static std::shared_ptr<FileReporter> instance;

    FileReporter () {
    }
    ros::NodeHandle nh_;
    ros::Publisher file_pub_;
    std::vector<OrinHealthChecker::File> file_vec_;
    std::mutex lock;

    public:
    void initialize (std::vector<File> file_vec);

    // void save (OrinHealthChecker::File file) {
    //     file_vec.push_back (file);
    //     return;
    // }

    void pubFileStatus ();
    void updateFileStatus (std::string file_name, bool file_status);

    static std::shared_ptr<FileReporter> getInstance () {
        // Create the singleton instance if it doesn't exist
        if (!instance) {
            instance = std::shared_ptr<FileReporter> (new FileReporter ());
        }
        return instance;
    }

    // void updateFileStatus (std::string file_name, bool file_status) {
    //     for (auto& file : file_vec_) {
    //         if (file.file_path != file_name) {
    //             continue;
    //         }
    //         file.status = file_status;
    //         return;
    //     }
    // }
};

} // namespace OrinHealthChecker
