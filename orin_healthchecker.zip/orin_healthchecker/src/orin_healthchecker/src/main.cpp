#include "ConfigParser.h"
#include "components/HWChecker.h"
#include "components/SysChecker.h"
#include "components/all.h"
#include "orin_healthchecker/orinStandBy.h"
#include "reporter/FileReporter.h"
#include "reporter/HwReporter.h"
#include "reporter/SwReporter.h"
#include "reporter/SysReporter.h"
#include "ros/init.h"
#include "ros/node_handle.h"
#include "ros/ros.h"
#include <cstdlib>
#include <memory>
#include <thread>

int main (int argc, char** argv) {
    /* Process Executed As a Ros Node */
    ros::init (argc, argv, "orin_healthchecker_node");

    auto config_parser_ptr = std::make_unique<::OrinHealthChecker::ConfigParser> ();

    /* Ensure Config Environment varaible is setted */
    const char* config_path = nullptr;
    if (config_path = ::std::getenv ("ORIN_CHECKER_CONFIG_PATH")) {
        LOG_F (INFO, "Config_Path: %s", config_path);
    } else if (!config_path) {
        LOG_F (WARNING, "Environemt Variable: [ORIN_CHECKER_CONFIG_PATH] is not setted. ");
        return (EXIT_SUCCESS);
    }
    config_parser_ptr->parse (); // load checkconfig.yaml


    /* Monitor File Components Thread */
    auto file_list = config_parser_ptr->getFileComponent ();
    if (!file_list.empty ()) {
        std::thread file_checker_th =
        std::thread (OrinHealthChecker::FileChecker::monitorFilesExist, file_list);
        file_checker_th.detach ();
    }


    /* Monitor Software Nodes Components Thread */
    auto node_list = config_parser_ptr->getSWComponent ();
    if (!node_list.empty ()) {
        std::thread sw_topic_checker_th = std::thread ([&node_list] () -> void {
            // setup ros callback
            std::vector<ros::Subscriber> ros_sub_vec;

            OrinHealthChecker::SWChecker::initNodesMonitor (node_list, ros_sub_vec);

            // start monitor nodes
            OrinHealthChecker::SWChecker::startMonitorNodes (true);
        });
        sw_topic_checker_th.detach ();
    }


    /* Monitor Hardware Components (GPS || Camera || Lidar)  Thread */
    auto hw_tuple = config_parser_ptr->getHWComponent (); // 0->gps; 1->camera; 2->lidar;
    int hw_tuple_size = std::tuple_size<decltype (hw_tuple)>::value;
    if (hw_tuple_size != 1) {
        std::thread hw_checker_th = std::thread ([&hw_tuple] () -> void {
            OrinHealthChecker::HardwareChecker::periodCheckHWStatus (hw_tuple, 10);
        });
        hw_checker_th.detach ();
    } else {
        LOG_F (ERROR, "error in parsing gps config, see example yml for more details.");
        // exit (EXIT_FAILURE);
    }

    /* Monitor System Components (Time || Disk )  Thread */
    auto sys_config = config_parser_ptr->getSysComponent ();
    if (sys_config.max_disk_threshold != 0) {
        std::thread sys_thread_th = std::thread ([&sys_config] () {
            OrinHealthChecker::SysChecker::periodCheckSysStatus (sys_config, 5);
        });
        sys_thread_th.detach ();
    }

    /* Publishing SW Status */
    std::thread orin_sw_status_pub = std::thread ([] () -> void {
        ros::Rate r (1);
        while (true) {
            OrinHealthChecker::SwReporter::getInstance ()->pubSwStatus ();
            r.sleep ();
        }
    });
    orin_sw_status_pub.detach ();

    /* Publishing HW Status */
    std::thread orin_hw_status_pub = std::thread ([] () -> void {
        ros::Rate r (1);
        while (true) {
            OrinHealthChecker::HwReporter::getInstance ()->pubHwStatus ();
            r.sleep ();
        }
    });
    orin_hw_status_pub.detach ();

    /* Publishing Sys Status */
    std::thread orin_sys_status_pub = std::thread ([] () -> void {
        ros::Rate r (1);
        while (true) {
            OrinHealthChecker::SysReporter::getInstance ()->pubSysStatus ();
            r.sleep ();
        }
    });
    orin_sys_status_pub.detach ();

    /* Publishing File Status */
    std::thread orin_file_status_pub = std::thread ([] () -> void {
        ros::Rate r (1);
        while (true) {
            OrinHealthChecker::FileReporter::getInstance ()->pubFileStatus ();
            r.sleep ();
        }
    });
    orin_file_status_pub.detach ();

    /* Publishing StandBy Message */
    std::thread orin_standby_pub = std::thread ([] () -> void {
        static ros::Rate r (1);
        static ros::NodeHandle nh;
        auto pub =
        nh.advertise<orin_healthchecker::orinStandBy> ("/orin_standby", 1);
        static orin_healthchecker::orinStandBy msg;

        while (true) {
            if (OrinHealthChecker::StandByController::IsPubStandByAllow ()) {
                msg.flag = true;
                msg.reason = "";
                pub.publish (msg);
            } else {
                msg.flag = false;
                msg.reason = OrinHealthChecker::StandByController::getReason();
                pub.publish (msg);
            }
            r.sleep ();
        }
    });
    orin_standby_pub.detach ();

    ros::spin ();
    return 0;
}
