#pragma once

#include "xmlrpcpp/XmlRpc.h"

namespace OrinHealthChecker {
class XmlRpcClient {
    // 1. trigger time sync mode change
};
} // namespace OrinHealthChecker
