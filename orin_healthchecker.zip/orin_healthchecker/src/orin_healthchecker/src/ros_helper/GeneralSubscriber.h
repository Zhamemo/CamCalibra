#include "XmlRpcClient.h"
#include "components/SWChecker.h"
#include "components/all.h"
#include "log/loguru.hpp"
#include "orin_healthchecker/TopicStatus.h"
#include "ros/init.h"
#include "ros/master.h"
#include "xmlrpcpp/XmlRpc.h"
#include <chrono>
#include <istream>
#include <log4cxx/log4cxx.h>
#include <memory>
#include <reporter/SwReporter.h>
#include <ros/ros.h>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <topic_tools/shape_shifter.h>


namespace RosHelper {


void checkRateCallBack (const ros::MessageEvent<topic_tools::ShapeShifter const>& msg_event,
std::tuple<int /*warning rate*/, int /*error rate*/, int /*fatal_error rate*/> check_rate,
const std::string& topic_name) {
    static long last_trigger_time;
    static int count         = 0;
    static int overdue_count = 0;

    static int warning_rate = std::get<0> (check_rate);
    static int error_rate   = std::get<1> (check_rate);
    static int fatal_rate   = std::get<2> (check_rate);

    static std::string pub_node_name = msg_event.getPublisherName ();

    static OrinHealthChecker::TopicStatus topic_status{ .topic_name = topic_name,
        .node_name      = pub_node_name,
        .warning_hz     = warning_rate,
        .error_hz       = error_rate,
        .fatal_error_hz = fatal_rate };


    if (count == 0) {
        count++;
        last_trigger_time = msg_event.getReceiptTime ().toNSec ();
        return;
    }

    auto cur_trigger_time = msg_event.getReceiptTime ().toNSec ();
    auto time_diff    = (int)((cur_trigger_time - last_trigger_time) / 1000000);
    last_trigger_time = cur_trigger_time;

    float frequncy = 1000 / time_diff;

    /* Update Sw Reporter Map */
    OrinHealthChecker::SwReporter::getInstance ()->updateTopicStatusMap (
    topic_status, frequncy);

    return;
}

ros::Subscriber subscribe (const std::string& node_name,
const std::string& topic,
std::tuple<int, int, int> check_rate) {
    LOG_F (INFO, "Subscribing to %s", topic.c_str ());

    ros::NodeHandle nh;
    // boost::shared_ptr<ros::Subscriber> sub (boost::make_shared<ros::Subscriber> ());

    ros::SubscribeOptions ops;
    ops.topic      = topic;
    ops.queue_size = 100;
    ops.md5sum     = ros::message_traits::md5sum<topic_tools::ShapeShifter> ();
    ops.datatype = ros::message_traits::datatype<topic_tools::ShapeShifter> ();

    LOG_F (INFO, "produced period timer: [%s].", topic.c_str ());
    ops.helper =
    boost::make_shared<ros::SubscriptionCallbackHelperT<const ros::MessageEvent<topic_tools::ShapeShifter const>&>> (
    boost::bind (&checkRateCallBack, boost::placeholders::_1, check_rate, topic));
    auto sub = nh.subscribe (ops);
    return sub;
}

// check node exist
bool lookupRosNode (std::string& node_name) {
    static const std::string& master_url = ros::master::getURI ();
    static const std::string caller_id   = "/orin_healthchecker_node";

    // master_url.substr (master_url.find (':', 1), std::string::npos);
    static const std::string& ros_master_url = [&] () {
        auto f                 = master_url.rfind ("/");
        auto e                 = master_url.rfind (":");
        int len                = e - f;
        std::string output_str = master_url.substr (f + 1, len - 1);
        return output_str;
    }();
    static int ros_master_port = ros::master::getPort ();

    static XmlRpc::XmlRpcClient client =
    XmlRpc::XmlRpcClient (ros_master_url.c_str (), ros_master_port);

    static XmlRpc::XmlRpcValue args, res;

    args[0] = caller_id;
    args[1] = node_name;

    if (client.execute ("lookupNode", args, res)) {
        if (res.size () != 3) {
            LOG_F (ERROR, "error in calling rpc:lookupNode method");
            throw std::runtime_error ("error in calling rpc:lookupNode method");
        }

        int res_code            = res[0];
        std::string& status_msg = res[1];
        if (res_code != 1) {
            OrinHealthChecker::StandByController::is_sw_pass = false;
            std::stringstream ss;
            ss << "ros_node: " << node_name << " is not existed !, status_msg:  " << status_msg;
            OrinHealthChecker::StandByController::updateReason(ss.str(), "sw");
            LOG_F (ERROR, ss.str ().c_str ());
            OrinHealthChecker::SwReporter::getInstance ()->updateNodeStatusMap (
            node_name, false);
            return false;
        }
        OrinHealthChecker::SwReporter::getInstance ()->updateNodeStatusMap (
        node_name, true);
        OrinHealthChecker::StandByController::is_sw_pass = true;
        return true;

    } else {
        LOG_F (ERROR, "error in calling rpc: lookupNode method, rosmasteris not found.");
        // throw std::runtime_error ("error in calling rpc:lookupNode method");
    }
    return false;
}

// check topic exist
bool lookupRosTopics (const std::string& node_name,
const std::string& topic_name,
const OrinHealthChecker::Node::CheckRate rate) {
    static const std::string& master_url = ros::master::getURI ();
    static const std::string caller_id   = "/orin_healthchecker_node";

    // master_url.substr (master_url.find (':', 1), std::string::npos);
    static const std::string& ros_master_url = [&] () {
        auto f                 = master_url.rfind ("/");
        auto e                 = master_url.rfind (":");
        int len                = e - f;
        std::string output_str = master_url.substr (f + 1, len - 1);
        return output_str;
    }();
    static int ros_master_port = ros::master::getPort ();

    static XmlRpc::XmlRpcClient client =
    XmlRpc::XmlRpcClient (ros_master_url.c_str (), ros_master_port);

    static XmlRpc::XmlRpcValue args, res;

    args[0] = caller_id;
    args[1] = "";

    if (client.execute ("getPublishedTopics", args, res)) {
        if (res.size () != 3) {
            LOG_F (ERROR, "error in calling rpc:lookupNode method");
            throw std::runtime_error ("error in calling rpc:lookupNode method");
        }

        int res_code = res[0];
        if (res_code != 1) {
            return false;
        }

        std::string& status_msg = res[1];
        auto&& sys_state        = res[2];
        for (int index = 0; index < sys_state.size (); index++) {
            std::string existed_topic_name = sys_state[index][0];

            if (topic_name == existed_topic_name) {
                OrinHealthChecker::StandByController::is_sw_pass = true;
                return true;
            }
        }

        std::stringstream ss;
        ss << "unable to find topic name " << topic_name << ", plz check configuration";
        LOG_F (ERROR, ss.str ().c_str ());

        OrinHealthChecker::StandByController::is_sw_pass = false;
        OrinHealthChecker::StandByController::updateReason(ss.str(), "sw");

        // assmble topic status
        OrinHealthChecker::TopicStatus topic_status (topic_name, node_name,
        std::get<0> (rate), std::get<1> (rate), std::get<2> (rate));
        OrinHealthChecker::SwReporter::getInstance ()->updateTopicStatusMap (
        topic_status, -1);
        return false;

    } else {
        LOG_F (ERROR, "error in calling rpc: lookupTopics method, rosmasteris not found.");
        // throw std::runtime_error ("error in calling rpc:lookupNode method");
    }
    return true;
}


void lookupRosNodeVec (const std::string& node_name, bool start_monitor) {
    static std::vector<std::string> node_vec;

    if (node_name.size () > 0) {
        LOG_F (INFO, "sw component monitor node: [%s]", node_name.c_str ());
        node_vec.push_back (node_name);
    }

    if (start_monitor) {
        while (true) {
            // LOG_F (INFO, "-1");
            for (auto& node_name : node_vec) {
                RosHelper::lookupRosNode (node_name);
            }
            // ros::spinOnce ();
            // std::cout << "spinning finished..." << std::endl;
            std::this_thread::sleep_for (std::chrono::milliseconds (100));
        }
    }
}
} // namespace RosHelper
