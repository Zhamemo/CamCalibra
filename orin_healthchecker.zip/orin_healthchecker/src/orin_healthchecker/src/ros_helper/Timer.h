#pragma once

#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include "log/loguru.hpp"
#include "ros/init.h"
#include "ros/rate.h"
#include <ros/ros.h>
#include <thread>


namespace RosHelper {

class TopicInfo {
    std::string topic;
    int check_rate;
};

struct TopicErrorReporter {
    private:
    static std::mutex m_;

    public:
    static const char*
    ReportTopicError (std::string node_name, std::string topic_name, int check_rate, int real_rate) {
        std::lock_guard<std::mutex> lg (m_);
        // TODO
        return nullptr;
    }
};

} // namespace RosHelper