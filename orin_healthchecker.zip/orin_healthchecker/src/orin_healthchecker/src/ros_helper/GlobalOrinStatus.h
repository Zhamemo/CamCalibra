#pragma once

#include "orin_healthchecker/orinStatus.h"
#include <mutex>
#include <shared_mutex>

namespace RosHelper {
struct OrinStatusMsg {
    typedef std::mutex Lock;
    typedef std::unique_lock<Lock> WriteLock;
    typedef std::shared_lock<Lock> ReadLock;

    public:
    static OrinStatusMsg& geinstance () {
        static OrinStatusMsg msg;
        return msg;
    }

    orin_healthchecker::orinStatus get () {
        ReadLock r_lock (lock);
        return msg_;
    }

    void set (orin_healthchecker::orinStatus msg) {
        WriteLock w_lock (lock);
        msg_ = msg;
        return;
    }

    private:
    orin_healthchecker::orinStatus msg_;
    Lock lock;
};
} // namespace RosHelper