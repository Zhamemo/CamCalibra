#pragma once

#include <boost/smart_ptr/shared_ptr.hpp>
#include <ros/ros.h>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

namespace OrinHealthChecker {

struct Node {
    typedef std::string TopicName;
    typedef std::tuple<int /*warning rate*/, int /*error rate*/, int /*fatal error*/> CheckRate;

    std::string name;
    std::unordered_map<TopicName, CheckRate> checkTopics;
};

struct SWChecker {
    static void initNodesMonitor (std::vector<Node> nodes,
    std::vector<ros::Subscriber>& ros_sub_vec);
    static void startMonitorNodes (bool start_flag = false);
};

} // namespace OrinHealthChecker