#pragma once

#include "log/loguru.hpp"
#include <string>
#include <vector>

namespace OrinHealthChecker {

struct Gps {
    std::string serial_port;
    int gps_singal_threshold;
    int sys_time_threshold;
};

struct Camera {
    std::string cam_name;
    std::string dev_name;
    bool status; // 连通状态
};

struct Lidar {
    std::string lidar_name;
    std::string ip;
    bool status;
};


struct HardwareChecker {
    static void checkGpsStatus (Gps gps_config);
    static void checkCpldStatus ();
    static void checkCamStatus (std::vector<Camera> cam_vec);
    static void checkLidarStatus (std::vector<Lidar> cam_vec);
    static void periodCheckHWStatus (std::tuple<OrinHealthChecker::Gps, 
std::vector<OrinHealthChecker::Camera>, 
std::vector<OrinHealthChecker::Lidar>>, int time);
};

} // namespace OrinHealthChecker
