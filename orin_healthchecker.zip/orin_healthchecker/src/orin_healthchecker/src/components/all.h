#pragma once

#include "components/FileChecker.h"
#include "components/HWChecker.h"
#include "components/SWChecker.h"
#include "components/SysChecker.h"

#include <mutex>
#include <string>
#include <atomic>


namespace OrinHealthChecker {
    struct StandByController {
        inline static bool is_sw_pass{true};
        inline static bool is_hw_pass{true};
        inline static bool is_sys_pass{true};
        inline static bool is_file_pass{true};

        inline static std::string hw_reason;
        inline static std::string sw_reason;
        inline static std::string sys_reason;
        inline static std::string file_reason;

        inline static std::mutex sw_reason_lock;
        inline static std::mutex hw_reason_lock;
        inline static std::mutex sys_reason_lock;
        inline static std::mutex file_reason_lock;

        static void updateReason(std::string reason, std::string module) {
            if (module == "sw") {
                std::lock_guard<std::mutex> lg(sw_reason_lock);
                if (!sw_reason.empty()) {
                    sw_reason.clear();
                }
                sw_reason = std::move(reason);
                return;
            }
            
            if (module == "hw") {
                std::lock_guard<std::mutex> lg(hw_reason_lock);
                if (!hw_reason.empty()) {
                    hw_reason.clear();
                }
                hw_reason = std::move(reason);
                return;
            }

            if (module == "sys") {
                std::lock_guard<std::mutex> lg(sys_reason_lock);
                if (!sys_reason.empty()) {
                    sys_reason.clear();
                }
                sys_reason = std::move(reason);
                return;
            }

            if (module == "file") {
                std::lock_guard<std::mutex> lg(file_reason_lock);
                if (!file_reason.empty()) {
                    file_reason.clear();
                }
                file_reason = std::move(reason);
                return;
            }

            return;
        };

        static void resetAllReason() {
            file_reason.clear();
            hw_reason.clear();
            sys_reason.clear();
            sw_reason.clear();
            return;
        }
        
        static std::string getReason()  {
            if (!file_reason.empty()) {
                std::lock_guard<std::mutex> lg(file_reason_lock);
                return file_reason;
            }

            if (!hw_reason.empty()) {
                std::lock_guard<std::mutex> lg(hw_reason_lock);
                return hw_reason;
            }

            if (!sys_reason.empty()) {
                std::lock_guard<std::mutex> lg(sys_reason_lock);
                return sys_reason;
            }

            if (!sw_reason.empty()) {
                std::lock_guard<std::mutex> lg(sw_reason_lock);
                return sw_reason;
            } else {
                return "undefined reason";
            }
        }

        static bool IsPubStandByAllow() {
            return (is_sw_pass & is_hw_pass & is_sys_pass & is_file_pass) ? true : false;
        }
    };
};