#include "components/SysChecker.h"
#include "common/BashHelper.h"
#include "components/all.h"
#include "log/loguru.hpp"
#include "orin_healthchecker/orinSysStatus.h"
#include "reporter/SysReporter.h"
#include "ros/rate.h"
#include <chrono>
#include <string>
#include <thread>
#include <tuple>


namespace OrinHealthChecker {

std::tuple<double, bool> checkSysDiskUsage (int max_disk_threshold) {
    const char* cmd = "df -h ${HOME} | awk 'FNR==2{print$5}' | cut -d '%' -f1";
    std::string cur_disk_usage = OrinHealthChecker::exec (cmd);

    if (std::stod (cur_disk_usage) > max_disk_threshold) {
        std::stringstream ss;
        ss << "system disk usage is %d over than max disk threshold %d", std::stod (cur_disk_usage), max_disk_threshold;
        LOG_F (ERROR, ss.str().c_str());
        OrinHealthChecker::StandByController::updateReason(ss.str(), "sys");
        return std::make_tuple (std::stod (cur_disk_usage), false);
    }

    return std::make_tuple (std::stod (cur_disk_usage), true);
}

std::tuple<double, bool> checkMemUsage (int max_mem_threshold) {
    static long total_mem =
    std::stol (OrinHealthChecker::exec ("free | awk '/^Mem:/{print $2}'"));
    long used_mem =
    std::stol (OrinHealthChecker::exec ("free | awk '/^Mem:/{print $3}'"));

    static double mem_usage = (used_mem * 100) / total_mem;

    if (mem_usage > max_mem_threshold) {
        std::stringstream ss;
        ss << "system mem usage is %f over than max mem threshold %d", mem_usage, max_mem_threshold;
        LOG_F (ERROR, ss.str().c_str());
        OrinHealthChecker::StandByController::updateReason(ss.str(), "sys");
        return std::make_tuple (mem_usage, false);
    }

    return std::make_tuple (mem_usage, true);
}

std::tuple<double, bool> checkCpuUsage (int max_cpu_threshold) {
    const std::string check_cpu_cmd =
    "grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print "
    "usage }'";
    double cpu_usage = std::stod (OrinHealthChecker::exec (check_cpu_cmd.c_str ()));
    if (cpu_usage > max_cpu_threshold) {
        std::stringstream ss;
        ss << "system cpu usage is %f over than max cpu threshold %d", cpu_usage, max_cpu_threshold;
        LOG_F (ERROR, ss.str().c_str());
        OrinHealthChecker::StandByController::updateReason(ss.str(), "sys");
        return std::make_tuple (cpu_usage, false);
    }
    return std::make_tuple (cpu_usage, true);
}

void SysChecker::periodCheckSysStatus (OrinHealthChecker::SysConfig sys_config, int time) {
    while (true) {
        auto [disk_usage, disk_status] = checkSysDiskUsage (sys_config.max_disk_threshold);
        auto [mem_usage, mem_status] = checkMemUsage (sys_config.max_mem_usage);
        auto [cpu_usage, cpu_status] = checkCpuUsage (sys_config.max_cpu_usage);

        SysCheckResult sys_check_result;
        sys_check_result.disk_usage = disk_usage;
        sys_check_result.disk_status = disk_status;
        sys_check_result.mem_usage = mem_usage;
        sys_check_result.mem_status = mem_status;
        sys_check_result.cpu_usage = cpu_usage;
        sys_check_result.cpu_status = cpu_status;

        OrinHealthChecker::StandByController::is_sys_pass = true;
        if (sys_check_result.mem_status == 0 || 
            sys_check_result.mem_status == 0 || 
            sys_check_result.cpu_status == 0  ) {
                OrinHealthChecker::StandByController::is_sys_pass = false;
        }

        OrinHealthChecker::SysReporter::getInstance ()->updateSysStatus(sys_check_result);

        OrinHealthChecker::SysReporter::getInstance ()->pubSysStatus ();

        std::this_thread::sleep_for (std::chrono::seconds (time));
    }
    return;
}

// bool checkTimeSyncSource (std::string sync_source) {
//     if (sync_source == "X86") {
//         /* check connection with x86 */
//         /* check local time service status */

//     } else if (sync_source == "NTP") {
//         /* check network connection */
//     } else if (sync_source == "GPS") {
//         /* check gps status */
//     }
//     return false;
// }

// bool checkSysTimeDiff (int sys_time_threshold) {
//     long long orin_time = [] () {
//         auto now = std::chrono::system_clock::now ();
//         auto epoch_time = std::chrono::duration_cast<std::chrono::milliseconds> (
//         now.time_since_epoch ())
//                           .count ();
//         return epoch_time;
//     }();

//     long long x86_time = [] () {
//         FILE* pipe;
//         const int buffer_size = 256;
//         char buffer[buffer_size];

//         // get x86 system time in milliseconds
//         pipe = popen ("ssh ubuntu@192.168.1.102 date +%s%3H", "r");

//         if (!pipe) {
//             LOG_F (ERROR, "Couldn't start command.");
//         }

//         // Read the output of the command
//         std::string result = "";
//         while (fgets (buffer, buffer_size, pipe) != NULL) {
//             result += buffer;
//         }

//         int return_code = pclose (pipe);
//         if (return_code != 0) {
//             LOG_F (ERROR, "Command failed with return code: %d", return_code);
//         }

//         return std::stoll (result);
//     }();

//     LOG_F (INFO, "x86_time: %d, orin_time: %d", x86_time, orin_time);

//     // calculate time diff
//     int time_diff = abs (orin_time - x86_time);
//     int threshold = sys_time_threshold;

//     if (time_diff > threshold) { // TODO: Gen err
//         return false;
//     }

//     return true;
// }

// void SysChecker::monitorTimeDiff (int maxlatency_ms) {
//     bool monitor_res;
//     while (true) {
//         monitor_res = checkSysTimeDiff (maxlatency_ms);
//         if (!monitor_res) {
//             LOG_F (ERROR, "time sync is failed, over threshold.");
//         }
//         std::this_thread::sleep_for (std::chrono::milliseconds (100));
//     }
//     return;
// }


} // namespace OrinHealthChecker
