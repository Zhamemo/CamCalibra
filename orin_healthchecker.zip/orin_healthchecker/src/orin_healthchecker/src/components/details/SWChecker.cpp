
#include "components/SWChecker.h"
#include "ros_helper/GeneralSubscriber.h"
#include <boost/smart_ptr/shared_ptr.hpp>

namespace OrinHealthChecker {

void SWChecker::initNodesMonitor (std::vector<Node> nodes,
std::vector<ros::Subscriber>& ros_sub_vec) {
    for (const auto& node : nodes) {
        LOG_F (INFO, "[sw component] monitor node: %s", node.name.c_str ());
        RosHelper::lookupRosNodeVec (node.name, false); // 检查 rosnode
        for (auto& [topic, rate] : node.checkTopics) {
            // Verify if Topic Exists
            LOG_F (INFO, "start to lookup topics %s", topic.c_str ());
            bool if_topic_existed = RosHelper::lookupRosTopics (node.name, topic, rate); // 检查 rostopic
            // if topic is not existed
            if (!if_topic_existed) {
                continue;
            }

            auto sub = RosHelper::subscribe (node.name, topic, rate);
            ros_sub_vec.push_back (sub); // 初始化 subscribe
        }
    }
    return;
}

void SWChecker::startMonitorNodes (bool start_flag) {
    if (start_flag) {
        LOG_F (INFO, "start to lookup monitor nodes");
         // Verify if Node Exists
        RosHelper::lookupRosNodeVec ("", true); // 传入空字段方便函数复用
        return;
    } else {
        LOG_F (WARNING, "fail to start to lookup monitor nodes");
        return;
    }
}

} // namespace OrinHealthChecker
