#include "components/FileChecker.h"
#include "components/SysChecker.h"
#include "components/all.h"
#include "log/loguru.hpp"
#include "reporter/FileReporter.h"
#include <iostream>
#include <sstream>
#include <sys/epoll.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <unordered_map>


namespace OrinHealthChecker {

void FileChecker::monitorFilesExist (std::vector<File> file_lists) {
    // 1. create epoll instance
    int epoll_fd = epoll_create1 (0);
    if (epoll_fd == -1) {
        LOG_F (ERROR, "epoll_create1");
        return;
    }

    // no file for monitoring.
    if (file_lists.empty ()) {
        LOG_F (WARNING, "Empty file given for monitoring.");
        return;
    }

    // create watch file lists
    std::unordered_map<int, std::string> watched_files;

    // 2. create inotify instnce and add file for watching
    // int inotify_fd = inotify_init1 (IN_NONBLOCK); //
    int inotify_fd = inotify_init (); //
    if (inotify_fd == -1) {
        LOG_F (ERROR, "inotify_init1");
        return;
    } else {
        LOG_F (INFO, "create inotify_fd: %d", inotify_fd);
    }

    for (const auto& file : file_lists) {
        LOG_F (INFO, "inotify_add_watch add file: %s", file.file_path.c_str ());

        std::string file_name_str = file.file_path;
        const char* file_name     = file_name_str.c_str ();

        int wd = inotify_add_watch (inotify_fd, file_name, IN_DELETE); // Watch for delete events
        if (wd < 0) {
            LOG_F (ERROR, "inotify_add_watch failed for file: %s, plz check if file existed.",
            file_name);
            // close (inotify_fd);
            // close (epoll_fd);
            continue;
        }

        watched_files[wd] = file.file_path;
    }

    struct epoll_event event;
    event.data.fd = inotify_fd;
    event.events  = EPOLLIN;

    if (epoll_ctl (epoll_fd, EPOLL_CTL_ADD, inotify_fd, &event) == -1) {
        LOG_F (ERROR, "epoll_ctl");
        close (inotify_fd);
        close (epoll_fd);
        return;
    }

    const int MAX_EVENTS = file_lists.size (); // Adjust as needed

    struct epoll_event events[MAX_EVENTS];

    while (true) {
        int num_events = epoll_wait (epoll_fd, events, MAX_EVENTS, -1); // 成功，返回准备就绪的事件数; 错误，返回-1

        if (num_events == -1) {
            LOG_F (ERROR, "epoll_wait");
            break;
        }

        for (int i = 0; i < num_events; ++i) {
            if (events[i].data.fd == inotify_fd) {
                char buf[1024];
                ssize_t bytesRead;
                bytesRead = read (inotify_fd, buf, sizeof (buf));

                if (bytesRead == -1) {
                    break;
                }

                struct inotify_event* event =
                reinterpret_cast<struct inotify_event*> (buf);

                int wd                = event->wd;
                std::string file_path = watched_files[wd];
                OrinHealthChecker::StandByController::is_file_pass = false;
                std::stringstream ss;
                ss << "file: [" << file_path << "] is deleted. "; 
                LOG_F (WARNING, ss.str().c_str());
                OrinHealthChecker::StandByController::updateReason(ss.str(), "file");
                OrinHealthChecker::FileReporter::getInstance ()->updateFileStatus (
                file_path, false);
            }
        }
    }

    for (const auto& pair : watched_files) {
        int wd = pair.first;
        inotify_rm_watch (inotify_fd, wd);
    }

    close (inotify_fd);
    close (epoll_fd);

    return;
} // namespace OrinHealthChecker

} // namespace OrinHealthChecker
