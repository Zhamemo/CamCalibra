#include "components/HWChecker.h"
#include "common/BashHelper.h"
#include "components/all.h"
#include "log/loguru.hpp"
#include "reporter/HwReporter.h"

#include <chrono>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <sstream>
#include <string>
#include <thread>
#include <unistd.h>

namespace OrinHealthChecker {

void HardwareChecker::checkGpsStatus (OrinHealthChecker::Gps gps_config) {

    std::string serial_port = gps_config.serial_port;
    int fd = open (serial_port.c_str (), O_RDWR | O_NOCTTY | O_NDELAY);
    fd_set fds;
    FD_ZERO (&fds);
    FD_SET (fd, &fds);
    struct timeval timeout = { gps_config.gps_singal_threshold, 0 };

    int ret = select (fd + 1, &fds, NULL, NULL, &timeout);

    if (ret == -1) {
        OrinHealthChecker::StandByController::is_hw_pass = false;
        std::stringstream ss;
        ss << "[hw component]  select error from serial_port:" << serial_port 
           << ", fd: " << fd;
        LOG_F (ERROR, ss.str().c_str());
        OrinHealthChecker::StandByController::updateReason(ss.str(), "hw");
        return;
        // TODO: Gen error
    }

    if (ret == 0) {
        OrinHealthChecker::StandByController::is_hw_pass = false;
        std::stringstream ss;
        ss << "[hw component] timeout for waiting GPRMC from serial_port: " << serial_port 
           << ", fd: " << fd;
        LOG_F (ERROR, ss.str().c_str());
        OrinHealthChecker::StandByController::updateReason(ss.str(), "hw");
        // TODO: notify orin_sysmanager
        return;
    }

    if (ret == 1) {
        const int buf_size = 100;
        char buf[buf_size];
        int len = read (fd, buf, buf_size);
        if (len <= 0) {
            // std::string GPRMC (buf, len);
            OrinHealthChecker::StandByController::is_hw_pass = false;
            std::stringstream ss;
            ss << "[hw component] GRPMC Statements is empty";
            OrinHealthChecker::StandByController::updateReason(ss.str(), "hw");
            LOG_F (ERROR, ss.str().c_str());
            // continue;
        }
        OrinHealthChecker::StandByController::is_hw_pass = true;
    }
    return;
}

void HardwareChecker::checkCamStatus (std::vector<Camera> cam_vec) {
    for (const auto& cam : cam_vec) {
        const std::string dev_name = cam.dev_name;
        const std::string bash_cmd = "ls " + dev_name; 
        auto res     = OrinHealthChecker::exec (bash_cmd.c_str ());

        auto res_str = std::string(res);
        // remove the last character 
	res_str.pop_back();

        bool is_match{false};

        if (res_str == dev_name) {
           is_match = true;
        } 


        static OrinHealthChecker::Camera cam_ins;
        cam_ins.cam_name = cam.cam_name;
        cam_ins.dev_name = cam.dev_name;
        cam_ins.status   = false;

        if (!is_match) {
            std::stringstream ss;
            ss << "[hw component] not found cam " << cam_ins.cam_name;
            LOG_F(WARNING, ss.str().c_str());  
            OrinHealthChecker::StandByController::is_hw_pass = false;
            OrinHealthChecker::StandByController::updateReason(ss.str(), "hw");
            OrinHealthChecker::HwReporter::getInstance ()->updateCamStatus (
            cam_ins, false);
        } else {
            //LOG_F(INFO, "found cam %s", cam_ins.cam_name.c_str());  
            OrinHealthChecker::StandByController::is_hw_pass = true;
            OrinHealthChecker::HwReporter::getInstance ()->updateCamStatus (
            cam_ins, true);
        }
    }
    return;
}


// ping -c1 -s1 172.19.135.243 | grep -o transmitted
void HardwareChecker::checkLidarStatus (std::vector<Lidar> lidar_vec) {
    for (const auto& lidar : lidar_vec) {
        const std::string ip = lidar.ip;
        const std::string bash_cmd = "ping -c1 -s1 " + ip + " | grep -o transmitted";
        auto res = OrinHealthChecker::exec (bash_cmd.c_str ());

        auto res_str = std::string(res);
        // remove the last character 
	res_str.pop_back();

        bool is_match{false};

        if (res_str == "transmitted") {
           is_match = true;
        } 

        static OrinHealthChecker::Lidar lidar_ins;
        lidar_ins.lidar_name = lidar.lidar_name;
        lidar_ins.ip         = lidar.ip;
        lidar_ins.status     = false;

        if (!is_match) {
            OrinHealthChecker::StandByController::is_hw_pass = false;
            std::stringstream ss;
            ss << "[hw component] not found lidar, lidar_name: " << lidar_ins.lidar_name
               << " , lidar_ip: " << lidar_ins.ip;
            LOG_F(WARNING, ss.str().c_str());  
            OrinHealthChecker::StandByController::updateReason(ss.str(), "hw");
            OrinHealthChecker::HwReporter::getInstance ()->updateLidarStatus (
            lidar_ins, false);
        } else {
            OrinHealthChecker::StandByController::is_hw_pass = true;
            // works fine
            OrinHealthChecker::HwReporter::getInstance ()->updateLidarStatus (
            lidar_ins, true);
        }
    }
    return;
}

void HardwareChecker::periodCheckHWStatus (std::tuple<OrinHealthChecker::Gps, 
std::vector<OrinHealthChecker::Camera>, 
std::vector<OrinHealthChecker::Lidar>> hw_tuple, int time) {
    auto gps_ins = std::get<0> (hw_tuple);
    auto cam_ins = std::get<1> (hw_tuple);
    auto lidar_ins = std::get<2> (hw_tuple);

    while (true) {
        /* Monitor GPS */
        if (gps_ins.gps_singal_threshold != 0) {
            LOG_F (INFO, "Orin Healthchecker start to track GPS status");
            OrinHealthChecker::HardwareChecker::checkGpsStatus (gps_ins);
        }

        /* Monitor Camera */
        if (!cam_ins.empty ()) {
            LOG_F (INFO, "Orin Healthchecker start to track Camera status");
            OrinHealthChecker::HardwareChecker::checkCamStatus (cam_ins);
        }

        /* Monitor Lidar */
        if (!lidar_ins.empty ()) {
            LOG_F (INFO, "Orin Healthchecker start to track Lidar status");
            OrinHealthChecker::HardwareChecker::checkLidarStatus (lidar_ins);
        }
        std::this_thread::sleep_for(std::chrono::seconds(time));
    }
}

} // namespace OrinHealthChecker
