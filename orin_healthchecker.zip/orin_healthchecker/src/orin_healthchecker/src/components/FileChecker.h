#pragma once

#include <string>
#include <vector>


namespace OrinHealthChecker {
struct File {
    std::string file_path;
    bool status;
};

struct FileChecker {
    static void monitorFilesExist (std::vector<File> file_lists);
};

} // namespace OrinHealthChecker