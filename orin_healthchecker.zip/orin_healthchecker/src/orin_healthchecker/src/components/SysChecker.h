#pragma once

#include <string>


namespace OrinHealthChecker {

struct SysConfig {
    int max_disk_threshold{ 0 };
    double max_mem_usage;
    double max_cpu_usage;
    std::string sync_source{ "" };
    int maxlatency_ms{ 0 };
};

struct SysCheckResult {
    double disk_usage;
    bool disk_status;
    double mem_usage;
    bool mem_status;
    double cpu_usage;
    bool cpu_status;
};

struct SysChecker {
    static void monitorTimeDiff (int maxlatency_ms);
    static void periodCheckSysStatus (OrinHealthChecker::SysConfig sys_config, int time);
};


} // namespace OrinHealthChecker