#include "ConfigParser.h"
#include "components/FileChecker.h"
#include "components/HWChecker.h"
#include "components/SWChecker.h"
#include "components/SysChecker.h"
#include "log/loguru.hpp"
#include "reporter/FileReporter.h"
#include "reporter/HwReporter.h"
#include "reporter/SwReporter.h"
#include "reporter/SysReporter.h"
#include "ros/node_handle.h"

#include <cstdlib>
#include <memory>
#include <string>
#include <tuple>
#include <yaml-cpp/exceptions.h>
#include <yaml-cpp/node/node.h>


namespace OrinHealthChecker {
void ConfigParser::parseConfig (std::string& config_path) try {
    LOG_F (INFO, "loading config file: %s", config_path.c_str ());
    YAML::Node root = YAML::LoadFile (config_path);

    auto sw_nodes   = this->parseSWComponent (root);
    auto files_vec  = this->parseFileComponent (root);
    auto hw_vec     = this->parseHWComponent (root);
    auto sys_config = this->parseSysComponent (root);

    nodes_vec_       = sw_nodes;
    files_vec_       = files_vec;
    hw_enenties_vec_ = hw_vec;
    sys_config_      = sys_config;

    return;
} catch (YAML::Exception& e) {
    LOG_F (ERROR, "exception happened. %s", e.what ());
    return;
}


std::vector<Node> ConfigParser::parseSWComponent (YAML::Node root) {
    std::vector<Node> check_nodes;
    std::vector<OrinHealthChecker::TopicStatus> monitor_topics_vec;
    std::vector<OrinHealthChecker::NodeStatus> monitor_nodes_vec;

    if (YAML::Node nodes = root["components"]["software"]["nodes"]) {


        for (const auto& node : nodes) {
            // Construct
            OrinHealthChecker::Node monitor_node;
            std::string nodeName = node["nodename"].as<std::string> ();
            monitor_node.name    = nodeName;
            monitor_nodes_vec.push_back ({ nodeName });

            if (YAML::Node topics_rates = node["topics&rates"]) {
                for (const auto& it : topics_rates) {
                    std::string topic_name = it["topic"].as<std::string> ();
                    int warning_rate       = it["rate"]["warning"].as<int> ();
                    int error_rate         = it["rate"]["error"].as<int> ();
                    int fatal_error_rate = it["rate"]["fatal_error"].as<int> ();
                    OrinHealthChecker::Node::CheckRate rate =
                    std::make_tuple (warning_rate, error_rate, fatal_error_rate);
                    monitor_node.checkTopics[topic_name] = rate;
                    OrinHealthChecker::TopicStatus topic_status (topic_name,
                    nodeName, warning_rate, error_rate, fatal_error_rate);
                    monitor_topics_vec.push_back (topic_status);
                    check_nodes.push_back (monitor_node);
                }
            } else {
                LOG_F (INFO, "add node: %s to monitor", nodeName.c_str());
                check_nodes.push_back (monitor_node);
            }
        }
    } else {
        LOG_F (WARNING, "parsing config error, no software nodes component config found.");
        return check_nodes;
    }

    ros::NodeHandle nh;
    OrinHealthChecker::SwReporter::getInstance ()->initialize (
    nh, monitor_topics_vec, monitor_nodes_vec);
    LOG_F (INFO, "parse sw components completed.");
    return check_nodes;
}

std::tuple<OrinHealthChecker::Gps, std::vector<OrinHealthChecker::Camera>, std::vector<OrinHealthChecker::Lidar>>
ConfigParser::parseHWComponent (YAML::Node root) {
    std::tuple<OrinHealthChecker::Gps, std::vector<OrinHealthChecker::Camera>, std::vector<OrinHealthChecker::Lidar>> hw_enenties;

    /* construct gps entity */
    if (YAML::Node gps_node = root["components"]["hardware"]["gps"]) {
        std::string serial_port = gps_node["serialport"].as<std::string> ();
        int gps_threshold       = gps_node["threshold"].as<int> ();

        OrinHealthChecker::Gps gps_config{ .serial_port = serial_port,
            .gps_singal_threshold                       = gps_threshold };

        std::get<0> (hw_enenties) = gps_config;
        LOG_F (WARNING, "gps config is enabled.");
    } else {
        LOG_F (WARNING, "gps config is not found.");
    }

    /* construct camera entity */
    std::vector<OrinHealthChecker::Camera> cam_entities_vec;
    if (YAML::Node camera_node = root["components"]["hardware"]["camera"]) {
        for (const auto& cam : camera_node) {
            OrinHealthChecker::Camera cam_entity{ .cam_name = cam["name"].as<std::string> (),
                .dev_name = cam["file"].as<std::string> (),
                .status   = false };
            cam_entities_vec.push_back (cam_entity);
        }
        std::get<1> (hw_enenties) = cam_entities_vec;
    } else {
        LOG_F (WARNING, "cam config is not found.");
    }

    /* construct lidar entity */
    std::vector<OrinHealthChecker::Lidar> lidar_entities_vec;
    if (YAML::Node lidar_node = root["components"]["hardware"]["lidar"]) {
        for (const auto& lidar : lidar_node) {
            OrinHealthChecker::Lidar lidar_entity{ .lidar_name =
                                                   lidar["name"].as<std::string> (),
                .ip     = lidar["ip"].as<std::string> (),
                .status = false };
            lidar_entities_vec.push_back (lidar_entity);
        }
        std::get<2> (hw_enenties) = lidar_entities_vec;
    } else {
        LOG_F (WARNING, "lidar config is not found.");
    }

    ros::NodeHandle nh;
    OrinHealthChecker::HwReporter::getInstance ()->initialize (nh, cam_entities_vec, lidar_entities_vec);

    LOG_F (INFO, "parse hw components completed.");
    return hw_enenties;
};

SysConfig ConfigParser::parseSysComponent (YAML::Node root) {
    SysConfig sys_config;

    if (YAML::Node system_config = root["components"]["system"]) {
        int disk_threshold = system_config["disk"]["threshold"].as<int> ();
        std::string sync_source = system_config["time"]["syncsource"].as<std::string> ();
        int maxlatency_ms = system_config["time"]["maxlatency_ms"].as<int> ();
        double cpu_usage = system_config["cpu"]["usage"].as<double> ();
        double mem_usage = system_config["mem"]["usage"].as<double> ();

        std::cout << "disk_threashold: " << disk_threshold 
                  << ", cpu_usage: " << cpu_usage
                  << ", mem_usage: " << mem_usage
                  << ", sync_source: " << sync_source
                  << ", maxlatency_ms: " << maxlatency_ms << std::endl;

        sys_config.sync_source        = sync_source;
        sys_config.max_disk_threshold = disk_threshold;
        sys_config.maxlatency_ms      = maxlatency_ms;
        sys_config.max_cpu_usage      = cpu_usage;
        sys_config.max_mem_usage      = mem_usage;

    } else {
        LOG_F (WARNING, "parsing config error, no file component config found.");
        return sys_config;
        // exit (EXIT_FAILURE);
    }

    ros::NodeHandle nh;
    OrinHealthChecker::SysReporter::getInstance ()->initialize (
    nh);

    LOG_F (INFO, "parse system components completed.");
    return sys_config;
}

std::vector<File> ConfigParser::parseFileComponent (YAML::Node root) {
    std::vector<File> file_list;

    if (YAML::Node files_maps =
        root["components"]["file"]["filelist"]["file&description"]) {
        for (const auto& it : files_maps) {
            OrinHealthChecker::File file;
            std::string file_path = it.first.as<std::string> ();
            file.file_path        = file_path;
            file_list.push_back (file);

            OrinHealthChecker::File file_ins;
            file_ins.file_path = file_path;
            file_ins.status    = true;
            // OrinHealthChecker::FileReporter::getInstance ()->save (file_ins);
        }
    } else {
        LOG_F (WARNING, "parsing config error, no file component config found.");
        return file_list;
        // exit (EXIT_FAILURE);
    }

    ros::NodeHandle nh;
    OrinHealthChecker::FileReporter::getInstance ()->initialize (file_list);

    LOG_F (INFO, "parse file components completed.");
    return file_list;
}


void ConfigParser::parse () noexcept {
    std::string config_file = this->getConfigPath ();
    this->parseConfig (config_file);
    return;
}

std::string ConfigParser::getConfigPath () {
    const char* config_path = std::getenv ("ORIN_CHECKER_CONFIG_PATH");
    return std::string (config_path);
}
} // namespace OrinHealthChecker
