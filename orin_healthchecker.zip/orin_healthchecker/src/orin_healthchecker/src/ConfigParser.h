#pragma once

#include "yaml-cpp/yaml.h"

#include "components/FileChecker.h"
#include "components/HWChecker.h"
#include "components/SWChecker.h"
#include "components/SysChecker.h"
#include "log/loguru.hpp"


namespace OrinHealthChecker {
class ConfigParser {
    public:
    void parse () noexcept;

    std::vector<Node> getSWComponent () {
        return nodes_vec_;
    }

    auto getHWComponent () {
        return hw_enenties_vec_;
    }

    std::vector<File> getFileComponent () {
        return files_vec_;
    }

    SysConfig getSysComponent () {
        return sys_config_;
    }

    private:
    void parseConfig (std::string& config_path);
    std::string getConfigPath ();

    std::vector<Node> parseSWComponent (YAML::Node root);
    std::vector<File> parseFileComponent (YAML::Node root);
    std::tuple<OrinHealthChecker::Gps, std::vector<OrinHealthChecker::Camera>, std::vector<OrinHealthChecker::Lidar>>
    parseHWComponent (YAML::Node root);
    SysConfig parseSysComponent (YAML::Node root);

    private:
    std::vector<Node> nodes_vec_;
    std::vector<File> files_vec_;
    std::tuple<OrinHealthChecker::Gps, std::vector<OrinHealthChecker::Camera>, std::vector<OrinHealthChecker::Lidar>> hw_enenties_vec_;
    SysConfig sys_config_;
};


} // namespace OrinHealthChecker