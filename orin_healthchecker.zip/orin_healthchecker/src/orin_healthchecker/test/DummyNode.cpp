#include <cstdio>
#include <ros/ros.h>

int main (int argc, char** argv) {
    if (argc < 2) {
        printf ("no name given, abort");
        return -1;
    }
    ros::init (argc, argv, argv[1]);
    ROS_INFO ("init rosnode %s", argv[1]);
    ros::spin ();
    return 0;
}