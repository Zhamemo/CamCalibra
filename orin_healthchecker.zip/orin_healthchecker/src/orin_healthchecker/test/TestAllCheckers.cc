#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "ConfigParser.h"
#include "log/loguru.hpp"
#include <cstdlib>
#include <memory>

TEST_CASE ("test_parse_config_file", "[ConfigParser]") {
    auto config_parser_ptr = std::make_unique<::OrinHealthChecker::ConfigParser> ();

    // Set environment varibale first.
    const char* dummy_config_path = "/home/ubuntu/orin_healthchecker/src/"
                                    "orin_healthchecker/config/checkconfig.yml";
    int res = setenv ("ORIN_CHECKER_CONFIG_PATH", dummy_config_path, true);
    if (res < 0) {
        LOG_F (ERROR, "set environment variable failed.");
    } else {
        LOG_F (INFO, "set environment variable successed.");
    }

    // Check env result.
    if (const char* config_path = std::getenv ("ORIN_CHECKER_CONFIG_PATH")) {
        std::cout << "config_path is :" << std::string (config_path) << std::endl;
    }

    config_parser_ptr->parse ();
}
