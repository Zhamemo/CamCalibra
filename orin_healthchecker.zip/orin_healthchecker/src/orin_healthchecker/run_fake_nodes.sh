#!/bin/bash

# ##功能模块启动选择，命名格式： UD_use_节点名字
# ud_obstacle_detection
# lidar_segment_nn_01
# lidar_detect_nn_01
# remote_control_node
# ud_perception_health_checker_node
# road_segmentation_01
# ud_vision_detection
# ud_vision_show_01
# lidar_track_01
# motion_predict_01
# multi_lidar_fusion
# ud_projection_view
# road_edge_extraction
# ud_insvision_detection
# invasion_detection

# #相机驱动模块启动选择
# camera_ros1
# camera_ros2
# camera_ros3
# camera_ros4
# camera_ros5
# camera_ros6
# camera_ros7
# camera_ros8

# ##一经驱动相关
# /ns1/zvision_sdk_node
# /ns2/zvision_sdk_node
# /ns3/zvision_sdk_node
# /ns4/zvision_sdk_node

# declare -a NAME_LIST=("ud_obstacle_detection" "lidar_segment_nn_01" "lidar_detect_nn_01")
declare -a NAME_LIST=("simple_node")

for node_name in ${NAME_LIST[@]}; do
  echo "running fake node: "  $node_name
  rosrun orin_healthchecker dummy_node $node_name &
done