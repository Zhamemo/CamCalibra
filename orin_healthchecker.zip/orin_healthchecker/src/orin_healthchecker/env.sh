#!/usr/bin/env bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

# TEST_CONFIG_FILE_PATH=$(dirname $(realpath $0))/config/checkconfig.yml
TEST_CONFIG_FILE_PATH=$SCRIPT_DIR/config/checkconfig.yml
echo $TEST_CONFIG_FILE_PATH

export ORIN_CHECKER_CONFIG_PATH=${TEST_CONFIG_FILE_PATH}
echo "set env var[ORIN_CHECKER_CONFIG_PATH] to" $TEST_CONFIG_FILE_PATH