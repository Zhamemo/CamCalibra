#include "log/loguru.hpp"
#include "xmlrpcpp/XmlRpc.h"
#include <string>

using namespace XmlRpc;

XmlRpcServer s;

class TimeSyncManager : public XmlRpcServerMethod {
    public:
    TimeSyncManager (XmlRpcServer* s) : XmlRpcServerMethod ("setTimeSync", s) {
    }

    void execute (XmlRpcValue& params, XmlRpcValue& result) {
        // params: GPS, NTP
        int args = params.size ();
        if (args > 1) {
            LOG_F (ERROR, "more than one args is given.");
            result = "failed";
            return;
        }

        if (args == 1) {
            std::string time_sync_mode = params[0];
            if ((time_sync_mode != "GPS") || (time_sync_mode != "NTP")) {
                LOG_F (ERROR, "call failed wrong mode: [%s] given",
                time_sync_mode.c_str ());
                result = "failed";
                return;
            }
            LOG_F (INFO, "received request, trigger time sync mode to %s",
            time_sync_mode.c_str ());
            // Setting Mode
        }
    }
} TimeSyncManager (&s);


int main (int argc, char* argv[]) {
    if (argc != 2) {
        LOG_F (INFO, "Usage: OrinSysManager [serverHost] serverPort\n");
        return -1;
    }
    int port = atoi (argv[argc - 1]); // Last argument

    XmlRpc::setVerbosity (5);

    // Create the server socket on the specified port (and host)
    if (argc == 2) {
        s.bindAndListen (port);
    }

    // Enable introspection
    s.enableIntrospection (true);

    // Wait for requests indefinitely
    s.work (-1.0);

    return 0;
}
