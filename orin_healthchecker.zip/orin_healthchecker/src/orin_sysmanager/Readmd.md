

1. rpc server
2. when received request, trigger method