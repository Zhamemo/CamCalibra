#include "TimeSyncManager.h"
#include "log/loguru.hpp"
#include <array>
#include <cstdlib>
#include <string>


namespace OrinSysManager {

bool TimeSyncManager::changeTimeSyncMode (std::string mode) {
    LOG_F (INFO, "change time sync mode to %s", mode.c_str ());
    if ((mode != "GPS") || (mode != "NTP")) {
        LOG_F (ERROR, "wrong mode called, only accepted GPS or NTP");
        return false;
    }

    if (mode == "GPS") {
        int ret = setTimeSyncToGps ();
        if (!ret) {
            LOG_F (ERROR, "chage time sync mode to GPS failed.");
            return false;
        }
    }

    if (mode == "NTP") {
        int ret = setTimeSyncToNtp ();
        if (!ret) {
            LOG_F (ERROR, "chage time sync mode to NTP failed.");
            return false;
        }
    }

    return true;
}

std::string executShellCmd (const char* cmd) {
    std::array<char, 128> buffer;
    std::string result;
    FILE* pipe = popen (cmd, "r");
    if (!pipe) {
        throw std::runtime_error ("popen() failed");
    }
    while (fgets (buffer.data (), buffer.size (), pipe) != nullptr) {
        result += buffer.data ();
    }
    pclose (pipe);
    return result;
}

std::string checkNtpStatus () {
    const char* cmd     = "timedatectl | grep NTP | awk '{print $NF}'";
    std::string cmd_res = executShellCmd (cmd);
    return cmd_res;
}

bool TimeSyncManager::setTimeSyncToNtp () {
    // 1. check current sys time sync method
    // 2. if it is ntp, than resart ntp server; if it is gps, than shutdown gps-systime chain
    // 3. check if ntp mode
    // 4. check system time diff with ntp server

    // exuecte timedatactl

    std::string cmd_res = checkNtpStatus ();

    if (cmd_res == "active") {
        // ntp server is already started
    }

    if (cmd_res == "inactive") {
        // ntp server is not started

        // check gps server & chrony server

        // use environment variable for check current time sync mode

        // 1.1. check chrony status
        // https://jfearn.fedorapeople.org/fdocs/en-US/Fedora_Draft_Documentation/0.1/html/System_Administrators_Guide/sect-Checking_if_chrony_is_synchronized.html

        // 1.2 check gps server status
        // https://stackoverflow.com/questions/58406854/how-to-chekc-that-the-gpsd-is-running

        //
    }

    return true;
}

bool TimeSyncManager::setTimeSyncToGps () {
    // Execute System Command

    return true;
}
} // namespace OrinSysManager