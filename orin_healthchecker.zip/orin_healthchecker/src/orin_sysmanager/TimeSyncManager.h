#pragma once

#include <string>

namespace OrinSysManager {
class TimeSyncManager {
    static bool changeTimeSyncMode (std::string mode);

    private:
    static bool setTimeSyncToNtp ();
    static bool setTimeSyncToGps ();
};
} // namespace OrinSysManager