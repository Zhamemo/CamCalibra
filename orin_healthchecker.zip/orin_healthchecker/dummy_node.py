import rospy
from std_msgs.msg import String

def simple_node():
    # Initialize the ROS node
    rospy.init_node('simple_node')

    # Create a publisher that publishes messages to the 'my_topic' topic
    pub = rospy.Publisher('my_topic', String, queue_size=10)

    # Set the rate at which the node will run (in Hz)
    rate = rospy.Rate(5)  # 1 Hz

    while not rospy.is_shutdown():
        # Create a message
        msg = String()
        msg.data = 'Hello, ROS!'

        # Publish the message
        pub.publish(msg)

        # Sleep to control the rate
        rate.sleep()

if __name__ == '__main__':
    try:
        simple_node()
    except rospy.ROSInterruptException:
        pass

