// Auto-generated. Do not edit!

// (in-package orin_healthchecker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class orinSysStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.disk_usage = null;
      this.disk_error_level = null;
      this.mem_usage = null;
      this.mem_error_level = null;
      this.cpu_usage = null;
      this.cpu_error_level = null;
    }
    else {
      if (initObj.hasOwnProperty('disk_usage')) {
        this.disk_usage = initObj.disk_usage
      }
      else {
        this.disk_usage = 0.0;
      }
      if (initObj.hasOwnProperty('disk_error_level')) {
        this.disk_error_level = initObj.disk_error_level
      }
      else {
        this.disk_error_level = 0;
      }
      if (initObj.hasOwnProperty('mem_usage')) {
        this.mem_usage = initObj.mem_usage
      }
      else {
        this.mem_usage = 0.0;
      }
      if (initObj.hasOwnProperty('mem_error_level')) {
        this.mem_error_level = initObj.mem_error_level
      }
      else {
        this.mem_error_level = 0;
      }
      if (initObj.hasOwnProperty('cpu_usage')) {
        this.cpu_usage = initObj.cpu_usage
      }
      else {
        this.cpu_usage = 0.0;
      }
      if (initObj.hasOwnProperty('cpu_error_level')) {
        this.cpu_error_level = initObj.cpu_error_level
      }
      else {
        this.cpu_error_level = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type orinSysStatus
    // Serialize message field [disk_usage]
    bufferOffset = _serializer.float64(obj.disk_usage, buffer, bufferOffset);
    // Serialize message field [disk_error_level]
    bufferOffset = _serializer.uint8(obj.disk_error_level, buffer, bufferOffset);
    // Serialize message field [mem_usage]
    bufferOffset = _serializer.float64(obj.mem_usage, buffer, bufferOffset);
    // Serialize message field [mem_error_level]
    bufferOffset = _serializer.uint8(obj.mem_error_level, buffer, bufferOffset);
    // Serialize message field [cpu_usage]
    bufferOffset = _serializer.float64(obj.cpu_usage, buffer, bufferOffset);
    // Serialize message field [cpu_error_level]
    bufferOffset = _serializer.uint8(obj.cpu_error_level, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type orinSysStatus
    let len;
    let data = new orinSysStatus(null);
    // Deserialize message field [disk_usage]
    data.disk_usage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disk_error_level]
    data.disk_error_level = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [mem_usage]
    data.mem_usage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [mem_error_level]
    data.mem_error_level = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [cpu_usage]
    data.cpu_usage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [cpu_error_level]
    data.cpu_error_level = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 27;
  }

  static datatype() {
    // Returns string type for a message object
    return 'orin_healthchecker/orinSysStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f0743ee73dc1d88fb0a4c5d1dfbc95ce';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 disk_usage
    uint8 disk_error_level
    
    float64 mem_usage
    uint8 mem_error_level
    
    float64 cpu_usage
    uint8 cpu_error_level
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new orinSysStatus(null);
    if (msg.disk_usage !== undefined) {
      resolved.disk_usage = msg.disk_usage;
    }
    else {
      resolved.disk_usage = 0.0
    }

    if (msg.disk_error_level !== undefined) {
      resolved.disk_error_level = msg.disk_error_level;
    }
    else {
      resolved.disk_error_level = 0
    }

    if (msg.mem_usage !== undefined) {
      resolved.mem_usage = msg.mem_usage;
    }
    else {
      resolved.mem_usage = 0.0
    }

    if (msg.mem_error_level !== undefined) {
      resolved.mem_error_level = msg.mem_error_level;
    }
    else {
      resolved.mem_error_level = 0
    }

    if (msg.cpu_usage !== undefined) {
      resolved.cpu_usage = msg.cpu_usage;
    }
    else {
      resolved.cpu_usage = 0.0
    }

    if (msg.cpu_error_level !== undefined) {
      resolved.cpu_error_level = msg.cpu_error_level;
    }
    else {
      resolved.cpu_error_level = 0
    }

    return resolved;
    }
};

module.exports = orinSysStatus;
