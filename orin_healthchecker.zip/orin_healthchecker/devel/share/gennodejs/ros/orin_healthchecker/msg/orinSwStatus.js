// Auto-generated. Do not edit!

// (in-package orin_healthchecker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NodeStatus = require('./NodeStatus.js');
let TopicStatus = require('./TopicStatus.js');

//-----------------------------------------------------------

class orinSwStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_status = null;
      this.topic_status = null;
    }
    else {
      if (initObj.hasOwnProperty('node_status')) {
        this.node_status = initObj.node_status
      }
      else {
        this.node_status = [];
      }
      if (initObj.hasOwnProperty('topic_status')) {
        this.topic_status = initObj.topic_status
      }
      else {
        this.topic_status = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type orinSwStatus
    // Serialize message field [node_status]
    // Serialize the length for message field [node_status]
    bufferOffset = _serializer.uint32(obj.node_status.length, buffer, bufferOffset);
    obj.node_status.forEach((val) => {
      bufferOffset = NodeStatus.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [topic_status]
    // Serialize the length for message field [topic_status]
    bufferOffset = _serializer.uint32(obj.topic_status.length, buffer, bufferOffset);
    obj.topic_status.forEach((val) => {
      bufferOffset = TopicStatus.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type orinSwStatus
    let len;
    let data = new orinSwStatus(null);
    // Deserialize message field [node_status]
    // Deserialize array length for message field [node_status]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.node_status = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.node_status[i] = NodeStatus.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [topic_status]
    // Deserialize array length for message field [topic_status]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.topic_status = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.topic_status[i] = TopicStatus.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.node_status.forEach((val) => {
      length += NodeStatus.getMessageSize(val);
    });
    object.topic_status.forEach((val) => {
      length += TopicStatus.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'orin_healthchecker/orinSwStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fcc3d52d2dbd22f4c9a5c84b656bce03';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ##### node_name, status #####
    NodeStatus[] node_status
    TopicStatus[] topic_status
    ================================================================================
    MSG: orin_healthchecker/NodeStatus
    string node_name
    bool status
    ================================================================================
    MSG: orin_healthchecker/TopicStatus
    string node_name
    string topic_name
    int8 topic_hz
    
    uint8 ERROR_LEVEL
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new orinSwStatus(null);
    if (msg.node_status !== undefined) {
      resolved.node_status = new Array(msg.node_status.length);
      for (let i = 0; i < resolved.node_status.length; ++i) {
        resolved.node_status[i] = NodeStatus.Resolve(msg.node_status[i]);
      }
    }
    else {
      resolved.node_status = []
    }

    if (msg.topic_status !== undefined) {
      resolved.topic_status = new Array(msg.topic_status.length);
      for (let i = 0; i < resolved.topic_status.length; ++i) {
        resolved.topic_status[i] = TopicStatus.Resolve(msg.topic_status[i]);
      }
    }
    else {
      resolved.topic_status = []
    }

    return resolved;
    }
};

module.exports = orinSwStatus;
