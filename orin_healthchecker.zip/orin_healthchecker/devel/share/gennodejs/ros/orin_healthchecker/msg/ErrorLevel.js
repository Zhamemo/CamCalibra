// Auto-generated. Do not edit!

// (in-package orin_healthchecker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ErrorLevel {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ErrorLevel
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ErrorLevel
    let len;
    let data = new ErrorLevel(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a message object
    return 'orin_healthchecker/ErrorLevel';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3d45cefeab55f5a34ea98bc124278669';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 FATAL_ERROR=0
    uint8 ERROR=1
    uint8 WARNING=2
    uint8 OK=3
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ErrorLevel(null);
    return resolved;
    }
};

// Constants for message
ErrorLevel.Constants = {
  FATAL_ERROR: 0,
  ERROR: 1,
  WARNING: 2,
  OK: 3,
}

module.exports = ErrorLevel;
