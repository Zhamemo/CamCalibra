// Auto-generated. Do not edit!

// (in-package orin_healthchecker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let File = require('./File.js');

//-----------------------------------------------------------

class orinFileStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.file_statuc_vec = null;
    }
    else {
      if (initObj.hasOwnProperty('file_statuc_vec')) {
        this.file_statuc_vec = initObj.file_statuc_vec
      }
      else {
        this.file_statuc_vec = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type orinFileStatus
    // Serialize message field [file_statuc_vec]
    // Serialize the length for message field [file_statuc_vec]
    bufferOffset = _serializer.uint32(obj.file_statuc_vec.length, buffer, bufferOffset);
    obj.file_statuc_vec.forEach((val) => {
      bufferOffset = File.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type orinFileStatus
    let len;
    let data = new orinFileStatus(null);
    // Deserialize message field [file_statuc_vec]
    // Deserialize array length for message field [file_statuc_vec]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.file_statuc_vec = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.file_statuc_vec[i] = File.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.file_statuc_vec.forEach((val) => {
      length += File.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'orin_healthchecker/orinFileStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e79ce5769f15add84f19b01d2eb147e7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    File[] file_statuc_vec
    
    ================================================================================
    MSG: orin_healthchecker/File
    string file_name
    bool status
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new orinFileStatus(null);
    if (msg.file_statuc_vec !== undefined) {
      resolved.file_statuc_vec = new Array(msg.file_statuc_vec.length);
      for (let i = 0; i < resolved.file_statuc_vec.length; ++i) {
        resolved.file_statuc_vec[i] = File.Resolve(msg.file_statuc_vec[i]);
      }
    }
    else {
      resolved.file_statuc_vec = []
    }

    return resolved;
    }
};

module.exports = orinFileStatus;
