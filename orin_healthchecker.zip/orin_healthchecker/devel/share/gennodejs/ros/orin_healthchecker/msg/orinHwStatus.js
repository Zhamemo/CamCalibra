// Auto-generated. Do not edit!

// (in-package orin_healthchecker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class orinHwStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.perception_cam_status = null;
      this.monitor_cam_status = null;
      this.blind_lidar_status = null;
    }
    else {
      if (initObj.hasOwnProperty('perception_cam_status')) {
        this.perception_cam_status = initObj.perception_cam_status
      }
      else {
        this.perception_cam_status = [];
      }
      if (initObj.hasOwnProperty('monitor_cam_status')) {
        this.monitor_cam_status = initObj.monitor_cam_status
      }
      else {
        this.monitor_cam_status = [];
      }
      if (initObj.hasOwnProperty('blind_lidar_status')) {
        this.blind_lidar_status = initObj.blind_lidar_status
      }
      else {
        this.blind_lidar_status = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type orinHwStatus
    // Serialize message field [perception_cam_status]
    bufferOffset = _arraySerializer.int8(obj.perception_cam_status, buffer, bufferOffset, null);
    // Serialize message field [monitor_cam_status]
    bufferOffset = _arraySerializer.int8(obj.monitor_cam_status, buffer, bufferOffset, null);
    // Serialize message field [blind_lidar_status]
    bufferOffset = _arraySerializer.int8(obj.blind_lidar_status, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type orinHwStatus
    let len;
    let data = new orinHwStatus(null);
    // Deserialize message field [perception_cam_status]
    data.perception_cam_status = _arrayDeserializer.int8(buffer, bufferOffset, null)
    // Deserialize message field [monitor_cam_status]
    data.monitor_cam_status = _arrayDeserializer.int8(buffer, bufferOffset, null)
    // Deserialize message field [blind_lidar_status]
    data.blind_lidar_status = _arrayDeserializer.int8(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.perception_cam_status.length;
    length += object.monitor_cam_status.length;
    length += object.blind_lidar_status.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'orin_healthchecker/orinHwStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f020304c5d843d4d7c98aff8fd74c15c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8[] perception_cam_status #广角相机 index: 0, Front; index: 1, Back; index: 2, Left; index: 3, Right;
    int8[] monitor_cam_status #长焦相机 index: 0, Front; index: 1, Back; index: 2, Left; index: 3, Right;
    int8[] blind_lidar_status #一经雷达 index: 0, Front; index: 1, Back; index: 2, Left; index: 3, Right;
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new orinHwStatus(null);
    if (msg.perception_cam_status !== undefined) {
      resolved.perception_cam_status = msg.perception_cam_status;
    }
    else {
      resolved.perception_cam_status = []
    }

    if (msg.monitor_cam_status !== undefined) {
      resolved.monitor_cam_status = msg.monitor_cam_status;
    }
    else {
      resolved.monitor_cam_status = []
    }

    if (msg.blind_lidar_status !== undefined) {
      resolved.blind_lidar_status = msg.blind_lidar_status;
    }
    else {
      resolved.blind_lidar_status = []
    }

    return resolved;
    }
};

module.exports = orinHwStatus;
