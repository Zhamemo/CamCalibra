// Auto-generated. Do not edit!

// (in-package orin_healthchecker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TopicStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_name = null;
      this.topic_name = null;
      this.topic_hz = null;
      this.ERROR_LEVEL = null;
    }
    else {
      if (initObj.hasOwnProperty('node_name')) {
        this.node_name = initObj.node_name
      }
      else {
        this.node_name = '';
      }
      if (initObj.hasOwnProperty('topic_name')) {
        this.topic_name = initObj.topic_name
      }
      else {
        this.topic_name = '';
      }
      if (initObj.hasOwnProperty('topic_hz')) {
        this.topic_hz = initObj.topic_hz
      }
      else {
        this.topic_hz = 0;
      }
      if (initObj.hasOwnProperty('ERROR_LEVEL')) {
        this.ERROR_LEVEL = initObj.ERROR_LEVEL
      }
      else {
        this.ERROR_LEVEL = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TopicStatus
    // Serialize message field [node_name]
    bufferOffset = _serializer.string(obj.node_name, buffer, bufferOffset);
    // Serialize message field [topic_name]
    bufferOffset = _serializer.string(obj.topic_name, buffer, bufferOffset);
    // Serialize message field [topic_hz]
    bufferOffset = _serializer.int8(obj.topic_hz, buffer, bufferOffset);
    // Serialize message field [ERROR_LEVEL]
    bufferOffset = _serializer.uint8(obj.ERROR_LEVEL, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TopicStatus
    let len;
    let data = new TopicStatus(null);
    // Deserialize message field [node_name]
    data.node_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [topic_name]
    data.topic_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [topic_hz]
    data.topic_hz = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [ERROR_LEVEL]
    data.ERROR_LEVEL = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.node_name.length;
    length += object.topic_name.length;
    return length + 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'orin_healthchecker/TopicStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cf81ddbd45373605103832f0e519ad8e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string node_name
    string topic_name
    int8 topic_hz
    
    uint8 ERROR_LEVEL
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TopicStatus(null);
    if (msg.node_name !== undefined) {
      resolved.node_name = msg.node_name;
    }
    else {
      resolved.node_name = ''
    }

    if (msg.topic_name !== undefined) {
      resolved.topic_name = msg.topic_name;
    }
    else {
      resolved.topic_name = ''
    }

    if (msg.topic_hz !== undefined) {
      resolved.topic_hz = msg.topic_hz;
    }
    else {
      resolved.topic_hz = 0
    }

    if (msg.ERROR_LEVEL !== undefined) {
      resolved.ERROR_LEVEL = msg.ERROR_LEVEL;
    }
    else {
      resolved.ERROR_LEVEL = 0
    }

    return resolved;
    }
};

module.exports = TopicStatus;
