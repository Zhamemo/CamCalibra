#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cmath>

// 生成0到1之间的随机浮点数
double random_double()
{
    return (double)rand() / RAND_MAX;
}

// 生成指定圆范围内的随机点
void generateData(double centerX, double centerY, double radius, double &outX, double &outY)
{
    double theta = random_double() * 2 * M_PI; // 随机角度
    double r = radius * sqrt(random_double()); // 随机半径，使用平方根分布来均匀分布点

    // 极坐标转换为笛卡尔坐标
    outX = centerX + r * cos(theta);
    outY = centerY + r * sin(theta);
}

int main(int argc, char **argv)
{
    const int num = 30;
    std::ofstream fs("/home/ubuntu/Code/Examples/DBSCAN-master/data/test.dat", std::ios::app);
    fs << num << std::endl;

    std::srand(std::time(0)); 
    double center_x = 0.0, center_y = 0.0, radius = 5.0;      
    double x = 0.0, y = 0.0;

    for (int i = 0; i < num; ++i)
    {
        if (i > num / 2)
        {
            center_x = 15.0;
            center_y = 15.0;
        }
        generateData(center_x, center_y, radius, x, y);
        fs << x << ", " << y << ", " << 0.0 << std::endl;
    }
    fs.close();
    return 0;
}