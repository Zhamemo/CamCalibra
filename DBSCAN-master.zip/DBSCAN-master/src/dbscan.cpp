#include "dbscan.h"
#include <iostream>

int DBSCAN::run()
{
    int clusterID = 1;
    vector<Point>::iterator iter;
    for (iter = vpoints_.begin(); iter != vpoints_.end(); ++iter)
    {
        if (iter->clusterID == UNCLASSIFIED)
        {
            if (expandCluster(*iter, clusterID) != FAILURE)
            {
                clusterID += 1;
            }
        }
    }

    return 0;
}

int DBSCAN::expandCluster(Point point, int clusterID)
{
    // 计算领域点，具体存放其在输入点集中的位置索引
    vector<int> clusterSeeds = calculateCluster(point);

    if (clusterSeeds.size() < min_points_)
    {
        point.clusterID = NOISE;
        return FAILURE;
    }
    else
    {
        int index = 0, indexCorePoint = 0;
        vector<int>::iterator iterSeeds;
        // 找到核心点在其领域点(包含自身)中的位置
        for (iterSeeds = clusterSeeds.begin(); iterSeeds != clusterSeeds.end(); ++iterSeeds)
        {
            vpoints_.at(*iterSeeds).clusterID = clusterID;
            if (vpoints_.at(*iterSeeds).x == point.x && vpoints_.at(*iterSeeds).y == point.y && vpoints_.at(*iterSeeds).z == point.z)
            {
                indexCorePoint = index;
            }
            ++index;
        }
        // 排除自身
        clusterSeeds.erase(clusterSeeds.begin() + indexCorePoint);

        for (vector<int>::size_type i = 0, n = clusterSeeds.size(); i < n; ++i)
        {
            vector<int> clusterNeighors = calculateCluster(vpoints_.at(clusterSeeds[i]));
            if (clusterNeighors.size() >= min_points_)
            {
                vector<int>::iterator iterNeighors;
                for (iterNeighors = clusterNeighors.begin(); iterNeighors != clusterNeighors.end(); ++iterNeighors)
                {
                    if (vpoints_.at(*iterNeighors).clusterID == UNCLASSIFIED || vpoints_.at(*iterNeighors).clusterID == NOISE)
                    {
                        if (vpoints_.at(*iterNeighors).clusterID == UNCLASSIFIED)
                        {
                            clusterSeeds.push_back(*iterNeighors);
                            n = clusterSeeds.size();
                        }
                        vpoints_.at(*iterNeighors).clusterID = clusterID;
                    }
                }
            }
        }

        return SUCCESS;
    }
}

vector<int> DBSCAN::calculateCluster(Point point)
{
    int index = 0;
    vector<Point>::iterator iter;
    vector<int> clusterIndex;
    for (iter = vpoints_.begin(); iter != vpoints_.end(); ++iter)
    {
        if (calculateDistance(point, *iter) <= epsilon_)
        {
            clusterIndex.push_back(index);
        }
        index++;
    }
    return clusterIndex;
}

inline double DBSCAN::calculateDistance(const Point &pointCore, const Point &pointTarget)
{
    return pow(pointCore.x - pointTarget.x, 2) + pow(pointCore.y - pointTarget.y, 2) + pow(pointCore.z - pointTarget.z, 2);
}
