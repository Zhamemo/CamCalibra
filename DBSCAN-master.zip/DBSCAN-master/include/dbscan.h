#ifndef DBSCAN_H
#define DBSCAN_H

#include <vector>
#include <cmath>

#define UNCLASSIFIED -1
#define CORE_POINT 1
#define BORDER_POINT 2
#define NOISE -2
#define SUCCESS 0
#define FAILURE -3

using namespace std;

typedef struct Point_
{
    float x, y, z; // X, Y, Z position
    int clusterID; // clustered ID
} Point;

class DBSCAN
{
public:
    DBSCAN(unsigned int minPts, float eps, vector<Point> points)
    {
        min_points_ = minPts;
        epsilon_ = eps;
        vpoints_ = points;
        point_size_ = points.size();
    }
    ~DBSCAN() {}

    int run();

    /**
     * @brief 找到目标点point在epsilon领域内所有点的索引
     *
     * @param point
     * @return vector<int> 
     */
    vector<int> calculateCluster(Point point);
    int expandCluster(Point point, int clusterID);
    inline double calculateDistance(const Point &pointCore, const Point &pointTarget);

    int getTotalPointSize() { return point_size_; }
    int getMinimumClusterSize() { return min_points_; }
    int getEpsilonSize() { return epsilon_; }

public:
    vector<Point> vpoints_;

private:
    unsigned int point_size_;
    unsigned int min_points_;
    float epsilon_;
};

#endif // DBSCAN_H
