import numpy as np
import matplotlib.pyplot as plt

# 读取数据文件，跳过第一行
data = np.loadtxt('/home/ubuntu/Code/Examples/DBSCAN-master/data/test.dat', delimiter=',', skiprows=1)

# 提取x和y坐标
x = data[:, 0]
y = data[:, 1]

# 创建图表
plt.figure(figsize=(10, 6))

# 绘制数据点
plt.scatter(x, y, color='b', marker='o')

# 添加标题和标签
plt.title('Data Visualization from test.dat')
plt.xlabel('X values')
plt.ylabel('Y values')

# 显示图表
plt.show()
