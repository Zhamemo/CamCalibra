#pragma once
#include <ros/ros.h>

#include <mutex>

#include "diagnostic_updater/diagnostic_updater.h"

namespace system_diagnostics {
class SystemDiagnostics {
 public:
  explicit SystemDiagnostics(double period = 2.0);
  ~SystemDiagnostics();
  SystemDiagnostics(const SystemDiagnostics&) = delete;
  SystemDiagnostics& operator=(const SystemDiagnostics&) = delete;

 private:
  void initParam(double period);
  void checkDisk(diagnostic_updater::DiagnosticStatusWrapper& stat);
  void checkMemory(diagnostic_updater::DiagnosticStatusWrapper& stat);
  void checkCPU(diagnostic_updater::DiagnosticStatusWrapper& stat);

 private:
  void checkUsage(const ros::TimerEvent&);

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  ros::Timer timer_;
  std::string node_name_str_;

  double max_disk_usage_{90.0};
  double max_memory_usage_{90.0};
  double max_cpu_usage_{90.0};

  double disk_usage_{0.0};
  double memory_usage_{0.0};
  double cpu_usage_{0.0};

  std::mutex data_mutex_;
};
}  // namespace system_diagnostics