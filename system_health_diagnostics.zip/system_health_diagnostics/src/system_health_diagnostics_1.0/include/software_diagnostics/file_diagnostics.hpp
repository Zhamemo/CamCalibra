#pragma once

#include <mutex>
#include <unordered_map>

#include "diagnostic_updater/diagnostic_updater.h"

namespace software_diagnostics {
class FileDiagnostics {
 public:
  explicit FileDiagnostics(double period = 1.0);
  ~FileDiagnostics();
  FileDiagnostics(const FileDiagnostics&) = delete;
  FileDiagnostics& operator=(const FileDiagnostics&) = delete;

 private:
  void initParam(double period);
  void checkFilesStatus(diagnostic_updater::DiagnosticStatusWrapper& stat,
                        const std::string& file_name);
  void lookupFilesExist(const ros::TimerEvent&);

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  ros::Timer timer_;
  std::vector<std::string> file_list_;
  std::string node_name_str_;

  std::mutex data_mutex_;
  std::unordered_map<std::string, bool> file_status_map_;

  std::vector<std::shared_ptr<diagnostic_updater::FunctionDiagnosticTask>>
      tasks_;  // 保存任务指针，防止被销毁
};
}  // namespace software_diagnostics