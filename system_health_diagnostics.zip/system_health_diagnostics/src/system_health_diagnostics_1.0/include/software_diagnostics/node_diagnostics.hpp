#pragma once

#include <XmlRpcClient.h>
#include <XmlRpcValue.h>
#include <ros/ros.h>

#include <mutex>
#include <unordered_map>

#include "diagnostic_updater/diagnostic_updater.h"

namespace software_diagnostics {
class NodeDiagnostics {
 public:
  explicit NodeDiagnostics(double period = 5.0);
  ~NodeDiagnostics();
  NodeDiagnostics(const NodeDiagnostics&) = delete;
  NodeDiagnostics& operator=(const NodeDiagnostics&) = delete;

 private:
  void initParam(double period);
  void checkNodesStatus(diagnostic_updater::DiagnosticStatusWrapper& stat,
                        const std::string& node_name);

  void lookupRosNodes(const ros::TimerEvent&);
  bool pingNode(const std::string& node_name, int timeout_ms = 200);

  std::unique_ptr<XmlRpc::XmlRpcClient> createRosMasterClient();
  bool resolveNodeUri(const std::string& node_name, std::string& host,
                      int& port);

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  ros::Timer timer_;
  std::vector<std::string> node_list_;
  std::string node_name_str_;

  std::mutex data_mutex_;
  std::unordered_map<std::string, bool> node_status_map_;

  std::vector<std::shared_ptr<diagnostic_updater::FunctionDiagnosticTask>>
      tasks_;  // 保存任务指针，防止被销毁
};
}  // namespace software_diagnostics