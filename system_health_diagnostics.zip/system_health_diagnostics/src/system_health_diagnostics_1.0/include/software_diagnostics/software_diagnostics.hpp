#pragma once

#include "sensor_diagnostics/camera_diagnostics.hpp"
#include "sensor_diagnostics/imu_diagnostics.hpp"
#include "sensor_diagnostics/lidar_diagnostics.hpp"
#include "sensor_diagnostics/odom_diagnostics.hpp"
#include "software_diagnostics/file_diagnostics.hpp"
#include "software_diagnostics/node_diagnostics.hpp"

namespace software_diagnostics {
class SoftwareDiagnostics {
 public:
  SoftwareDiagnostics();
  ~SoftwareDiagnostics() = default;
  SoftwareDiagnostics(const SoftwareDiagnostics&) = delete;
  SoftwareDiagnostics& operator=(const SoftwareDiagnostics&) = delete;

 private:
  void initParam();

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  std::string node_name_str_;

  std::unique_ptr<FileDiagnostics> file_diagnostics_;
  std::unique_ptr<NodeDiagnostics> node_diagnostics_;
  std::vector<std::unique_ptr<sensor_diagnostics::CameraDiagnostics>>
      camera_diagnostics_;
  std::vector<std::unique_ptr<sensor_diagnostics::LidarDiagnostics>>
      lidar_diagnostics_;
  std::unique_ptr<sensor_diagnostics::ImuDiagnostics> imu_diagnostics_;
  std::unique_ptr<sensor_diagnostics::OdomDiagnostics> odom_diagnostics_;
};
}  // namespace software_diagnostics