#pragma once

#include "software_diagnostics/software_diagnostics.hpp"
#include "system_diagnostics/system_diagnostics.hpp"

namespace diagnostic_manager {
class DiagnosticManager {
 public:
  DiagnosticManager();
  ~DiagnosticManager() = default;

  DiagnosticManager(const DiagnosticManager&) = delete;
  DiagnosticManager& operator=(const DiagnosticManager&) = delete;

 public:
  void run();

 private:
  std::string node_name_str_;

  diagnostic_updater::Updater updater_;
  std::unique_ptr<system_diagnostics::SystemDiagnostics> system_diagnostics_;
  std::unique_ptr<software_diagnostics::SoftwareDiagnostics>
      software_diagnostics_;
};
}  // namespace diagnostic_manager