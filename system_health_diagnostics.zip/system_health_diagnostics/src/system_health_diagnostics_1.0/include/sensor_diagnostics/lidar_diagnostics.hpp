#pragma once

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/PointCloud2.h>

#include <atomic>
#include <mutex>

#include "diagnostic_updater/diagnostic_updater.h"
#include "diagnostic_updater/update_functions.h"

namespace sensor_diagnostics {
class LidarDiagnostics {
 public:
  explicit LidarDiagnostics(const std::string& device, double period = 2.0);
  ~LidarDiagnostics();
  LidarDiagnostics(const LidarDiagnostics&) = delete;
  LidarDiagnostics& operator=(const LidarDiagnostics&) = delete;

 private:
  void initParam(double period);
  void checkConnectionStatus(const ros::TimerEvent&);
  void pointCloudCB(const sensor_msgs::LaserScanConstPtr& msg);
  void pointCloudCB(const sensor_msgs::PointCloud2ConstPtr& msg);

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  ros::Subscriber point_cloud_sub_;
  ros::Timer timer_;

  std::string device_;
  std::string dev_ip_;
  std::string topic_name_;
  std::string node_name_str_;

  double min_freq_ = 0.0;
  double max_freq_ = 0.0;
  std::mutex status_mutex_;
  std::atomic<bool> connected_ = false;

  std::unique_ptr<diagnostic_updater::FrequencyStatus> freq_status_;
  std::unique_ptr<diagnostic_updater::TimeStampStatus> stamp_status_;
};
}  // namespace sensor_diagnostics