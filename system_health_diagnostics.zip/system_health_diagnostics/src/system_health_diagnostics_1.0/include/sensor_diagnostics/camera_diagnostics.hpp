#pragma once

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

#include <atomic>
#include <mutex>

#include "diagnostic_updater/diagnostic_updater.h"
#include "diagnostic_updater/update_functions.h"

namespace sensor_diagnostics {
class CameraDiagnostics {
 public:
  explicit CameraDiagnostics(const std::string& device, double period = 2.0);
  ~CameraDiagnostics();
  CameraDiagnostics(const CameraDiagnostics&) = delete;
  CameraDiagnostics& operator=(const CameraDiagnostics&) = delete;

 private:
  void initParam(double period);
  void checkConnectionStatus(const ros::TimerEvent&);
  void pointCloudCB(const sensor_msgs::PointCloud2ConstPtr& msg);

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  ros::Subscriber point_cloud_sub_;
  ros::Timer timer_;

  std::string device_;
  std::vector<std::string> dev_path_;
  std::string topic_name_;
  std::string node_name_str_;

  double min_freq_ = 0.0;
  double max_freq_ = 0.0;
  std::mutex status_mutex_;
  std::atomic<bool> connected_ = false;

  std::unique_ptr<diagnostic_updater::FrequencyStatus> freq_status_;
  std::unique_ptr<diagnostic_updater::TimeStampStatus> stamp_status_;
};
}  // namespace sensor_diagnostics