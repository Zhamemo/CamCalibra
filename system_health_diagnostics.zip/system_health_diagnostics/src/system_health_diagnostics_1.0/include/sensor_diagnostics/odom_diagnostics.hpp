#pragma once

#include <nav_msgs/Odometry.h>
#include <ros/ros.h>

#include <atomic>
#include <mutex>

#include "diagnostic_updater/diagnostic_updater.h"
#include "diagnostic_updater/update_functions.h"

namespace sensor_diagnostics {
class OdomDiagnostics {
 public:
  explicit OdomDiagnostics(const std::string& device);
  ~OdomDiagnostics();
  OdomDiagnostics(const OdomDiagnostics&) = delete;
  OdomDiagnostics& operator=(const OdomDiagnostics&) = delete;

 private:
  void initParam();
  void odomCB(const nav_msgs::Odometry::ConstPtr& msg);

 public:
  void registerTasks(diagnostic_updater::Updater& updater);

 private:
  ros::Subscriber odom_sub_;

  std::string device_;
  std::string dev_path_;
  std::string topic_name_;
  std::string node_name_str_;

  double min_freq_ = 0.0;
  double max_freq_ = 0.0;
  std::mutex status_mutex_;
  std::atomic<bool> connected_ = false;

  std::unique_ptr<diagnostic_updater::FrequencyStatus> freq_status_;
  std::unique_ptr<diagnostic_updater::TimeStampStatus> stamp_status_;
};
}  // namespace sensor_diagnostics