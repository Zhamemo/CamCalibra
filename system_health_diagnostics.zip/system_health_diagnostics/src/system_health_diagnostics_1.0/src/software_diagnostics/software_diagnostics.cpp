#include "software_diagnostics/software_diagnostics.hpp"

namespace software_diagnostics {
SoftwareDiagnostics::SoftwareDiagnostics() { initParam(); }

void SoftwareDiagnostics::initParam() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  file_diagnostics_ = std::make_unique<FileDiagnostics>();
  node_diagnostics_ = std::make_unique<NodeDiagnostics>();

  {
    camera_diagnostics_.clear();
    XmlRpc::XmlRpcValue camera_list;
    if (nh.getParam("cameras", camera_list)) {
      for (int i = 0; i < camera_list.size(); ++i) {
        const std::string camera_name =
            static_cast<std::string>(camera_list[i]);
        camera_diagnostics_.emplace_back(
            std::make_unique<sensor_diagnostics::CameraDiagnostics>(
                camera_name));
      }
    }
  }

  {
    lidar_diagnostics_.clear();
    XmlRpc::XmlRpcValue lidar_list;
    if (nh.getParam("lidars", lidar_list)) {
      for (int i = 0; i < lidar_list.size(); ++i) {
        const std::string lidar_name = static_cast<std::string>(lidar_list[i]);
        lidar_diagnostics_.emplace_back(
            std::make_unique<sensor_diagnostics::LidarDiagnostics>(lidar_name));
      }
    }
  }

  std::string imu = "/imu";
  if (nh.getParam("imus", imu)) {
    imu_diagnostics_ =
        std::make_unique<sensor_diagnostics::ImuDiagnostics>(imu);
  }

  std::string odom = "/odom";
  if (nh.getParam("odoms", odom)) {
    odom_diagnostics_ =
        std::make_unique<sensor_diagnostics::OdomDiagnostics>(odom);
  }
}

void SoftwareDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  file_diagnostics_->registerTasks(updater);
  node_diagnostics_->registerTasks(updater);

  for (const auto& camera_diag : camera_diagnostics_) {
    camera_diag->registerTasks(updater);
  }

  for (const auto& lidar_diag : lidar_diagnostics_) {
    lidar_diag->registerTasks(updater);
  }

  imu_diagnostics_->registerTasks(updater);
  odom_diagnostics_->registerTasks(updater);
  return;
}
}  // namespace software_diagnostics