#include "software_diagnostics/file_diagnostics.hpp"

#include <boost/filesystem.hpp>

namespace software_diagnostics {
FileDiagnostics::FileDiagnostics(double period) { initParam(period); }

FileDiagnostics::~FileDiagnostics() { timer_.stop(); }

void FileDiagnostics::initParam(double period) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  file_list_.clear();
  file_list_.reserve(100);

  nh.param<std::vector<std::string>>("file_list", file_list_,
                                     std::vector<std::string>());
  if (file_list_.empty()) {
    ROS_ERROR("[%s][%s][%d]: file_list is empty.", node_name_str_.c_str(),
              __func__, __LINE__);
  }

  timer_ = nh.createTimer(ros::Duration(period),
                          &FileDiagnostics::lookupFilesExist, this);
  lookupFilesExist(ros::TimerEvent());  // 初始化时立即检查一次文件状态
  return;
}

void FileDiagnostics::checkFilesStatus(
    diagnostic_updater::DiagnosticStatusWrapper& stat,
    const std::string& file_name) {
  bool exist = true;
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    exist = file_status_map_.count(file_name) && file_status_map_.at(file_name);
  }

  if (!exist) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
                 file_name + " does not exist");
  } else {
    stat.summary(diagnostic_msgs::DiagnosticStatus::OK, file_name + " exists");
  }
  stat.add(file_name, exist);
  return;
}

void FileDiagnostics::lookupFilesExist(const ros::TimerEvent&) {
  std::unordered_map<std::string, bool> file_status_map;
  for (const auto& file : file_list_) {
    if (!boost::filesystem::exists(file)) {
      file_status_map[file] = false;
      ROS_ERROR("[%s][%s][%d]: File %s does not exist!", node_name_str_.c_str(),
                __func__, __LINE__, file.c_str());
    } else {
      file_status_map[file] = true;
    }
  }

  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    file_status_map_ = file_status_map;
  }
  return;
}

void FileDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  auto composite_task =
      std::make_shared<diagnostic_updater::CompositeDiagnosticTask>(
          "Files Status");

  tasks_.clear();
  for (const auto& file : file_list_) {
    auto task = std::make_shared<diagnostic_updater::FunctionDiagnosticTask>(
        file, [this, file](diagnostic_updater::DiagnosticStatusWrapper& stat) {
          checkFilesStatus(stat, file);
        });
    composite_task->addTask(task.get());
    tasks_.emplace_back(task);
  }

  updater.add(
      "Files Status",
      [composite_task](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        composite_task->run(stat);
      });
  return;
}
}  // namespace software_diagnostics