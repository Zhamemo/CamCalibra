#include "software_diagnostics/node_diagnostics.hpp"

#include <future>

namespace software_diagnostics {
NodeDiagnostics::NodeDiagnostics(double period) { initParam(period); }

NodeDiagnostics::~NodeDiagnostics() { timer_.stop(); }

void NodeDiagnostics::initParam(double period) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  node_list_.clear();
  node_list_.reserve(100);
  nh.param<std::vector<std::string>>("node_list", node_list_,
                                     std::vector<std::string>());
  if (node_list_.empty()) {
    ROS_ERROR("[%s][%s][%d]: node_list is empty.", node_name_str_.c_str(),
              __func__, __LINE__);
  }

  timer_ = nh.createTimer(ros::Duration(period),
                          &NodeDiagnostics::lookupRosNodes, this);
  lookupRosNodes(ros::TimerEvent());  // 初始化时立即检查一次节点状态
  return;
}

void NodeDiagnostics::checkNodesStatus(
    diagnostic_updater::DiagnosticStatusWrapper& stat,
    const std::string& node_name) {
  bool running = false;
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    running =
        node_status_map_.count(node_name) && node_status_map_.at(node_name);
  }

  if (!running) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
                 node_name + " is not running");
  } else {
    stat.summary(diagnostic_msgs::DiagnosticStatus::OK,
                 node_name + " is running");
  }
  stat.add(node_name, running);
  return;
}

void NodeDiagnostics::lookupRosNodes(const ros::TimerEvent&) {
  auto client = createRosMasterClient();
  XmlRpc::XmlRpcValue args, res;
  args[0] = node_name_str_;

  if (!client->execute("getSystemState", args, res)) {
    ROS_ERROR("[%s][%s][%d]: Failed to call ROS master RPC: getSystemState.",
              node_name_str_.c_str(), __func__, __LINE__);
    return;
  }

  if (res.size() != 3 || (int)res[0] != 1) {
    ROS_ERROR(
        "[%s][%s][%d]: getSystemState failed or malformed: %s",
        node_name_str_.c_str(), __func__, __LINE__,
        res.size() > 1 ? static_cast<std::string>(res[1]).c_str() : "Unknown");
    return;
  }

  auto&& sys_state = res[2];
  std::unordered_map<std::string, bool> node_status_map;
  for (const auto& name : node_list_) {
    node_status_map[name] = false;
  }

  auto process_node_list = [&](const XmlRpc::XmlRpcValue& list) {
    for (int i = 0; i < list.size(); ++i) {
      const auto& topic_info = list[i];
      if (topic_info.size() != 2) continue;
      const auto& nodes = topic_info[1];
      for (int j = 0; j < nodes.size(); ++j) {
        std::string node_name = static_cast<std::string>(nodes[j]);
        auto it = node_status_map.find(node_name);
        if (it != node_status_map.end()) {
          it->second = true;
        }
      }
    }
  };

  process_node_list(sys_state[0]);  // publishers
  process_node_list(sys_state[1]);  // subscribers
  process_node_list(sys_state[2]);  // services

  for (auto& [name, status] : node_status_map) {
    if (!status || !pingNode(name)) {
      ROS_ERROR("[%s][%s][%d]: Node %s is not reachable!",
                node_name_str_.c_str(), __func__, __LINE__, name.c_str());
      status = false;
    }
  }

  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    node_status_map_ = node_status_map;
  }
  return;
}

bool NodeDiagnostics::pingNode(const std::string& node_name, int timeout_ms) {
  std::string host = "";
  int port = 0;
  if (!resolveNodeUri(node_name, host, port)) return false;

  XmlRpc::XmlRpcClient node_client(host.c_str(), port);
  XmlRpc::XmlRpcValue args, res;
  args[0] = ros::this_node::getName();

  auto future = std::async(std::launch::async, [&]() {
    return node_client.execute("getPid", args, res) && (int)res[0] == 1;
  });

  if (future.wait_for(std::chrono::milliseconds(timeout_ms)) ==
      std::future_status::ready) {
    return future.get();
  }
  return false;
}

std::unique_ptr<XmlRpc::XmlRpcClient> NodeDiagnostics::createRosMasterClient() {
  static const std::string& master_url = ros::master::getURI();
  static const std::string& ros_master_host = [&]() {
    auto f = master_url.rfind("/");
    auto e = master_url.rfind(":");
    int len = e - f;
    return master_url.substr(f + 1, len - 1);
  }();

  static int port = ros::master::getPort();
  return std::make_unique<XmlRpc::XmlRpcClient>(ros_master_host.c_str(), port);
}

bool NodeDiagnostics::resolveNodeUri(const std::string& node_name,
                                     std::string& host, int& port) {
  try {
    auto client = createRosMasterClient();
    XmlRpc::XmlRpcValue args, result;
    args[0] = ros::this_node::getName();
    args[1] = node_name;

    if (!client->execute("lookupNode", args, result) ||
        static_cast<int>(result[0]) != 1)
      return false;

    std::string uri = static_cast<std::string>(result[2]);
    auto pos = uri.find(':', 7);
    if (pos == std::string::npos) return false;

    host = uri.substr(7, pos - 7);
    port = std::stoi(uri.substr(pos + 1));
    return true;
  } catch (const std::exception& e) {
    ROS_WARN("[%s][%s][%d]: Exception: %s", node_name_str_.c_str(), __func__,
             __LINE__, e.what());
    return false;
  } catch (...) {
    ROS_WARN("[%s][%s][%d]: Unknown error!", node_name_str_.c_str(), __func__,
             __LINE__);
    return false;
  }
}

void NodeDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  auto composite_task =
      std::make_shared<diagnostic_updater::CompositeDiagnosticTask>(
          "Nodes Status");

  tasks_.clear();
  for (const auto& node_name : node_list_) {
    auto task = std::make_shared<diagnostic_updater::FunctionDiagnosticTask>(
        node_name,
        [this, node_name](diagnostic_updater::DiagnosticStatusWrapper& stat) {
          this->checkNodesStatus(stat, node_name);
        });

    composite_task->addTask(task.get());
    tasks_.emplace_back(task);
  }

  updater.add(
      "Nodes Status",
      [composite_task](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        composite_task->run(stat);
      });
  return;
}
}  // namespace software_diagnostics