#include "diagnostic_manager/diagnostic_manager.hpp"

namespace diagnostic_manager {
DiagnosticManager::DiagnosticManager()
    : updater_(), system_diagnostics_(nullptr), software_diagnostics_(nullptr) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();

  updater_.setHardwareID("System Health Diagnostics");
  system_diagnostics_ =
      std::make_unique<system_diagnostics::SystemDiagnostics>();
  software_diagnostics_ =
      std::make_unique<software_diagnostics::SoftwareDiagnostics>();

  system_diagnostics_->registerTasks(updater_);
  software_diagnostics_->registerTasks(updater_);
}

void DiagnosticManager::run() {
  ros::Rate rate(10);
  while (ros::ok()) {
    ros::spinOnce();
    updater_.update();
    rate.sleep();
  }
  return;
}
}  // namespace diagnostic_manager

int main(int argc, char** argv) {
  ros::init(argc, argv, "system_health_diagnostics_node");
  diagnostic_manager::DiagnosticManager diagnostic_manager;
  diagnostic_manager.run();
  return 0;
}