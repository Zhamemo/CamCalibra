#include "sensor_diagnostics/camera_diagnostics.hpp"

namespace sensor_diagnostics {
CameraDiagnostics::CameraDiagnostics(const std::string& device, double period)
    : device_(device), freq_status_(nullptr), stamp_status_(nullptr) {
  initParam(period);
}

CameraDiagnostics::~CameraDiagnostics() {
  point_cloud_sub_.shutdown();
  timer_.stop();
}

void CameraDiagnostics::initParam(double period) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  double min_stamp_diff = 0.0, max_stamp_diff = 0.0;

  nh.param(device_ + "/dev_path", dev_path_, std::vector<std::string>());
  nh.param(device_ + "/topic_name", topic_name_,
           std::string("/nuwa_1/depth0/points"));
  nh.param(device_ + "/min_freq", min_freq_, 0.0);
  nh.param(device_ + "/max_freq", max_freq_, 30.0);
  nh.param(device_ + "/min_stamp_diff", min_stamp_diff, 0.0);
  nh.param(device_ + "/max_stamp_diff", max_stamp_diff, 1.0);

  auto freq_param =
      diagnostic_updater::FrequencyStatusParam(&min_freq_, &max_freq_);
  freq_status_ =
      std::make_unique<diagnostic_updater::FrequencyStatus>(freq_param);

  auto stamp_param =
      diagnostic_updater::TimeStampStatusParam(min_stamp_diff, max_stamp_diff);
  stamp_status_ =
      std::make_unique<diagnostic_updater::TimeStampStatus>(stamp_param);

  point_cloud_sub_ = nh.subscribe<sensor_msgs::PointCloud2>(
      topic_name_, 100,
      std::bind(&CameraDiagnostics::pointCloudCB, this, std::placeholders::_1));

  timer_ = nh.createTimer(ros::Duration(period),
                          &CameraDiagnostics::checkConnectionStatus, this);
  checkConnectionStatus(ros::TimerEvent());  // 初始化时立即检查一次连接状态
  return;
}

void CameraDiagnostics::checkConnectionStatus(const ros::TimerEvent&) {
  bool connected = true;
  for (const auto path : dev_path_) {
    if (!boost::filesystem::exists(path)) {
      connected = false;
      break;
    }
  }
  connected_.store(connected);
  return;
}

void CameraDiagnostics::pointCloudCB(
    const sensor_msgs::PointCloud2ConstPtr& msg) {
  {
    std::lock_guard<std::mutex> lock(status_mutex_);
    if (freq_status_) freq_status_->tick();
    if (stamp_status_) stamp_status_->tick(msg->header.stamp);
  }
  return;
}

void CameraDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  auto camera_task =
      std::make_shared<diagnostic_updater::CompositeDiagnosticTask>(device_ +
                                                                    " Status");

  // camera_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
  //     "Connection Status",
  //     [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
  //       bool connected = connected_.load();
  //       if (connected) {
  //         stat.summary(diagnostic_msgs::DiagnosticStatus::OK,
  //                      device_ + " connected");
  //       } else {
  //         stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
  //                      device_ + " not found");
  //       }
  //       stat.add(device_, connected);
  //     }));

  camera_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "Frequency Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        std::lock_guard<std::mutex> lock(status_mutex_);
        if (freq_status_) freq_status_->run(stat);
      }));

  camera_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "TimeStamp Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        std::lock_guard<std::mutex> lock(status_mutex_);
        if (stamp_status_) stamp_status_->run(stat);
      }));

  updater.add(device_ + " Status",
              [camera_task](diagnostic_updater::DiagnosticStatusWrapper& stat) {
                camera_task->run(stat);
              });
  return;
}
}  // namespace sensor_diagnostics