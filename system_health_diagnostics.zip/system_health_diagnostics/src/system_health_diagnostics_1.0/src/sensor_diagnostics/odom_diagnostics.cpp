#include "sensor_diagnostics/odom_diagnostics.hpp"

namespace sensor_diagnostics {
OdomDiagnostics::OdomDiagnostics(const std::string& device)
    : device_(device), freq_status_(nullptr), stamp_status_(nullptr) {
  initParam();
}

OdomDiagnostics::~OdomDiagnostics() { odom_sub_.shutdown(); }

void OdomDiagnostics::initParam() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  double min_stamp_diff = 0.0, max_stamp_diff = 0.0;

  nh.param(device_ + "/topic_name", topic_name_, std::string("/odom"));
  nh.param(device_ + "/min_freq", min_freq_, 0.0);
  nh.param(device_ + "/max_freq", max_freq_, 30.0);
  nh.param(device_ + "/min_stamp_diff", min_stamp_diff, 0.0);
  nh.param(device_ + "/max_stamp_diff", max_stamp_diff, 1.0);

  auto freq_param =
      diagnostic_updater::FrequencyStatusParam(&min_freq_, &max_freq_);
  freq_status_ =
      std::make_unique<diagnostic_updater::FrequencyStatus>(freq_param);

  auto stamp_param =
      diagnostic_updater::TimeStampStatusParam(min_stamp_diff, max_stamp_diff);
  stamp_status_ =
      std::make_unique<diagnostic_updater::TimeStampStatus>(stamp_param);

  odom_sub_ = nh.subscribe<nav_msgs::Odometry>(
      topic_name_, 100,
      std::bind(&OdomDiagnostics::odomCB, this, std::placeholders::_1));
}

void OdomDiagnostics::odomCB(const nav_msgs::Odometry::ConstPtr& msg) {
  {
    std::lock_guard<std::mutex> lock(status_mutex_);
    if (freq_status_) freq_status_->tick();
    if (stamp_status_) stamp_status_->tick(msg->header.stamp);
  }
  return;
}

void OdomDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  auto odom_task =
      std::make_shared<diagnostic_updater::CompositeDiagnosticTask>(device_ +
                                                                    " Status");

  odom_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "Frequency Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        std::lock_guard<std::mutex> lock(status_mutex_);
        if (freq_status_) freq_status_->run(stat);
      }));

  odom_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "TimeStamp Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        std::lock_guard<std::mutex> lock(status_mutex_);
        if (stamp_status_) stamp_status_->run(stat);
      }));

  updater.add(device_ + " Status",
              [odom_task](diagnostic_updater::DiagnosticStatusWrapper& stat) {
                odom_task->run(stat);
              });
  return;
}
}  // namespace sensor_diagnostics