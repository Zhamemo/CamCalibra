#include "sensor_diagnostics/lidar_diagnostics.hpp"

#include "common/helper_function.hpp"

namespace sensor_diagnostics {
LidarDiagnostics::LidarDiagnostics(const std::string& device, double period)
    : device_(device), freq_status_(nullptr), stamp_status_(nullptr) {
  initParam(period);
}

LidarDiagnostics::~LidarDiagnostics() {
  point_cloud_sub_.shutdown();
  timer_.stop();
}

void LidarDiagnostics::initParam(double period) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  double min_stamp_diff = 0.0, max_stamp_diff = 0.0;

  nh.param(device_ + "/ip", dev_ip_, std::string("192.168.0.20"));
  nh.param(device_ + "/topic_name", topic_name_, std::string("/scan_2d"));
  nh.param(device_ + "/min_freq", min_freq_, 0.0);
  nh.param(device_ + "/max_freq", max_freq_, 30.0);
  nh.param(device_ + "/min_stamp_diff", min_stamp_diff, 0.0);
  nh.param(device_ + "/max_stamp_diff", max_stamp_diff, 1.0);

  auto freq_param =
      diagnostic_updater::FrequencyStatusParam(&min_freq_, &max_freq_);
  freq_status_ =
      std::make_unique<diagnostic_updater::FrequencyStatus>(freq_param);

  auto stamp_param =
      diagnostic_updater::TimeStampStatusParam(min_stamp_diff, max_stamp_diff);
  stamp_status_ =
      std::make_unique<diagnostic_updater::TimeStampStatus>(stamp_param);

  if (topic_name_ == "/scan_2d") {
    point_cloud_sub_ = nh.subscribe<sensor_msgs::LaserScan>(
        topic_name_, 100, [this](const sensor_msgs::LaserScanConstPtr& msg) {
          pointCloudCB(msg);
        });
  } else if (topic_name_ == "/rslidar_points") {
    point_cloud_sub_ = nh.subscribe<sensor_msgs::PointCloud2>(
        topic_name_, 100, [this](const sensor_msgs::PointCloud2ConstPtr& msg) {
          pointCloudCB(msg);
        });
  }

  timer_ = nh.createTimer(ros::Duration(period),
                          &LidarDiagnostics::checkConnectionStatus, this);
  checkConnectionStatus(ros::TimerEvent());  // 初始化时立即检查一次连接状态
  return;
}

void LidarDiagnostics::checkConnectionStatus(const ros::TimerEvent&) {
  std::string cmd = "ping -c1 -s1 " + dev_ip_ + " | grep -o transmitted";
  std::string result = common::exec(cmd.c_str());
  result.pop_back();
  connected_.store(result == "transmitted" ? true : false);
  return;
}

void LidarDiagnostics::pointCloudCB(const sensor_msgs::LaserScanConstPtr& msg) {
  {
    std::lock_guard<std::mutex> lock(status_mutex_);
    if (freq_status_) freq_status_->tick();
    if (stamp_status_) stamp_status_->tick(msg->header.stamp);
  }
  return;
}

void LidarDiagnostics::pointCloudCB(
    const sensor_msgs::PointCloud2ConstPtr& msg) {
  {
    std::lock_guard<std::mutex> lock(status_mutex_);
    if (freq_status_) freq_status_->tick();
    if (stamp_status_) stamp_status_->tick(msg->header.stamp);
  }
  return;
}

void LidarDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  auto lidar_task =
      std::make_shared<diagnostic_updater::CompositeDiagnosticTask>(device_ +
                                                                    " Status");

  lidar_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "Connection Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        bool connected = connected_.load();
        if (connected) {
          stat.summary(diagnostic_msgs::DiagnosticStatus::OK,
                       device_ + " connected");
        } else {
          stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
                       device_ + " not found");
        }
        stat.add(device_, connected);
      }));

  lidar_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "Frequency Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        std::lock_guard<std::mutex> lock(status_mutex_);
        if (freq_status_) freq_status_->run(stat);
      }));

  lidar_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "TimeStamp Status",
      [this](diagnostic_updater::DiagnosticStatusWrapper& stat) {
        std::lock_guard<std::mutex> lock(status_mutex_);
        if (stamp_status_) stamp_status_->run(stat);
      }));

  updater.add(device_ + " Status",
              [lidar_task](diagnostic_updater::DiagnosticStatusWrapper& stat) {
                lidar_task->run(stat);
              });
  return;
}
}  // namespace sensor_diagnostics