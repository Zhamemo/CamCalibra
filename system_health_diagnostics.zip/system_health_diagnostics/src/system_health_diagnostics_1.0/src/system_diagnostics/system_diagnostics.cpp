#include "system_diagnostics/system_diagnostics.hpp"

#include "common/helper_function.hpp"

namespace system_diagnostics {
SystemDiagnostics::SystemDiagnostics(double period) { initParam(period); }

SystemDiagnostics::~SystemDiagnostics() { timer_.stop(); }

void SystemDiagnostics::initParam(double period) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  nh.param("disk_usage", max_disk_usage_, 90.0);
  nh.param("memory_usage", max_memory_usage_, 90.0);
  nh.param("cpu_usage", max_cpu_usage_, 90.0);

  timer_ = nh.createTimer(ros::Duration(period), &SystemDiagnostics::checkUsage,
                          this);
  checkUsage(ros::TimerEvent());  // 初始化时立即检查一次系统状态
  return;
}

void SystemDiagnostics::checkDisk(
    diagnostic_updater::DiagnosticStatusWrapper& stat) {
  double disk_usage = 0.0;
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    disk_usage = disk_usage_;
  }

  if (disk_usage > max_disk_usage_) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
                 "Disk usage is too high");
  } else if (disk_usage > max_disk_usage_ * 0.8) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::WARN, "Disk usage is high");
  } else {
    stat.summary(diagnostic_msgs::DiagnosticStatus::OK, "Disk usage is normal");
  }
  stat.add("Disk Usage", disk_usage);
  return;
}

void SystemDiagnostics::checkMemory(
    diagnostic_updater::DiagnosticStatusWrapper& stat) {
  double memory_usage = 0.0;
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    memory_usage = memory_usage_;
  }

  if (memory_usage > max_memory_usage_) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
                 "Memory usage is too high");
  } else if (memory_usage > max_memory_usage_ * 0.8) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::WARN,
                 "Memory usage is high");
  } else {
    stat.summary(diagnostic_msgs::DiagnosticStatus::OK,
                 "Memory usage is normal");
  }
  stat.add("Memory Usage", memory_usage);
  return;
}

void SystemDiagnostics::checkCPU(
    diagnostic_updater::DiagnosticStatusWrapper& stat) {
  double cpu_usage = 0.0;
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    cpu_usage = cpu_usage_;
  }

  if (cpu_usage > max_cpu_usage_) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::ERROR,
                 "CPU usage is too high");
  } else if (cpu_usage > max_cpu_usage_ * 0.8) {
    stat.summary(diagnostic_msgs::DiagnosticStatus::WARN, "CPU usage is high");
  } else {
    stat.summary(diagnostic_msgs::DiagnosticStatus::OK, "CPU usage is normal");
  }
  stat.add("CPU Usage", cpu_usage);
  return;
}

void SystemDiagnostics::checkUsage(const ros::TimerEvent&) {
  try {
    // 检查磁盘使用情况
    const std::string check_disk_cmd =
        "df -h ${HOME} | awk 'FNR==2{print$5}' | cut -d '%' -f1";
    const double disk_usage = std::stod(common::exec(check_disk_cmd.c_str()));

    // 检查内存使用情况
    const std::string check_total_memory_cmd = "free | awk '/^Mem:/{print $2}'";
    const std::string check_used_memory_cmd = "free | awk '/^Mem:/{print $3}'";
    const long total_memory =
        std::stol(common::exec(check_total_memory_cmd.c_str()));
    const long used_memory =
        std::stol(common::exec(check_used_memory_cmd.c_str()));
    const double memory_usage =
        static_cast<double>(used_memory) / total_memory * 100;

    // 检查CPU使用情况
    const std::string check_cpu_cmd =
        "grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END "
        "{print "
        "usage }'";
    const double cpu_usage = std::stod(common::exec(check_cpu_cmd.c_str()));

    // ROS_INFO("[%s][%s][%d]: disk_usage: %f; memory_usage: %f; cpu_usage:
    // %f!",
    //          node_name_str_.c_str(), __func__, __LINE__, disk_usage,
    //          memory_usage, cpu_usage);

    {
      std::lock_guard<std::mutex> lock(data_mutex_);
      disk_usage_ = disk_usage;
      memory_usage_ = memory_usage;
      cpu_usage_ = cpu_usage;
    }
  } catch (const std::exception& e) {
    ROS_ERROR("[%s][%s][%d]: Exception in checkUsage: %s!",
              node_name_str_.c_str(), __func__, __LINE__, e.what());
  }
}

void SystemDiagnostics::registerTasks(diagnostic_updater::Updater& updater) {
  auto system_task =
      std::make_shared<diagnostic_updater::CompositeDiagnosticTask>(
          "System Status");

  system_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "Disk Status",
      std::bind(&SystemDiagnostics::checkDisk, this, std::placeholders::_1)));
  system_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "Memory Status",
      std::bind(&SystemDiagnostics::checkMemory, this, std::placeholders::_1)));
  system_task->addTask(new diagnostic_updater::FunctionDiagnosticTask(
      "CPU Status",
      std::bind(&SystemDiagnostics::checkCPU, this, std::placeholders::_1)));

  updater.add("System Status",
              [system_task](diagnostic_updater::DiagnosticStatusWrapper& stat) {
                system_task->run(stat);
              });
  return;
}
}  // namespace system_diagnostics