#include <custom_msgs_srvs/SetHealthPause.h>

#include <diagnostic_aggregator/diagnostic_aggregator.hpp>

namespace system_health_diagnostics {
DiagnosticAggregator::DiagnosticAggregator() { initParm(); }

void DiagnosticAggregator::initParm() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  nh.param("sys_fault_timeout", sys_fault_timeout_, 25.0);
  nh.param("node_topic_fault_timeout", node_topic_fault_timeout_, 15.0);
  nh.param("rgbd_cam_fault_timeout", rgbd_cam_fault_timeout_, 25.0);
  nh.param("lidar_3d_fault_timeout", lidar_3d_fault_timeout_, 25.0);
  nh.param("lidar_2d_fault_timeout", lidar_2d_fault_timeout_, 25.0);
  nh.param("imu_fault_timeout", imu_fault_timeout_, 35.0);
  nh.param("odom_fault_timeout", odom_fault_timeout_, 35.0);
  nh.param("zwj_swj_connection_timeout", zwj_swj_connection_timeout_, 15.0);

  sys_perf_status_sub_ =
      nh.subscribe<custom_msgs_srvs::SystemPerformanceStatus>(
          "/sys_perf_status", 10, &DiagnosticAggregator::getSysPerfStatus,
          this);
  file_status_sub_ = nh.subscribe<custom_msgs_srvs::FileStatusArray>(
      "/file_status", 10, &DiagnosticAggregator::getFileStatus, this);
  nodes_heart_status_sub_ = nh.subscribe<custom_msgs_srvs::NodeHealthStaus>(
      "/node_status", 10, &DiagnosticAggregator::getNodesHeartStatus, this);
  front_rgbd_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/front_rgbd_status", 10, &DiagnosticAggregator::getFrontRgbdStatus,
      this);
  back_rgbd_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/back_rgbd_status", 10, &DiagnosticAggregator::getBackRgbdStatus, this);
  left_rgbd_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/left_rgbd_status", 10, &DiagnosticAggregator::getLeftRgbdStatus, this);
  right_rgbd_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/right_rgbd_status", 10, &DiagnosticAggregator::getRightRgbdStatus,
      this);
  lidar_3d_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/lidar_3d_status", 10, &DiagnosticAggregator::getLidar3dStatus, this);
  lidar_2d_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/lidar_2d_status", 10, &DiagnosticAggregator::getLidar2dStatus, this);
  imu_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/imu_status", 10, &DiagnosticAggregator::getImuStatus, this);
  odom_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/odom_status", 10, &DiagnosticAggregator::getOdomStatus, this);
  zwj_swj_connection_status_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/zwj_swj_connection_status", 10,
      &DiagnosticAggregator::getZwjSwjConnectionStatus, this);
  robot_localization_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_localization_status", 10,
      &DiagnosticAggregator::getRobotLocalizationStatus, this);
  robot_planning_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_planning_status", 10,
      &DiagnosticAggregator::getRobotPlanningStatus, this);
  robot_perception_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_perception_status", 10,
      &DiagnosticAggregator::getRobotPerceptionStatus, this);
  robot_charge_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_charge_status", 10, &DiagnosticAggregator::getRobotChargeStatus,
      this);
  clean_device_sub_ = nh.subscribe<custom_msgs_srvs::SensorStatus>(
      "/clean_device_status", 10, &DiagnosticAggregator::getCleanDeviceStatus,
      this);

  system_status_pub_ = nh.advertise<custom_msgs_srvs::SystemHealthStaus>(
      "/diagnostics", 1, true);

  robot_localization_status_buffer_.reserve(100);
  robot_planning_status_buffer_.reserve(100);
  robot_perception_status_buffer_.reserve(100);
  robot_charge_status_buffer_.reserve(100);
  return;
}

void DiagnosticAggregator::getSysPerfStatus(
    const custom_msgs_srvs::SystemPerformanceStatus::ConstPtr& msg) {
  sys_perf_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getFileStatus(
    const custom_msgs_srvs::FileStatusArray::ConstPtr& msg) {
  file_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getNodesHeartStatus(
    const custom_msgs_srvs::NodeHealthStaus::ConstPtr& msg) {
  node_heart_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getFrontRgbdStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  front_rgbd_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getBackRgbdStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  back_rgbd_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getLeftRgbdStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  left_rgbd_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getRightRgbdStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  right_rgbd_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getLidar3dStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  lidar_3d_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getLidar2dStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  lidar_2d_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getImuStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  imu_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getOdomStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  odom_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getZwjSwjConnectionStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  zwj_swj_connection_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getRobotLocalizationStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  std::lock_guard<std::mutex> lock(robot_localization_status_mutex_);
  robot_localization_status_buffer_.emplace_back(*msg);
  return;
}

void DiagnosticAggregator::getRobotPlanningStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  std::lock_guard<std::mutex> lock(robot_planning_status_mutex_);
  robot_planning_status_buffer_.emplace_back(*msg);
  return;
}

void DiagnosticAggregator::getRobotPerceptionStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  std::lock_guard<std::mutex> lock(robot_perception_status_mutex_);
  robot_perception_status_buffer_.emplace_back(*msg);
  return;
}

void DiagnosticAggregator::getRobotChargeStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  std::lock_guard<std::mutex> lock(robot_charge_status_mutex_);
  robot_charge_status_buffer_.emplace_back(*msg);
  return;
}

void DiagnosticAggregator::getCleanDeviceStatus(
    const custom_msgs_srvs::SensorStatus::ConstPtr& msg) {
  clean_device_status_.Store(*msg);
  return;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processSysPerfStatus() {
  auto msg = sys_perf_status_.Load();
  custom_msgs_srvs::StatusInfo sys_perf_status;
  sys_perf_status.header = msg.header;
  sys_perf_status.module = "sys";
  sys_perf_status.error_msg = "";
  sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  sys_perf_status.error_code = 10000;

  bool happen_error = false;
  if (msg.disk_error_level == 0) {
    sys_perf_status.error_msg.append("disk overload; ");
    happen_error = true;
  }

  if (msg.mem_error_level == 0) {
    sys_perf_status.error_msg.append("mem overload; ");
    happen_error = true;
  }

  if (msg.cpu_error_level == 0) {
    sys_perf_status.error_msg.append("cpu overload; ");
    happen_error = true;
  }

  static ros::Time last_fault_time = ros::Time::now();
  static bool last_sys_fault_active = false;
  if (happen_error) {
    // TODO: 重置系统错误发生时间
    if (!last_sys_fault_active) {
      last_fault_time = ros::Time::now();
      last_sys_fault_active = true;
    }
    sys_perf_status.error_msg.append("#ED0#EV0#ER0#EB002#V1");

    if (checkFaultTimeout(last_fault_time, sys_fault_timeout_)) {
      sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    last_sys_fault_active = false;  // 超时时间内恢复重置
  }
  return sys_perf_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processFileStatus() {
  auto msg = file_status_.Load();
  custom_msgs_srvs::StatusInfo file_status;
  file_status.header = msg.header;
  file_status.module = "file";
  file_status.error_msg = "";
  file_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  file_status.error_code = 10010;

  for (const auto& file : msg.file_status) {
    if (!file.status) {
      file_status.error_msg.append("file missing! #ED0#EV0#ER0#EB002#V1");
      file_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
      break;
    }
  }
  return file_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processNodesHeartStatus() {
  auto msg = node_heart_status_.Load();
  custom_msgs_srvs::StatusInfo node_heart_status;
  node_heart_status.header = msg.header;
  node_heart_status.module = "sw";
  node_heart_status.error_msg = "";
  node_heart_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  node_heart_status.error_code = 10020;

  bool current_node_error_exist = false;
  for (const auto& node : msg.node_status) {
    if (!node.status) {
      current_node_error_exist = true;
      node_heart_status.error_msg.append(
          node.node_name + " is not exist! #ED0#EV0#ER0#EB002#V1");
      break;
    }
  }

  static ros::Time last_node_fault_time = ros::Time::now();
  static bool last_node_fault_active = false;
  if (current_node_error_exist) {
    if (!last_node_fault_active) {
      last_node_fault_time = ros::Time::now();
      last_node_fault_active = true;
    }

    if (checkFaultTimeout(last_node_fault_time, node_topic_fault_timeout_)) {
      node_heart_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      node_heart_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
    node_heart_status.error_code = 10020;
    return node_heart_status;
  } else {
    last_node_fault_active = false;
  }

  bool current_topic_error_exist = false;
  for (const auto& topic : msg.topic_status) {
    if (topic.ERROR_LEVEL == custom_msgs_srvs::StatusInfo::ERROR) {
      current_topic_error_exist = true;
      node_heart_status.error_msg.append(
          topic.topic_name + " frequency is abnormal! #ED0#EV0#ER0#EB002#V1");
      break;
    }
  }

  static ros::Time last_topic_fault_time = ros::Time::now();
  static bool last_topic_fault_active = false;
  if (current_topic_error_exist) {
    if (!last_topic_fault_active) {
      last_topic_fault_time = ros::Time::now();
      last_topic_fault_active = true;
    }

    if (checkFaultTimeout(last_topic_fault_time, node_topic_fault_timeout_)) {
      node_heart_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      node_heart_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
    node_heart_status.error_code = 10021;
  } else {
    last_topic_fault_active = false;
  }
  return node_heart_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processFrontRgbdStatus() {
  auto msg = front_rgbd_status_.Load();
  custom_msgs_srvs::StatusInfo front_rgbd_status;
  front_rgbd_status.header = msg.header;
  front_rgbd_status.module = "hw";
  front_rgbd_status.error_msg = "";
  front_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  front_rgbd_status.error_code = 10100;

  static ros::Time last_fault_time = ros::Time::now();
  static bool front_rgbd_fault_active = false;
  if (msg.state != 0) {
    if (!front_rgbd_fault_active) {
      last_fault_time = ros::Time::now();
      front_rgbd_fault_active = true;
    }

    front_rgbd_status.error_msg =
        "front_rgbd_cam is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, rgbd_cam_fault_timeout_)) {
      front_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      front_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    front_rgbd_fault_active = false;
  }
  return front_rgbd_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processBackRgbdStatus() {
  auto msg = back_rgbd_status_.Load();
  custom_msgs_srvs::StatusInfo back_rgbd_status;
  back_rgbd_status.header = msg.header;
  back_rgbd_status.module = "hw";
  back_rgbd_status.error_msg = "";
  back_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  back_rgbd_status.error_code = 10101;

  static ros::Time last_fault_time = ros::Time::now();
  static bool back_rgbd_fault_active = false;
  if (msg.state != 0) {
    if (!back_rgbd_fault_active) {
      last_fault_time = ros::Time::now();
      back_rgbd_fault_active = true;
    }

    back_rgbd_status.error_msg = "back_rgbd_cam is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, rgbd_cam_fault_timeout_)) {
      back_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      back_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    back_rgbd_fault_active = false;
  }
  return back_rgbd_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processLeftRgbdStatus() {
  auto msg = left_rgbd_status_.Load();
  custom_msgs_srvs::StatusInfo left_rgbd_status;
  left_rgbd_status.header = msg.header;
  left_rgbd_status.module = "hw";
  left_rgbd_status.error_msg = "";
  left_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  left_rgbd_status.error_code = 10102;

  static ros::Time last_fault_time = ros::Time::now();
  static bool left_rgbd_fault_active = false;
  if (msg.state != 0) {
    if (!left_rgbd_fault_active) {
      last_fault_time = ros::Time::now();
      left_rgbd_fault_active = true;
    }

    left_rgbd_status.error_msg = "left_rgbd_cam is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, rgbd_cam_fault_timeout_)) {
      left_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      left_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    left_rgbd_fault_active = false;
  }
  return left_rgbd_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processRightRgbdStatus() {
  auto msg = right_rgbd_status_.Load();
  custom_msgs_srvs::StatusInfo right_rgbd_status;
  right_rgbd_status.header = msg.header;
  right_rgbd_status.module = "hw";
  right_rgbd_status.error_msg = "";
  right_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  right_rgbd_status.error_code = 10103;

  static ros::Time last_fault_time = ros::Time::now();
  static bool right_rgbd_fault_active = false;
  if (msg.state != 0) {
    if (!right_rgbd_fault_active) {
      last_fault_time = ros::Time::now();
      right_rgbd_fault_active = true;
    }

    right_rgbd_status.error_msg =
        "right_rgbd_cam is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, rgbd_cam_fault_timeout_)) {
      right_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      right_rgbd_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    right_rgbd_fault_active = false;
  }
  return right_rgbd_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processLidar3dStatus() {
  auto msg = lidar_3d_status_.Load();
  custom_msgs_srvs::StatusInfo lidar_3d_status;
  lidar_3d_status.header = msg.header;
  lidar_3d_status.module = "hw";
  lidar_3d_status.error_msg = "";
  lidar_3d_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  lidar_3d_status.error_code = 10200;

  static ros::Time last_fault_time = ros::Time::now();
  static bool lidar_3d_fault_active = false;
  if (msg.state != 0) {
    if (!lidar_3d_fault_active) {
      last_fault_time = ros::Time::now();
      lidar_3d_fault_active = true;
    }

    lidar_3d_status.error_msg = "lidar_3d is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, lidar_3d_fault_timeout_)) {
      lidar_3d_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      lidar_3d_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    lidar_3d_fault_active = false;
  }
  return lidar_3d_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processLidar2dStatus() {
  auto msg = lidar_2d_status_.Load();
  custom_msgs_srvs::StatusInfo lidar_2d_status;
  lidar_2d_status.header = msg.header;
  lidar_2d_status.module = "hw";
  lidar_2d_status.error_msg = "";
  lidar_2d_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  lidar_2d_status.error_code = 10300;

  static ros::Time last_fault_time = ros::Time::now();
  static bool lidar_2d_fault_active = false;
  if (msg.state != 0) {
    if (!lidar_2d_fault_active) {
      last_fault_time = ros::Time::now();
      lidar_2d_fault_active = true;
    }

    lidar_2d_status.error_msg = "lidar_2d is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, lidar_2d_fault_timeout_)) {
      lidar_2d_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      lidar_2d_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    lidar_2d_fault_active = false;
  }
  return lidar_2d_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processImuStatus() {
  auto msg = imu_status_.Load();
  custom_msgs_srvs::StatusInfo imu_status;
  imu_status.header = msg.header;
  imu_status.module = "hw";
  imu_status.error_msg = "";
  imu_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  imu_status.error_code = 10400;

  static ros::Time last_fault_time = ros::Time::now();
  static bool imu_fault_active = false;
  if (msg.state != 0) {
    if (!imu_fault_active) {
      last_fault_time = ros::Time::now();
      imu_fault_active = true;
    }

    imu_status.error_msg = "imu is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, imu_fault_timeout_)) {
      imu_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      imu_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    imu_fault_active = false;
  }
  return imu_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processOdomStatus() {
  auto msg = odom_status_.Load();
  custom_msgs_srvs::StatusInfo odom_status;
  odom_status.header = msg.header;
  odom_status.module = "hw";
  odom_status.error_msg = "";
  odom_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  odom_status.error_code = 10500;

  static ros::Time last_fault_time = ros::Time::now();
  static bool odom_fault_active = false;
  if (msg.state != 0) {
    if (!odom_fault_active) {
      last_fault_time = ros::Time::now();
      odom_fault_active = true;
    }

    odom_status.error_msg = "odom is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, odom_fault_timeout_)) {
      odom_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      odom_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    odom_fault_active = false;
  }
  return odom_status;
}

custom_msgs_srvs::StatusInfo
DiagnosticAggregator::processZwjSwjConnectionStatus() {
  auto msg = zwj_swj_connection_status_.Load();
  custom_msgs_srvs::StatusInfo zwj_swj_connection_status;
  zwj_swj_connection_status.header = msg.header;
  zwj_swj_connection_status.module = "sw";
  zwj_swj_connection_status.error_msg = "";
  zwj_swj_connection_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  zwj_swj_connection_status.error_code = 10600;

  static ros::Time last_fault_time = ros::Time::now();
  static bool zwj_swj_connection_fault_active = false;
  if (msg.state != 0) {
    if (!zwj_swj_connection_fault_active) {
      last_fault_time = ros::Time::now();
      zwj_swj_connection_fault_active = true;
    }

    zwj_swj_connection_status.error_msg =
        "zwj_swj connection is Lost! #ED1#EV0#ER4#EB002#V1";
    if (checkFaultTimeout(last_fault_time, zwj_swj_connection_timeout_)) {
      zwj_swj_connection_status.error_level =
          custom_msgs_srvs::StatusInfo::FATAL_ERROR;
    } else {
      zwj_swj_connection_status.error_level =
          custom_msgs_srvs::StatusInfo::ERROR;
    }
  } else {
    zwj_swj_connection_fault_active = false;
  }
  return zwj_swj_connection_status;
}

custom_msgs_srvs::StatusInfo
DiagnosticAggregator::processRobotLocalizationStatus() {
  std::vector<custom_msgs_srvs::StatusInfo> buffer_copy;
  {
    std::lock_guard<std::mutex> lock(robot_localization_status_mutex_);
    buffer_copy = robot_localization_status_buffer_;
    robot_localization_status_buffer_.clear();
  }

  custom_msgs_srvs::StatusInfo robot_localization_status;
  if (buffer_copy.empty()) {
    robot_localization_status.header.stamp = ros::Time::now();
    robot_localization_status.module = "sw";
    robot_localization_status.error_msg = "";
    robot_localization_status.error_level = custom_msgs_srvs::StatusInfo::OK;
    robot_localization_status.error_code = 12000;
    return robot_localization_status;
  }

  robot_localization_status = sort(buffer_copy);
  return robot_localization_status;
}

custom_msgs_srvs::StatusInfo
DiagnosticAggregator::processRobotPlanningStatus() {
  std::vector<custom_msgs_srvs::StatusInfo> buffer_copy;
  {
    std::lock_guard<std::mutex> lock(robot_planning_status_mutex_);
    buffer_copy = robot_planning_status_buffer_;
    robot_planning_status_buffer_.clear();
  }

  custom_msgs_srvs::StatusInfo robot_planning_status;
  if (buffer_copy.empty()) {
    robot_planning_status.header.stamp = ros::Time::now();
    robot_planning_status.module = "sw";
    robot_planning_status.error_msg = "";
    robot_planning_status.error_level = custom_msgs_srvs::StatusInfo::OK;
    robot_planning_status.error_code = 13000;
    return robot_planning_status;
  }

  robot_planning_status = sort(buffer_copy);
  return robot_planning_status;
}

custom_msgs_srvs::StatusInfo
DiagnosticAggregator::processRobotPerceptionStatus() {
  std::vector<custom_msgs_srvs::StatusInfo> buffer_copy;
  {
    std::lock_guard<std::mutex> lock(robot_perception_status_mutex_);
    buffer_copy = robot_perception_status_buffer_;
    robot_perception_status_buffer_.clear();
  }

  custom_msgs_srvs::StatusInfo robot_perception_status;
  if (buffer_copy.empty()) {
    robot_perception_status.header.stamp = ros::Time::now();
    robot_perception_status.module = "sw";
    robot_perception_status.error_msg = "";
    robot_perception_status.error_level = custom_msgs_srvs::StatusInfo::OK;
    robot_perception_status.error_code = 11000;
    return robot_perception_status;
  }

  robot_perception_status = sort(buffer_copy);
  return robot_perception_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processRobotChargeStatus() {
  std::vector<custom_msgs_srvs::StatusInfo> buffer_copy;
  {
    std::lock_guard<std::mutex> lock(robot_charge_status_mutex_);
    buffer_copy = robot_charge_status_buffer_;
    robot_charge_status_buffer_.clear();
  }

  static custom_msgs_srvs::StatusInfo robot_charge_status;
  if (buffer_copy.empty()) {
    if (robot_charge_status.header.stamp.isZero()) {
      robot_charge_status.header.stamp = ros::Time::now();
      robot_charge_status.module = "sw";
      robot_charge_status.error_msg = "";
      robot_charge_status.error_level = custom_msgs_srvs::StatusInfo::OK;
      robot_charge_status.error_code = 14000;
    }
    return robot_charge_status;
  }

  robot_charge_status = sort(buffer_copy);
  return robot_charge_status;
}

custom_msgs_srvs::StatusInfo DiagnosticAggregator::processCleanDeviceStatus() {
  auto msg = clean_device_status_.Load();
  custom_msgs_srvs::StatusInfo clean_device_status;
  clean_device_status.header = msg.header;
  clean_device_status.module = "hw";
  clean_device_status.error_msg = "";
  clean_device_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  clean_device_status.error_code = 15000;
  return clean_device_status;
}

custom_msgs_srvs::SystemHealthStaus::Ptr
DiagnosticAggregator::getSystemStatus() {
  custom_msgs_srvs::SystemHealthStaus system_status;
  system_status.sys_perf = processSysPerfStatus();
  system_status.file = processFileStatus();
  system_status.nodes_heart = processNodesHeartStatus();

  system_status.front_rgbd = processFrontRgbdStatus();
  system_status.back_rgbd = processBackRgbdStatus();
  system_status.left_rgbd = processLeftRgbdStatus();
  system_status.right_rgbd = processRightRgbdStatus();
  system_status.lidar_3d = processLidar3dStatus();
  system_status.lidar_2d = processLidar2dStatus();
  system_status.imu = processImuStatus();
  system_status.odom = processOdomStatus();
  system_status.zwj_swj_connection = processZwjSwjConnectionStatus();

  system_status.robot_localization = processRobotLocalizationStatus();
  system_status.robot_planning = processRobotPlanningStatus();
  system_status.robot_perception = processRobotPerceptionStatus();
  system_status.robot_charge = processRobotChargeStatus();
  system_status.clean_device = processCleanDeviceStatus();

  system_status_pub_.publish(system_status);
  return boost::make_shared<custom_msgs_srvs::SystemHealthStaus>(system_status);
}
}  // namespace system_health_diagnostics