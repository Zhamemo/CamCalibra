#include "diagnostic_analysis/diagnostic_analysis.hpp"

#include <custom_msgs_srvs/SetHealthPause.h>
#include <shm_grace.h>
#include <std_msgs/String.h>

namespace system_health_diagnostics {
DiagnosticAnalysis::DiagnosticAnalysis() { initParm(); }

void DiagnosticAnalysis::initParm() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();

  error_record_pub_ = nh.advertise<custom_msgs_srvs::StatusInfo>(
      "/system_health_state", 1, true);
  robot_pause_client_ =
      nh.serviceClient<custom_msgs_srvs::SetHealthPause>("/set_health_pause");
}

void DiagnosticAnalysis::applyRobotSafetyControl(int mode) {
  static int last_mode = -1;
  if (last_mode == mode) {
    // ROS_INFO("[%s][%s][%d]: Already %d!", node_name_str_.c_str(), __func__,
    //          __LINE__, mode);
    return;
  }
  last_mode = mode;

  switch (mode) {
    case 0:
      ROS_INFO("[%s][%s][%d]: Received the stop command! mode: %d!",
               node_name_str_.c_str(), __func__, __LINE__, mode);
      if (!pauseRobot(true)) {
        Grace::ChassisCmd cmd_vel;
        cmd_vel.command_linear_x = 0.0;
        cmd_vel.command_linear_y = 0.0;
        cmd_vel.command_angular_z = 0.0;
        Grace::send_speed(cmd_vel);
      }
      break;

    case 1:
      ROS_INFO("[%s][%s][%d]: Received the resume command! mode: %d!",
               node_name_str_.c_str(), __func__, __LINE__, mode);
      pauseRobot(false);
      break;

    default:
      ROS_WARN("[%s][%s][%d]: Received an invalid command! mode: %d",
               node_name_str_.c_str(), __func__, __LINE__, mode);
      break;
  }
  return;
}

bool DiagnosticAnalysis::pauseRobot(bool pause) {
  custom_msgs_srvs::SetHealthPause::Request req;
  custom_msgs_srvs::SetHealthPause::Response res;
  req.pause = pause;
  if (!robot_pause_client_.call(req, res)) {
    ROS_ERROR("[%s][%s][%d]: Failed to %s the robot!", node_name_str_.c_str(),
              __func__, __LINE__, pause ? "pause" : "resume");
    return false;
  }
  return true;
}

int DiagnosticAnalysis::compareModulePriority(const std::string& module) {
  if (module == "sys") return 4;
  if (module == "file") return 3;
  if (module == "hw") return 2;
  if (module == "sw") return 1;
  return 0;
}

void DiagnosticAnalysis::updateDiagnosticStatus(
    const custom_msgs_srvs::SystemHealthStaus::Ptr& msg) {
  static custom_msgs_srvs::StatusInfo last_health_status;
  custom_msgs_srvs::StatusInfo cur_health_status;

  // OK = 0，WARNING = 1, ERROR = 2, FATAL_ERROR = 3
  if (last_health_status.error_level == 3) {
    // TODO: 发生过致命错误，则不可恢复
    cur_health_status = last_health_status;
  } else {
    std::vector<custom_msgs_srvs::StatusInfo> infos{
        msg->sys_perf,            // 系统运行
        msg->file,                // 文件状态
        msg->nodes_heart,         // 节点心跳
        msg->front_rgbd,          // 前向深度相机
        msg->back_rgbd,           // 后向深度相机
        msg->left_rgbd,           // 左向深度相机
        msg->right_rgbd,          // 右向深度相机
        msg->lidar_3d,            // 3D雷达
        msg->lidar_2d,            // 2D雷达
        msg->imu,                 // IMU
        msg->odom,                // 里程计
        msg->zwj_swj_connection,  // 中上连接
        msg->robot_localization,  // 定位模块
        msg->robot_planning,      // 规划模块
        msg->robot_perception,    // 感知模块
        msg->robot_charge,        // 充电模块
        msg->clean_device,        // 清洁设备
    };

    std::sort(infos.begin(), infos.end(), [this](const auto& a, const auto& b) {
      // 1. 按错误级别排序 FATAL_ERROR > ERROR > WARNING > OK
      if (a.error_level != b.error_level) {
        return a.error_level > b.error_level;
      }
      // 2. 按模块优先级排序 file > hw > sw > sys
      const int a_priority = compareModulePriority(a.module);
      const int b_priority = compareModulePriority(b.module);
      if (a_priority != b_priority) {
        return a_priority > b_priority;
      }
      // 3. 按错误代码排序
      if (a.error_code != b.error_code) {
        return a.error_code < b.error_code;
      }
      // 4. 按时间排序 记录最新的
      return a.header.stamp > b.header.stamp;
    });

    cur_health_status = infos.front();
    last_health_status = cur_health_status;
  }

  // 发生错误，准备驻车
  static bool is_robot_paused = false;
  if (cur_health_status.error_level > 1) {
    applyRobotSafetyControl(0);
    is_robot_paused = true;
  } else {
    if (is_robot_paused) {
      applyRobotSafetyControl(1);
      is_robot_paused = false;
    }
  }

  error_record_pub_.publish(cur_health_status);
  return;
}
}  // namespace system_health_diagnostics