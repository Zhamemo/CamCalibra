#pragma once

#include <custom_msgs_srvs/SystemHealthStaus.h>
#include <ros/ros.h>

namespace system_health_diagnostics {
class DiagnosticAnalysis
    : public std::enable_shared_from_this<DiagnosticAnalysis> {
 public:
  ~DiagnosticAnalysis() = default;

  DiagnosticAnalysis(const DiagnosticAnalysis&) = delete;
  DiagnosticAnalysis& operator=(const DiagnosticAnalysis&) = delete;

 private:
  DiagnosticAnalysis();

 private:
  void initParm();

 private:
  void applyRobotSafetyControl(int mode);

  bool pauseRobot(bool pause);

  int compareModulePriority(const std::string& module);

 public:
  void updateDiagnosticStatus(
      const custom_msgs_srvs::SystemHealthStaus::Ptr& msg);

  static std::shared_ptr<DiagnosticAnalysis> getInstance() {
    static std::shared_ptr<DiagnosticAnalysis> instance(
        new DiagnosticAnalysis());
    return instance;
  }

 private:
  ros::Publisher error_record_pub_;
  ros::ServiceClient robot_pause_client_;

  std::string node_name_str_;
};
}  // namespace system_health_diagnostics