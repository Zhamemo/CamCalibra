#pragma once

#include <custom_msgs_srvs/FileStatus.h>
#include <custom_msgs_srvs/FileStatusArray.h>
#include <custom_msgs_srvs/NodeHealthStaus.h>
#include <custom_msgs_srvs/SensorStatus.h>
#include <custom_msgs_srvs/StatusInfo.h>
#include <custom_msgs_srvs/SystemHealthStaus.h>
#include <custom_msgs_srvs/SystemPerformanceStatus.h>
#include <ros/ros.h>

#include "common/atomic.hpp"

namespace system_health_diagnostics {
class DiagnosticAggregator
    : public std::enable_shared_from_this<DiagnosticAggregator> {
 public:
  ~DiagnosticAggregator() = default;
  DiagnosticAggregator(const DiagnosticAggregator&) = delete;
  DiagnosticAggregator& operator=(const DiagnosticAggregator&) = delete;

 private:
  DiagnosticAggregator();

 private:
  void initParm();

 private:
  void getSysPerfStatus(
      const custom_msgs_srvs::SystemPerformanceStatus::ConstPtr& msg);

  void getFileStatus(const custom_msgs_srvs::FileStatusArray::ConstPtr& msg);

  void getNodesHeartStatus(
      const custom_msgs_srvs::NodeHealthStaus::ConstPtr& msg);

  void getFrontRgbdStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getBackRgbdStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getLeftRgbdStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getRightRgbdStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getLidar3dStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getLidar2dStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getImuStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getOdomStatus(const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getZwjSwjConnectionStatus(
      const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

  void getRobotLocalizationStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotPlanningStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotPerceptionStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotChargeStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getCleanDeviceStatus(
      const custom_msgs_srvs::SensorStatus::ConstPtr& msg);

 private:
  custom_msgs_srvs::StatusInfo processSysPerfStatus();

  custom_msgs_srvs::StatusInfo processFileStatus();

  custom_msgs_srvs::StatusInfo processNodesHeartStatus();

  custom_msgs_srvs::StatusInfo processFrontRgbdStatus();

  custom_msgs_srvs::StatusInfo processBackRgbdStatus();

  custom_msgs_srvs::StatusInfo processLeftRgbdStatus();

  custom_msgs_srvs::StatusInfo processRightRgbdStatus();

  custom_msgs_srvs::StatusInfo processLidar3dStatus();

  custom_msgs_srvs::StatusInfo processLidar2dStatus();

  custom_msgs_srvs::StatusInfo processImuStatus();

  custom_msgs_srvs::StatusInfo processOdomStatus();

  custom_msgs_srvs::StatusInfo processZwjSwjConnectionStatus();

  custom_msgs_srvs::StatusInfo processRobotLocalizationStatus();

  custom_msgs_srvs::StatusInfo processRobotPlanningStatus();

  custom_msgs_srvs::StatusInfo processRobotPerceptionStatus();

  custom_msgs_srvs::StatusInfo processRobotChargeStatus();

  custom_msgs_srvs::StatusInfo processCleanDeviceStatus();

 private:
  bool checkFaultTimeout(const ros::Time& last_fault_time, double timeout) {
    return (ros::Time::now() - last_fault_time).toSec() > timeout;
  }

  custom_msgs_srvs::StatusInfo sort(
      std::vector<custom_msgs_srvs::StatusInfo>& vec_status_info) {
    std::sort(vec_status_info.begin(), vec_status_info.end(),
              [](const custom_msgs_srvs::StatusInfo& a,
                 const custom_msgs_srvs::StatusInfo& b) {
                // 1. 按错误级别排序 FATAL_ERROR > ERROR > WARNING > OK
                if (a.error_level != b.error_level) {
                  return a.error_level > b.error_level;
                }
                // 2. 按错误代码排序
                if (a.error_code != b.error_code) {
                  return a.error_code < b.error_code;
                }
                // 3. 按时间排序 记录最新的
                return a.header.stamp > b.header.stamp;
              });
    return vec_status_info.front();
  }

 public:
  custom_msgs_srvs::SystemHealthStaus::Ptr getSystemStatus();

  static std::shared_ptr<DiagnosticAggregator> getInstance() {
    static std::shared_ptr<DiagnosticAggregator> instance(
        new DiagnosticAggregator());
    return instance;
  }

 private:
  ros::Subscriber sys_perf_status_sub_;
  ros::Subscriber file_status_sub_;
  ros::Subscriber nodes_heart_status_sub_;
  ros::Subscriber front_rgbd_status_sub_;  // 前向深度相机
  ros::Subscriber back_rgbd_status_sub_;   // 后向深度相机
  ros::Subscriber left_rgbd_status_sub_;   // 左向深度相机
  ros::Subscriber right_rgbd_status_sub_;  // 右向深度相机
  ros::Subscriber lidar_3d_status_sub_;
  ros::Subscriber lidar_2d_status_sub_;
  ros::Subscriber imu_status_sub_;
  ros::Subscriber odom_status_sub_;
  ros::Subscriber zwj_swj_connection_status_sub_;
  ros::Subscriber robot_localization_status_sub_;
  ros::Subscriber robot_planning_status_sub_;
  ros::Subscriber robot_perception_status_sub_;
  ros::Subscriber robot_charge_status_sub_;
  ros::Subscriber clean_device_sub_;
  ros::Publisher system_status_pub_;

  std::string node_name_str_;
  double sys_fault_timeout_;
  double node_topic_fault_timeout_;
  double rgbd_cam_fault_timeout_;
  double lidar_3d_fault_timeout_;
  double lidar_2d_fault_timeout_;
  double imu_fault_timeout_;
  double odom_fault_timeout_;
  double zwj_swj_connection_timeout_;

  common::Atomic<custom_msgs_srvs::SystemPerformanceStatus> sys_perf_status_;
  common::Atomic<custom_msgs_srvs::FileStatusArray> file_status_;
  common::Atomic<custom_msgs_srvs::NodeHealthStaus> node_heart_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> front_rgbd_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> back_rgbd_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> left_rgbd_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> right_rgbd_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> lidar_3d_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> lidar_2d_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> imu_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> odom_status_;
  common::Atomic<custom_msgs_srvs::SensorStatus> zwj_swj_connection_status_;

  std::mutex robot_localization_status_mutex_;
  std::vector<custom_msgs_srvs::StatusInfo> robot_localization_status_buffer_;

  std::mutex robot_planning_status_mutex_;
  std::vector<custom_msgs_srvs::StatusInfo> robot_planning_status_buffer_;

  std::mutex robot_perception_status_mutex_;
  std::vector<custom_msgs_srvs::StatusInfo> robot_perception_status_buffer_;

  std::mutex robot_charge_status_mutex_;
  std::vector<custom_msgs_srvs::StatusInfo> robot_charge_status_buffer_;

  common::Atomic<custom_msgs_srvs::SensorStatus> clean_device_status_;
};
}  // namespace system_health_diagnostics