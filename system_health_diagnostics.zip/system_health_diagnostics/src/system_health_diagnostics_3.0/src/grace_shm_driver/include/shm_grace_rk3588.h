/**
 * @file shm-grace.h
 * @brief Grace机器人共享内存接口头文件
 * @details 提供了通过共享内存控制和监控Grace机器人的接口。
 * 包含了机器人的运动控制、清扫控制、传感器状态获取等功能。
 * 使用共享内存机制实现进程间通信,提供了一系列结构体和函数用于读写共享内存数据。
 * @author Your Name
 * @version 1.0
 * @date 2023-12-20
 * @copyright Copyright (c) 2023
 */

#pragma once

#include <cstring>
#include <cstdint>
#include <cstdio>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <memory>

/**
 * @brief Grace机器人共享内存起始地址
 * @details 用于创建和访问共享内存的唯一标识符。
 * 该值必须在系统中唯一,用作shmget()的key参数。
 */
#define GRACE_SHM_START 0x3b1a0002

/**
 * @brief grace机器人共享内存大小
 * @details 共享内存段的总大小,单位为字节
 */
#define GRACE_SHM_SIZE 8388608 // 8 MB

/**
 * @defgroup MemoryBaseAddresses 内存基地址定义
 * @brief 定义了不同功能模块在共享内存中的基地址
 * @details 每个模块占用一段固定大小的内存空间,通过基地址加偏移量访问具体数据
 * @{
 */
#define VEHICLE_BASE     0x100000  /**< 车辆状态段基地址,包含速度、位置等基本状态信息 */
#define MCU_RX_BASE     0x100c00  /**< MCU接收数据段基地址,存储从MCU接收的传感器数据等 */
#define MCU_TX_BASE     0x100e00  /**< MCU发送数据段基地址,存储发送给MCU的控制指令等 */
#define STATION_BASE    0x100a00  /**< 工作站状态段基地址,存储充电站、清洗站等状态 */
/** @} */

/**
 * @defgroup DataTypeSizes 数据类型大小定义
 * @brief 定义了常用数据类型的字节大小
 * @details 用于内存读写时确保数据对齐和正确的内存操作
 * @{
 */
#define INT8_SIZE       1  /**< 8位整数字节大小,用于int8_t等类型 */
#define INT16_SIZE      2  /**< 16位整数字节大小,用于int16_t等类型 */
#define INT32_SIZE      4  /**< 32位整数字节大小,用于int32_t等类型 */
#define INT64_SIZE      8  /**< 64位整数字节大小,用于int64_t等类型 */
#define FLOAT_SIZE      4  /**< 单精度浮点数字节大小,用于float类型 */
#define DOUBLE_SIZE     8  /**< 双精度浮点数字节大小,用于double类型 */
/** @} */

/**
 * @brief 从指定内存位置读取指定类型的值
 * @tparam T 要读取的数据类型
 * @param data 内存起始地址
 * @param offset 相对于起始地址的偏移量
 * @return 读取到的值
 * @note 使用memcpy确保内存对齐访问,避免因对齐问题导致的异常
 * 
 * @par 示例:
 * @code
 * float speed = READ_VALUE(float, shm_ptr, 0x100);
 * int32_t count = READ_VALUE(int32_t, shm_ptr, 0x104);
 * @endcode
 */
#define READ_VALUE(T, data, offset) ({ \
    T value; \
    std::memcpy(&value, (data) + (offset), sizeof(T)); \
    value; \
})

/**
 * @brief 将指定类型的值写入指定内存位置
 * @tparam T 要写入的数据类型,如int32_t、float等
 * @param data 内存起始地址,通常是共享内存的基地址
 * @param offset 相对于起始地址的偏移量,单位为字节
 * @param value 要写入的值
 * @note 使用memcpy确保内存对齐访问,避免因对齐问题导致的异常
 * 
 * @par 示例:
 * @code
 * WRITE_VALUE(float, shm_ptr, 0x100, 3.14f);
 * WRITE_VALUE(int32_t, shm_ptr, 0x104, 42);
 * @endcode
 */
#define WRITE_VALUE(T, data, offset, value) \
    std::memcpy((data) + (offset), &(value), sizeof(T))

/**
 * @brief 日志标签
 * @details 用于标识日志来源的标签字符串
 */
#define TAG "shm-grace"

/**
 * @brief 日志打印宏
 * @param fmt 格式化字符串,支持printf风格的格式说明符
 * @param ... 可变参数列表,对应格式化字符串中的参数
 * @details 打印带有标签和行号的格式化日志信息。
 * 每条日志都会包含模块标签和代码行号,便于调试。
 * 
 * @par 示例:
 * @code
 * LOG("Speed: %f m/s, Direction: %d", speed, direction);
 * LOG("Starting..."); // 无参数
 * LOG("Error code: 0x%x", error_code); // 十六进制输出
 * @endcode
 */
#define LOG(fmt, ...) do { \
    printf("[%s] %d: " fmt "\n", TAG, __LINE__, ##__VA_ARGS__); \
} while(0)

/**
 * @namespace Grace
 * @brief Grace机器人控制命名空间
 * @details 包含了所有用于通过共享内存控制和监控Grace机器人的类、结构体和函数
 */
namespace Grace {

    /**
     * @struct ChassisCmd
     * @brief 底盘控制指令结构体
     * @details 包含了控制机器人底盘运动的速度指令参数
     */
    struct ChassisCmd {
        float command_linear_x;    /**< X方向线速度指令,单位:m/s */
        float command_linear_y;    /**< Y方向线速度指令,单位:m/s */
        float command_angular_z;   /**< Z轴角速度指令,单位:rad/s */
    };

    /**
     * @struct Odom
     * @brief 里程计数据结构体
     * @details 包含了机器人的运动状态和位姿信息
     */
    struct Odom {
        uint64_t timestamp;         /**< 时间戳,单位:ns */
        float vehicle_linear_x;     /**< 车体X方向线速度,单位:m/s */
        float vehicle_linear_y;     /**< 车体Y方向线速度,单位:m/s */
        float vehicle_angular_z;    /**< 车体Z轴角速度,单位:rad/s */
        double odom_x;             /**< X坐标位置,单位:m */
        double odom_y;             /**< Y坐标位置,单位:m */
        double odom_theta;         /**< 航向角,单位:rad */
    };

    /**
     * @struct CleaningDeviceCmd
     * @brief 清扫设备控制结构体
     * @details 包含了所有清扫相关设备的控制指令。
     * 用于控制刷盘、风机、水泵等清扫设备的工作状态。
     */
    struct CleaningDeviceCmd {
        int brush_speed;           /**< 刷盘速度,单位:rpm */
        int fan_speed;             /**< 风机速度,单位:rpm */
        bool lifter_cmd;           /**< 刷盘推杆控制,true表示升起 */
        bool suction_cmd;          /**< 吸扒推杆控制,true表示升起 */
        bool supply_pump_cmd;      /**< 加水泵控制,true表示开启 */
        bool cycle_pump_cmd;       /**< 循环泵控制,true表示开启 */
        bool selfclean_pump_cmd;   /**< 自清洁泵控制,true表示开启 */
        bool spray_water_cmd;      /**< 喷水泵控制,true表示开启 */
        bool front_light_cmd;      /**< 前照灯控制,true表示开启 */
        bool search_light_cmd;     /**< 前探照灯控制,true表示开启 */
        bool seweage_cmd;          /**< 污水排水阀控制,true表示开启 */
        bool left_back_light_cmd;  /**< 左后灯带控制,true表示开启 */
        bool right_back_light_cmd; /**< 右后灯带控制,true表示开启 */
    };

    /**
     * @struct CleaningDeviceStatus
     * @brief 清扫设备状态结构体
     * @details 包含了所有清扫相关设备的实际运行状态。
     * 用于监控各个清扫设备的工作状态和故障状态。
     */
    struct CleaningDeviceStatus {
        int actual_brush_speed;     /**< 刷盘实际速度,单位:rpm */
        int actual_fan_speed;       /**< 风机实际速度,单位:rpm */
        bool brush_down;            /**< 刷盘推杆状态,true表示已降下 */
        bool suction_down;          /**< 吸扒推杆状态,true表示已降下 */
        uint8_t sewage_level;       /**< 污水液位(0-15) */
        uint8_t clean_water_level;  /**< 清水液位(0-15) */
        bool spray_valve_on;        /**< 喷水阀状态 */
        bool clean_drain_valve_on;  /**< 清水排阀状态 */
        bool sewage_drain_valve_on; /**< 污水排阀状态 */
        bool suction_pump_on;       /**< 吸水泵状态 */
        bool suction_valve_on;      /**< 吸水阀状态 */
        bool selfclean_pump_on;     /**< 自清洁泵状态 */
        bool selfclean_valve_on;    /**< 自清洁阀状态 */
        bool cycle_pump_on;         /**< 循环泵状态 */
        bool cycle_valve_on;        /**< 循环阀状态 */
        uint32_t sweep_err_code1;   /**< 清洗驱动器系统故障码1 */
        uint32_t sweep_err_code2;   /**< 清洗驱动器系统故障码2 */
    };

    /**
     * @brief 获取共享内存
     * @return std::shared_ptr<void> 共享内存指针,获取失败返回nullptr
     * @details 使用单例模式获取共享内存,确保只创建一次共享内存连接。
     * 使用智能指针管理共享内存的生命周期,自动处理内存的分离。
     * 
     * @par 示例:
     * @code
     * auto shm = Grace::get_shm();
     * if(shm) {
     *     // 使用共享内存
     * }
     * @endcode
     */
    static std::shared_ptr<void> get_shm() {
        static std::shared_ptr<void> shm;
        if (!shm) {
            int shmid = shmget(GRACE_SHM_START, GRACE_SHM_SIZE, 0666);
            if (shmid < 0) {
                return nullptr;
            }
            shm = std::shared_ptr<void>(shmat(shmid, nullptr, 0), [](void* p) { shmdt(p); });
        }
        return shm;
    }


    template<typename T>
    void set_bits(unsigned char* base, size_t offset, std::initializer_list<std::pair<int, bool>> bit_settings) {
        T value = READ_VALUE(T, base, offset);

        for (const auto &pair : bit_settings)
        {
            int bit = pair.first;
            bool enable = pair.second;

            if (enable)
                value |= (1 << bit);
            else
                value &= ~(1 << bit);
        }

        WRITE_VALUE(T, base, offset, value);
    }

    static void set_sweep_ctrl_bit(std::initializer_list<std::pair<int, bool>> bit_settings) {
        constexpr size_t kSweepCtrlAddr = 0x105f34;
        auto shm = get_shm();
        if (!shm) return;

        set_bits<uint16_t>((unsigned char*)shm.get(), kSweepCtrlAddr, bit_settings);
    }

    /**
     * @brief 发送速度控制指令
     * @param cmd 速度控制指令结构体
     * @return bool 发送是否成功
     * @details 将速度控制指令写入共享内存的对应位置。
     * 支持同时控制X、Y方向线速度和Z轴角速度。
     * 
     * @par 示例:
     * @code
     * ChassisCmd cmd;
     * cmd.command_linear_x = 0.5f;  // 向前0.5m/s
     * cmd.command_linear_y = 0.0f;  // 不左右移动
     * cmd.command_angular_z = 0.0f; // 不旋转
     * send_speed(cmd);
     * @endcode
     */
    static bool send_speed(ChassisCmd cmd) {
        auto shm = get_shm();
        if (!shm) {
            return false;
        }

        float x = static_cast<float>(cmd.command_linear_x);
        float y = static_cast<float>(cmd.command_linear_y);
        float z = static_cast<float>(cmd.command_angular_z);

        WRITE_VALUE(float, (unsigned char*)shm.get(), 0x10002C, x);
        WRITE_VALUE(float, (unsigned char*)shm.get(), 0x100030, y);
        WRITE_VALUE(float, (unsigned char*)shm.get(), 0x100034, z);
        return true;
    }

    /**
     * @brief 获取里程计数据
     * @return Odom 里程计数据结构体
     * @details 从共享内存读取当前里程计数据。
     * 包含机器人的位置、速度和时间戳信息。
     * 
     * @par 示例:
     * @code
     * Odom odom = get_odom();
     * printf("Position: (%.2f, %.2f), Heading: %.2f\n", 
     *        odom.odom_x, odom.odom_y, odom.odom_theta);
     * @endcode
     */
    static Odom get_odom() {
        Odom odom;
        auto shm = get_shm();
        if (!shm) {
            return Odom();
        }

        odom.vehicle_linear_x = READ_VALUE(float, (unsigned char*)shm.get(), 0x100050);
        odom.vehicle_linear_y = READ_VALUE(float, (unsigned char*)shm.get(), 0x100054);
        odom.vehicle_angular_z = READ_VALUE(float, (unsigned char*)shm.get(), 0x100058);
        odom.odom_x = READ_VALUE(float, (unsigned char*)shm.get(), 0x10005C);
        odom.odom_y = READ_VALUE(float, (unsigned char*)shm.get(), 0x100060);
        odom.odom_theta = READ_VALUE(float, (unsigned char*)shm.get(), 0x100064);
        odom.timestamp = READ_VALUE(uint64_t, (unsigned char*)shm.get(), 0x100068);

        return odom;
    }

    /**
     * @brief 控制前照灯
     * @param cmd true开启,false关闭
     * @details 控制机器人前照灯的开关状态。
     * 通过设置控制字的相应位来实现。
     * 
     * @par 示例:
     * @code
     * ctrl_front_light_cmd(true);  // 开启前照灯
     * ctrl_front_light_cmd(false); // 关闭前照灯
     * @endcode
     */
    static void ctrl_front_light_cmd(bool cmd) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f3c);
        if (cmd) {
            value |= 0x40;  // Set bit 6 (seventh bit) to 1
        } else {
            value &= ~0x40; // Set bit 6 (seventh bit) to 0
        }
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f3c, value);
    }

    /**
     * @brief 控制前探照灯
     * @param cmd true开启,false关闭
     * @details 控制机器人前探照灯的开关状态。
     * 通过设置控制字的相应位来实现。
     * 
     * @par 示例:
     * @code
     * ctrl_search_light_cmd(true);  // 开启前探照灯
     * ctrl_search_light_cmd(false); // 关闭前探照灯
     * @endcode
     */
    static void ctrl_search_light_cmd(bool cmd) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f5c);
        if (cmd) {
            value |= 0x20;  // Set bit 5 (sixth bit) to 1
        } else {
            value &= ~0x20; // Set bit 5 (sixth bit) to 0
        }
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f5c, value);
    }

    /**
     * @brief 控制左后灯带
     * @param cmd true开启,false关闭
     * @details 控制机器人左后灯带的开关状态。
     * 通过设置控制字的相应位来实现。
     * 
     * @par 示例:
     * @code
     * ctrl_left_back_light_cmd(true);  // 开启左后灯带
     * ctrl_left_back_light_cmd(false); // 关闭左后灯带
     * @endcode
     */
    static void ctrl_left_back_light_cmd(bool cmd) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f3c);
        if (cmd) {
            value |= 0x07;  // Set bits 0,1,2 to 1 (0b00000111)
        } else {
            value &= ~0x07; // Set bits 0,1,2 to 0 (0b00000111)
        }
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f3c, value);
    }

    /**
     * @brief 控制右后灯带
     * @param cmd true开启,false关闭
     * @details 控制机器人右后灯带的开关状态。
     * 通过设置控制字的相应位来实现。
     * 
     * @par 示例:
     * @code
     * ctrl_right_back_light_cmd(true);  // 开启右后灯带
     * ctrl_right_back_light_cmd(false); // 关闭右后灯带
     * @endcode
     */
    static void ctrl_right_back_light_cmd(bool cmd) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f3c);
        if (cmd) {
            value |= 0x38;  // Set bits 3,4,5 to 1 (0b00111000)
        } else {
            value &= ~0x38; // Set bits 3,4,5 to 0 (0b00111000)
        }
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(), 0x105f3c, value);
    }

    /**
     * @brief 控制报警灯带和语音播报
     * @param cmd true开启,false关闭
     * @details 控制机器人报警灯带和语音播报的开关状态。
     * 通过设置控制字的相应位来实现。
     * 
     * @par 示例:
     * @code
     * ctrl_alert_light_with_voice_cmd(true);  // 开启报警灯带和语音播报
     * ctrl_alert_light_with_voice_cmd(false); // 关闭报警灯带和语音播报
     * @endcode
     */
    static void ctrl_alert_light_with_voice_cmd(bool cmd) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        uint16_t light_value = READ_VALUE(uint16_t, (unsigned char*)shm.get(),  0x105f5c);
        uint16_t alert_voice_value = READ_VALUE(uint16_t, (unsigned char*)shm.get(),  0x105f38);
        uint16_t voice_cmd_value = READ_VALUE(uint16_t, (unsigned char*)shm.get(),  0x105f48);

        if (cmd) {
            light_value = (light_value & 0x01) | 64;  // Set value to 64 when cmd is true
            voice_cmd_value = 1;
            alert_voice_value = 528;
        } else {
            light_value = (light_value & 0x01) | 0;  // Set value to 0 when cmd is false
            voice_cmd_value = 0;
            alert_voice_value = 0;
        }

        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(),  0x105f5c, light_value);
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(),  0x105f38, alert_voice_value);
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(),  0x105f48, voice_cmd_value);
    }

    /**
     * @brief 控制喷水泵速度
     * @param water_speed 喷水泵速度,单位:rpm,范围0-100
     * @details 设置喷水泵的运行速度。
     * 速度值超出范围会被限制在有效范围内。
     * 
     * @par 示例:
     * @code
     * ctrl_water_speed(1500);  // 设置为1500rpm
     * ctrl_water_speed(0);   // 停止喷水泵
     * @endcode
     */
    static void ctrl_water_speed(int water_speed) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(int16_t, (unsigned char*)shm.get(), 0x105f2c, water_speed);
    }

    /**
     * @brief 控制刷盘速度
     * @param brush_speed 刷盘速度,单位:rpm
     * @details 设置刷盘的运行速度。
     * 速度值超出范围会被限制在有效范围内。
     * 
     * @par 示例:
     * @code
     * ctrl_brush_speed(1500);  // 设置为1500rpm
     * ctrl_brush_speed(0);   // 停止刷盘
     * @endcode
     */
    static void ctrl_brush_speed(int brush_speed) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(int16_t, (unsigned char*)shm.get(), 0x105f28, brush_speed);
    }

    /**
     * @brief 控制吸风电机
     * @param wind_speed 吸风电机速度,单位:rpm
     * @details 设置吸风电机的运行速度。
     * 速度值超出范围会被限制在有效范围内。
     * 
     * @par 示例:
     * @code
     * ctrl_wind_speed(500);  // 设置为500rpm
     * ctrl_wind_speed(0);   // 停止吸风电机
     * @endcode
     */
    static void ctrl_wind_speed(int wind_speed) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(int16_t, (unsigned char*)shm.get(), 0x105f24, wind_speed);
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_test_cmd(int cmd)
    {
        bool value = cmd > 100;
        int bit = cmd % 100;
        set_sweep_ctrl_bit({{bit, value}});
    }

    // mcutx.sweep_ctrl 下相关控制, 设备初始化
    static void ctrl_initial_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({
            {0, cmd},
            {1, cmd},
            {2, cmd},
            {3, cmd},
            {4, cmd},
            {5, cmd},
            {6, cmd},
            {7, cmd},
            {8, cmd},
            {9, cmd},
            {10, cmd},
            {11, cmd},
            {12, cmd},
            {13, cmd},
            {14, cmd},
            {15, cmd}
            }); // mcutx.sweep_ctrl.b0: 初始化
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_lifter_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({
            {1, cmd}, // mcutx.sweep_ctrl.b1: 设置运动指令
            {2, cmd}  // mcutx.sweep_ctrl.b2: 滚刷升降(默认flase，升起)
        });
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_suction_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({
            {3, cmd}, // mcutx.sweep_ctrl.b3: 设置运动指令
            {4, cmd}  // mcutx.sweep_ctrl.b4: 吸扒升降(默认flase，升起)
        });
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_water_suction_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{5, cmd}}); // mcutx.sweep_ctrl.b5: 加水推杆方向 升降
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_water_spray_solenoid_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({
            {6, cmd}, // mcutx.sweep_ctrl.b6: 喷水球阀 开关
            // {7, cmd}  // mcutx.sweep_ctrl.b7: 喷水电磁阀(旧代码遗留，62004上未标明) 开关
        });
    }

    // mcutx.sweep_ctrl 下相关控制，清水阀
    static void ctrl_clean_drain_ball_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{8, cmd}}); // mcutx.sweep_ctrl.b8: 清水排水球阀
    }

    // mcutx.sweep_ctrl 下相关控制, 污水阀
    static void ctrl_sewage_drain_ball_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{9, cmd}}); // mcutx.sweep_ctrl.b9: 污水排水球阀
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_cycle_supply_switch_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{10, cmd}}); // mcutx.sweep_ctrl.b11: 循环/自吸水模式 切换
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_cycle_pump_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{11, cmd}}); // mcutx.sweep_ctrl.b11: 自清洁泵/自吸泵 切换
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_supply_pump_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{12, cmd}}); // mcutx.sweep_ctrl.b12: 自吸泵 开关
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_selfclean_pump_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{13, cmd}}); // mcutx.sweep_ctrl.b13: 自清洁阀 开关
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_defoamer_pump_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{14, cmd}}); // mcutx.sweep_ctrl.b14: 消泡剂泵 开关
    }

    // mcutx.sweep_ctrl 下相关控制
    static void ctrl_detergent_pump_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({{15, cmd}}); // mcutx.sweep_ctrl.b15: 清洁剂泵 开关
    }

    // mcutx.sweep_ctrl 下相关控制：自清洁控制函数
    // TODO: 测试发现只需要控制阀的状态，不需要控制泵，修正后与一键排水相同
    static void self_cleaning(bool cmd)
    {
        // 设置自清洁泵/阀开关
        set_sweep_ctrl_bit({
            {8, cmd}, // mcutx.sweep_ctrl.b8: 清水排水球阀
            {9, cmd} // mcutx.sweep_ctrl.b9: 污水排水球阀
        });

        // // 设置自清洁泵转速（0 或 100）
        // int16_t speed = cmd ? 100 : 0;
        // auto shm = get_shm();
        // if (!shm)
        //     return;

        // WRITE_VALUE(int16_t, (unsigned char *)shm.get(), 0x100c0c, speed); // 自清洁泵转速设置地址
    }

    // mcutx.sweep_ctrl 下相关控制，一键排水
    static void ctrl_water_drain_cmd(bool cmd)
    {
        set_sweep_ctrl_bit({
            {8, cmd}, // mcutx.sweep_ctrl.b8: 清水排水球阀
            {9, cmd}  // mcutx.sweep_ctrl.b9: 污水排水球阀
        });
    }

    /**
     * @struct McuStatus
     * @brief MCU状态结构体
     * @details 包含了MCU的各种状态信息,包括:
     *          - 轮毂电机电流
     *          - 各种泵和风机的实际速度和电流
     *          - 液位信息
     *          - 故障码
     */
    struct McuStatus {
        float wheel_current_l;      /**< 左轮毂电机实际电流,单位:A */
        float wheel_current_r;      /**< 右轮毂电机实际电流,单位:A */
        float spray_real_sp;        /**< 喷水泵实际速度,单位:% (0-100) */
        float wind_real_sp;         /**< 吸水风机实际速度,单位:% (0-100) */
        float brush_real_sp;        /**< 滚刷电机实际速度,单位:% (0-100) */
        float wind_real_current;    /**< 吸水风机实际电流,单位:A */
        float brush_real_current;   /**< 滚刷电机实际电流,单位:A */
        int liquid1;                /**< 清水箱液位,单位:mm */
        int liquid2;                /**< 污水箱液位,单位:mm */
        uint32_t sweep_err_code1;   /**< 清洗驱动器系统故障码1 */
        uint32_t sweep_err_code2;   /**< 清洗驱动器系统故障码2 */
    };

    /**
     * @brief 获取MCU状态
     * @return McuStatus MCU状态结构体
     * @details 从共享内存读取当前MCU的状态信息,包括:
     *          - 轮毂电机电流(0x100c06, 0x100c08)
     *          - 泵和风机速度(0x100c0a-0x100c0e)
     *          - 风机和滚刷电流(0x100c10, 0x100c12)
     *          - 故障码(0x105f34, 0x100c18)
     *          - 液位信息(0x100c24, 0x100c26)
     * 
     * @note 电流值需要除以100转换为安培
     */
    static McuStatus get_mcu_status() {
        McuStatus status;
        auto shm = get_shm();
        if (!shm) {
            return McuStatus();
        }

        status.wheel_current_l = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c06) / 100.0f;
        status.wheel_current_r = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c08) / 100.0f;
        status.spray_real_sp = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c0a);
        status.wind_real_sp = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c0c);
        status.brush_real_sp = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c0e);
        status.wind_real_current = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c10);
        status.brush_real_current = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c12);
        status.sweep_err_code1 = READ_VALUE(uint32_t, (unsigned char*)shm.get(), 0x100C14);
        status.sweep_err_code2 = READ_VALUE(uint32_t, (unsigned char*)shm.get(), 0x100c18);
        status.liquid1 = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c24);
        status.liquid2 = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c26);

        return status;
    }

    /**
     * @brief 获取超声波数据
     * @param index 超声波传感器索引(1-6)
     * @return uint16_t 距离值,单位:mm,范围0-1082mm
     * @details 读取指定索引超声波传感器的距离数据。
     * 数据存储在共享内存地址0x100a28开始,每个传感器占用2字节。
     * 
     * @note 索引范围为1-6,对应6个超声波传感器
     * @note 返回值单位为毫米,最大测量距离1082mm
     * @note 如果索引无效或共享内存访问失败,返回0
     * 
     * @par 示例:
     * @code
     * uint16_t dist = get_ultrasonic_data(1); // 读取1号超声波距离
     * @endcode
     */
    static uint16_t get_ultrasonic_data(int index) {
        auto shm = get_shm();
        if (!shm || index < 1 || index > 6) {
            return 0;
        }

        uint16_t offset = 0x100a28 + (index - 1) * 2;
        return READ_VALUE(uint16_t, (unsigned char*)shm.get(), offset);
    }

    /**
     * @struct ImuData
     * @brief IMU数据结构体
     * @details 包含了IMU的完整数据,包括:
     *          - 三轴角速度(°/s)
     *          - 三轴加速度(mg)
     *          - 陀螺仪温度(℃)
     *          - 时间戳(ms)
     */
    struct ImuData {
        float x_angle_speed;        /**< X轴角速度,单位:°/s */
        float y_angle_speed;        /**< Y轴角速度,单位:°/s */
        float z_angle_speed;        /**< Z轴角速度,单位:°/s */
        float x_acc;                /**< X轴加速度,单位:mg */
        float y_acc;                /**< Y轴加速度,单位:mg */
        float z_acc;                /**< Z轴加速度,单位:mg */
        float gyro_temp;            /**< 陀螺仪温度,单位:℃ */
        uint64_t timestamp;         /**< 时间戳,单位:ms */
    };

    /**
     * @brief 获取IMU数据
     * @return ImuData IMU数据结构体
     * @details 从共享内存读取当前IMU的完整数据,包括:
     *          - 角速度数据(0x100c38-0x100c40)
     *          - 加速度数据(0x100c44-0x100c4c)
     *          - 温度数据(0x100c50)
     *          - 时间戳(0x100c54)
     * 
     * @note 所有数据都是float类型,直接读取即可
     * @note 如果共享内存访问失败,返回空结构体
     */
    static ImuData get_imu_data() {
        ImuData imu;
        auto shm = get_shm();
        if (!shm) {
            return ImuData();
        }

        imu.x_angle_speed = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c38);
        imu.y_angle_speed = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c3c);
        imu.z_angle_speed = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c40);
        imu.x_acc = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c44);
        imu.y_acc = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c48);
        imu.z_acc = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c4c);
        imu.gyro_temp = READ_VALUE(float, (unsigned char*)shm.get(), 0x100c50);
        imu.timestamp = READ_VALUE(uint64_t, (unsigned char*)shm.get(), 0x100c54);

        return imu;
    }

    /**
     * @brief 获取超声波错误状态
     * @return uint16_t 超声波错误状态位域
     * @details 从共享内存地址0x100c5e读取超声波错误状态位域。
     * 每个位表示一个超声波传感器的错误状态:
     *          - bit0-7: 超声波1-8的错误状态
     *          - 1表示错误
     *          - 0表示正常
     * 
     * @note 如果共享内存访问失败,返回0
     * 
     * @par 示例:
     * @code
     * uint16_t err = get_ultrasonic_err();
     * bool us1_error = err & 0x01; // 检查超声波1是否错误
     * @endcode
     */
    static uint16_t get_ultrasonic_err() {
        auto shm = get_shm();
        if (!shm) {
            return 0;
        }
        return READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100c5e);
    }

    /**
     * @brief 获取电梯状态
     * @return uint8_t 电梯状态位域
     * @details 从共享内存地址0x100a60读取电梯状态位域。
     * 包含以下状态标志:
     *          - bit0: 电梯门状态(1开0关)
     *          - bit1: 电梯离线状态(1离线0在线)
     *          - bit2: 电梯故障状态(1故障0正常)
     * 
     * @note 如果共享内存访问失败,返回0
     * 
     * @par 示例:
     * @code
     * uint8_t status = get_lift_status();
     * bool door_open = status & 0x01; // 检查电梯门是否打开
     * @endcode
     */
    static uint8_t get_lift_status() {
        auto shm = get_shm();
        if (!shm) {
            return 0;
        }
        return READ_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100a60);
    }

    /**
     * @brief 获取工作站状态
     * @return uint16_t 工作站状态位域
     * @details 从共享内存地址0x100a20读取工作站状态位域。
     * 包含以下状态标志:
     *          - bit0: 通讯状态(1成功0失败)
     *          - bit1: 加水状态(1到位0未到位)
     *          - bit2: 排水状态(1到位0未到位)
     *          - bit8: 充电状态(1到位0未到位)
     *          - bit9: 水路状态(1到位0未到位)
     *          - bit10: 充电电流状态(1有0无)
     *          - bit11: 流量开关状态(1开0关)
     *          - bit12: 清水状态(1空0非空)
     *          - bit13: 污水状态(1满0未满)
     *          - bit14: 消泡剂状态(1空0非空)
     *          - bit15: 清洁剂状态(1空0非空)
     * 
     * @note 如果共享内存访问失败,返回0
     * 
     * @par 示例:
     * @code
     * uint16_t status = get_station_status();
     * bool charging = status & (1<<8); // 检查是否在充电
     * @endcode
     */
    static uint16_t get_station_status() {
        auto shm = get_shm();
        if (!shm) {
            return 0;
        }
        return READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100a20);
    }

    /**
     * @brief 设置语音音量
     * @param volume 音量值,范围0-100
     * @details 通过写入共享内存地址0x100c24来控制语音播报音量。
     * 音量范围为0-100:
     *          - 0: 静音
     *          - 1-100: 对应音量百分比
     * 
     * @note 输入值大于100时会被限制为100
     * 
     * @par 示例:
     * @code
     * set_volume(50);  // 设置音量为50%
     * set_volume(0);   // 静音
     * @endcode
     */
    static void set_volume(uint8_t volume) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        if (volume > 100) volume = 100;
        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100c24, volume);
    }

    /**
     * @brief 设置速度限制
     * @param speed_limit 速度限制值,范围0-255,单位cm/s
     * @details 通过写入共享内存地址0x100c2c来限制机器人的最大运动速度。
     * 速度限制说明:
     *          - 0: 不限速
     *          - 1-255: 对应的最大速度(cm/s)
     * 
     * @note 此限速作用于所有运动模式
     * 
     * @par 示例:
     * @code
     * set_speed_limit(0);    // 取消速度限制
     * set_speed_limit(100);  // 限速100cm/s
     * @endcode
     */
    static void set_speed_limit(uint8_t speed_limit) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100c2c, speed_limit);
    }

    /**
     * @brief 控制传感器屏蔽
     * @param shield_bits 传感器屏蔽位域
     * @details 通过写入共享内存地址0x100e1a来控制传感器的使能/屏蔽。
     * 每个位对应一个传感器:
     *          - 1: 屏蔽对应传感器
     *          - 0: 使能对应传感器
     * 
     * @warning 屏蔽关键传感器可能导致安全隐患
     * 
     * @par 示例:
     * @code
     * ctrl_sensor_shield(0x01);  // 屏蔽传感器1
     * ctrl_sensor_shield(0x00);  // 使能所有传感器
     * @endcode
     */
    static void ctrl_sensor_shield(uint8_t shield_bits) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100e1a, shield_bits);
    }

    /**
     * @brief 控制超声波屏蔽
     * @param shield_bits 超声波屏蔽位域
     * @details 通过写入共享内存地址0x100e1b来控制超声波传感器的使能/屏蔽。
     * 位0-7分别对应超声波1-8:
     *          - 1: 屏蔽对应超声波
     *          - 0: 使能对应超声波
     * 
     * @warning 屏蔽超声波可能影响避障功能
     * 
     * @par 示例:
     * @code
     * ctrl_ultrasound_shield(0x01);  // 屏蔽超声波1
     * ctrl_ultrasound_shield(0x00);  // 使能所有超声波
     * @endcode
     */
    static void ctrl_ultrasound_shield(uint8_t shield_bits) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100e1b, shield_bits);
    }

    /**
     * @brief 控制手动操作
     * @param pad_bits 手动操作控制位域
     * @details 通过写入共享内存地址0x100e1c来控制手动操作功能。
     * 具体位定义见相关文档。
     * 
     * @note 手动操作优先级高于自动控制
     * 
     * @par 示例:
     * @code
     * ctrl_pad(0x01);  // 启动特定手动操作
     * ctrl_pad(0x00);  // 停止所有手动操作
     * @endcode
     */
    static void ctrl_pad(uint16_t pad_bits) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100e1c, pad_bits);
    }

    /**
     * @brief 控制程序重启
     * @param remote_bits 远程重启控制位域
     * @details 通过写入共享内存地址0x100e1e来控制不同模块的重启。
     * 具体位定义见相关文档。
     * 
     * @warning 重启操作可能导致当前任务中断
     * 
     * @par 示例:
     * @code
     * ctrl_remote(0x01);  // 重启特定模块
     * @endcode
     */
    static void ctrl_remote(uint16_t remote_bits) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100e1e, remote_bits);
    }

    /**
     * @brief 控制电梯命令
     * @param lift_cmd_bits 电梯命令控制位域
     * @details 通过写入共享内存地址0x100e20来控制电梯的各种操作。
     * 具体位定义见相关文档。
     * 
     * @note 电梯控制需要确保通信正常
     * 
     * @par 示例:
     * @code
     * ctrl_lift_cmd(0x01);  // 发送特定电梯命令
     * @endcode
     */
    static void ctrl_lift_cmd(uint8_t lift_cmd_bits) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100e20, lift_cmd_bits);
    }

    /**
     * @brief 设置目标楼层
     * @param floor 目标楼层号
     * @details 通过写入共享内存地址0x100e23来设置电梯运行的目标楼层。
     * 楼层编号说明:
     *          - 正值: 地上楼层
     *          - 负值: 地下楼层
     * 
     * @note 设置前应确认电梯状态正常
     * 
     * @par 示例:
     * @code
     * set_target_floor(2);   // 前往2楼
     * set_target_floor(-1);  // 前往地下1楼
     * @endcode
     */
    static void set_target_floor(int8_t floor) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }
        WRITE_VALUE(int8_t, (unsigned char*)shm.get(), 0x100e23, floor);
    }

    /**
     * @brief 车辆状态结构体
     * @details 包含车辆的完整运动状态信息,包括:
     *          - 运动状态标志
     *          - 控制模式
     *          - 行驶距离等
     */
    struct VehicleStatus {
        bool is_moving;              /**< 是否在运动中 */
        bool is_normal_stopped;      /**< 是否正常停止 */
        bool is_emergency_stopped;   /**< 是否紧急停止 */
        bool is_slowed_down;        /**< 是否处于减速状态 */
        bool is_enabled;            /**< 是否使能 */
        int control_mode;           /**< 控制模式(-1:急停,0:导航,1:遥控,5:绕障,7:转运) */
        float totally_distance;     /**< 总行驶距离,单位:m */
    };

    /**
     * @brief 获取车辆状态
     * @return VehicleStatus 车辆状态结构体
     * @details 从共享内存读取当前车辆的完整状态信息,包括:
     *          - 运动状态(0x100070-0x10007C)
     *          - 使能状态(0x100028)
     *          - 控制模式(0x100024)
     *          - 行驶距离(0x100080)
     * 
     * @note 所有状态都会实时更新
     * 
     * @par 示例:
     * @code
     * auto status = get_vehicle_status();
     * if(status.is_moving) {
     *     // 车辆正在运动
     * }
     * @endcode
     */
    static VehicleStatus get_vehicle_status() {
        VehicleStatus status;
        auto shm = get_shm();
        if (!shm) {
            return VehicleStatus();
        }

        status.is_moving = READ_VALUE(int, (unsigned char*)shm.get(), 0x100070) != 0;
        status.is_normal_stopped = READ_VALUE(int, (unsigned char*)shm.get(), 0x100074) != 0;
        status.is_emergency_stopped = READ_VALUE(int, (unsigned char*)shm.get(), 0x100078) != 0;
        status.is_slowed_down = READ_VALUE(int, (unsigned char*)shm.get(), 0x10007C) != 0;
        status.is_enabled = READ_VALUE(int, (unsigned char*)shm.get(), 0x100028) != 0;
        status.control_mode = READ_VALUE(int, (unsigned char*)shm.get(), 0x100024);
        status.totally_distance = READ_VALUE(double, (unsigned char*)shm.get(), 0x100080);

        return status;
    }

    /**
     * @brief 获取车辆是否处于锁车状态
     * @return bool 返回车辆锁车状态
     *         - true: 车辆处于锁车状态
     *         - false: 车辆处于挪车状态
     * 
     * @note 锁车状态会实时更新
     * 
     * @par 示例:
     * @code
     * if(is_chassis_locked()) {
     *     // 车辆已锁车,禁止运动
     * }
     * @endcode
     */
    static bool is_chassis_locked() {
        auto shm = get_shm();
        if (!shm) {
            return false;
        }
        uint8_t lock_status = READ_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100e1c);
        if (lock_status == 1) {
            return false;
        } else {
            return true;
        }
    }


    /**
     * @brief 控制车辆锁车状态
     * @param cmd 锁车命令
     *        - true: 锁车
     *        - false: 解锁
     * @return bool 返回控制结果
     *         - true: 控制成功
     *         - false: 控制失败(共享内存访问失败)
     * 
     * @note 锁车状态会立即生效
     * 
     * @par 示例:
     * @code
     * // 锁定车辆
     * ctrl_chassis_lock(true);
     * 
     * // 解锁车辆
     * ctrl_chassis_lock(false);
     * @endcode
     */
    static bool ctrl_chassis_lock(bool cmd) {
        auto shm = get_shm();
        if (!shm) {
            return false;
        }
        uint8_t lock_status = READ_VALUE(uint8_t, (unsigned char*)shm.get(),0x105f5c);
        if (cmd) {
            lock_status &= ~(1 << 0); // Clear bit 0
        } else {
            lock_status |= (1 << 0); // Set bit 0
        }
        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x105f5c, lock_status);
        return true;
    }

    /**
     * @brief 获取清扫设备状态
     * @return CleaningDeviceStatus 清扫设备状态结构体
     * @details 从共享内存读取当前清扫设备的完整状态信息,包括:
     *          - 滚刷和风机速度(0x100c0e, 0x100c0c)
     *          - 设备状态位域(0x100c1c)
     *          - 错误码(0x105f34, 0x100c18)
     * 
     * @note 状态会实时更新
     * 
     * @par 示例:
     * @code
     * auto status = get_cleaning_device_status();
     * if(status.brush_down) {
     *     // 滚刷已降下
     * }
     * @endcode
     */
    static CleaningDeviceStatus get_cleaning_device_status() {
        CleaningDeviceStatus status;
        auto shm = get_shm();
        if (!shm) {
            return CleaningDeviceStatus();
        }

        // 读取实际速度
        status.actual_brush_speed = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c0e);
        status.actual_fan_speed = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100c0c);

        // 读取sweep_status位域
        uint32_t sweep_status = READ_VALUE(uint32_t, (unsigned char*)shm.get(), 0x100c1c);
        
        // 解析状态位
        status.sewage_level = sweep_status & 0xF;
        status.clean_water_level = (sweep_status >> 4) & 0xF;
        status.spray_valve_on = (sweep_status >> 8) & 0x1;
        status.clean_drain_valve_on = (sweep_status >> 9) & 0x1;
        status.sewage_drain_valve_on = (sweep_status >> 10) & 0x1;
        status.suction_pump_on = (sweep_status >> 11) & 0x1;
        status.suction_valve_on = (sweep_status >> 12) & 0x1;
        status.brush_down = (sweep_status >> 13) & 0x1;
        status.suction_down = (sweep_status >> 14) & 0x1;
        status.selfclean_pump_on = (sweep_status >> 16) & 0x1;
        status.selfclean_valve_on = (sweep_status >> 17) & 0x1;
        status.cycle_pump_on = (sweep_status >> 18) & 0x1;
        status.cycle_valve_on = (sweep_status >> 19) & 0x1;

        // 读取错误码
        status.sweep_err_code1 = READ_VALUE(uint32_t, (unsigned char*)shm.get(), 0x100C14);
        status.sweep_err_code2 = READ_VALUE(uint32_t, (unsigned char*)shm.get(), 0x100c18);

        return status;
    }

    /**
     * @brief 获取车辆锁定状态
     * @return bool true表示车辆锁定,false表示车辆未锁定
     * @details 从共享内存读取PSD状态位域,检查b0位判断车辆是否锁定
     * 
     * @note 此函数用于检查车辆是否处于锁定状态
     */
    static bool is_car_locked() {
        auto shm = get_shm();
        if (!shm) {
            return false;
        }
        
        uint16_t psd_status = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100c22);
        if (psd_status == 1) {
            return true;
        }
        return false;
    }


    /**
     * @brief 错误码定义
     * @details 定义了系统可能出现的各种错误状态:
     *          - ERR_NONE: 无错误,系统正常
     *          - ERR_EMERGENCY_STOP: 急停按钮被按下
     *          - ERR_SWEEP_DRIVE: 清洗驱动器通信超时
     *          - ERR_RS485_0/1: RS485通信超时
     *          - ERR_DU88D: DU88D通信超时
     *          - ERR_IMU: IMU通信超时
     *          - ERR_PSD: PSD通信超时
     *          - ERR_BATTERY: 电池通信故障
     *          - ERR_WATER_LEVEL_LOW: 清水液位过低
     *          - ERR_SEWAGE_LEVEL_HIGH: 污水液位过高
     */
    enum ErrorCode {
        ERR_NONE = 0,                /**< 无错误 */
        ERR_EMERGENCY_STOP = 1,      /**< 急停触发 */
        ERR_SWEEP_DRIVE = 2,         /**< 清洗驱动器超时 */
        ERR_RS485_0 = 3,            /**< 0#RS485超时 */
        ERR_RS485_1 = 4,            /**< 1#RS485超时 */
        ERR_DU88D = 5,              /**< DU88D超时 */
        ERR_IMU = 6,                /**< IMU超时 */
        ERR_PSD = 7,                /**< PSD超时 */
        ERR_BATTERY = 8,            /**< 电池通讯故障 */
        ERR_WATER_LEVEL_LOW = 9,    /**< 清水液位过低 */
        ERR_SEWAGE_LEVEL_HIGH = 10, /**< 污水液位过高 */
    };

    /**
     * @brief 获取系统错误状态
     * @return int 错误码,0表示无错误
     * @details 检查系统各个部分的状态,返回当前最严重的错误。
     *          按照优先级顺序检查:
     *          1. 急停状态
     *          2. 驱动器通信状态
     *          3. 各种通信模块状态
     *          4. 液位状态
     * 
     * @note 返回值对应ErrorCode枚举中定义的错误码
     * 
     * @par 示例:
     * @code
     * int err = get_error_status();
     * if(err != ERR_NONE) {
     *     // 处理错误
     * }
     * @endcode
     */
    static int get_error_status() {
        auto shm = get_shm();
        if (!shm) {
            return -1;
        }

        uint16_t veh_status = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100c04);
        uint32_t sweep_status = READ_VALUE(uint32_t, (unsigned char*)shm.get(), 0x100c1c);
        
        if (veh_status & (1 << 3)) return ERR_EMERGENCY_STOP;
        if (veh_status & (1 << 4)) return ERR_SWEEP_DRIVE;
        if (veh_status & (1 << 5)) return ERR_RS485_0;
        if (veh_status & (1 << 6)) return ERR_RS485_1;
        if (veh_status & (1 << 7)) return ERR_DU88D;
        if (veh_status & (1 << 8)) return ERR_IMU;
        if (veh_status & (1 << 9)) return ERR_PSD;
        if (veh_status & (1 << 12)) return ERR_BATTERY;

        uint8_t clean_water_level = (sweep_status >> 4) & 0xF;
        uint8_t sewage_level = sweep_status & 0xF;
        
        if (clean_water_level <= 2) return ERR_WATER_LEVEL_LOW;
        if (sewage_level >= 13) return ERR_SEWAGE_LEVEL_HIGH;

        return ERR_NONE;
    }

    /**
     * @brief 工作站控制命令结构体
     * @details 包含了控制工作站的各种命令标志:
     *          - enable_comm: 工作站通讯使能
     *          - charger_power: 工作站充电器下电
     *          - water_supply: 工作站加水
     *          - water_drain: 工作站排水
     */
    struct StationCmd {
        bool enable_comm;        /**< 工作站通讯使能 */
        bool charger_power;      /**< 工作站充电器下电 */
        bool water_supply;       /**< 工作站加水 */
        bool water_drain;        /**< 工作站排水 */
    };

    /**
     * @brief 工作站状态结构体
     * @details 包含了工作站的各种状态标志:
     *          - 通讯状态
     *          - 加水/排水状态
     *          - 充电状态
     *          - 水路状态
     *          - 耗材状态
     */
    struct StationStatus {
        bool comm_ok;           /**< 工作站通讯成功 */
        bool water_supply_ok;   /**< 工作站加水到位 */
        bool water_drain_ok;    /**< 工作站排水到位 */
        bool charge_ok;         /**< 工作站充电到位 */
        bool water_path_ok;     /**< 工作站水路到位 */
        bool charge_current_ok; /**< 充电电流感应开关 */
        bool flow_switch_ok;    /**< 流量开关 */
        bool clean_water_empty; /**< 清水空 */
        bool sewage_full;       /**< 污水满 */
        bool foam_empty;        /**< 消泡剂空 */
        bool cleaner_empty;     /**< 清洁剂空 */
    };

    /**
     * @brief 控制工作站
     * @param cmd 工作站控制命令结构体
     * @details 根据命令结构体中的标志位控制工作站的各种功能:
     *          - bit0: 通讯使能
     *          - bit1: 充电器下电
     *          - bit3: 加水
     *          - bit4: 排水
     * 
     * @par 示例:
     * @code
     * StationCmd cmd;
     * cmd.enable_comm = true;
     * cmd.water_supply = true;
     * ctrl_station(cmd);  // 使能通讯并开始加水
     * @endcode
     */
    static void ctrl_station(const StationCmd& cmd) {
        auto shm = get_shm();
        if (!shm) {
            return;
        }

        uint8_t value = 0;
        if (cmd.enable_comm) value |= (1 << 0);
        if (cmd.charger_power) value |= (1 << 1);
        if (cmd.water_supply) value |= (1 << 3);
        if (cmd.water_drain) value |= (1 << 4);

        WRITE_VALUE(uint8_t, (unsigned char*)shm.get(), 0x105f40, value);
    }

    /**
     * @brief 获取工作站状态
     * @return StationStatus 工作站状态结构体
     * @details 从共享内存读取工作站的完整状态信息:
     *          - 通讯状态(bit0)
     *          - 加水/排水状态(bit1-2)
     *          - 充电状态(bit8)
     *          - 水路状态(bit9-11)
     *          - 耗材状态(bit12-15)
     * 
     * @note 所有状态都会实时更新
     * 
     * @par 示例:
     * @code
     * auto status = get_station_status_struct();
     * if(status.water_supply_ok) {
     *     // 加水完成
     * }
     * @endcode
     */
    static StationStatus get_station_status_struct() {
        StationStatus status = {};
        auto shm = get_shm();
        if (!shm) {
            return status;
        }

        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100a20);
        
        status.comm_ok = value & (1 << 0);
        status.water_supply_ok = value & (1 << 1);
        status.water_drain_ok = value & (1 << 2);
        status.charge_ok = value & (1 << 8);
        status.water_path_ok = value & (1 << 9);
        status.charge_current_ok = value & (1 << 10);
        status.flow_switch_ok = value & (1 << 11);
        status.clean_water_empty = value & (1 << 12);
        status.sewage_full = value & (1 << 13);
        status.foam_empty = value & (1 << 14);
        status.cleaner_empty = value & (1 << 15);

        return status;
    }

    /**
     * @brief 车辆状态位域结构体
     * @details 解析mcurx.veh_status的各个位的含义:
     *          - 电源状态(bit0)
     *          - 急停状态(bit3)
     *          - 通信状态(bit4-9)
     *          - 关机状态(bit10-11)
     *          - 电池状态(bit12)
     */
    struct VehStatusBits {
        bool power_on;              /**< 开机信号(b0) */
        bool emergency_stop;        /**< 急停触发(b3) */
        bool sweep_drive_timeout;   /**< 清洗驱动器超时(b4) */
        bool rs485_0_timeout;       /**< 0#RS485超时(b5) */
        bool rs485_1_timeout;       /**< 1#RS485超时(b6) */
        bool du88d_timeout;         /**< DU88D超时(b7) */
        bool imu_timeout;           /**< IMU超时(b8) */
        bool psd_timeout;           /**< PSD超时(b9) */
        bool power_off;             /**< 关机标志位(b10-11) */
        bool battery_comm_error;    /**< 电池通讯故障(b12) */
    };

    /**
     * @brief 获取车辆状态位域
     * @return VehStatusBits 车辆状态位域结构体
     * @details 从共享内存读取并解析车辆状态位域,包含了车辆的各种状态标志位:
     *          - 电源状态(bit0)
     *          - 急停状态(bit3)
     *          - 通信状态(bit4-9)
     *          - 关机状态(bit10-11)
     *          - 电池状态(bit12)
     * 
     * @note 读取地址为0x100c04,数据类型为uint16_t
     * 
     * @par 示例:
     * @code
     * auto bits = get_veh_status_bits();
     * if(bits.emergency_stop) {
     *     // 处理急停状态
     * }
     * @endcode
     */
    static VehStatusBits get_veh_status_bits() {
        VehStatusBits bits = {};
        auto shm = get_shm();
        if (!shm) {
            return bits;
        }

        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100c04);
        
        bits.power_on = value & (1 << 0);
        bits.emergency_stop = value & (1 << 3);
        bits.sweep_drive_timeout = value & (1 << 4);
        bits.rs485_0_timeout = value & (1 << 5);
        bits.rs485_1_timeout = value & (1 << 6);
        bits.du88d_timeout = value & (1 << 7);
        bits.imu_timeout = value & (1 << 8);
        bits.psd_timeout = value & (1 << 9);
        bits.power_off = (value >> 10) & 0x3;
        bits.battery_comm_error = value & (1 << 12);

        return bits;
    }

    /**
     * @brief 传感器状态位域结构体
     * @details 用于解析mcurx.sensor_status的各个位,包含了各种传感器的触发状态:
     *          - 防跌落传感器(bit0-1)
     *          - 碰撞传感器(bit4)
     *          - 压脚传感器(bit5)
     * 
     * @note 每个位代表一个传感器的状态,1表示触发,0表示未触发
     */
    struct SensorStatusBits {
        bool left_drop;       /**< 左防跌落触发状态(bit0) */
        bool right_drop;      /**< 右防跌落触发状态(bit1) */
        bool front_bump;      /**< 前触边触发状态(bit4) */
        bool foot_guard;      /**< 压脚触发状态(bit5) */
    };

    /**
     * @brief 获取传感器状态位域
     * @return SensorStatusBits 传感器状态位域结构体
     * @details 从共享内存读取并解析传感器状态位域,包含了各传感器的触发状态:
     *          - 防跌落传感器(bit0-1)
     *          - 碰撞传感器(bit4)
     *          - 压脚传感器(bit5)
     * 
     * @note 读取地址为0x100a5c,数据类型为uint16_t
     * 
     * @par 示例:
     * @code
     * auto bits = get_sensor_status_bits();
     * if(bits.front_bump) {
     *     // 处理碰撞
     * }
     * @endcode
     */
    static SensorStatusBits get_sensor_status_bits() {
        SensorStatusBits bits = {};
        auto shm = get_shm();
        if (!shm) {
            return bits;
        }

        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100a5c);
        
        bits.left_drop = value & (1 << 0);
        bits.right_drop = value & (1 << 1);
        bits.front_bump = value & (1 << 4);
        bits.foot_guard = value & (1 << 5);

        return bits;
    }

    /**
     * @brief 超声波错误状态位域结构体
     * @details 用于解析mcurx.ultrasonic_err的各个位,表示8个超声波传感器的故障状态
     * 
     * @note 每个位代表一个超声波传感器的故障状态,1表示故障,0表示正常
     */
    struct UltrasonicErrorBits {
        bool ultrasonic_error[8];  /**< 超声波1-8的故障状态数组,索引0-7对应超声波1-8 */
    };

    /**
     * @brief 获取超声波错误状态位域
     * @return UltrasonicErrorBits 超声波错误状态位域结构体
     * @details 从共享内存读取并解析超声波错误状态位域,包含了8个超声波传感器的故障状态
     * 
     * @note 读取地址为0x100a5e,数据类型为uint16_t
     * 
     * @par 示例:
     * @code
     * auto bits = get_ultrasonic_error_bits();
     * if(bits.ultrasonic_error[0]) {
     *     // 处理1号超声波故障
     * }
     * @endcode
     */
    static UltrasonicErrorBits get_ultrasonic_error_bits() {
        UltrasonicErrorBits bits = {};
        auto shm = get_shm();
        if (!shm) {
            return bits;
        }

        uint16_t value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x100a5e);
        
        for(int i = 0; i < 8; i++) {
            bits.ultrasonic_error[i] = value & (1 << i);
        }

        return bits;
    }

    /**
     * @brief 电梯状态位域结构体
     * @details 用于解析mcurx.lift_status的各个位,包含了电梯的各种工作状态。
     * 每个位代表电梯的一种状态,1表示该状态激活,0表示未激活。
     * 
     * @note 结构体成员对应共享内存地址0x100a60的各个位
     */
    struct LiftStatusBits {
        bool door_open;      /**< 电梯门状态(bit0),1表示开门,0表示关门 */
        bool offline;        /**< 电梯离线状态(bit1),1表示离线,0表示在线 */
        bool error;          /**< 电梯故障状态(bit2),1表示故障,0表示正常 */
    };

    /**
     * @brief 获取电梯状态位域
     * @return LiftStatusBits 电梯状态位域结构体
     * @details 从共享内存读取并解析电梯状态位域,包含了电梯的门状态、在线状态和故障状态。
     * 通过读取共享内存地址0x100a60的值,解析各个位的含义。
     * 
     * @note 读取地址为0x100a60,数据类型为uint8_t
     * 
     * @par 示例:
     * @code
     * auto bits = get_lift_status_bits();
     * if(bits.door_open) {
     *     // 电梯门开启
     * }
     * if(bits.offline) {
     *     // 电梯离线
     * }
     * if(bits.error) {
     *     // 电梯故障
     * }
     * @endcode
     */
    static LiftStatusBits get_lift_status_bits() {
        LiftStatusBits bits = {};
        auto shm = get_shm();
        if (!shm) {
            return bits;
        }

        uint8_t value = READ_VALUE(uint8_t, (unsigned char*)shm.get(), 0x100a60);
        
        bits.door_open = value & (1 << 0);
        bits.offline = value & (1 << 1);
        bits.error = value & (1 << 2);

        return bits;
    }

    /**
     * @brief 检查是否可以安全移动
     * @return bool true表示可以安全移动,false表示不能安全移动
     * @details 综合检查多个安全相关的状态,包括:
     *          - 车辆关键状态(急停、驱动器超时、电源状态)
     *          - 传感器状态(防跌落、碰撞检测)
     * 
     * 任何安全相关的状态异常都会导致返回false,包括:
     * - 急停按钮被按下
     * - 清洁驱动器通信超时
     * - 电源未开启
     * - 防跌落传感器触发
     * - 碰撞传感器触发
     * 
     * @note 此函数用于机器人移动前的安全检查
     * 
     * @par 示例:
     * @code
     * if(is_safe_to_move()) {
     *     // 可以安全移动
     *     start_moving();
     * } else {
     *     // 存在安全隐患,不能移动
     *     stop_moving();
     * }
     * @endcode
     */
    static bool is_safe_to_move() {
        auto veh_status = get_veh_status_bits();
        auto sensor_status = get_sensor_status_bits();
        
        // 检查关键故障
        if (veh_status.emergency_stop || 
            veh_status.sweep_drive_timeout || 
            !veh_status.power_on) {
            return false;
        }

        // 检查防跌落和碰撞
        if (sensor_status.left_drop || 
            sensor_status.right_drop || 
            sensor_status.front_bump || 
            sensor_status.foot_guard) {
            return false;
        }

        return true;
    }

    /**
     * @brief 检查是否可以开始清扫
     * @return bool true表示可以开始清扫,false表示不能开始清扫
     * @details 综合检查清扫相关的各项条件,包括:
     *          - 清水箱和污水箱液位
     *          - 清扫系统故障状态
     *          - 安全移动条件
     * 
     * 以下任一条件不满足都会返回false:
     * - 清水箱液位低于2格
     * - 污水箱液位高于13格
     * - 清扫系统存在故障(错误码不为0)
     * - 不满足安全移动条件
     * 
     * @note 此函数用于清扫任务开始前的状态检查
     * 
     * @par 示例:
     * @code
     * if(is_ready_to_clean()) {
     *     // 可以开始清扫
     *     start_cleaning();
     * } else {
     *     // 条件不满足,不能清扫
     *     show_error();
     * }
     * @endcode
     */
    static bool is_ready_to_clean() {
        auto cleaning_status = get_cleaning_device_status();
        
        // 检查水位
        if (cleaning_status.clean_water_level <= 2 || 
            cleaning_status.sewage_level >= 13) {
            return false;
        }

        // 检查设备状态
        if (cleaning_status.sweep_err_code1 != 0 || 
            cleaning_status.sweep_err_code2 != 0) {
            return false;
        }

        // 检查是否可以安全移动
        if (!is_safe_to_move()) {
            return false;
        }

        return true;
    }

    /**
     * @brief 检查是否需要维护
     * @return bool true表示需要维护,false表示不需要维护
     * @details 综合检查需要维护的各项条件,包括:
     *          - 通信系统故障(RS485、DU88D、IMU、PSD、电池通信)
     *          - 清扫系统故障
     *          - 耗材状态(清水、污水、泡沫、清洁剂)
     * 
     * 以下任一条件满足都会返回true:
     * - RS485通信超时
     * - DU88D通信超时
     * - IMU通信超时
     * - PSD通信超时
     * - 电池通信错误
     * - 清扫系统故障(错误码不为0)
     * - 清水箱空
     * - 污水箱满
     * - 泡沫箱空
     * - 清洁剂箱空
     * 
     * @note 此函数用于检查设备是否需要维护或补充耗材
     * 
     * @par 示例:
     * @code
     * if(need_maintenance()) {
     *     // 需要维护
     *     notify_maintenance();
     * }
     * @endcode
     */
    static bool need_maintenance() {
        auto veh_status = get_veh_status_bits();
        auto cleaning_status = get_cleaning_device_status();
        auto station_status = get_station_status_struct();
        
        // 检查通信故障
        if (veh_status.rs485_0_timeout || 
            veh_status.rs485_1_timeout || 
            veh_status.du88d_timeout || 
            veh_status.imu_timeout || 
            veh_status.psd_timeout || 
            veh_status.battery_comm_error) {
            return true;
        }

        // 检查清扫系统故障
        if (cleaning_status.sweep_err_code1 != 0 || 
            cleaning_status.sweep_err_code2 != 0) {
            return true;
        }

        // 检查耗材状态
        if (station_status.clean_water_empty || 
            station_status.sewage_full || 
            station_status.foam_empty || 
            station_status.cleaner_empty) {
            return true;
        }

        return false;
    }

    /**
     * @brief 电池状态结构体
     * @details 包含了电池的完整状态信息,包括:
     *          - 充电状态
     *          - 电压电流信息
     *          - 容量信息
     *          - 循环次数
     *          - 剩余电量百分比
     */
    struct BatteryStatus {
        bool is_charging;       /**< 电池充电状态,true表示正在充电,false表示未充电 */
        bool charging_signal;  /**< 充电信号,true表示有充电信号,false表示无充电信号 */
        float battery_voltage;    /**< 电池电压,单位:V */
        float battery_current;    /**< 电池电流,单位:A */
        int total_capacity;     /**< 电池总容量,单位:mAh */
        int left_capacity;      /**< 电池剩余容量,单位:mAh */
        int cycle_count;        /**< 电池充放电循环次数 */
        float current_power_percent;  /**< 当前电量百分比(0-100) */
    };

    /**
     * @brief 获取电池状态
     * @return BatteryStatus 电池状态结构体
     * @details 从共享内存读取电池的完整状态信息,包括:
     *          - 充电状态(0x10080e bit1)
     *          - 电压(0x100832)
     *          - 电流(0x100834)
     *          - 总容量(0x100836)
     *          - 剩余容量(0x100838)
     *          - 循环次数(0x10083a)
     * 
     * @note 电压和电流值需要除以100转换为实际值
     * 
     * @par 示例:
     * @code
     * auto status = get_battery_status();
     * if(status.is_charging) {
     *     // 电池正在充电
     * }
     * printf("电池电量: %.1f%%\n", status.current_power_percent);
     * @endcode
     */
    static BatteryStatus get_battery_status() {
        BatteryStatus status = {};
        auto shm = get_shm();
        if (!shm) {
            return status;
        }

        // 0x10080e bit1: 充电状态位, bit2: 充电接触状态
        uint16_t mask = READ_VALUE(uint16_t, (unsigned char*)shm.get(), 0x10080e);
        status.is_charging = (mask >> 1) & 0x0001;
        status.charging_signal = (mask >> 2) & 0x0001;

        // 0x100832: 电池电压 (单位:0.01V)
        status.battery_voltage = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100832) / 100.0f;

        // 0x100834: 电池电流 (单位:0.01A, 充电>0，放电<0)
        status.battery_current = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100834) / 100.0f;

        // 0x100836: 电池总容量 (单位:mAh)
        status.total_capacity = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100836);

        // 0x100838: 剩余容量 (单位:mAh)
        status.left_capacity = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x100838);

        // 0x10083a: 充放电循环次数
        status.cycle_count = READ_VALUE(int16_t, (unsigned char*)shm.get(), 0x10083a);

        // 计算当前电量百分比
        status.current_power_percent = ((float)status.left_capacity / status.total_capacity) * 100;

        return status;
    }

    /**
     * @brief 传感器状态结构体
     * @details 包含了所有传感器的状态信息,包括:
     *          - 防跌落传感器(左右)
     *          - 碰撞传感器
     *          - 防压脚传感器
     *          - 6个超声波传感器的距离值
     */
    struct SensorStatus {
        bool left_drop;          /**< 左防跌落传感器状态,true表示触发(检测到悬空) */
        bool right_drop;         /**< 右防跌落传感器状态,true表示触发(检测到悬空) */
        bool bumper;             /**< 碰撞传感器状态,true表示触发(发生碰撞) */
        bool foot_protection;    /**< 防压脚传感器状态,true表示触发(检测到障碍) */
        int16_t ultrasound1;     /**< 超声波1距离值,单位:mm */
        int16_t ultrasound2;     /**< 超声波2距离值,单位:mm */
        int16_t ultrasound3;     /**< 超声波3距离值,单位:mm */
        int16_t ultrasound4;     /**< 超声波4距离值,单位:mm */
        int16_t ultrasound5;     /**< 超声波5距离值,单位:mm */
        int16_t ultrasound6;     /**< 超声波6距离值,单位:mm */
    };

    /**
     * @brief 获取传感器状态
     * @return SensorStatus 传感器状态结构体
     * @details 从共享内存读取所有传感器的状态信息:
     *          - 传感器状态字(0x100c5c)
     *          - 超声波距离数据(0x100c28-0x100c33)
     * 
     * @note 超声波距离值单位为毫米
     * 
     * @par 示例:
     * @code
     * auto status = get_sensor_status();
     * if(status.left_drop || status.right_drop) {
     *     // 检测到悬空,停止移动
     * }
     * if(status.ultrasound1 < 200) {
     *     // 前方障碍物距离小于20cm
     * }
     * @endcode
     */
    static SensorStatus get_sensor_status() {
        SensorStatus status = {};
        auto shm = get_shm();
        if (!shm) {
            return status;
        }

        // 读取传感器状态字 (0x100c5c)
        uint16_t sensor_value = READ_VALUE(uint16_t, (unsigned char*)shm.get(), MCU_RX_BASE + 0x5c);
        status.left_drop = sensor_value & (1 << 0);
        status.right_drop = sensor_value & (1 << 1);
        status.bumper = sensor_value & (1 << 4);
        status.foot_protection = sensor_value & (1 << 5);

        // 读取超声波数据 (0x100c28-0x100c33)
        for(int i = 0; i < 6; i++) {
            uint16_t ultrasonic_data = READ_VALUE(uint16_t, (unsigned char*)shm.get(), MCU_RX_BASE + 0x28 + i*2);
            switch(i) {
                case 0: status.ultrasound1 = ultrasonic_data; break;
                case 1: status.ultrasound2 = ultrasonic_data; break;
                case 2: status.ultrasound3 = ultrasonic_data; break;
                case 3: status.ultrasound4 = ultrasonic_data; break;
                case 4: status.ultrasound5 = ultrasonic_data; break;
                case 5: status.ultrasound6 = ultrasonic_data; break;
            }
        }

        return status;
    }

}
