#include "shm_grace.h"
#include <iostream>
#include <ctime>
#include <unistd.h>

// [DONE]
void test_get_odom() {
    for(int i = 0; i < 10; i++) {
        // Test getting odometry data
        auto odom = Grace::get_odom();
        
        std::cout << "里程计数据:" << std::endl;
        std::cout << "线速度 X: " << odom.vehicle_linear_x << std::endl;
        std::cout << "线速度 Y: " << odom.vehicle_linear_y << std::endl; 
        std::cout << "角速度 Z: " << odom.vehicle_angular_z << std::endl;
        std::cout << "位置 X: " << odom.odom_x << std::endl;
        std::cout << "位置 Y: " << odom.odom_y << std::endl;
        std::cout << "角度: " << odom.odom_theta << std::endl;
        std::cout << "时间戳: " << odom.timestamp << std::endl;

        std::cout << "----------------------------------------" << std::endl;
    }
}

// ? 
void test_front_light_ctrl() {
    std::cout << "测试前灯控制..." << std::endl;
    Grace::ctrl_front_light_cmd(true);
    std::cout << "前灯已打开" << std::endl;
    sleep(1);
    Grace::ctrl_front_light_cmd(false);
    std::cout << "前灯已关闭" << std::endl;
}

// ? 
void test_search_light_ctrl() {
    std::cout << "测试前探照灯控制..." << std::endl;
    Grace::ctrl_search_light_cmd(true);
    std::cout << "前探照灯已打开" << std::endl;
    sleep(1);
    Grace::ctrl_search_light_cmd(false);
    std::cout << "前探照灯已关闭" << std::endl;
}

// [DONE]
void test_water_pump() {
    std::cout << "测试喷水泵控制..." << std::endl;
    
    // Test different speeds
    std::cout << "设置喷水泵速度为 1000 rpm" << std::endl;
    Grace::ctrl_water_speed(1000);
    sleep(1);
    
    std::cout << "设置喷水泵速度为 2000 rpm" << std::endl;
    Grace::ctrl_water_speed(2000);
    sleep(1);
    
    std::cout << "设置喷水泵速度为 0 rpm" << std::endl;
    Grace::ctrl_water_speed(0);
}

// [DONE]
void test_brush() {
    std::cout << "测试刷盘控制..." << std::endl;
    
    // Test brush speed
    std::cout << "设置刷盘速度为 500 rpm" << std::endl;
    Grace::ctrl_brush_speed(500);
    sleep(3);
    
    std::cout << "设置刷盘速度为 1000 rpm" << std::endl;
    Grace::ctrl_brush_speed(1000);
    sleep(3);


    std::cout << "设置刷盘速度为 1500 rpm" << std::endl;
    Grace::ctrl_brush_speed(1500);
    sleep(3);

    std::cout << "设置刷盘速度为 2000 rpm" << std::endl;
    Grace::ctrl_brush_speed(2000);
    sleep(3);

    std::cout << "设置刷盘速度为 2500 rpm" << std::endl;
    Grace::ctrl_brush_speed(2500);
    sleep(3);

    std::cout << "设置刷盘速度为 3000 rpm" << std::endl;
    Grace::ctrl_brush_speed(3000);
    sleep(3);
    
    std::cout << "设置刷盘速度为 0 rpm" << std::endl;
    Grace::ctrl_brush_speed(0);
}

// [DONE]
void test_supply_pump() {
    std::cout << "测试加水泵控制..." << std::endl;
    Grace::ctrl_supply_pump_cmd(true);
    std::cout << "加水泵已打开" << std::endl;
    sleep(1);
    Grace::ctrl_supply_pump_cmd(false);
    std::cout << "加水泵已关闭" << std::endl;
}


// [DONE]
void test_lifter() {
    std::cout << "测试刷盘升降控制..." << std::endl;
    Grace::ctrl_lifter_cmd(true);
    std::cout << "刷盘已降下" << std::endl;
    sleep(3);
    Grace::ctrl_lifter_cmd(false);
    std::cout << "刷盘已升起" << std::endl;
}

// [DONE]
void test_suction() {
    std::cout << "测试吸趴(滚刷)控制..." << std::endl;
    Grace::ctrl_suction_cmd(true);
    std::cout << "吸趴(滚刷)已降下" << std::endl;
    sleep(3);
    Grace::ctrl_suction_cmd(false);
    std::cout << "吸趴(滚刷)已升起" << std::endl;
}

// [DONE]
void test_water_spray_solenoid_valve() {
    std::cout << "测试喷水电磁阀控制..." << std::endl;
    Grace::ctrl_water_suction_cmd(true);
    std::cout << "喷水电磁阀已打开" << std::endl;
    sleep(3);
    Grace::ctrl_water_suction_cmd(false);
    std::cout << "喷水电磁阀已关闭" << std::endl;
}

// [DONE]
void test_water_speed() {
    std::cout << "测试喷水泵速度控制..." << std::endl;
    Grace::ctrl_water_speed(1000);
    std::cout << "喷水泵速度已设置为 1000 rpm" << std::endl;
    sleep(3);
    Grace::ctrl_water_speed(2000);
    std::cout << "喷水泵速度已设置为 2000 rpm" << std::endl;
    sleep(3);
    Grace::ctrl_water_speed(3000);
    std::cout << "喷水泵速度已设置为 3000 rpm" << std::endl;
    sleep(3);
    Grace::ctrl_water_speed(0);
    std::cout << "喷水泵速度已设置为 0 rpm" << std::endl;
}

// [DONE]
void test_ctrl_supply_pump_cmd() {
    std::cout << "测试加水泵控制..." << std::endl;
    Grace::ctrl_supply_pump_cmd(true);
    std::cout << "加水泵已打开" << std::endl;
    sleep(3);
    Grace::ctrl_supply_pump_cmd(false);
    std::cout << "加水泵已关闭" << std::endl;
}

// [DONE]
void test_sewage_drain_ball_valve() {
    std::cout << "测试污水排水阀控制..." << std::endl;
    Grace::ctrl_sewage_drain_ball_cmd(true);
    std::cout << "污水排水阀已打开" << std::endl;
    sleep(3);
    Grace::ctrl_sewage_drain_ball_cmd(false);
    std::cout << "污水排水阀已关闭" << std::endl;
}

// 测试MCU状态获取
// [TODO]
void test_mcu_status() {
    std::cout << "测试MCU状态获取..." << std::endl;
    auto status = Grace::get_mcu_status();
    
    std::cout << "左轮毂电流: " << status.wheel_current_l << "A" << std::endl;
    std::cout << "右轮毂电流: " << status.wheel_current_r << "A" << std::endl;
    std::cout << "喷水泵速度: " << status.spray_real_sp << "%" << std::endl;
    std::cout << "风机速度: " << status.wind_real_sp << "%" << std::endl;
    std::cout << "滚刷速度: " << status.brush_real_sp << "%" << std::endl;
    std::cout << "风机电流: " << status.wind_real_current << "A" << std::endl;
    std::cout << "滚刷电流: " << status.brush_real_current << "A" << std::endl;
    std::cout << "清水液位: " << status.liquid1 << "mm" << std::endl;
    std::cout << "污水液位: " << status.liquid2 << "mm" << std::endl;
    std::cout << "故障码1: 0x" << std::hex << status.sweep_err_code1 << std::endl;
    std::cout << "故障码2: 0x" << std::hex << status.sweep_err_code2 << std::dec << std::endl;
}

// 测试超声波数据获取
// [TODO]
void test_ultrasonic() {
    std::cout << "测试超声波数据获取..." << std::endl;
    for(int i = 1; i <= 6; i++) {
        uint16_t distance = Grace::get_ultrasonic_data(i);
        std::cout << "超声波" << i << ": " << distance << "mm" << std::endl;
    }
}

// 测试IMU数据获取
// [TODO]
void test_imu() {
    std::cout << "测试IMU数据获取..." << std::endl;
    auto imu = Grace::get_imu_data();
    
    std::cout << "角速度 X: " << imu.x_angle_speed << "°/s" << std::endl;
    std::cout << "角速度 Y: " << imu.y_angle_speed << "°/s" << std::endl;
    std::cout << "角速度 Z: " << imu.z_angle_speed << "°/s" << std::endl;
    std::cout << "加速度 X: " << imu.x_acc << "mg" << std::endl;
    std::cout << "加速度 Y: " << imu.y_acc << "mg" << std::endl;
    std::cout << "加速度 Z: " << imu.z_acc << "mg" << std::endl;
    std::cout << "温度: " << imu.gyro_temp << "℃" << std::endl;
    std::cout << "时间戳: " << imu.timestamp << "ms" << std::endl;
}

// 测试传感器状态获取
void test_sensor_status() {
    std::cout << "测试传感器状态获取..." << std::endl;
    auto bits = Grace::get_sensor_status_bits();
    
    std::cout << "左防跌落: " << (bits.left_drop ? "触发" : "正常") << std::endl;
    std::cout << "右防跌落: " << (bits.right_drop ? "触发" : "正常") << std::endl;
    std::cout << "前触边: " << (bits.front_bump ? "触发" : "正常") << std::endl;
    std::cout << "压��: " << (bits.foot_guard ? "触发" : "正常") << std::endl;
}

// 测试超声波错误状态
// [TODO]
void test_ultrasonic_error() {
    std::cout << "测试超声波错误状态..." << std::endl;
    auto bits = Grace::get_ultrasonic_error_bits();
    
    for(int i = 0; i < 8; i++) {
        std::cout << "超声波" << (i+1) << ": " 
                  << (bits.ultrasonic_error[i] ? "故障" : "正常") << std::endl;
    }
}

// 测试电梯状态
void test_lift_status() {
    std::cout << "测试电梯状态..." << std::endl;
    auto bits = Grace::get_lift_status_bits();
    
    std::cout << "电梯门: " << (bits.door_open ? "开" : "关") << std::endl;
    std::cout << "电梯状态: " << (bits.offline ? "离线" : "在线") << std::endl;
    std::cout << "电梯故障: " << (bits.error ? "有" : "无") << std::endl;
}

// 测试工作站状态
void test_station_status() {
    std::cout << "测试工作站状态..." << std::endl;
    auto status = Grace::get_station_status_struct();
    
    std::cout << "通讯状态: " << (status.comm_ok ? "正常" : "异常") << std::endl;
    std::cout << "加水状态: " << (status.water_supply_ok ? "到位" : "未到位") << std::endl;
    std::cout << "排水状态: " << (status.water_drain_ok ? "到位" : "未到位") << std::endl;
    std::cout << "充电状态: " << (status.charge_ok ? "到位" : "未到位") << std::endl;
    std::cout << "水路状态: " << (status.water_path_ok ? "到位" : "未到位") << std::endl;
    std::cout << "充电电流: " << (status.charge_current_ok ? "正常" : "异常") << std::endl;
    std::cout << "流量开关: " << (status.flow_switch_ok ? "开" : "关") << std::endl;
    std::cout << "清水: " << (status.clean_water_empty ? "空" : "有") << std::endl;
    std::cout << "污水: " << (status.sewage_full ? "满" : "未满") << std::endl;
    std::cout << "消泡剂: " << (status.foam_empty ? "空" : "有") << std::endl;
    std::cout << "清洁剂: " << (status.cleaner_empty ? "空" : "有") << std::endl;
}

// 测试一键排水功能
void test_draining() {
    std::cout << "测试一键排水功能..." << std::endl;
    
    std::cout << "开始排水..." << std::endl;
    Grace::ctrl_water_drain_cmd(true);
    sleep(5);
    
    std::cout << "停止排水..." << std::endl;
    Grace::ctrl_water_drain_cmd(false);
}

// 测试语音控制
void test_voice_control() {
    std::cout << "测试语音控制..." << std::endl;
    
    // 设置音量
    std::cout << "设置音量为50%..." << std::endl;
    Grace::set_volume(50);
    sleep(1);
    
    // // 测试各种语音播报
    // uint32_t voice_bits = 0;
    // std::cout << "测试清洁作业语音..." << std::endl;
    // voice_bits |= (1 << 0);  // 清洁作业
    // Grace::ctrl_voice(voice_bits);
    // sleep(2);
    
    // std::cout << "测试消杀作业语音..." << std::endl;
    // voice_bits |= (1 << 1);  // 消杀作业
    // Grace::ctrl_voice(voice_bits);
    // sleep(2);
    
    // std::cout << "测试报警语音..." << std::endl;
    // voice_bits |= (1 << 2);  // 碰撞报警
    // voice_bits |= (1 << 3);  // 防跌落报警
    // Grace::ctrl_voice(voice_bits);
    // sleep(2);
    
    // // 关闭所有语音
    // Grace::ctrl_voice(0);
}

// 测试传感器屏蔽控制
void test_sensor_shield() {
    std::cout << "测试传感器屏蔽控制..." << std::endl;
    
    // 屏蔽左右防跌落
    uint8_t shield_bits = 0x03;  // b0和b1
    std::cout << "屏蔽左右防跌落..." << std::endl;
    Grace::ctrl_sensor_shield(shield_bits);
    sleep(2);
    
    // 屏蔽触边和压脚
    shield_bits = 0x30;  // b4和b5
    std::cout << "屏蔽触边和压脚..." << std::endl;
    Grace::ctrl_sensor_shield(shield_bits);
    sleep(2);
    
    // 取消所有屏蔽
    Grace::ctrl_sensor_shield(0);
}

// 测试超声波屏蔽控制
void test_ultrasonic_shield() {
    std::cout << "测试超声波屏蔽控制..." << std::endl;
    
    // 屏蔽前方超声波
    uint8_t shield_bits = 0x03;  // 屏蔽1,2号超声波
    std::cout << "屏蔽前方超声波..." << std::endl;
    Grace::ctrl_ultrasound_shield(shield_bits);
    sleep(2);
    
    // 屏蔽侧方超声波
    shield_bits = 0x0C;  // 屏蔽3,4号超声波
    std::cout << "屏蔽侧方超声波..." << std::endl;
    Grace::ctrl_ultrasound_shield(shield_bits);
    sleep(2);
    
    // 取消所有屏蔽
    Grace::ctrl_ultrasound_shield(0);
}

// 测试手动控制
void test_manual_control() {
    std::cout << "测试手动控制..." << std::endl;
    
    uint16_t pad_bits = 0;
    
    // 测试挪车开关
    std::cout << "打开挪车开关..." << std::endl;
    pad_bits |= (1 << 0);
    Grace::ctrl_pad(pad_bits);
    sleep(2);
    
    // 测试手动喷水
    std::cout << "打开手动喷水..." << std::endl;
    pad_bits |= (1 << 1);
    Grace::ctrl_pad(pad_bits);
    sleep(2);
    
    // 测试手动排水
    std::cout << "打开手动排水..." << std::endl;
    pad_bits |= (1 << 2) | (1 << 3);  // 清水和污水排水
    Grace::ctrl_pad(pad_bits);
    sleep(2);
    
    // 关闭所有手动控制
    Grace::ctrl_pad(0);
}

// 测试电梯控制
void test_lift_control() {
    std::cout << "测试电梯控制..." << std::endl;
    
    // 设置目标楼层
    std::cout << "设置目标楼层为3..." << std::endl;
    Grace::set_target_floor(3);
    sleep(1);
    
    // 发送乘梯指令
    uint8_t lift_cmd = 1;  // b0: 乘梯指令
    std::cout << "发送乘梯指令..." << std::endl;
    Grace::ctrl_lift_cmd(lift_cmd);
    sleep(5);
    
    // 取消乘梯指令
    lift_cmd = 2;  // b1: 取消乘梯指令
    std::cout << "取消乘梯指令..." << std::endl;
    Grace::ctrl_lift_cmd(lift_cmd);
}

// 测试工作站控制
void test_station_control() {
    std::cout << "测试工作站控制..." << std::endl;
    
    Grace::StationCmd cmd = {};
    
    // 测试通讯使能
    std::cout << "打开工作站通讯..." << std::endl;
    cmd.enable_comm = true;
    Grace::ctrl_station(cmd);
    sleep(2);
    
    // 测试加水
    std::cout << "开始加水..." << std::endl;
    cmd.water_supply = true;
    Grace::ctrl_station(cmd);
    sleep(5);
    
    // 测试排水
    std::cout << "开始排水..." << std::endl;
    cmd.water_supply = false;
    cmd.water_drain = true;
    Grace::ctrl_station(cmd);
    sleep(5);
    
    // 关闭所有控制
    cmd = {};
    Grace::ctrl_station(cmd);
}

// 测试错误状态和恢复
void test_error_handling() {
    std::cout << "测试错误状态和恢复..." << std::endl;
    
    // 获取当前错误状态
    int error_code = Grace::get_error_status();
    std::cout << "当前错误码: " << error_code << std::endl;
    
    // 测试安全检查
    bool is_safe = Grace::is_safe_to_move();
    std::cout << "是否可以安全移动: " << (is_safe ? "是" : "否") << std::endl;
    
    bool is_ready = Grace::is_ready_to_clean();
    std::cout << "是否可以开始清扫: " << (is_ready ? "是" : "否") << std::endl;
    
    bool need_maintain = Grace::need_maintenance();
    std::cout << "是否需要维护: " << (need_maintain ? "是" : "否") << std::endl;
}

// 测试车辆状态获取
void test_vehicle_status() {
    std::cout << "测试车辆状态获取..." << std::endl;
    auto status = Grace::get_vehicle_status();
    
    std::cout << "运动状态: " << (status.is_moving ? "运动中" : "静止") << std::endl;
    std::cout << "正常停车: " << (status.is_normal_stopped ? "是" : "否") << std::endl;
    std::cout << "紧急停车: " << (status.is_emergency_stopped ? "是" : "否") << std::endl;
    std::cout << "减速状态: " << (status.is_slowed_down ? "是" : "否") << std::endl;
    std::cout << "使能状态: " << (status.is_enabled ? "已使能" : "未使能") << std::endl;
    std::cout << "控制模式: ";
    switch(status.control_mode) {
        case -1: std::cout << "急停"; break;
        case 0: std::cout << "导航"; break;
        case 1: std::cout << "遥控"; break;
        case 5: std::cout << "绕障"; break;
        case 7: std::cout << "转运"; break;
        default: std::cout << "未知(" << status.control_mode << ")";
    }
    std::cout << std::endl;
    std::cout << "总行驶距离: " << status.totally_distance << "m" << std::endl;
}

// 测试车辆状态位域获取
void test_veh_status_bits() {
    std::cout << "测试车辆状态位域获取..." << std::endl;
    auto bits = Grace::get_veh_status_bits();
    
    std::cout << "开机状态: " << (bits.power_on ? "开机" : "关机") << std::endl;
    std::cout << "急停状态: " << (bits.emergency_stop ? "触发" : "正常") << std::endl;
    std::cout << "清洗驱动器: " << (bits.sweep_drive_timeout ? "超时" : "正常") << std::endl;
    std::cout << "0#RS485: " << (bits.rs485_0_timeout ? "超时" : "正常") << std::endl;
    std::cout << "1#RS485: " << (bits.rs485_1_timeout ? "超时" : "正常") << std::endl;
    std::cout << "DU88D: " << (bits.du88d_timeout ? "超时" : "正常") << std::endl;
    std::cout << "IMU: " << (bits.imu_timeout ? "超时" : "正常") << std::endl;
    std::cout << "PSD: " << (bits.psd_timeout ? "超时" : "正常") << std::endl;
    std::cout << "关机标志: " << (bits.power_off ? "关机" : "正常") << std::endl;
    std::cout << "电池通讯: " << (bits.battery_comm_error ? "故障" : "正常") << std::endl;
}

// 测试清扫设备状态获取
void test_cleaning_device_status() {
    std::cout << "测试清扫设备状态获取..." << std::endl;
    auto status = Grace::get_cleaning_device_status();
    
    std::cout << "刷盘速度: " << status.actual_brush_speed << "rpm" << std::endl;
    std::cout << "风机速度: " << status.actual_fan_speed << "rpm" << std::endl;
    std::cout << "刷盘位置: " << (status.brush_down ? "下降" : "上升") << std::endl;
    std::cout << "吸扒位置: " << (status.suction_down ? "下降" : "上升") << std::endl;
    std::cout << "污水液位: " << (int)status.sewage_level << "/15" << std::endl;
    std::cout << "清水液位: " << (int)status.clean_water_level << "/15" << std::endl;
    std::cout << "喷水阀: " << (status.spray_valve_on ? "开" : "关") << std::endl;
    std::cout << "清水排水阀: " << (status.clean_drain_valve_on ? "开" : "关") << std::endl;
    std::cout << "污水排水阀: " << (status.sewage_drain_valve_on ? "开" : "关") << std::endl;
    std::cout << "吸水泵: " << (status.suction_pump_on ? "开" : "关") << std::endl;
    std::cout << "吸水阀: " << (status.suction_valve_on ? "开" : "关") << std::endl;
    std::cout << "自清洁泵: " << (status.selfclean_pump_on ? "开" : "关") << std::endl;
    std::cout << "自清洁阀: " << (status.selfclean_valve_on ? "开" : "关") << std::endl;
    std::cout << "循环泵: " << (status.cycle_pump_on ? "开" : "关") << std::endl;
    std::cout << "循环阀: " << (status.cycle_valve_on ? "开" : "关") << std::endl;
}

// 测试速度控制
void test_speed_control() {
    std::cout << "测试速度控制..." << std::endl;
    
    Grace::ChassisCmd cmd;
    
    // 前进
    std::cout << "前进..." << std::endl;
    for (int i = 0; i < 10; ++i) {
        cmd.command_linear_x = 0.3;  // 0.3m/s
        cmd.command_linear_y = 0.0;
        cmd.command_angular_z = 0.0;
        Grace::send_speed(cmd);
        sleep(3);
    }
    
    // 后退
    for (int i = 0; i < 10; ++i) {
        std::cout << "后退..." << std::endl;
        cmd.command_linear_x = -0.3;  // -0.3m/s
        Grace::send_speed(cmd);
        sleep(3);
    }
    
    // 左移
    for (int i = 0; i < 10; ++i) {  
        std::cout << "左移..." << std::endl;
        cmd.command_linear_x = 0.0;
        cmd.command_linear_y = 0.3;  // 0.3m/s
        Grace::send_speed(cmd);
        sleep(3);
    }
    
    // 右移
    for (int i = 0; i < 10; ++i) {
        std::cout << "右移..." << std::endl;
        cmd.command_linear_y = -0.3;  // -0.3m/s
        Grace::send_speed(cmd);
        sleep(3);
    }
    
    // 原地旋转
    for (int i = 0; i < 10; ++i) {  
        std::cout << "原地旋转..." << std::endl;
        cmd.command_linear_y = 0.0;
        cmd.command_angular_z = 0.5;  // 0.5rad/s
        Grace::send_speed(cmd);
        sleep(3);
    }
    
    // 停止
    std::cout << "停止..." << std::endl;
    cmd.command_linear_x = 0.0;
    cmd.command_linear_y = 0.0;
    cmd.command_angular_z = 0.0;
    Grace::send_speed(cmd);
}


// [DONE]
void test_get_sensor_status() {
    auto status = Grace::get_sensor_status();
    std::cout << "传感器状态: " 
     << "左防跌落: " << status.left_drop 
     << ", 右防跌落: " << status.right_drop 
     << ", 碰撞: " << status.bumper 
     << ", 压脚: " << status.foot_protection 
     << std::endl;

    std::cout << "超声波状态: " 
    << " 超声1: " << status.ultrasound1 << ", 超声2: " << status.ultrasound2 << ", 超声3: " << status.ultrasound3 << ", 超声4: " << status.ultrasound4 << ", 超声5: " << status.ultrasound5 << ", 超声6: " << status.ultrasound6  << std::endl;
    return;
}

void test_get_battery_status() {
    auto status = Grace::get_battery_status();
    std::cout << "充电状态: " << status.is_charging << ", 电池电压: " << status.battery_voltage << ", 电池电流: " << status.battery_current << ", 电池总容量: " << status.total_capacity << ", 剩余容量: " << status.left_capacity << ", 充放电循环次数: " << status.cycle_count  << ", 当前电量百分比: " << status.current_power_percent << std::endl;
    return;
}

void test_wind_speed() {
    Grace::ctrl_wind_speed(500);
    std::cout << "吸风电机启动..." << std::endl;
    sleep(3);
    Grace::ctrl_wind_speed(0);
    std::cout << "吸风电机停止..." << std::endl;
    return;
}

void test_spray_water() {
    Grace::ctrl_water_spray_solenoid_cmd(true);
    std::cout << "喷水泵启动..." << std::endl;
    sleep(3);
    Grace::ctrl_water_spray_solenoid_cmd(false);
    std::cout << "喷水泵停止..." << std::endl;
    return;
}

void test_ctrl_selfclean_pump_cmd() {
    Grace::ctrl_selfclean_pump_cmd(true);
    std::cout << "自清洁泵启动..." << std::endl;
    sleep(3);
    Grace::ctrl_selfclean_pump_cmd(false);
    std::cout << "自清洁泵停止..." << std::endl;
    return;
}


int main() {
    // test_get_odom();

    // test_front_light_ctrl();
    // test_search_light_ctrl();

    // test_water_spray_solenoid_valve();
    // test_water_speed();

    // test_ctrl_supply_pump_cmd();
    // test_sewage_drain_ball_valve();
    
    // for (int i = 0; i < 10; ++i) {
    //     test_mcu_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    // for (int i = 0; i < 10; ++i ) {
    //     test_ultrasonic();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    // for (int i = 0; i < 10; ++i) {
    //     test_imu();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    // for (int i = 0; i < 10; ++i) {  
    //     test_sensor_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    // for (int i = 0; i < 10; ++i) {
    //     test_ultrasonic_error();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
        
        // 以下测试会实际控制设备,请谨慎使用
        // test_cleaning();
        // test_self_cleaning();
        // test_draining();
        
    // for (int i = 0; i < 10; ++i) {
    //     test_voice_control();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    // }
        
    // for (int i = 0; i < 10; ++i) {
    //     test_sensor_shield();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    // }
        
    // for (int i = 0; i < 10; ++i) {
    //     test_ultrasonic_shield();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    // }
        
    // for (int i = 0; i < 10; ++i) {
    //     test_manual_control();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    // }
        
        
    // for (int i = 0; i < 10; ++i) {      
    //     test_error_handling();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    // for (int i = 0; i < 10; ++i) {
    //     test_vehicle_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    // while (true) {
    //     test_get_battery_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }

    // test_lifter();
    // test_suction();

    // test_brush();
    // test_water_speed();

    // test_spray_water();
    // test_ctrl_selfclean_pump_cmd();
    // test_ctrl_supply_pump_cmd();
    test_veh_status_bits();


        
    // for (int i = 0; i < 10; ++i) {
    //     test_cleaning_device_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }

    // for (int i = 0; i < 10; ++i) {
    //     test_get_sensor_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }

    // for (int i = 0; i < 10; ++i) {
    //     test_vehicle_status();
    //     std::cout << "\n----------------------------------------\n" << std::endl;
    //     sleep(1);
    // }
        
    
    // 以下测试会实际控制设备移动,请谨慎使用
    // test_speed_control();
    
    return 0;
}