#include <arpa/inet.h>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <errno.h>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <netinet/in.h>
#include <signal.h>
#include <sstream>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>
#include <vector>

#define SHM_SIZE 8388608 // 8 MB
#define BUFFER_SIZE 1024
#define MAX_RETRIES 5
#define RETRY_DELAY_MS 1000

void printVehicleData(uint8_t* shm_ptr) {

    // vehicle section (offset: 0x100000)   
    std::cout << "vehicle.id: " << *(int16_t*)(shm_ptr + 0x100000) << std::endl;          // "id": "int16"
    std::cout << "vehicle.type: " << *(int16_t*)(shm_ptr + 0x100002) << std::endl;        // "type": "int16"
    
    // POSITION 结构体包含 x/y/angle，都是 float 类型
    std::cout << "vehicle.manual_velocity.x: " << *(float*)(shm_ptr + 0x100004) << std::endl;
    std::cout << "vehicle.manual_velocity.y: " << *(float*)(shm_ptr + 0x100008) << std::endl;
    std::cout << "vehicle.manual_velocity.angle: " << *(float*)(shm_ptr + 0x10000C) << std::endl;
    
    std::cout << "vehicle.normal_stop: " << *(int32_t*)(shm_ptr + 0x100010) << " (正常停车)" << std::endl;          // "int"
    std::cout << "vehicle.emergency_stop: " << *(int32_t*)(shm_ptr + 0x100014) << " (紧急停车标志位)" << std::endl;  // "int"
    std::cout << "vehicle.fault_stop: " << *(int32_t*)(shm_ptr + 0x100018) << " (错误停车标志位)" << std::endl;     // "int"
    std::cout << "vehicle.slow_down: " << *(int32_t*)(shm_ptr + 0x10001C) << " (减速标志位)" << std::endl;          // "int"
    std::cout << "vehicle.enable: " << *(int32_t*)(shm_ptr + 0x100020) << " (底盘使能标志位)" << std::endl;         // "int"
    std::cout << "vehicle.control_mode: " << *(int32_t*)(shm_ptr + 0x100024) << " (控制模式)" << std::endl;         // "int"
    std::cout << "vehicle.enabled: " << *(int32_t*)(shm_ptr + 0x100028) << " (车辆使能)" << std::endl;              // "int"
    
    // POSITION 结构体，所有速度相关字段都是 float
    std::cout << "vehicle.command_velocity.x: " << *(float*)(shm_ptr + 0x10002C) << " (下发速度x轴)" << std::endl;
    std::cout << "vehicle.command_velocity.y: " << *(float*)(shm_ptr + 0x100030) << " (下发速度y轴)" << std::endl;
    std::cout << "vehicle.command_velocity.angle: " << *(float*)(shm_ptr + 0x100034) << " (下发角速度)" << std::endl;
    
    std::cout << "vehicle.ref_velocity.x: " << *(float*)(shm_ptr + 0x100038) << std::endl;
    std::cout << "vehicle.ref_velocity.y: " << *(float*)(shm_ptr + 0x10003C) << std::endl;
    std::cout << "vehicle.ref_velocity.angle: " << *(float*)(shm_ptr + 0x100040) << std::endl;
    
    std::cout << "vehicle.actual_command_velocity.x: " << *(float*)(shm_ptr + 0x100044) << " (实际执行速度x轴)" << std::endl;
    std::cout << "vehicle.actual_command_velocity.y: " << *(float*)(shm_ptr + 0x100048) << " (实际执行速度y轴)" << std::endl;
    std::cout << "vehicle.actual_command_velocity.angle: " << *(float*)(shm_ptr + 0x10004C) << " (实际执行角速度)" << std::endl;
    
    std::cout << "vehicle.actual_velocity.x: " << *(float*)(shm_ptr + 0x100050) << " (实际反馈速度x轴)" << std::endl;
    std::cout << "vehicle.actual_velocity.y: " << *(float*)(shm_ptr + 0x100054) << " (实际反馈速度y轴)" << std::endl;
    std::cout << "vehicle.actual_velocity.angle: " << *(float*)(shm_ptr + 0x100058) << " (实际反馈角速度)" << std::endl;
    
    std::cout << "vehicle.odometer.x: " << *(float*)(shm_ptr + 0x10005C) << std::endl;
    std::cout << "vehicle.odometer.y: " << *(float*)(shm_ptr + 0x100060) << std::endl;
    std::cout << "vehicle.odometer.angle: " << *(float*)(shm_ptr + 0x100064) << std::endl;
    
    std::cout << "vehicle.timestamp: " << *(int64_t*)(shm_ptr + 0x100068) << std::endl;    // "timestamp": "int64"
    
    std::cout << "vehicle.is_moving: " << *(int32_t*)(shm_ptr + 0x100070) << std::endl;              // "int"
    std::cout << "vehicle.is_normal_stopped: " << *(int32_t*)(shm_ptr + 0x100074) << std::endl;      // "int"
    std::cout << "vehicle.is_emergency_stopped: " << *(int32_t*)(shm_ptr + 0x100078) << std::endl;   // "int"
    std::cout << "vehicle.is_slowed_down: " << *(int32_t*)(shm_ptr + 0x10007C) << std::endl;        // "int"
    
    std::cout << "vehicle.totally_distance: " << *(double*)(shm_ptr + 0x100080) << std::endl;        // "double"

    std::cout << "----------------------------------------" << std::endl;

    // mcurx section (base offset: 0x100c00)

    // Basic info
    std::cout << "mcurx.id: " << *(int16_t*)(shm_ptr + 0x100c00) << std::endl;          // 0x00-0x01
    std::cout << "mcurx.type: " << *(int16_t*)(shm_ptr + 0x100c02) << std::endl;        // 0x02-0x03

    // veh_status (0x04-0x05)
    uint16_t veh_status = *(int16_t*)(shm_ptr + 0x100c04);
    std::cout << "mcurx.veh_status.b0: " << (veh_status & 0x0001) << " (开机信号: " << ((veh_status & 0x0001) ? "开机" : "关机") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b1-2: " << ((veh_status >> 1) & 0x0003) << std::endl;
    std::cout << "mcurx.veh_status.b3: " << ((veh_status >> 3) & 0x0001) << " (急停触发: " << (((veh_status >> 3) & 0x0001) ? "急停触发" : "急停未触发") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b4: " << ((veh_status >> 4) & 0x0001) << " (清洗驱动器超时: " << (((veh_status >> 4) & 0x0001) ? "超时" : "未超时") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b5: " << ((veh_status >> 5) & 0x0001) << " (0#RS485超时: " << (((veh_status >> 5) & 0x0001) ? "超时" : "正常") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b6: " << ((veh_status >> 6) & 0x0001) << " (1#RS485超时: " << (((veh_status >> 6) & 0x0001) ? "超时" : "正常") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b7: " << ((veh_status >> 7) & 0x0001) << " (DU88D超时: " << (((veh_status >> 7) & 0x0001) ? "超时" : "正常") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b8: " << ((veh_status >> 8) & 0x0001) << " (IMU超时: " << (((veh_status >> 8) & 0x0001) ? "超时" : "正常") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b9: " << ((veh_status >> 9) & 0x0001) << " (PSD超时: " << (((veh_status >> 9) & 0x0001) ? "超时" : "") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b10-11: " << ((veh_status >> 10) & 0x0003) << " (关机标志位: " << (((veh_status >> 10) & 0x0003) ? "关机" : "正常开机") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b12: " << ((veh_status >> 12) & 0x0001) << " (电池通讯故障: " << (((veh_status >> 12) & 0x0001) ? "故障" : "正常") << ")" << std::endl;
    std::cout << "mcurx.veh_status.b13-15: " << ((veh_status >> 13) & 0x0007) << std::endl;

    // Current and speed values
    float wheel_current_l = *(int16_t*)(shm_ptr + 0x100c06) / 100.0f;  // 0x06-0x07
    float wheel_current_r = *(int16_t*)(shm_ptr + 0x100c08) / 100.0f;  // 0x08-0x09
    std::cout << "mcurx.wheel_current_l: " << wheel_current_l << "A (左轮毂电流)" << std::endl;
    std::cout << "mcurx.wheel_current_r: " << wheel_current_r << "A (右轮毂电流)" << std::endl;

    float spray_real_sp = *(int16_t*)(shm_ptr + 0x100c0a) / 100.0f;    // 0x0a-0x0b
    float wind_real_sp = *(int16_t*)(shm_ptr + 0x100c0c) / 100.0f;     // 0x0c-0x0d
    float brush_real_sp = *(int16_t*)(shm_ptr + 0x100c0e) / 100.0f;    // 0x0e-0x0f
    std::cout << "mcurx.spray_real_sp: " << spray_real_sp << "% (喷水泵实际速度)" << std::endl;
    std::cout << "mcurx.wind_real_sp: " << wind_real_sp << "% (风机实际度)" << std::endl;
    std::cout << "mcurx.brush_real_sp: " << brush_real_sp << "% (滚刷实际速度)" << std::endl;

    float wind_real_current = *(int16_t*)(shm_ptr + 0x100c10) / 1000.0f;   // 0x10-0x11
    float brush_real_current = *(int16_t*)(shm_ptr + 0x100c12) / 1000.0f;  // 0x12-0x13
    std::cout << "mcurx.wind_real_current: " << wind_real_current << "A (风机实际电流)" << std::endl;
    std::cout << "mcurx.brush_real_current: " << brush_real_current << "A (滚刷实际电流)" << std::endl;

    // Error codes and status
    std::cout << "mcurx.sweep_err_code1: " << *(int32_t*)(shm_ptr + 0x106134) << " (清洗驱动器系统故障码1)" << std::endl;  // 0x14-0x17
    std::cout << "mcurx.sweep_err_code2: " << *(int32_t*)(shm_ptr + 0x100c18) << " (清洗驱动器系统故障码2)" << std::endl;  // 0x18-0x1b

    uint32_t sweep_status = *(uint32_t*)(shm_ptr + 0x100c1c);  // 0x1c-0x1f
    // 液位状态
    uint8_t dirty_water_level = sweep_status & 0x0F;
    uint8_t clean_water_level = (sweep_status >> 4) & 0x0F;
    std::cout << "mcurx.sweep_status.b0-3: " << static_cast<int>(dirty_water_level) 
              << " (污水液位: " << (dirty_water_level == 15 ? "空液位" : std::to_string(dirty_water_level)) << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b4-7: " << static_cast<int>(clean_water_level)
              << " (清水液位: " << (clean_water_level == 15 ? "空液位" : std::to_string(clean_water_level)) << ")" << std::endl;

    // 阀门状态
    std::cout << "mcurx.sweep_status.b8: " << ((sweep_status >> 8) & 0x01) 
              << " (喷水阀状态: " << (((sweep_status >> 8) & 0x01) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b9: " << ((sweep_status >> 9) & 0x01) 
              << " (排水阀1（清水）状态: " << (((sweep_status >> 9) & 0x01) ? "开" : "关") << ")" << std::endl;

    // sweep status continued
    std::cout << "mcurx.sweep_status.b10: " << ((sweep_status >> 10) & 0x01) 
              << " (排水阀2（污水）状态: " << (((sweep_status >> 10) & 0x01) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b11: " << ((sweep_status >> 11) & 0x01) 
              << " (吸水泵状态: " << (((sweep_status >> 11) & 0x01) ? "吸水泵开" : "吸水泵关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b12: " << ((sweep_status >> 12) & 0x01) 
              << " (吸水阀状态: " << (((sweep_status >> 12) & 0x01) ? "吸水阀开" : "吸水阀关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b13: " << ((sweep_status >> 13) & 0x01) 
              << " (刷盘状态: " << (((sweep_status >> 13) & 0x01) ? "刷盘降" : "刷盘升") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b14: " << ((sweep_status >> 14) & 0x01) 
              << " (吸扒状态: " << (((sweep_status >> 14) & 0x01) ? "吸扒降" : "吸扒升") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b15: " << ((sweep_status >> 15) & 0x01) << std::endl;
    std::cout << "mcurx.sweep_status.b16: " << ((sweep_status >> 16) & 0x01) 
              << " (自清洁泵状态: " << (((sweep_status >> 16) & 0x01) ? "自清洁泵开" : "自清洁泵关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b17: " << ((sweep_status >> 17) & 0x01) 
              << " (自清洁阀状态: " << (((sweep_status >> 17) & 0x01) ? "自清洁阀开" : "自清洁阀关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b18: " << ((sweep_status >> 18) & 0x01) 
              << " (循环泵状态: " << (((sweep_status >> 18) & 0x01) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b19: " << ((sweep_status >> 19) & 0x01) 
              << " (循环阀状态: " << (((sweep_status >> 19) & 0x01) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcurx.sweep_status.b20-31: " << ((sweep_status >> 20) & 0xFFF) << std::endl;

    // station status (0x1e-0x1f)
    uint16_t station_status = *(uint16_t*)(shm_ptr + 0x100c1e);
    std::cout << "mcurx.station_status.b0: " << (station_status & 0x01) 
              << " (工作站通讯: " << ((station_status & 0x01) ? "成功" : "失败") << ")" << std::endl;
    std::cout << "mcurx.station_status.b1: " << ((station_status >> 1) & 0x01) 
              << " (工作站加水: " << (((station_status >> 1) & 0x01) ? "到位" : "未到位") << ")" << std::endl;
    std::cout << "mcurx.station_status.b2: " << ((station_status >> 2) & 0x01) 
              << " (工作站水: " << (((station_status >> 2) & 0x01) ? "到位" : "未到位") << ")" << std::endl;
    std::cout << "mcurx.station_status.b3-7: " << ((station_status >> 3) & 0x1F) << std::endl;
    std::cout << "mcurx.station_status.b8: " << ((station_status >> 8) & 0x01) 
              << " (工作站充电: " << (((station_status >> 8) & 0x01) ? "到位" : "未到位") << ")" << std::endl;
    std::cout << "mcurx.station_status.b9: " << ((station_status >> 9) & 0x01) 
              << " (工作站水路: " << (((station_status >> 9) & 0x01) ? "到位" : "未到位") << ")" << std::endl;
    std::cout << "mcurx.station_status.b10: " << ((station_status >> 10) & 0x01) 
              << " (充电电流感应开关: " << (((station_status >> 10) & 0x01) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcurx.station_status.b11: " << ((station_status >> 11) & 0x01) 
              << " (流量开关: " << (((station_status >> 11) & 0x01) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcurx.station_status.b12: " << ((station_status >> 12) & 0x01) 
              << " (清水: " << (((station_status >> 12) & 0x01) ? "空" : "未空") << ")" << std::endl;
    std::cout << "mcurx.station_status.b13: " << ((station_status >> 13) & 0x01) 
              << " (污水: " << (((station_status >> 13) & 0x01) ? "满" : "未满") << ")" << std::endl;
    std::cout << "mcurx.station_status.b14: " << ((station_status >> 14) & 0x01) 
              << " (消泡剂: " << (((station_status >> 14) & 0x01) ? "空" : "未空") << ")" << std::endl;
    std::cout << "mcurx.station_status.b15: " << ((station_status >> 15) & 0x01) 
              << " (清洁剂: " << (((station_status >> 15) & 0x01) ? "空" : "未空") << ")" << std::endl;

    // psd_status (0x22-0x23)
    uint16_t psd_status = *(uint16_t*)(shm_ptr + 0x100c22);  // 0x22-0x23
    std::cout << "mcurx.psd_status.b0: " << (psd_status & 0x0001) << " (车抱死状态: " << ((psd_status & 0x0001) ? "抱死" : "未抱死") << ")" << std::endl;
    std::cout << "mcurx.psd_status.b1: " << ((psd_status >> 1) & 0x0001) << " (手充抱死状态: " << (((psd_status >> 1) & 0x0001) ? "正常" : "异常") << ")" << std::endl;
    std::cout << "mcurx.psd_status.b2: " << ((psd_status >> 2) & 0x0001) << " (左电机在电流环: " << (((psd_status >> 2) & 0x0001) ? "是" : "否") << ")" << std::endl;
    std::cout << "mcurx.psd_status.b3: " << ((psd_status >> 3) & 0x0001) << " (右电机在电流环: " << (((psd_status >> 3) & 0x0001) ? "是" : "否") << ")" << std::endl;
    std::cout << "mcurx.psd_status.b4-15: " << ((psd_status >> 4) & 0x0FFF) << std::endl;

    // Liquid levels
    std::cout << "mcurx.liquid1: " << *(int16_t*)(shm_ptr + 0x100c24) << " mm (清水液位)" << std::endl;    // 0x24-0x25
    std::cout << "mcurx.liquid2: " << *(int16_t*)(shm_ptr + 0x100c26) << " mm (污水液位)" << std::endl;    // 0x26-0x27

    // Ultrasonic data (6 * int16 = 12 bytes)
    for(int i = 0; i < 6; i++) {
        std::cout << "mcurx.ultrasonic_data_" << (i+1) << ": " 
                  << *(int16_t*)(shm_ptr + 0x100c28 + i*2) << " mm (超声" << (i+1) << ")" << std::endl;
    }  // 0x28-0x33

    // User data
    std::cout << "mcurx.user1: " << *(int16_t*)(shm_ptr + 0x100c34) << std::endl;  // 0x34-0x35
    std::cout << "mcurx.user2: " << *(int16_t*)(shm_ptr + 0x100c36) << std::endl;  // 0x36-0x37

    // IMU data (all int32, 4 bytes each)
    std::cout << "mcurx.x_angle_speed: " << *(int32_t*)(shm_ptr + 0x100c38) << std::endl;  // 0x38-0x3b
    std::cout << "mcurx.y_angle_speed: " << *(int32_t*)(shm_ptr + 0x100c3c) << std::endl;  // 0x3c-0x3f
    std::cout << "mcurx.z_angle_speed: " << *(int32_t*)(shm_ptr + 0x100c40) << std::endl;  // 0x40-0x43
    std::cout << "mcurx.x_acc: " << *(int32_t*)(shm_ptr + 0x100c44) << std::endl;          // 0x44-0x47
    std::cout << "mcurx.y_acc: " << *(int32_t*)(shm_ptr + 0x100c48) << std::endl;          // 0x48-0x4b
    std::cout << "mcurx.z_acc: " << *(int32_t*)(shm_ptr + 0x100c4c) << std::endl;          // 0x4c-0x4f
    std::cout << "mcurx.gyro_temp: " << *(int32_t*)(shm_ptr + 0x100c50) << std::endl;      // 0x50-0x53
    std::cout << "mcurx.gyro_timestamp: " << *(int64_t*)(shm_ptr + 0x100c54) << std::endl; // 0x54-0x5b

    // Status data
    uint16_t sensor_status = *(uint16_t*)(shm_ptr + 0x100c5c);    // 0x5c-0x5d
    std::cout << "mcurx.sensor_status.b0: " << (sensor_status & 0x0001) << " (左防跌落: " << ((sensor_status & 0x0001) ? "触发" : "未触发") << ")" << std::endl;
    std::cout << "mcurx.sensor_status.b1: " << ((sensor_status >> 1) & 0x0001) << " (右防跌落: " << (((sensor_status >> 1) & 0x0001) ? "触发" : "未触发") << ")" << std::endl;
    std::cout << "mcurx.sensor_status.b2-3: " << ((sensor_status >> 2) & 0x0003) << std::endl;
    std::cout << "mcurx.sensor_status.b4: " << ((sensor_status >> 4) & 0x0001) << " (前触边: " << (((sensor_status >> 4) & 0x0001) ? "触发" : "未触发") << ")" << std::endl;
    std::cout << "mcurx.sensor_status.b5: " << ((sensor_status >> 5) & 0x0001) << " (压脚: " << (((sensor_status >> 5) & 0x0001) ? "触发" : "未触发") << ")" << std::endl;
    std::cout << "mcurx.sensor_status.b6-15: " << ((sensor_status >> 6) & 0x03FF) << std::endl;

    uint16_t ultrasonic_err = *(uint16_t*)(shm_ptr + 0x100c5e);   // 0x5e-0x5f
    std::cout << "mcurx.ultrasonic_err.b0: " << (ultrasonic_err & 0x0001) << " (超声1故障: " << ((ultrasonic_err & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b1: " << ((ultrasonic_err >> 1) & 0x0001) << " (超声2故障: " << (((ultrasonic_err >> 1) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b2: " << ((ultrasonic_err >> 2) & 0x0001) << " (超声3故障: " << (((ultrasonic_err >> 2) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b3: " << ((ultrasonic_err >> 3) & 0x0001) << " (超声4故障: " << (((ultrasonic_err >> 3) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b4: " << ((ultrasonic_err >> 4) & 0x0001) << " (超声5故障: " << (((ultrasonic_err >> 4) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b5: " << ((ultrasonic_err >> 5) & 0x0001) << " (超声6故障: " << (((ultrasonic_err >> 5) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b6: " << ((ultrasonic_err >> 6) & 0x0001) << " (超声7故障: " << (((ultrasonic_err >> 6) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b7: " << ((ultrasonic_err >> 7) & 0x0001) << " (超声8故障: " << (((ultrasonic_err >> 7) & 0x0001) ? "超时故障" : "通讯正常") << ")" << std::endl;
    std::cout << "mcurx.ultrasonic_err.b8-15: " << ((ultrasonic_err >> 8) & 0x00FF) << std::endl;

    // Final status bytes (all int8, 1 byte each)
    std::cout << "mcurx.lift_status: " << (int)*(int8_t*)(shm_ptr + 0x100c60) << std::endl;    // 0x60
    std::cout << "mcurx.robot_floor: " << (int)*(int8_t*)(shm_ptr + 0x100c61) << std::endl;    // 0x61
    std::cout << "mcurx.lift_floor: " << (int)*(int8_t*)(shm_ptr + 0x100c62) << std::endl;     // 0x62
    std::cout << "mcurx.user3: " << (int)*(int8_t*)(shm_ptr + 0x100c63) << std::endl;          // 0x63

    std::cout << "----------------------------------------" << std::endl;

    // mcutx section (base offset: 0x100e00)

    // Basic info
    std::cout << "mcutx.id: " << *(int16_t*)(shm_ptr + 0x100e00) << std::endl;
    std::cout << "mcutx.type: " << *(int16_t*)(shm_ptr + 0x100e02) << std::endl;

    // Speed controls
    float wind_speed = *(int16_t*)(shm_ptr + 0x100e04) / 100.0f;
    float brush_speed = *(int16_t*)(shm_ptr + 0x100e06) / 100.0f;
    float water_speed = *(int16_t*)(shm_ptr + 0x100e08) / 100.0f;
    std::cout << "mcutx.wind_speed: " << wind_speed << "% (风机目标速度)" << std::endl;
    std::cout << "mcutx.brush_speed: " << brush_speed << "% (滚刷目标速度)" << std::endl;
    std::cout << "mcutx.water_speed: " << water_speed << "% (喷水泵目标速度)" << std::endl;

    std::cout << "mcutx.usr_define: " << *(int16_t*)(shm_ptr + 0x100e0a) << std::endl;

    // sweep_ctrl (0x0c-0x0d)
    uint16_t sweep_ctrl = *(uint16_t*)(shm_ptr + 0x100e0c);
    std::cout << "mcutx.sweep_ctrl.b0: " << (sweep_ctrl & 0x0001) << " (清洗初始化: " << ((sweep_ctrl & 0x0001) ? "已初始化" : "未初始化") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b1: " << ((sweep_ctrl >> 1) & 0x0001) << " (滚刷升降运动指令: " << (((sweep_ctrl >> 1) & 0x0001) ? "运动" : "停止") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b2: " << ((sweep_ctrl >> 2) & 0x0001) << " (滚刷升降方向: " << (((sweep_ctrl >> 2) & 0x0001) ? "下降" : "上升") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b3: " << ((sweep_ctrl >> 3) & 0x0001) << " (吸扒升降运动指令: " << (((sweep_ctrl >> 3) & 0x0001) ? "运动" : "停止") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b4: " << ((sweep_ctrl >> 4) & 0x0001) << " (吸扒升降方向: " << (((sweep_ctrl >> 4) & 0x0001) ? "下降" : "上升") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b5: " << ((sweep_ctrl >> 5) & 0x0001) << " (加水推杆方向: " << (((sweep_ctrl >> 5) & 0x0001) ? "下降" : "上升") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b6: " << ((sweep_ctrl >> 6) & 0x0001) << " (喷水球阀: " << (((sweep_ctrl >> 6) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b7: " << ((sweep_ctrl >> 7) & 0x0001) << std::endl;
    std::cout << "mcutx.sweep_ctrl.b8: " << ((sweep_ctrl >> 8) & 0x0001) << " (清水排水球阀: " << (((sweep_ctrl >> 8) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b9: " << ((sweep_ctrl >> 9) & 0x0001) << " (污水排水球阀: " << (((sweep_ctrl >> 9) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b10: " << ((sweep_ctrl >> 10) & 0x0001) << " (循环/自吸水模式: " << (((sweep_ctrl >> 10) & 0x0001) ? "自吸水模式" : "循环模式") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b11: " << ((sweep_ctrl >> 11) & 0x0001) << " (自清洁泵/自吸泵: " << (((sweep_ctrl >> 11) & 0x0001) ? "自泵" : "自清洁泵") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b12: " << ((sweep_ctrl >> 12) & 0x0001) << " (自吸泵: " << (((sweep_ctrl >> 12) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b13: " << ((sweep_ctrl >> 13) & 0x0001) << " (自清洁阀: " << (((sweep_ctrl >> 13) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b14: " << ((sweep_ctrl >> 14) & 0x0001) << " (消泡剂泵: " << (((sweep_ctrl >> 14) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.sweep_ctrl.b15: " << ((sweep_ctrl >> 15) & 0x0001) << " (清洁剂泵: " << (((sweep_ctrl >> 15) & 0x0001) ? "开" : "关") << ")" << std::endl;

    // task (0x0e-0x0f)
    uint16_t task = *(uint16_t*)(shm_ptr + 0x100e0e);
    std::cout << "mcutx.task.b0: " << (task & 0x0001) << " (车辆抱死: " << ((task & 0x0001) ? "抱死" : "未抱死") << ")" << std::endl;
    std::cout << "mcutx.task.b1: " << ((task >> 1) & 0x0001) << " (助力模式: " << (((task >> 1) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.task.b2: " << ((task >> 2) & 0x0001) << " (消杀电源: " << (((task >> 2) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.task.b3-15: " << ((task >> 3) & 0x1FFF) << std::endl;

    // LED control (0x10-0x11)
    uint16_t led = *(uint16_t*)(shm_ptr + 0x100e10);
    std::cout << "mcutx.led.b0: " << (led & 0x0001) << " (灯0: " << ((led & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b1: " << ((led >> 1) & 0x0001) << " (灯1: " << (((led >> 1) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b2: " << ((led >> 2) & 0x0001) << " (灯2: " << (((led >> 2) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b3: " << ((led >> 3) & 0x0001) << " (灯3: " << (((led >> 3) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b4: " << ((led >> 4) & 0x0001) << " (灯4: " << (((led >> 4) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b5: " << ((led >> 5) & 0x0001) << " (灯5: " << (((led >> 5) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b6: " << ((led >> 6) & 0x0001) << " (灯6: " << (((led >> 6) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b7: " << ((led >> 7) & 0x0001) << " (灯7: " << (((led >> 7) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.led.b8-15: " << ((led >> 8) & 0x00FF) << std::endl;

    // Station control (0x12-0x13)
    uint16_t station = *(uint16_t*)(shm_ptr + 0x100e12);
    std::cout << "mcutx.station.b0: " << (station & 0x0001) << " (工作站通讯使能: " << ((station & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.station.b1: " << ((station >> 1) & 0x0001) << " (工作站充电器: " << (((station >> 1) & 0x0001) ? "下电" : "未下电") << ")" << std::endl;
    std::cout << "mcutx.station.b2: " << ((station >> 2) & 0x0001) << std::endl;
    std::cout << "mcutx.station.b3: " << ((station >> 3) & 0x0001) << " (工作站加水: " << (((station >> 3) & 0x0001) ? "开进水阀" : "关进水阀") << ")" << std::endl;
    std::cout << "mcutx.station.b4: " << ((station >> 4) & 0x0001) << " (工作站排水: " << (((station >> 4) & 0x0001) ? "开排水阀" : "关排水阀") << ")" << std::endl;
    std::cout << "mcutx.station.b5-7: " << ((station >> 5) & 0x0007) << std::endl;

    // Station and volume
    std::cout << "mcutx.station: " << (int)*(uint8_t*)(shm_ptr + 0x100e12) << std::endl;
    std::cout << "mcutx.volume: " << (int)*(uint8_t*)(shm_ptr + 0x100e13) << "% (语音音量, 0-100)" << std::endl;

    // Voice control (int32, 4 bytes, needs alignment)
    uint32_t voice = *(uint32_t*)(shm_ptr + 0x100e14);  // 0x14-0x17
    std::cout << "mcutx.voice.b0: " << (voice & 0x0001) << " (清洁作业: " << ((voice & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.voice.b1: " << ((voice >> 1) & 0x0001) << " (消杀作业: " << (((voice >> 1) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.voice.b2: " << ((voice >> 2) & 0x0001) << " (碰撞报警: " << (((voice >> 2) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.voice.b3: " << ((voice >> 3) & 0x0001) << " (防跌落报警: " << (((voice >> 3) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.voice.b4: " << ((voice >> 4) & 0x0001) << " (低电量报警: " << (((voice >> 4) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.voice.b5: " << ((voice >> 5) & 0x0001) << " (低水量报警: " << (((voice >> 5) & 0x0001) ? "开启" : "关闭") << ")" << std::endl;
    std::cout << "mcutx.voice.b6-31: " << ((voice >> 6) & 0x03FFFFFF) << std::endl;

    // Speed limit and torque (int8)
    std::cout << "mcutx.speed_limit: " << (int)*(uint8_t*)(shm_ptr + 0x100e18) << " cm/s (速度限制)" << std::endl;  // 0x18
    std::cout << "mcutx.tqsp: " << (int)*(uint8_t*)(shm_ptr + 0x100e19) << " (电流环目标转矩)" << std::endl;       // 0x19

    // Sensor shield control (0x1a)
    uint8_t sensor_shield = *(uint8_t*)(shm_ptr + 0x100e1a);
    std::cout << "mcutx.sensor_shield.b0: " << (sensor_shield & 0x01) << " (左跌落: " << ((sensor_shield & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.sensor_shield.b1: " << ((sensor_shield >> 1) & 0x01) << " (右跌落: " << (((sensor_shield >> 1) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.sensor_shield.b2-3: " << ((sensor_shield >> 2) & 0x03) << std::endl;
    std::cout << "mcutx.sensor_shield.b4: " << ((sensor_shield >> 4) & 0x01) << " (触边: " << (((sensor_shield >> 4) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.sensor_shield.b5: " << ((sensor_shield >> 5) & 0x01) << " (防压脚: " << (((sensor_shield >> 5) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.sensor_shield.b6-7: " << ((sensor_shield >> 6) & 0x03) << std::endl;

    // Ultrasound shield control (0x1b)
    uint8_t ultrasound_shield = *(uint8_t*)(shm_ptr + 0x100e1b);
    std::cout << "mcutx.ultrasound_shield.b0: " << (ultrasound_shield & 0x01) << " (超声1: " << ((ultrasound_shield & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b1: " << ((ultrasound_shield >> 1) & 0x01) << " (超声2: " << (((ultrasound_shield >> 1) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b2: " << ((ultrasound_shield >> 2) & 0x01) << " (超声3: " << (((ultrasound_shield >> 2) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b3: " << ((ultrasound_shield >> 3) & 0x01) << " (超声4: " << (((ultrasound_shield >> 3) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b4: " << ((ultrasound_shield >> 4) & 0x01) << " (超声5: " << (((ultrasound_shield >> 4) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b5: " << ((ultrasound_shield >> 5) & 0x01) << " (超声6: " << (((ultrasound_shield >> 5) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b6: " << ((ultrasound_shield >> 6) & 0x01) << " (超声7: " << (((ultrasound_shield >> 6) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;
    std::cout << "mcutx.ultrasound_shield.b7: " << ((ultrasound_shield >> 7) & 0x01) << " (超声8: " << (((ultrasound_shield >> 7) & 0x01) ? "屏蔽" : "未屏蔽") << ")" << std::endl;

    // Pad and remote control (int16)
    uint16_t pad = *(uint16_t*)(shm_ptr + 0x100e1c);    // 0x1c-0x1d
    std::cout << "mcutx.pad.b0: " << (pad & 0x0001) << " (触摸屏挪车开关: " << ((pad & 0x0001) ? "电机去使能" : "电机使能") << ")" << std::endl;
    std::cout << "mcutx.pad.b1: " << ((pad >> 1) & 0x0001) << " (手动喷水阀: " << (((pad >> 1) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.pad.b2: " << ((pad >> 2) & 0x0001) << " (手动排清水阀: " << (((pad >> 2) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.pad.b3: " << ((pad >> 3) & 0x0001) << " (手动排污水阀: " << (((pad >> 3) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.pad.b4-7: " << ((pad >> 4) & 0x000F) << std::endl;
    std::cout << "mcutx.pad.b8: " << ((pad >> 8) & 0x0001) << " (手动工作站进水阀: " << (((pad >> 8) & 0x0001) ? "开" : "关") << ")" << std::endl;
    std::cout << "mcutx.pad.b9-15: " << ((pad >> 9) & 0x007F) << std::endl;

    uint16_t remote = *(uint16_t*)(shm_ptr + 0x100e1e); // 0x1e-0x1f
    std::cout << "mcutx.remote.b0: " << (remote & 0x0001) << " (PSD: " << ((remote & 0x0001) ? "重��" : "上电") << ")" << std::endl;
    std::cout << "mcutx.remote.b1: " << ((remote >> 1) & 0x0001) << " (激光: " << (((remote >> 1) & 0x0001) ? "重启" : "上电") << ")" << std::endl;
    std::cout << "mcutx.remote.b2-15: " << ((remote >> 2) & 0x3FFF) << std::endl;

    // Final control and floor information (all int8)
    std::cout << "mcutx.lift_cmd: " << (int)*(uint8_t*)(shm_ptr + 0x100e20) << std::endl;             // 0x20
    std::cout << "mcutx.robot_floor: " << (int)*(int8_t*)(shm_ptr + 0x100e21) << "层 (机器人楼层)" << std::endl;    // 0x21
    std::cout << "mcutx.min_floor: " << (int)*(int8_t*)(shm_ptr + 0x100e22) << "层 (电梯最小楼层)" << std::endl;    // 0x22
    std::cout << "mcutx.target_floor: " << (int)*(int8_t*)(shm_ptr + 0x100e23) << "层 (机器人目的楼层)" << std::endl; // 0x23

    // Read mcurxhead fields
    std::cout << "\n=== MCU RX Head Fields ===" << std::endl;

    // Basic header info
    std::cout << "mcurxhead.id: " << *(uint16_t*)(shm_ptr + 0x100800) << std::endl;
    std::cout << "mcurxhead.type: " << *(uint16_t*)(shm_ptr + 0x100802) << std::endl;
    
    // Frame header
    std::cout << "mcurxhead.frame_head.sequence: " << *(uint16_t*)(shm_ptr + 0x100804) << std::endl;
    std::cout << "mcurxhead.frame_head.version: " << (int)*(uint8_t*)(shm_ptr + 0x100806) << std::endl;
    std::cout << "mcurxhead.frame_head.segment: " << (int)*(uint8_t*)(shm_ptr + 0x100807) << std::endl;
    std::cout << "mcurxhead.frame_head.offset: " << *(uint32_t*)(shm_ptr + 0x100808) << std::endl;
    std::cout << "mcurxhead.frame_head.data_len: " << *(uint16_t*)(shm_ptr + 0x10080c) << std::endl;

    // Mask bits
    uint16_t mask = *(uint16_t*)(shm_ptr + 0x10080e);
    std::cout << "mcurxhead.mask.b0: " << (mask & 0x0001) << " (驱动轮: " << ((mask & 0x0001) ? "使能" : "去使能") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b1: " << ((mask >> 1) & 0x0001) << " (充电: " << (((mask >> 1) & 0x0001) ? "充电" : "未充电") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b2: " << ((mask >> 2) & 0x0001) << " (充电接触: " << (((mask >> 2) & 0x0001) ? "接触" : "未接触") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b3: " << ((mask >> 3) & 0x0001) << " (S轮: " << (((mask >> 3) & 0x0001) ? "未到位" : "到位") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b4-7: " << ((mask >> 4) & 0x000F) << std::endl;
    std::cout << "mcurxhead.mask.b8: " << ((mask >> 8) & 0x0001) << " (底盘左轮驱动器错误: " << (((mask >> 8) & 0x0001) ? "已清除" : "未清除") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b9: " << ((mask >> 9) & 0x0001) << " (底盘右轮驱动器错误: " << (((mask >> 9) & 0x0001) ? "已清除" : "未清除") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b10: " << ((mask >> 10) & 0x0001) << " (清扫驱动器错误: " << (((mask >> 10) & 0x0001) ? "已清除" : "未清除") << ")" << std::endl;
    std::cout << "mcurxhead.mask.b11-15: " << ((mask >> 11) & 0x001F) << std::endl;

    // Speed values
    std::cout << "mcurxhead.speed_x: " << *(int16_t*)(shm_ptr + 0x100810) << " m/s (x轴方向目标线速度)" << std::endl;
    std::cout << "mcurxhead.speed_y: " << *(int16_t*)(shm_ptr + 0x100812) << " m/s (y轴方向目标线速度)" << std::endl;
    std::cout << "mcurxhead.speed_angle: " << *(int16_t*)(shm_ptr + 0x100814) << " rad/s (目标角速度)" << std::endl;

    // Timestamps
    std::cout << "mcurxhead.time_stamp_second: " << *(uint32_t*)(shm_ptr + 0x100816) << std::endl;
    std::cout << "mcurxhead.time_stamp_microsecond: " << *(uint32_t*)(shm_ptr + 0x10081a) << std::endl;

    // Driver errors
    for(int i = 0; i < 8; i++) {
        std::cout << "mcurxhead.driver_error[" << i << "]: " << *(uint16_t*)(shm_ptr + 0x10081e + i*2) << std::endl;
    }

    // VCU status and errors
    std::cout << "mcurxhead.vcu_status: " << *(int16_t*)(shm_ptr + 0x10082e) << " (VCU状态)" << std::endl;
    
    uint16_t vcu_error = *(uint16_t*)(shm_ptr + 0x100830);
    std::cout << "mcurxhead.vcu_error.b0: " << (vcu_error & 0x0001) << " (标定: " << ((vcu_error & 0x0001) ? "未标定" : "已标定") << ")" << std::endl;
    std::cout << "mcurxhead.vcu_error.b1: " << ((vcu_error >> 1) & 0x0001) << " (时间同步: " << (((vcu_error >> 1) & 0x0001) ? "异常" : "正常") << ")" << std::endl;
    std::cout << "mcurxhead.vcu_error.b2: " << ((vcu_error >> 2) & 0x0001) << " (0#CAN总线: " << (((vcu_error >> 2) & 0x0001) ? "故障" : "正常") << ")" << std::endl;
    std::cout << "mcurxhead.vcu_error.b3: " << ((vcu_error >> 3) & 0x0001) << " (1#CAN总线: " << (((vcu_error >> 3) & 0x0001) ? "故障" : "正常") << ")" << std::endl;
    std::cout << "mcurxhead.vcu_error.b4: " << ((vcu_error >> 4) & 0x0001) << " (0#RS485: " << (((vcu_error >> 4) & 0x0001) ? "故障" : "正常") << ")" << std::endl;
    std::cout << "mcurxhead.vcu_error.b5: " << ((vcu_error >> 5) & 0x0001) << " (1#RS485: " << (((vcu_error >> 5) & 0x0001) ? "故障" : "正常") << ")" << std::endl;
    std::cout << "mcurxhead.vcu_error.b6-7: " << ((vcu_error >> 6) & 0x0003) << std::endl;
    
    for(int i = 8; i < 16; i++) {
        std::cout << "mcurxhead.vcu_error.b" << i << ": " << ((vcu_error >> i) & 0x0001) << " (" << i-8 << "#驱动器: " << (((vcu_error >> i) & 0x0001) ? "故障" : "正常") << ")" << std::endl;
    }

    // Battery info
    std::cout << "mcurxhead.vcu_battery.voltage: " << *(int16_t*)(shm_ptr + 0x100832) / 100.0 << "V (电池电压)" << std::endl;
    std::cout << "mcurxhead.vcu_battery.current: " << *(int16_t*)(shm_ptr + 0x100834) / 100.0 << "A (电池电流)" << std::endl;
    std::cout << "mcurxhead.vcu_battery.total_capacity: " << *(int16_t*)(shm_ptr + 0x100836) << std::endl;
    std::cout << "mcurxhead.vcu_battery.left_capacity: " << *(int16_t*)(shm_ptr + 0x100838) << std::endl;
    std::cout << "mcurxhead.vcu_battery.cycle: " << *(int16_t*)(shm_ptr + 0x10083a) << std::endl;
    std::cout << "mcurxhead.vcu_battery.status: " << *(int16_t*)(shm_ptr + 0x10083c) << std::endl;

    // Coordinate info
    std::cout << "mcurxhead.coordinate_x: " << *(int32_t*)(shm_ptr + 0x10083e) << std::endl;
    std::cout << "mcurxhead.coordinate_y: " << *(int32_t*)(shm_ptr + 0x100842) << std::endl;
    std::cout << "mcurxhead.coordinate_angle: " << *(int16_t*)(shm_ptr + 0x100846) << std::endl;

    // Additional status
    std::cout << "mcurxhead.battery_status2: " << *(int16_t*)(shm_ptr + 0x100848) << std::endl;
    std::cout << "mcurxhead.driver_error_ext: " << *(int16_t*)(shm_ptr + 0x10084a) << std::endl;
    std::cout << "mcurxhead.driver_error_ext2: " << *(int16_t*)(shm_ptr + 0x10084c) << std::endl;

}

class SharedMemory {
private:
    int shmid_;
    void* shm_ptr_;
    bool initialized_;

public:
    SharedMemory() : shmid_(-1), shm_ptr_(nullptr), initialized_(false) {}

    bool init() {
        // 使用固定key值 0x3b1a0002
        key_t key = 0x3b1a0002;

        // 尝试连接共享内存
        shmid_ = shmget(key, SHM_SIZE, 0666);
        if (shmid_ == -1) {
            std::cerr << "Failed to get shared memory (key=0x" 
                     << std::hex << key << "): " 
                     << strerror(errno) << std::endl;
            return false;
        }

        // 射共享内存
        shm_ptr_ = shmat(shmid_, nullptr, 0);
        if (shm_ptr_ == (void*)-1) {
            std::cerr << "Failed to attach shared memory: " << strerror(errno) << std::endl;
            return false;
        }

        initialized_ = true;
        std::cout << "Successfully attached to shared memory segment (key=0x" 
                 << std::hex << key << ", id=" << std::dec << shmid_ << ")" << std::endl;
        return true;
    }

    void* getPtr() const {
        return initialized_ ? shm_ptr_ : nullptr;
    }

    ~SharedMemory() {
        if (initialized_ && shm_ptr_ != nullptr) {
            shmdt(shm_ptr_);
        }
    }
};

void printHelp() {
    std::cout << "Usage: read_grace_mem [options]\n"
              << "Options:\n"
              << "  -h, --help     Show this help message\n"
              << "  -i, --interval Specify update interval in milliseconds (default: 1000)\n"
              << "  -c, --count    Specify number of updates (default: infinite)\n"
              << std::endl;
}

// 全局变量用于信号处理
std::atomic<bool> g_running{true};

// 信号处理函
void signalHandler(int) {
    g_running = false;
}

int main(int argc, char* argv[]) {
    // 默认参数
    int interval_ms = 1000;
    int update_count = -1;  // -1 表示无限循环

    // 解析命令行参数
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-h" || arg == "--help") {
            printHelp();
            return 0;
        } else if (arg == "-i" || arg == "--interval") {
            if (i + 1 < argc) {
                interval_ms = std::stoi(argv[++i]);
            }
        } else if (arg == "-c" || arg == "--count") {
            if (i + 1 < argc) {
                update_count = std::stoi(argv[++i]);
            }
        }
    }

    // 初始化共享内存
    SharedMemory shm;
    if (!shm.init()) {
        std::cerr << "Failed to initialize shared memory" << std::endl;
        return 1;
    }

    // 设置信号处理
    signal(SIGINT, signalHandler);

    // 主循环
    int count = 0;
    while (g_running && (update_count == -1 || count < update_count)) {
        system("clear");  // 清屏
        std::cout << "=== Grace Memory Monitor ===\n" 
                 << "Press Ctrl+C to exit\n"
                 << "Update interval: " << interval_ms << "ms\n"
                 << "Update count: " << count << "\n"
                 << "========================\n" << std::endl;

        // 打印数
        printVehicleData(static_cast<uint8_t*>(shm.getPtr()));

        // 等待下一次更新
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
        count++;
    }

    return 0;
}
