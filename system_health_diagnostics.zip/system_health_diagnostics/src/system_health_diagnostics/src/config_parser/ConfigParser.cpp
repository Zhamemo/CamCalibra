#include "config_parser/ConfigParser.h"

#include <yaml-cpp/exceptions.h>
#include <yaml-cpp/node/node.h>

#include <cstdlib>
#include <memory>
#include <string>
#include <tuple>

#include "components/FileChecker.h"
#include "components/SWChecker.h"
#include "components/SysChecker.h"
#include "reporter/FileReporter.h"
#include "reporter/SwReporter.h"
#include "reporter/SysReporter.h"
#include "ros/node_handle.h"

namespace system_health_diagnostics {
ConfigParser::ConfigParser() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  nh.param<std::string>(
      "config_path", config_path_,
      "/home/ubuntu/ud_ws/params/params/C50B/system_health_diagnostics.yaml");
}

void ConfigParser::parseConfig(std::string& config_path) try {
  ROS_INFO("[%s][%s][%d]: Loading config file: %s", node_name_str_.c_str(),
           __func__, __LINE__, config_path.c_str());

  YAML::Node root = YAML::LoadFile(config_path);
  auto sys_config = this->parseSysComponent(root);
  auto files_vec = this->parseFileComponent(root);
  auto sw_nodes = this->parseSWComponent(root);

  sys_config_ = sys_config;
  files_vec_ = files_vec;
  nodes_vec_ = sw_nodes;
  return;
} catch (YAML::Exception& e) {
  ROS_ERROR("[%s][%s][%d]: Exception happened: %s", node_name_str_.c_str(),
            __func__, __LINE__, e.what());
  return;
}

SysConfig ConfigParser::parseSysComponent(YAML::Node root) {
  SysConfig sys_config;
  if (YAML::Node system_config = root["components"]["system"]) {
    int disk_threshold = system_config["disk"]["threshold"].as<int>();
    double cpu_usage = system_config["cpu"]["usage"].as<double>();
    double mem_usage = system_config["mem"]["usage"].as<double>();

    std::stringstream ss;
    ss << "disk_threashold: " << disk_threshold << ", cpu_usage: " << cpu_usage
       << ", mem_usage: " << mem_usage;
    ROS_INFO("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
             ss.str().c_str());

    sys_config.max_disk_threshold = disk_threshold;
    sys_config.max_cpu_usage = cpu_usage;
    sys_config.max_mem_usage = mem_usage;
  } else {
    ROS_ERROR(
        "[%s][%s][%d]: Parsing config error, no file component config found!",
        node_name_str_.c_str(), __func__, __LINE__);
    return sys_config;
  }

  system_health_diagnostics::SysReporter::getInstance()->initialize();
  ROS_INFO("[%s][%s][%d]:Parse system components completed!",
           node_name_str_.c_str(), __func__, __LINE__);
  return sys_config;
}

std::vector<File> ConfigParser::parseFileComponent(YAML::Node root) {
  std::vector<File> file_list;
  if (YAML::Node files_seq = root["components"]["file"]["filelist"]) {
    if (!files_seq.IsSequence()) {
      ROS_ERROR("[%s][%s][%d]: Not a sequence!", node_name_str_.c_str(),
                __func__, __LINE__);
      return file_list;
    }

    for (const auto& file_node : files_seq) {
      File file;
      std::string file_path = file_node.as<std::string>();
      file.file_path = file_path;
      file_list.push_back(file);

      custom_msgs_srvs::FileStatus file_ins;
      file_ins.file_path = file_path;
    }
  } else {
    ROS_ERROR(
        "[%s][%s][%d]: Parsing config error, no file component config found!",
        node_name_str_.c_str(), __func__, __LINE__);
    return file_list;
  }

  system_health_diagnostics::FileReporter::getInstance()->initialize(file_list);
  ROS_INFO("[%s][%s][%d]: Parse file components completed!",
           node_name_str_.c_str(), __func__, __LINE__);
  return file_list;
}

std::vector<Node> ConfigParser::parseSWComponent(YAML::Node root) {
  std::vector<Node> check_nodes;
  std::vector<system_health_diagnostics::TopicStatus> monitor_topics_vec;
  std::vector<system_health_diagnostics::NodeStatus> monitor_nodes_vec;

  if (YAML::Node nodes = root["components"]["software"]["nodes"]) {
    for (const auto& node : nodes) {
      system_health_diagnostics::Node monitor_node;
      std::string nodeName = node["nodename"].as<std::string>();
      monitor_node.name = nodeName;
      monitor_nodes_vec.push_back({nodeName});

      if (YAML::Node topics_rates = node["topics&rates"]) {
        for (const auto& it : topics_rates) {
          std::string topic_name = it["topic"].as<std::string>();
          int warning_rate = it["rate"]["warning"].as<int>();
          int error_rate = it["rate"]["error"].as<int>();
          int fatal_error_rate = it["rate"]["fatal_error"].as<int>();
          system_health_diagnostics::Node::CheckRate rate =
              std::make_tuple(warning_rate, error_rate, fatal_error_rate);
          monitor_node.checkTopics[topic_name] = rate;
          system_health_diagnostics::TopicStatus topic_status(
              topic_name, nodeName, warning_rate, error_rate, fatal_error_rate);
          monitor_topics_vec.push_back(topic_status);
        }
      }
      check_nodes.push_back(monitor_node);
    }
  } else {
    ROS_ERROR(
        "[%s][%s][%d]: Parsing config error, no software nodes component "
        "config found!",
        node_name_str_.c_str(), __func__, __LINE__);
    return check_nodes;
  }

  system_health_diagnostics::SwReporter::getInstance()->initialize(
      monitor_topics_vec, monitor_nodes_vec);

  ROS_INFO("[%s][%s][%d]: Parse sw components completed!",
           node_name_str_.c_str(), __func__, __LINE__);
  return check_nodes;
}

void ConfigParser::parse() noexcept {
  this->parseConfig(config_path_);
  return;
}
}  // namespace system_health_diagnostics
