#include "reporter/SwReporter.h"

#include <custom_msgs_srvs/NodeHealthStaus.h>
#include <custom_msgs_srvs/NodeStatus.h>
#include <custom_msgs_srvs/StatusInfo.h>
#include <custom_msgs_srvs/TopicStatus.h>

#include <chrono>
#include <sstream>
#include <thread>

#include "ros/node_handle.h"
#include "ros/rate.h"

namespace system_health_diagnostics {

// Initialize the static member variable
std::shared_ptr<SwReporter> SwReporter::instance = nullptr;

void SwReporter::initialize(std::vector<TopicStatus> monitor_topics,
                            std::vector<NodeStatus> monitor_nodes) {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();

  sw_pub_ =
      nh.advertise<custom_msgs_srvs::NodeHealthStaus>("/software_status", 1);

  /* initialize default map */
  for (const auto& topic : monitor_topics) {
    topic_status_map_[topic] = 0;
  }

  for (const auto& node : monitor_nodes) {
    node_status_map_[node] = false;
  }

  sys_sw_status_ = nullptr;
  return;
}

custom_msgs_srvs::NodeHealthStaus SwReporter::getRosMsg() {
  custom_msgs_srvs::NodeHealthStaus msg;
  msg.header.stamp = ros::Time::now();
  for (const auto& [node, status] : node_status_map_) {
    custom_msgs_srvs::NodeStatus node_status_msg;
    node_status_msg.node_name = node.node_name;
    node_status_msg.status = status;
    msg.node_status.push_back(node_status_msg);
  }

  for (const auto& [topic_stauts, freq] : topic_status_map_) {
    custom_msgs_srvs::TopicStatus topic_status_msg;
    topic_status_msg.topic_name = topic_stauts.topic_name;
    topic_status_msg.node_name = topic_stauts.node_name;
    topic_status_msg.topic_hz = freq;

    /* Set Error Level in Here */
    if (topic_stauts.fatal_error_hz > freq) {
      std::stringstream ss;
      ss << "node: " << topic_stauts.node_name
         << "; topic: " << topic_stauts.topic_name << "; actual rate: " << freq
         << " is lower than topic fatal error hz: "
         << topic_stauts.fatal_error_hz << std::endl;
      ROS_INFO("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
               ss.str().c_str());

      topic_status_msg.ERROR_LEVEL = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
      msg.topic_status.push_back(topic_status_msg);
      continue;
    }

    if (topic_stauts.error_hz > freq) {
      std::stringstream ss;
      ss << "node: " << topic_stauts.node_name
         << "; topic: " << topic_stauts.topic_name << "; actual rate: " << freq
         << " is lower than topic error hz: " << topic_stauts.error_hz
         << std::endl;
      ROS_INFO("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
               ss.str().c_str());

      topic_status_msg.ERROR_LEVEL = custom_msgs_srvs::StatusInfo::ERROR;
      msg.topic_status.push_back(topic_status_msg);
      continue;
    }

    if (topic_stauts.warning_hz > freq) {
      std::stringstream ss;
      ss << "node: " << topic_stauts.node_name
         << "; topic: " << topic_stauts.topic_name << "; actual rate: " << freq
         << " is lower than topic warning hz: " << topic_stauts.warning_hz
         << std::endl;
      ROS_INFO("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
               ss.str().c_str());

      topic_status_msg.ERROR_LEVEL = custom_msgs_srvs::StatusInfo::WARNING;
      msg.topic_status.push_back(topic_status_msg);
      continue;
    }

    topic_status_msg.ERROR_LEVEL = custom_msgs_srvs::StatusInfo::OK;
    msg.topic_status.push_back(topic_status_msg);
  }
  return msg;
}

bool SwReporter::checkStatusMap() {
  /*
   *  check if topic_status_map is filled.
   */
  for (auto& [topic, freq] : topic_status_map_) {
    if (freq != -1) {
      return true;
    }
  }
  return false;
}

void SwReporter::pubSwStatus() {
  if (!ros::ok()) {
    return;
  }

  /* if not all status are not set, wait 500ms */
  std::lock_guard<std::mutex> lg(lock);
  if (!checkStatusMap()) {
    return;
  }

  /* all topics are setted */
  const auto& sw_status = getRosMsg();
  setSwStatus(sw_status);
  sw_pub_.publish(sw_status);

  /* reset flag when publish is finished */
  for (auto& [_, flag] : topic_status_map_) {
    flag = -1.0;
  }
  return;
}

void SwReporter::updateTopicStatusMap(const TopicStatus& topic_status,
                                      float actual_rate) {
  std::lock_guard<std::mutex> lg(lock);
  topic_status_map_[topic_status] = actual_rate;
  return;
}

void SwReporter::updateNodeStatusMap(const NodeStatus& node_status,
                                     bool is_existd) {
  std::lock_guard<std::mutex> lg(lock);
  node_status_map_[node_status] = is_existd;
  return;
}

void SwReporter::setSwStatus(
    const custom_msgs_srvs::NodeHealthStaus& sw_status) {
  sys_sw_status_ =
      boost::make_shared<custom_msgs_srvs::NodeHealthStaus>(sw_status);
}

custom_msgs_srvs::NodeHealthStaus::ConstPtr SwReporter::getSwStatus() {
  std::lock_guard<std::mutex> lg(sw_status_lock_);
  return sys_sw_status_;
}
}  // namespace system_health_diagnostics