
#include "reporter/SysReporter.h"

#include <custom_msgs_srvs/SystemPerformanceStatus.h>
#include <ros/ros.h>

#include <cstddef>
#include <memory>
#include <mutex>

#include "components/SysChecker.h"
#include "ros/node_handle.h"

namespace system_health_diagnostics {
std::shared_ptr<SysReporter> SysReporter::instance = nullptr;

void SysReporter::initialize() {
  ros::NodeHandle nh("~");
  sys_pub_ = nh.advertise<custom_msgs_srvs::SystemPerformanceStatus>(
      "/perf_status", 1);
  return;
}

void SysReporter::updateSysStatus(
    const system_health_diagnostics::SysCheckResult& sys_check_result) {
  std::lock_guard<std::mutex> lg(lock);
  sys_status_.disk_usage = sys_check_result.disk_usage;
  sys_status_.disk_error_level = sys_check_result.disk_status;

  sys_status_.mem_usage = sys_check_result.mem_usage;
  sys_status_.mem_error_level = sys_check_result.mem_status;

  sys_status_.cpu_usage = sys_check_result.cpu_usage;
  sys_status_.cpu_error_level = sys_check_result.cpu_status;
  return;
}

void SysReporter::pubSysStatus() {
  if (!sys_pub_) {
    return;
  }

  custom_msgs_srvs::SystemPerformanceStatus sys_status;
  sys_status.header.stamp = ros::Time::now();
  {
    std::lock_guard<std::mutex> lg(lock);
    sys_status = sys_status_;
  }

  sys_pub_.publish(sys_status);
  return;
}

custom_msgs_srvs::SystemPerformanceStatus::ConstPtr
SysReporter::getSysStatus() {
  std::lock_guard<std::mutex> lg(lock);
  return boost::make_shared<custom_msgs_srvs::SystemPerformanceStatus>(
      sys_status_);
}
}  // namespace system_health_diagnostics
