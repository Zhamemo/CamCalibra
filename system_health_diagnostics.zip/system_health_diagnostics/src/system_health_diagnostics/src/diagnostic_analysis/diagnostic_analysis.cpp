#include "diagnostic_analysis/diagnostic_analysis.hpp"

#include <shm_grace.h>
#include <std_msgs/String.h>

namespace system_health_diagnostics {
DiagnosticAnalysis::DiagnosticAnalysis() { initParm(); }

void DiagnosticAnalysis::initParm() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
  error_record_pub_ =
      nh.advertise<custom_msgs_srvs::StatusInfo>("/ZWJ_health_state", 1, true);
  error_reset_pub_ =
      nh.advertise<custom_msgs_srvs::StatusInfo>("/ZWJ_error_restore", 1, true);
}

void DiagnosticAnalysis::stopRobot() {
  Grace::ChassisCmd cmd_vel;
  cmd_vel.command_linear_x = 0.0;
  cmd_vel.command_linear_y = 0.0;
  Grace::send_speed(cmd_vel);
  return;
}

int DiagnosticAnalysis::compareModulePriority(const std::string& module) {
  if (module == "file") return 4;
  if (module == "hw") return 3;
  if (module == "sw") return 2;
  if (module == "sys") return 1;
  return 0;
}

bool DiagnosticAnalysis::checkFaultTimeout(const ros::Time& last_fault_time,
                                           double timeout) {
  return (ros::Time::now() - last_fault_time).toSec() > timeout;
}

void DiagnosticAnalysis::publishErrorMsg(const StatusInfoWrapper& msg,
                                         ros::Publisher& pub) {
  static StatusInfoWrapper last_error_msg = StatusInfoWrapper();
  static ros::Time last_error_time = ros::Time::now();
  if (msg != last_error_msg || checkFaultTimeout(last_error_time)) {
    const auto& error_msg = toRosMsg(msg);
    pub.publish(error_msg);
    last_error_time = ros::Time::now();

    if (msg.error_level != 0) {
      ROS_ERROR(
          "[%s][%s][%d]: Error happened! module: %s; error_msg: %s; "
          "error_level: "
          "%d",
          node_name_str_.c_str(), __func__, __LINE__, error_msg.module.c_str(),
          error_msg.error_msg.c_str(), (int)error_msg.error_level);
    }
    return;
  }
}

void DiagnosticAnalysis::restApkErrorMsg(const StatusInfoWrapper& msg,
                                         ros::Publisher& pub) {
  const auto& error_msg = toRosMsg(msg);
  pub.publish(error_msg);

  ROS_INFO(
      "[%s][%s][%d]: The error has been restored! module: %s; error_msg: %s; "
      "error_level: %d",
      node_name_str_.c_str(), __func__, __LINE__, error_msg.module.c_str(),
      error_msg.error_msg.c_str(), (int)error_msg.error_level);
  return;
}

custom_msgs_srvs::StatusInfo DiagnosticAnalysis::toRosMsg(
    const StatusInfoWrapper& wrapper) {
  custom_msgs_srvs::StatusInfo msg;
  msg.header = wrapper.header;
  msg.module = wrapper.module;
  msg.error_msg = wrapper.error_msg;
  msg.error_level = wrapper.error_level;
  return msg;
}

void DiagnosticAnalysis::updateDiagnosticStatus(
    const custom_msgs_srvs::SystemHealthStaus::Ptr& msg) {
  std::vector<StatusInfoWrapper> infos{msg->chassis,             // 清洁设备
                                       msg->file,                // 文件状态
                                       msg->nodes_heart,         // 节点心跳
                                       msg->nuwa_1,              // 前向深度相机
                                       msg->nuwa_2,              // 后向深度相机
                                       msg->nuwa_3,              // 左向深度相机
                                       msg->nuwa_4,              // 右向深度相机
                                       msg->lidar_3d,            // 3D雷达
                                       msg->lidar_2d,            // 2D雷达
                                       msg->imu,                 // IMU
                                       msg->odom,                // 里程计
                                       msg->zwj_swj_connection,  // 中上连接
                                       msg->robot_localization,  // 定位模块
                                       msg->robot_planning,      // 规划模块
                                       msg->robot_perception,    // 感知模块
                                       msg->robot_charge,        // 充电模块
                                       msg->sys_perf};           // 系统运行

  std::sort(infos.begin(), infos.end(), [this](const auto& a, const auto& b) {
    // 1. 按错误级别排序
    if (a.error_level != b.error_level) {
      return a.error_level < b.error_level;
    }
    // 2. 按模块优先级排序
    const int a_priority = compareModulePriority(a.module);
    const int b_priority = compareModulePriority(b.module);
    if (a_priority != b_priority) {
      return a_priority < b_priority;
    }
    // 3. 按时间排序
    return a.header.stamp > b.header.stamp;
  });

  const auto cur_error = infos.back();
  static auto last_error = cur_error;

  // 错误等级 OK=0 WARNING=1 ERROR=2(可恢复) FATAL_ERROR=3(不可恢复)
  if (cur_error.error_level != 0) {
    stopRobot();
  }
  publishErrorMsg(cur_error, error_record_pub_);

  // 恢复APK错误消息
  if (cur_error.error_level == 0 && last_error.error_level == 2) {
    restApkErrorMsg(last_error, error_reset_pub_);
  }

  last_error = cur_error;
  return;
}
}  // namespace system_health_diagnostics