# Orin HealthChecker

## 介绍:

__特性列表__:

1. 支持配置文件自定义实现对文件，软件结点&话题频率, 硬件(GPS||相机), 系统磁盘以及系统时间的检查
2. orin健康检测往`/orin_status`发布msg

```
bool sw_module_state # 软件模块检查;当status为true时代表正常，当status为false时代表异常
bool hw_module_state # 硬件模块检查;当status为true时代表正常，当status为false时代表异常
bool file_module_state  # 文件模块检查;当status为true时代表正常，当status为false时代表异常
bool sys_module_state # 系统模块检查;当status为true时代表正常，当status为false时代表异常

string reason # 如果模块检查为false，显示原因

uint8 FATAL_ERROR=0
uint8 ERROR=1
uint8 WARNING=2
uint8 OK=3
uint8 ERROR_LEVEL
```

__使用方式__:

读取环境变量`ORIN_CHECKER_CONFIG_PATH`为配置文件路径，修改.yml文件来适配检查项. 参考`config/checkconfig.yml`文件. 之后启动结点`rosrun system_health_diagnostics orin_healthchecker_node`即可.


## 检查逻辑:

Note: 所有报错都会带上报错原因

### 软件模块

1. 配置的结点在运行过程中出现rosmaster检测不到,则报FATAL_ERROR.
2. 配置的结点频率在运行过程掉频(小于目标1hz),则报ERROR.


### 硬件模块

1. cpld状态不正常, 报FATAL_ERROR
1. 当与x86系统时钟源差值大于阈值则报FATAL_ERROR

### 文件模块

1. 配置的文件在运行过程中或者启动时不存在，会将msgz中的file_module_state设为False，并报FATAL_ERROR

### 系统模块

1. 当实际上的文件阈值($HOME目录下)占用的磁盘空间大于配置的文件的磁盘空间，则报FATAL_ERROR

### TODO
```
software:
	check topic1 [pubnode ;topic ;frequency; error level]
	check topic2 [pubnode ;topic ;frequency; error level]
	
	check node1[nodename; 1] # exist
	check node2[nodename; 2] # no exist

hardware:
	perception camera [1,1,1,1] #Front, Back, Left, Right
	monitor camera[1,1,1,1]
	zvision[1,1,1,1]

system:
	disk   [status; error level]
	mem [status; error level]
	cpu   [status; error level]

file: 
	check file1[file name; 1] # exist
	check file2[file name; 0] # no exist

standby accept: 0/1

```