#pragma once

#include <ros/ros.h>

#include <boost/smart_ptr/shared_ptr.hpp>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

namespace system_health_diagnostics {
struct Node {
  typedef std::string TopicName;
  typedef std::tuple<int /*warning rate*/, int /*error rate*/,
                     int /*fatal error*/>
      CheckRate;

  std::string name;
  std::unordered_map<TopicName, CheckRate> checkTopics;
};

class SWChecker {
 public:
  SWChecker();
  ~SWChecker() = default;
  SWChecker(const SWChecker&) = delete;
  SWChecker& operator=(const SWChecker&) = delete;

 private:
  void checkNodesStatus(const std::vector<Node>& nodes);

 public:
  void initNodesMonitor(const std::vector<Node>& nodes,
                        std::vector<ros::Subscriber>& ros_sub_vec);
  void startMonitorNodes(bool start_flag = false);

 private:
  std::string node_name_str_;
};

}  // namespace system_health_diagnostics