#pragma once

#include <memory>
#include <mutex>

namespace common {
template <typename T>
class Atomic final {
 public:
  Atomic() : data_() {}

  explicit Atomic(T data) : data_(std::move(data)) {}

  T Load() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return data_;
  }

  void Store(const T& data) {
    std::lock_guard<std::mutex> lock(mutex_);
    data_ = data;
  }

  void Store(T&& data) {
    std::lock_guard<std::mutex> lock(mutex_);
    data_ = std::move(data);
  }

 private:
  mutable std::mutex mutex_;
  T data_;
};
}  // namespace common