#pragma once

#include <custom_msgs_srvs/SystemHealthStaus.h>
#include <ros/ros.h>

namespace system_health_diagnostics {
struct StatusInfoWrapper {
  std_msgs::Header header;
  std::string module;
  std::string error_msg;
  uint8_t error_level;

  StatusInfoWrapper() : header(), module(""), error_msg(""), error_level(0) {}

  StatusInfoWrapper(const custom_msgs_srvs::StatusInfo& msg)
      : header(msg.header),
        module(msg.module),
        error_msg(msg.error_msg),
        error_level(msg.error_level) {}

  bool operator==(const StatusInfoWrapper& other) const {
    return header.stamp == other.header.stamp &&
           header.frame_id == other.header.frame_id && module == other.module &&
           error_msg == other.error_msg && error_level == other.error_level;
  }

  bool operator!=(const StatusInfoWrapper& other) const {
    return !(*this == other);
  }
};

class DiagnosticAnalysis
    : public std::enable_shared_from_this<DiagnosticAnalysis> {
 public:
  ~DiagnosticAnalysis() = default;

  DiagnosticAnalysis(const DiagnosticAnalysis&) = delete;
  DiagnosticAnalysis& operator=(const DiagnosticAnalysis&) = delete;

 private:
  DiagnosticAnalysis();

 private:
  void initParm();

 private:
  void stopRobot();

  int compareModulePriority(const std::string& module);

  bool checkFaultTimeout(const ros::Time& last_fault_time,
                         double timeout = 10.0);

  void publishErrorMsg(const StatusInfoWrapper& msg, ros::Publisher& pub);

  void restApkErrorMsg(const StatusInfoWrapper& msg, ros::Publisher& pub);

  custom_msgs_srvs::StatusInfo toRosMsg(const StatusInfoWrapper& wrapper);

 public:
  void updateDiagnosticStatus(
      const custom_msgs_srvs::SystemHealthStaus::Ptr& msg);

  static std::shared_ptr<DiagnosticAnalysis> getInstance() {
    static std::shared_ptr<DiagnosticAnalysis> instance(
        new DiagnosticAnalysis());
    return instance;
  }

 private:
  ros::Publisher error_record_pub_;
  ros::Publisher error_reset_pub_;

  std::string node_name_str_;
};
}  // namespace system_health_diagnostics