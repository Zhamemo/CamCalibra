#pragma once

#include <components/SysChecker.h>
#include <custom_msgs_srvs/SystemPerformanceStatus.h>
#include <ros/ros.h>

#include <memory>
#include <mutex>

namespace system_health_diagnostics {
class SysReporter : public std::enable_shared_from_this<SysReporter> {
 public:
  ~SysReporter() {}
  SysReporter(const SysReporter&) = delete;
  SysReporter& operator=(const SysReporter&) = delete;

 private:
  SysReporter() = default;

 private:
  static std::shared_ptr<SysReporter> instance;

  ros::Publisher sys_pub_;
  custom_msgs_srvs::SystemPerformanceStatus sys_status_;
  std::mutex lock;

 public:
  void initialize();
  void updateSysStatus(
      const system_health_diagnostics::SysCheckResult& sys_check_result);
  void pubSysStatus();

  custom_msgs_srvs::SystemPerformanceStatus::ConstPtr getSysStatus();

  static std::shared_ptr<SysReporter> getInstance() {
    // Create the singleton instance if it doesn't exist
    if (!instance) {
      instance = std::shared_ptr<SysReporter>(new SysReporter());
    }
    return instance;
  }
};
}  // namespace system_health_diagnostics