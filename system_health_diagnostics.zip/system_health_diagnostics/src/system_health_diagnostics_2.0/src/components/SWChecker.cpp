
#include "components/SWChecker.h"

#include <ros/master.h>

#include <boost/smart_ptr/shared_ptr.hpp>

#include "common/general_subscriber.h"

namespace system_health_diagnostics {
SWChecker::SWChecker() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
}
void SWChecker::checkNodesStatus(const std::vector<Node>& nodes) {
  std::vector<std::string> active_nodes;
  active_nodes.reserve(nodes.size());
  ros::master::getNodes(active_nodes);

  std::set<std::string> active_node_set(active_nodes.begin(),
                                        active_nodes.end());
  for (const auto& node : nodes) {
    bool is_found = (active_node_set.find(node.name) != active_node_set.end());
    auto sw_reporter = SwReporter::getInstance();
    if (sw_reporter) {
      sw_reporter->updateNodeStatusMap(NodeStatus(node.name), is_found);
    }
  }
}

void SWChecker::initNodesMonitor(const std::vector<Node>& nodes,
                                 std::vector<ros::Subscriber>& ros_sub_vec) {
  // checkNodesStatus(nodes);

  for (const auto& node : nodes) {
    ROS_INFO("[%s][%s][%d]: monitor node: %s", node_name_str_.c_str(), __func__,
             __LINE__, node.name.c_str());

    common::lookupRosNodeVec(node.name, false);  // 检查 rosnode
    for (auto& [topic, rate] : node.checkTopics) {
      ROS_INFO("[%s][%s][%d]: Start to lookup topics %s",
               node_name_str_.c_str(), __func__, __LINE__, topic.c_str());

      bool if_topic_existed =
          common::lookupRosTopics(node.name, topic, rate);  // 检查 rostopic
      if (!if_topic_existed) {
        continue;
      }

      auto sub = common::subscribe(node.name, topic, rate);
      ros_sub_vec.push_back(sub);  // 初始化 subscribe
    }
  }
  return;
}

void SWChecker::startMonitorNodes(bool start_flag) {
  if (start_flag) {
    ROS_INFO("[%s][%s][%d]: Start to lookup monitor nodes",
             node_name_str_.c_str(), __func__, __LINE__);

    common::lookupRosNodeVec("", true);  // 传入空字段方便函数复用
    return;
  } else {
    ROS_ERROR("[%s][%s][%d]: Failed to start to lookup monitor nodes",
              node_name_str_.c_str(), __func__, __LINE__);
    return;
  }
}
}  // namespace system_health_diagnostics
