#include "components/FileChecker.h"

#include <sys/epoll.h>
#include <sys/inotify.h>
#include <unistd.h>

#include <iostream>
#include <sstream>
#include <unordered_map>

#include "components/SysChecker.h"
#include "reporter/FileReporter.h"

namespace system_health_diagnostics {

FileChecker::FileChecker() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
}

void FileChecker::monitorFilesExist(const std::vector<File>& file_lists) {
  int epoll_fd = epoll_create1(0);
  if (epoll_fd == -1) {
    return;
  }

  if (file_lists.empty()) {
    ROS_ERROR("[%s][%s][%d]: Empty file given for monitoring.",
              node_name_str_.c_str(), __func__, __LINE__);
    return;
  }

  std::unordered_map<int, std::string> watched_files;
  std::unordered_map<std::string, bool> current_file_status;  // 跟踪文件状态

  int inotify_fd = inotify_init();
  if (inotify_fd == -1) {
    return;
  } else {
    ROS_INFO("[%s][%s][%d]: create inotify_fd: %d", node_name_str_.c_str(),
             __func__, __LINE__, inotify_fd);
  }

  for (const auto& file : file_lists) {
    const std::string& file_path = file.file_path;

    // 启动时检查文件状态，并上报
    bool exists = (access(file_path.c_str(), F_OK) == 0);
    current_file_status[file_path] = exists;
    system_health_diagnostics::FileReporter::getInstance()->updateFileStatus(
        file_path, exists);

    if (exists) {
      ROS_INFO("[%s][%s][%d]: Initial check: file exists: %s",
               node_name_str_.c_str(), __func__, __LINE__, file_path.c_str());
    } else {
      ROS_WARN("[%s][%s][%d]: Initial check: file MISSING: %s",
               node_name_str_.c_str(), __func__, __LINE__, file_path.c_str());
    }

    // 监听删除 和 属性变化（如重新创建）事件
    int wd = inotify_add_watch(inotify_fd, file_path.c_str(),
                               IN_DELETE_SELF | IN_ATTRIB);
    if (wd < 0) {
      ROS_ERROR("[%s][%s][%d]: inotify_add_watch failed for file: %s",
                node_name_str_.c_str(), __func__, __LINE__, file_path.c_str());
      continue;
    }

    watched_files[wd] = file_path;
  }

  struct epoll_event event;
  event.data.fd = inotify_fd;
  event.events = EPOLLIN;

  if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, inotify_fd, &event) == -1) {
    close(inotify_fd);
    close(epoll_fd);
    return;
  }

  const int MAX_EVENTS = file_lists.size();
  struct epoll_event events[MAX_EVENTS];

  while (true) {
    int num_events = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
    if (num_events == -1) {
      break;
    }

    for (int i = 0; i < num_events; ++i) {
      if (events[i].data.fd == inotify_fd) {
        char buf[1024];
        ssize_t bytesRead = read(inotify_fd, buf, sizeof(buf));

        if (bytesRead <= 0) {
          continue;
        }

        ssize_t offset = 0;
        while (offset < bytesRead) {
          struct inotify_event* evt = (struct inotify_event*)&buf[offset];
          int wd = evt->wd;

          if (watched_files.count(wd) == 0) {
            offset += sizeof(struct inotify_event) + evt->len;
            continue;
          }

          std::string file_path = watched_files[wd];

          // 文件删除
          if (evt->mask & IN_DELETE_SELF) {
            if (current_file_status[file_path] == true) {
              current_file_status[file_path] = false;

              std::stringstream ss;
              ss << "file: [" << file_path << "] is deleted.";
              ROS_ERROR("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__,
                        __LINE__, ss.str().c_str());

              system_health_diagnostics::FileReporter::getInstance()
                  ->updateFileStatus(file_path, false);
            }
          }

          // 文件重新出现（属性变化）
          else if (evt->mask & IN_ATTRIB) {
            bool exists = (access(file_path.c_str(), F_OK) == 0);
            if (exists && current_file_status[file_path] == false) {
              current_file_status[file_path] = true;

              std::stringstream ss;
              ss << "file: [" << file_path << "] is restored.";
              ROS_INFO("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__,
                       __LINE__, ss.str().c_str());

              system_health_diagnostics::FileReporter::getInstance()
                  ->updateFileStatus(file_path, true);
            }
          }

          offset += sizeof(struct inotify_event) + evt->len;
        }
      }
    }
  }

  for (const auto& pair : watched_files) {
    inotify_rm_watch(inotify_fd, pair.first);
  }

  close(inotify_fd);
  close(epoll_fd);
}

}  // namespace system_health_diagnostics
