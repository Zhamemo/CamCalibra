#include "components/SysChecker.h"

#include <chrono>
#include <string>
#include <thread>
#include <tuple>

#include "common/helper_function.hpp"
#include "reporter/SysReporter.h"
#include "ros/rate.h"

namespace system_health_diagnostics {
SysChecker::SysChecker() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();
}

std::tuple<double, bool, std::string> SysChecker::checkSysDiskUsage(
    int max_disk_threshold) {
  const char* cmd = "df -h ${HOME} | awk 'FNR==2{print$5}' | cut -d '%' -f1";
  std::string cur_disk_usage = system_health_diagnostics::exec(cmd);

  if (std::stod(cur_disk_usage) > max_disk_threshold) {
    std::stringstream ss;
    ss << "system disk usage is %d over than max disk threshold %d",
        std::stod(cur_disk_usage), max_disk_threshold;
    ROS_ERROR("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
              ss.str().c_str());

    return std::make_tuple(std::stod(cur_disk_usage), false, ss.str());
  }
  return std::make_tuple(std::stod(cur_disk_usage), true, "");
}

std::tuple<double, bool, std::string> SysChecker::checkMemUsage(
    int max_mem_threshold) {
  static long total_mem = std::stol(
      system_health_diagnostics::exec("free | awk '/^Mem:/{print $2}'"));
  long used_mem = std::stol(
      system_health_diagnostics::exec("free | awk '/^Mem:/{print $3}'"));
  static double mem_usage = (used_mem * 100) / total_mem;

  if (mem_usage > max_mem_threshold) {
    std::stringstream ss;
    ss << "system mem usage is %f over than max mem threshold %d", mem_usage,
        max_mem_threshold;
    ROS_ERROR("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
              ss.str().c_str());

    return std::make_tuple(mem_usage, false, ss.str());
  }
  return std::make_tuple(mem_usage, true, "");
}

std::tuple<double, bool, std::string> SysChecker::checkCpuUsage(
    int max_cpu_threshold) {
  const std::string check_cpu_cmd =
      "grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print "
      "usage }'";
  double cpu_usage =
      std::stod(system_health_diagnostics::exec(check_cpu_cmd.c_str()));
  if (cpu_usage > max_cpu_threshold) {
    std::stringstream ss;
    ss << "system cpu usage is %f over than max cpu threshold %d", cpu_usage,
        max_cpu_threshold;
    ROS_ERROR("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__,
              ss.str().c_str());

    return std::make_tuple(cpu_usage, false, ss.str());
  }
  return std::make_tuple(cpu_usage, true, "");
}

void SysChecker::periodCheckSysStatus(
    system_health_diagnostics::SysConfig sys_config, int time) {
  while (true) {
    auto [disk_usage, disk_status, disk_cause] =
        checkSysDiskUsage(sys_config.max_disk_threshold);
    auto [mem_usage, mem_status, mem_cause] =
        checkMemUsage(sys_config.max_mem_usage);
    auto [cpu_usage, cpu_status, cpu_cause] =
        checkCpuUsage(sys_config.max_cpu_usage);

    SysCheckResult sys_check_result;
    sys_check_result.disk_usage = disk_usage;
    sys_check_result.disk_status = disk_status;
    sys_check_result.mem_usage = mem_usage;
    sys_check_result.mem_status = mem_status;
    sys_check_result.cpu_usage = cpu_usage;
    sys_check_result.cpu_status = cpu_status;

    system_health_diagnostics::SysReporter::getInstance()->updateSysStatus(
        sys_check_result);
    system_health_diagnostics::SysReporter::getInstance()->pubSysStatus();
    std::this_thread::sleep_for(std::chrono::seconds(time));
  }
  return;
}
}  // namespace system_health_diagnostics
