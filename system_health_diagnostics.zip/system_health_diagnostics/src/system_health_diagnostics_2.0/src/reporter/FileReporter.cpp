
#include "reporter/FileReporter.h"

#include <ros/ros.h>

namespace system_health_diagnostics {

std::shared_ptr<FileReporter> FileReporter::instance = nullptr;

void FileReporter::initialize(const std::vector<File>& file_vec) {
  {
    std::lock_guard<std::mutex> lg(lock);
    file_vec_ = file_vec;
  }

  ros::NodeHandle nh("~");
  file_pub_ =
      nh.advertise<custom_msgs_srvs::FileStatusArray>("/file_status", 1);
  return;
}

void FileReporter::updateFileStatus(const std::string& file_path,
                                    bool file_status) {
  std::lock_guard<std::mutex> lg(lock);
  for (auto& file : file_vec_) {
    if (file.file_path != file_path) {
      continue;
    }
    file.status = file_status;
    return;
  }
}

void FileReporter::pubFileStatus() {
  std::vector<File> file_vec;
  {
    std::lock_guard<std::mutex> lg(lock);
    file_vec = file_vec_;
  }

  custom_msgs_srvs::FileStatusArray orin_file_msg;
  orin_file_msg.header.stamp = ros::Time::now();

  for (const auto& file : file_vec) {
    custom_msgs_srvs::FileStatus file_msg;
    file_msg.file_path = file.file_path;
    file_msg.status = file.status;
    orin_file_msg.file_status.push_back(file_msg);
  }

  setFileStatus(orin_file_msg);
  file_pub_.publish(orin_file_msg);
  return;
}

void FileReporter::setFileStatus(
    const custom_msgs_srvs::FileStatusArray& file_status) {
  std::lock_guard<std::mutex> lg(file_status_lock_);
  sys_file_status_ =
      boost::make_shared<custom_msgs_srvs::FileStatusArray>(file_status);
}

custom_msgs_srvs::FileStatusArray::ConstPtr FileReporter::getFileStatus() {
  std::lock_guard<std::mutex> lg(file_status_lock_);
  return sys_file_status_;
}
}  // namespace system_health_diagnostics
