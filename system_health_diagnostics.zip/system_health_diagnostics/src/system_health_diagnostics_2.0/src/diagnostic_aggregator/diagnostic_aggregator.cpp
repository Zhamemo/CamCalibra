#include <diagnostic_aggregator/diagnostic_aggregator.hpp>

namespace system_health_diagnostics {
DiagnosticAggregator::DiagnosticAggregator() { initParm(); }

void DiagnosticAggregator::initParm() {
  ros::NodeHandle nh("~");
  node_name_str_ = ros::this_node::getName();

  chassis_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/chassis_status", 10, &DiagnosticAggregator::getChassisStatus, this);
  file_status_sub_ = nh.subscribe<custom_msgs_srvs::FileStatusArray>(
      "/file_status", 10, &DiagnosticAggregator::getFileStatus, this);
  nodes_heart_status_sub_ = nh.subscribe<custom_msgs_srvs::NodeHealthStaus>(
      "/software_status", 10, &DiagnosticAggregator::getNodesHeartStatus, this);
  nuwa_1_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/nuwa_1_status", 10, &DiagnosticAggregator::getNuwa1Status, this);
  nuwa_2_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/nuwa_2_status", 10, &DiagnosticAggregator::getNuwa2Status, this);
  nuwa_3_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/nuwa_3_status", 10, &DiagnosticAggregator::getNuwa3Status, this);
  nuwa_4_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/nuwa_4_status", 10, &DiagnosticAggregator::getNuwa4Status, this);
  lidar_3d_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/lidar_3d_status", 10, &DiagnosticAggregator::getLidar3dStatus, this);
  lidar_2d_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/lidar_2d_status", 10, &DiagnosticAggregator::getLidar2dStatus, this);
  imu_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/imu_status", 10, &DiagnosticAggregator::getImuStatus, this);
  odom_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/odom_status", 10, &DiagnosticAggregator::getOdomStatus, this);
  zwj_swj_connection_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/zwj_swj_connection_status", 10,
      &DiagnosticAggregator::getZwjSwjConnectionStatus, this);
  robot_localization_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_localization_status", 10,
      &DiagnosticAggregator::getRobotLocalizationStatus, this);
  robot_planning_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_planning_status", 10,
      &DiagnosticAggregator::getRobotPlanningStatus, this);
  robot_perception_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_perception_status", 10,
      &DiagnosticAggregator::getRobotPerceptionStatus, this);
  robot_charge_status_sub_ = nh.subscribe<custom_msgs_srvs::StatusInfo>(
      "/robot_charge_status", 10, &DiagnosticAggregator::getRobotChargeStatus,
      this);
  sys_perf_status_sub_ =
      nh.subscribe<custom_msgs_srvs::SystemPerformanceStatus>(
          "/sys_perf_status", 10, &DiagnosticAggregator::getSysPerfStatus,
          this);
  system_status_pub_ = nh.advertise<custom_msgs_srvs::SystemHealthStaus>(
      "/diagnostics", 1, true);
  return;
}

void DiagnosticAggregator::getChassisStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  chassis_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getFileStatus(
    const custom_msgs_srvs::FileStatusArray::ConstPtr& msg) {
  custom_msgs_srvs::StatusInfo file_status;
  file_status.header = msg->header;
  file_status.module = "file";
  file_status.error_msg = "";
  file_status.error_level = custom_msgs_srvs::StatusInfo::OK;

  for (const auto& file : msg->file_status) {
    if (!file.status) {
      file_status.error_msg.append("102 A File missing #ED3#EV0#ER2#EB003#V1");
      file_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
      break;
    }
  }
  file_status_.Store(file_status);
  return;
}

void DiagnosticAggregator::getNodesHeartStatus(
    const custom_msgs_srvs::NodeHealthStaus::ConstPtr& msg) {
  custom_msgs_srvs::StatusInfo node_heart_status;
  node_heart_status.header = msg->header;
  node_heart_status.module = "sw";
  node_heart_status.error_msg = "";
  node_heart_status.error_level = custom_msgs_srvs::StatusInfo::OK;

  for (const auto& node : msg->node_status) {
    if (!node.status) {
      node_heart_status.error_msg.append(
          "103 A Node " + node.node_name +
          " is not exist! #ED3#EV0#ER2#EB004#V1");
      node_heart_status.error_level = custom_msgs_srvs::StatusInfo::FATAL_ERROR;
      node_heart_status_.Store(node_heart_status);
      return;
    }
  }

  for (const auto& topic : msg->topic_status) {
    if (topic.ERROR_LEVEL == custom_msgs_srvs::StatusInfo::ERROR) {
      node_heart_status.error_msg.append(
          "103 B " + topic.topic_name +
          " frequency is abnormal! #ED3#EV0#ER2#EB004#V1");
      node_heart_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
      node_heart_status_.Store(node_heart_status);
      return;
    }
  }

  node_heart_status_.Store(node_heart_status);
  return;
}

void DiagnosticAggregator::getNuwa1Status(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  nuwa_1_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getNuwa2Status(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  nuwa_2_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getNuwa3Status(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  nuwa_3_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getNuwa4Status(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  nuwa_4_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getLidar3dStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  lidar_3d_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getLidar2dStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  lidar_2d_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getImuStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  imu_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getOdomStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  odom_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getZwjSwjConnectionStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  zwj_swj_connection_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getRobotLocalizationStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  robot_localization_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getRobotPlanningStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  robot_planning_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getRobotPerceptionStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  robot_perception_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getRobotChargeStatus(
    const custom_msgs_srvs::StatusInfo::ConstPtr& msg) {
  robot_charge_status_.Store(*msg);
  return;
}

void DiagnosticAggregator::getSysPerfStatus(
    const custom_msgs_srvs::SystemPerformanceStatus::ConstPtr& msg) {
  custom_msgs_srvs::StatusInfo sys_perf_status;
  sys_perf_status.header = msg->header;
  sys_perf_status.module = "sys";
  sys_perf_status.error_msg = "";
  sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::OK;
  if (static_cast<int>(msg->disk_error_level) == 0) {
    sys_perf_status.error_msg.append("Disk overload; ");
    sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
  } else if (static_cast<int>(msg->mem_error_level) == 0) {
    sys_perf_status.error_msg.append("Mem overload; ");
    sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
  } else if (static_cast<int>(msg->cpu_error_level) == 0) {
    sys_perf_status.error_msg.append("Cpu overload; ");
    sys_perf_status.error_level = custom_msgs_srvs::StatusInfo::ERROR;
  }

  sys_perf_status_.Store(sys_perf_status);
  return;
}

custom_msgs_srvs::SystemHealthStaus::Ptr
DiagnosticAggregator::getSystemStatus() {
  custom_msgs_srvs::SystemHealthStaus system_status;
  system_status.chassis = chassis_status_.Load();
  system_status.file = file_status_.Load();
  system_status.nodes_heart = node_heart_status_.Load();
  system_status.nuwa_1 = nuwa_1_status_.Load();
  system_status.nuwa_2 = nuwa_2_status_.Load();
  system_status.nuwa_3 = nuwa_3_status_.Load();
  system_status.nuwa_4 = nuwa_4_status_.Load();
  system_status.lidar_3d = lidar_3d_status_.Load();
  system_status.lidar_2d = lidar_2d_status_.Load();
  system_status.imu = imu_status_.Load();
  system_status.odom = odom_status_.Load();
  system_status.zwj_swj_connection = zwj_swj_connection_status_.Load();
  system_status.robot_localization = robot_localization_status_.Load();
  system_status.robot_planning = robot_planning_status_.Load();
  system_status.robot_perception = robot_perception_status_.Load();
  system_status.robot_charge = robot_charge_status_.Load();
  system_status.sys_perf = sys_perf_status_.Load();
  system_status_pub_.publish(system_status);

  return boost::make_shared<custom_msgs_srvs::SystemHealthStaus>(system_status);
}
}  // namespace system_health_diagnostics