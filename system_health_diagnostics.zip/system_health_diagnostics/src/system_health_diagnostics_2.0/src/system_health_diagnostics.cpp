#include <cstdlib>
#include <memory>
#include <thread>

#include "config_parser/ConfigParser.h"
#include "diagnostic_aggregator/diagnostic_aggregator.hpp"
#include "diagnostic_analysis/diagnostic_analysis.hpp"
#include "reporter/FileReporter.h"
#include "reporter/SwReporter.h"
#include "reporter/SysReporter.h"
#include "ros/init.h"
#include "ros/node_handle.h"
#include "ros/ros.h"

int main(int argc, char** argv) {
  /* Process Executed As a Ros Node */
  ros::init(argc, argv, "system_health_diagnostics_node");
  ros::NodeHandle nh;

  auto config_parser_ptr =
      std::make_unique<::system_health_diagnostics::ConfigParser>();
  config_parser_ptr->parse();  // load checkconfig.yaml

  std::vector<std::thread> vec_thread;
  vec_thread.reserve(10);

  /* Monitor File Components Thread */
  auto file_checker_ptr =
      std::make_shared<system_health_diagnostics::FileChecker>();
  auto file_list = config_parser_ptr->getFileComponent();
  if (!file_list.empty()) {
    vec_thread.emplace_back([file_checker_ptr, file_list]() {
      file_checker_ptr->monitorFilesExist(file_list);
    });
  }

  /* Monitor Software Nodes Components Thread */
  auto sw_checker_ptr =
      std::make_shared<system_health_diagnostics::SWChecker>();
  auto node_list = config_parser_ptr->getSWComponent();
  if (!node_list.empty()) {
    vec_thread.emplace_back([sw_checker_ptr, node_list]() {
      std::vector<ros::Subscriber> ros_sub_vec;
      sw_checker_ptr->initNodesMonitor(node_list, ros_sub_vec);
      sw_checker_ptr->startMonitorNodes(true);
    });
  }

  /* Monitor System Components (Time || Disk )  Thread */
  auto sys_checker_ptr =
      std::make_shared<system_health_diagnostics::SysChecker>();
  auto sys_config = config_parser_ptr->getSysComponent();
  if (sys_config.max_disk_threshold != 0) {
    vec_thread.emplace_back([sys_checker_ptr, sys_config]() {
      sys_checker_ptr->periodCheckSysStatus(sys_config, 5);
    });
  }

  /* Publishing File Status */
  vec_thread.emplace_back([]() {
    ros::Rate r(1);
    while (ros::ok()) {
      system_health_diagnostics::FileReporter::getInstance()->pubFileStatus();
      r.sleep();
    }
  });

  /* Publishing SW Status */
  vec_thread.emplace_back([]() {
    ros::Rate r(1);
    while (ros::ok()) {
      system_health_diagnostics::SwReporter::getInstance()->pubSwStatus();
      r.sleep();
    }
  });

  /* Publishing Sys Status */
  vec_thread.emplace_back([]() {
    ros::Rate r(1);
    while (ros::ok()) {
      system_health_diagnostics::SysReporter::getInstance()->pubSysStatus();
      r.sleep();
    }
  });

  /* Publishing system_status Message */
  vec_thread.emplace_back([]() {
    ros::Rate r(1);
    while (ros::ok()) {
      const auto& sys_health_status =
          system_health_diagnostics::DiagnosticAggregator::getInstance()
              ->getSystemStatus();
      system_health_diagnostics::DiagnosticAnalysis::getInstance()
          ->updateDiagnosticStatus(sys_health_status);
      r.sleep();
    }
  });

  ros::spin();
  for (auto& t : vec_thread) {
    if (t.joinable()) {
      t.join();
    }
  }
  return 0;
}
