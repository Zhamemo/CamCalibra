#pragma once

#include <string>
#include <vector>

namespace system_health_diagnostics {
struct File {
  std::string file_path;
  bool status;
};

class FileChecker {
 public:
  FileChecker();
  ~FileChecker() = default;
  FileChecker(const FileChecker&) = delete;
  FileChecker& operator=(const FileChecker&) = delete;

 public:
  void monitorFilesExist(const std::vector<File>& file_lists);

 private:
  std::string node_name_str_;
};

}  // namespace system_health_diagnostics