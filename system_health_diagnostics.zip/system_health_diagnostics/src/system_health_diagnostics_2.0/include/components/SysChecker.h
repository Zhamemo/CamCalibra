#pragma once

#include <string>

namespace system_health_diagnostics {
struct SysConfig {
  int max_disk_threshold{0};
  double max_mem_usage;
  double max_cpu_usage;
};

struct SysCheckResult {
  double disk_usage;
  bool disk_status;
  double mem_usage;
  bool mem_status;
  double cpu_usage;
  bool cpu_status;
};

class SysChecker {
 public:
  SysChecker();
  ~SysChecker() = default;
  SysChecker(const SysChecker&) = delete;
  SysChecker& operator=(const SysChecker&) = delete;

 private:
  std::tuple<double, bool, std::string> checkSysDiskUsage(
      int max_disk_threshold);
  std::tuple<double, bool, std::string> checkMemUsage(int max_mem_threshold);
  std::tuple<double, bool, std::string> checkCpuUsage(int max_cpu_threshold);

 public:
  void periodCheckSysStatus(system_health_diagnostics::SysConfig sys_config,
                            int time);

 private:
  std::string node_name_str_;
};
}  // namespace system_health_diagnostics