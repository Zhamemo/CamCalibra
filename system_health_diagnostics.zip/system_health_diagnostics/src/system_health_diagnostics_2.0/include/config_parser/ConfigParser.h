#pragma once

#include "components/FileChecker.h"
#include "components/SWChecker.h"
#include "components/SysChecker.h"
#include "yaml-cpp/yaml.h"

namespace system_health_diagnostics {
class ConfigParser {
 public:
  ConfigParser();
  ~ConfigParser() = default;
  ConfigParser(const ConfigParser&) = delete;
  ConfigParser& operator=(const ConfigParser&) = delete;

 public:
  void parse() noexcept;

  SysConfig getSysComponent() { return sys_config_; }
  std::vector<File> getFileComponent() { return files_vec_; }
  std::vector<Node> getSWComponent() { return nodes_vec_; }

 private:
  void parseConfig(std::string& config_path);

  SysConfig parseSysComponent(YAML::Node root);
  std::vector<File> parseFileComponent(YAML::Node root);
  std::vector<Node> parseSWComponent(YAML::Node root);

 private:
  std::string node_name_str_;
  std::string config_path_;

  std::vector<Node> nodes_vec_;
  std::vector<File> files_vec_;
  SysConfig sys_config_;
};
}  // namespace system_health_diagnostics