#pragma once

#include <custom_msgs_srvs/NodeHealthStaus.h>
#include <ros/ros.h>

#include <cstddef>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>

#include "ros/node_handle.h"
#include "ros/publisher.h"

namespace system_health_diagnostics {
struct TopicStatus {
  std::string topic_name;
  std::string node_name;
  int warning_hz;
  int error_hz;
  int fatal_error_hz;

  TopicStatus(std::string topic_name, std::string node_name, int warning_hz,
              int error_rate, int fatal_error_rate) {
    this->topic_name = topic_name;
    this->node_name = node_name;
    this->warning_hz = warning_hz;
    this->error_hz = error_hz;
    this->fatal_error_hz = fatal_error_hz;
  }

  bool operator==(const TopicStatus& rhs) const {
    return ((this->topic_name == rhs.topic_name) &&
            (this->node_name == rhs.node_name) &&
            (this->warning_hz == rhs.warning_hz))
               ? true
               : false;
  }

  struct CustomHash {
    size_t operator()(const TopicStatus& lhs) const {
      return (std::hash<std::string>()(lhs.topic_name) ^
              std::hash<std::string>()(lhs.node_name) ^
              std::hash<int>()(lhs.warning_hz));
    }
  };
};

struct NodeStatus {
  std::string node_name;

  NodeStatus(std::string node_name) { this->node_name = node_name; }

  bool operator==(const NodeStatus& rhs) const {
    return (this->node_name == rhs.node_name) ? true : false;
  }

  struct CustomHash {
    size_t operator()(const NodeStatus& lhs) const {
      return (std::hash<std::string>()(lhs.node_name));
    }
  };
};

class SwReporter : public std::enable_shared_from_this<SwReporter> {
 public:
  ~SwReporter() = default;
  SwReporter(const SwReporter&) = delete;
  SwReporter& operator=(const SwReporter&) = delete;

 private:
  SwReporter() = default;

  bool checkStatusMap();
  void setSwStatus(const custom_msgs_srvs::NodeHealthStaus& sw_status);

 private:
  static std::shared_ptr<SwReporter> instance;

  ros::Publisher sw_pub_;
  int topic_size_;
  std::unordered_map<TopicStatus, float /*calculated frequency*/,
                     TopicStatus::CustomHash>
      topic_status_map_;
  std::unordered_map<NodeStatus, bool /*flag for is_node_found*/,
                     NodeStatus::CustomHash>
      node_status_map_;
  std::mutex lock;
  std::mutex sw_status_lock_;
  std::string node_name_str_;

 private:
  custom_msgs_srvs::NodeHealthStaus getRosMsg();
  custom_msgs_srvs::NodeHealthStaus::ConstPtr sys_sw_status_;

 public:
  void initialize(std::vector<TopicStatus> monitor_topics,
                  std::vector<NodeStatus> monitor_nodes);
  void pubSwStatus();
  void updateTopicStatusMap(const TopicStatus& topic_status, float actual_rate);
  void updateNodeStatusMap(const NodeStatus& node_status, bool is_existd);

  custom_msgs_srvs::NodeHealthStaus::ConstPtr getSwStatus();

  static std::shared_ptr<SwReporter> getInstance() {
    // Create the singleton instance if it doesn't exist
    static std::shared_ptr<SwReporter> instance(new SwReporter());
    return instance;
  }
};
}  // namespace system_health_diagnostics