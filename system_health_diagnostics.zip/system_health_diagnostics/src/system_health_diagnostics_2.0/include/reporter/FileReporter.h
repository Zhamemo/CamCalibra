#pragma once

#include <custom_msgs_srvs/FileStatus.h>
#include <custom_msgs_srvs/FileStatusArray.h>
#include <ros/ros.h>

#include <memory>
#include <mutex>

#include "components/FileChecker.h"

namespace system_health_diagnostics {
class FileReporter {
 public:
  ~FileReporter() = default;
  FileReporter(const FileReporter&) = delete;
  FileReporter& operator=(const FileReporter&) = delete;

 private:
  FileReporter() = default;
  void setFileStatus(const custom_msgs_srvs::FileStatusArray& file_status);

 private:
  static std::shared_ptr<FileReporter> instance;

  ros::Publisher file_pub_;
  std::vector<File> file_vec_;
  std::mutex lock;

  std::mutex file_status_lock_;
  custom_msgs_srvs::FileStatusArray::ConstPtr sys_file_status_;

 public:
  void initialize(const std::vector<File>& file_vec);

  void pubFileStatus();
  void updateFileStatus(const std::string& file_path, bool file_status);

  custom_msgs_srvs::FileStatusArray::ConstPtr getFileStatus();

  static std::shared_ptr<FileReporter> getInstance() {
    // Create the singleton instance if it doesn't exist
    if (!instance) {
      instance = std::shared_ptr<FileReporter>(new FileReporter());
    }
    return instance;
  }
};
}  // namespace system_health_diagnostics
