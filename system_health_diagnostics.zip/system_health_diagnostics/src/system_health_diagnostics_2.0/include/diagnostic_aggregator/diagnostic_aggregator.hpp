#pragma once

#include <custom_msgs_srvs/FileStatus.h>
#include <custom_msgs_srvs/FileStatusArray.h>
#include <custom_msgs_srvs/NodeHealthStaus.h>
#include <custom_msgs_srvs/StatusInfo.h>
#include <custom_msgs_srvs/SystemHealthStaus.h>
#include <custom_msgs_srvs/SystemPerformanceStatus.h>
#include <ros/ros.h>

#include "common/atomic.hpp"

namespace system_health_diagnostics {
class DiagnosticAggregator
    : public std::enable_shared_from_this<DiagnosticAggregator> {
 public:
  ~DiagnosticAggregator() = default;
  DiagnosticAggregator(const DiagnosticAggregator&) = delete;
  DiagnosticAggregator& operator=(const DiagnosticAggregator&) = delete;

 private:
  DiagnosticAggregator();

 private:
  void initParm();

 private:
  void getChassisStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getFileStatus(const custom_msgs_srvs::FileStatusArray::ConstPtr& msg);

  void getNodesHeartStatus(
      const custom_msgs_srvs::NodeHealthStaus::ConstPtr& msg);

  void getNuwa1Status(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getNuwa2Status(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getNuwa3Status(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getNuwa4Status(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getLidar3dStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getLidar2dStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getImuStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getOdomStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getZwjSwjConnectionStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotLocalizationStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotPlanningStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotPerceptionStatus(
      const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getRobotChargeStatus(const custom_msgs_srvs::StatusInfo::ConstPtr& msg);

  void getSysPerfStatus(
      const custom_msgs_srvs::SystemPerformanceStatus::ConstPtr& msg);

 public:
  custom_msgs_srvs::SystemHealthStaus::Ptr getSystemStatus();

  static std::shared_ptr<DiagnosticAggregator> getInstance() {
    static std::shared_ptr<DiagnosticAggregator> instance(
        new DiagnosticAggregator());
    return instance;
  }

 private:
  ros::Subscriber chassis_status_sub_;
  ros::Subscriber file_status_sub_;
  ros::Subscriber nodes_heart_status_sub_;
  ros::Subscriber nuwa_1_status_sub_;
  ros::Subscriber nuwa_2_status_sub_;
  ros::Subscriber nuwa_3_status_sub_;
  ros::Subscriber nuwa_4_status_sub_;
  ros::Subscriber lidar_3d_status_sub_;
  ros::Subscriber lidar_2d_status_sub_;
  ros::Subscriber imu_status_sub_;
  ros::Subscriber odom_status_sub_;
  ros::Subscriber zwj_swj_connection_status_sub_;
  ros::Subscriber robot_localization_status_sub_;
  ros::Subscriber robot_planning_status_sub_;
  ros::Subscriber robot_perception_status_sub_;
  ros::Subscriber robot_charge_status_sub_;
  ros::Subscriber sys_perf_status_sub_;
  ros::Publisher system_status_pub_;

  std::string node_name_str_;

  common::Atomic<custom_msgs_srvs::StatusInfo> chassis_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> file_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> node_heart_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> nuwa_1_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> nuwa_2_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> nuwa_3_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> nuwa_4_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> lidar_3d_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> lidar_2d_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> imu_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> odom_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> zwj_swj_connection_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> robot_localization_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> robot_planning_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> robot_perception_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> robot_charge_status_;
  common::Atomic<custom_msgs_srvs::StatusInfo> sys_perf_status_;
};
}  // namespace system_health_diagnostics