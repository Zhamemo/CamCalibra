#pragma once

#include <cstdio>
#include <stdexcept>
namespace system_health_diagnostics {
static std::string exec(const char* cmd) {
  char buffer[128];
  std::string result = "";
  FILE* pipe = popen(cmd, "r");

  if (!pipe) throw std::runtime_error("popen() failed!");

  try {
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
      result += buffer;
    }
  } catch (...) {
    pclose(pipe);
    throw;
  }

  pclose(pipe);
  return result;
}

}  // namespace system_health_diagnostics