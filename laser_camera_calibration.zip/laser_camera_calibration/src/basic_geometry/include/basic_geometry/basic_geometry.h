/**
 * @file basic_geometry.h
 * @author joyce.lou (joyce.lou@uditech.com.cn)
 * @brief 基本的几何运算接口，在货柜对接模块重构过程中拆分重构而来。
 * @version 0.1
 * @date 2022-05-19
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef BASIC_GEOMETRY_H
#define BASIC_GEOMETRY_H

#include <cmath>
#include <vector>
#include <iostream>
#include <ros/ros.h>
#include <angles/angles.h>
#include <Eigen/Geometry>
#include <tf/transform_listener.h>
#include "geometry_msgs/PoseStamped.h"

namespace basic_geometry
{

/**
 * @brief 计算两个数的平方和
 * 
 * @tparam T 模板参数，用于保持返回类型与输入类型一致
 * @param x 第一个数
 * @param y 第二个数
 * @return T 平方和
 */
template<typename T>
inline T squariance(T x, T y)
{
  return pow(x, 2.0) + pow(y, 2.0);
}

/**
 * @brief 查找角点（与首尾两点连线最远的点）。数组容易溢出，建议用另一个重载的findCorner代替，但目前由于整体算法流程设计，不便更改
 * 
 * @param X x坐标（数组）
 * @param Y y坐标（数组）
 * @param n 数组长度
 * @param Eps 角点与首尾两点连线距离的阈值
 * @return int 角点索引号
 */
template<typename T>
int findCorner(T* X,
               T* Y,
               int n,
               float Eps)
{
  float dis = hypot(X[0] - X[n - 1], Y[0] - Y[n - 1]);
  float cosTheta = (X[n - 1] - X[0]) / dis;
  float sinTheta = -(Y[n - 1] - Y[0]) / dis;
  float MaxDis = 0;
  float dbDis;

  int i;
  int MaxDisInd = -1;

  for (i = 1; i < n - 1; i++)
  {
    // 进行坐标旋转，求旋转后的点到x轴的距离
    dbDis = fabs((Y[i] - Y[0]) * cosTheta + (X[i] - X[0]) * sinTheta);  // error 数据有无穷大
    if (dbDis > MaxDis)
    {
      MaxDis = dbDis;  //将离直线最远的点距离赋值给MaxDis
      MaxDisInd = i;   //记录最远点（角点）距离索引
    }
  }
  if (MaxDis >= Eps)
  {                    //若是大于精度200
    return MaxDisInd;  //则返回角点的索引
  }
  // std::cout << Eps << ", " << MaxDis << std::endl;
  return 0;  //若无角点则返回0
}

/**
 * @brief 查找角点（与首尾两点连线最远的点）
 * 
 * @param X x坐标（数组）
 * @param Y y坐标（数组）
 * @param Eps 角点与首尾两点连线距离的阈值
 * @return int 角点索引号
 */
template<typename T>
int findCorner(std::vector<T>& X,
               std::vector<T>& Y,
               float Eps)
{
  if (X.size() != Y.size() || X.size() < static_cast<size_t>(3))
    return 0;
  float dis = hypot(X[0] - X.back(), Y[0] - Y.back());
  float cosTheta = (X.back() - X[0]) / dis;
  float sinTheta = -(Y.back() - Y[0]) / dis;
  float MaxDis = 0;
  float dbDis;

  int i;
  int MaxDisInd = -1;

  for (i = 1; i < static_cast<int>(X.size()) - 1; i++)
  {
    // 进行坐标旋转，求旋转后的点到x轴的距离
    dbDis = fabs((Y[i] - Y[0]) * cosTheta + (X[i] - X[0]) * sinTheta);  // error 数据有无穷大
    if (dbDis > MaxDis)
    {
      MaxDis = dbDis;  //将离直线最远的点距离赋值给MaxDis
      MaxDisInd = i;   //记录最远点（角点）距离索引
    }
  }
  if (MaxDis >= Eps)
  {                    //若是大于精度
    return MaxDisInd;  //则返回角点的索引
  }
  return 0;  //若无角点则返回0
}

/**
 * @brief 计算折线夹角角度
 * 
 * @tparam T_POINT 点的类型，只支持二维点，需要有名为x、y的成员
 * @param first 第一个端点
 * @param center 角点
 * @param second 第二个端点
 * @return double 夹角角度
 */
template<typename T_POINT>
double getLineAngle(const T_POINT& first,
                    const T_POINT& center,
                    const T_POINT& second)
{
  double dx1 = static_cast<double>(first.x - center.x);
  double dy1 = static_cast<double>(first.y - center.y);
  double dx2 = static_cast<double>(second.x - center.x);
  double dy2 = static_cast<double>(second.y - center.y);

  double c = hypot(dx1, dy1) * hypot(dx2, dy2);

  if (c == 0)
    return 0.0;

  double angle = (double)acos((dx1 * dx2 + dy1 * dy2) / c);

  return angles::to_degrees(angle);
}

/**
 * @brief 计算原点是否在凸角内部
 * 
 * @tparam T_POINT 点类型的模板，须有x、y成员
 * @param A 角第一条边上的点
 * @param B 角的顶点
 * @param C 角第二条边上的点
 * @return true 坐标原点在∠ABC组成的凸角内
 * @return false 坐标原点在∠ABC组成的凸角外
 */
template<typename T_POINT>
bool insideCorner(const T_POINT& A,
                  const T_POINT& B,
                  const T_POINT& C)
{
  float i = A.x * (C.y - B.y) + B.x * (A.y - C.y) + C.x * (B.y - A.y);
  float j = C.x * B.y - B.x * C.y;
  float k = B.x * A.y - A.x * B.y;
  return (i > 0 && j > 0 && k > 0) || (i < 0 && j < 0 && k < 0);
}

/**
 * @brief 计算角平分线在极坐标下的角度
 * 
 * @tparam T_POINT 点类型的模板，须有x、y成员
 * @param A 角第一条边上的点
 * @param B 角的顶点
 * @param C 角第二条边上的点
 * @return double 角平分线的弧度
 */
template<typename T_RETURN, typename T_POINT>
T_RETURN getTriangleAngle(const T_POINT& A,
                          const T_POINT& B,
                          const T_POINT& C)
{
  if (!insideCorner(A, B, C))
  {
    return 999.0;
  }
  T_RETURN a1 = A.y - B.y;
  T_RETURN b1 = B.x - A.x;
  T_RETURN a2 = B.y - C.y;
  T_RETURN b2 = C.x - B.x;
  T_RETURN m1 = sqrt(a1 * a1 + b1 * b1);
  T_RETURN m2 = sqrt(a2 * a2 + b2 * b2);

  T_RETURN dx = (A.x - B.x) * m2 + (C.x - B.x) * m1;
  T_RETURN dy = (A.y - B.y) * m2 + (C.y - B.y) * m1;

  T_RETURN result = atan2(dy, dx);
  return result;
}

/**
 * @brief 位姿融合，注意所有位姿在相同坐标系下，从使用来说，建议使用该接口
 * 
 * @param factor 融合系数，表示旧的位姿（基于里程计估计）所占比重
 * @param new_pose 新的位姿，通常来自传感器数据的处理
 * @param out_pose 传入旧的位姿，并更新为融合后的位姿，通常为基于里程计估计的位姿
 * @todo 增加坐标系的检查
 */
void fusePose(float factor,
              const geometry_msgs::PoseStamped& new_pose,
              geometry_msgs::PoseStamped& out_pose);

/**
 * @brief 位姿融合，注意所有位姿在相同坐标系下
 * 
 * @param factor 融合系数，表示第一个位姿所占比重
 * @param pose1 第一个位姿
 * @param pose2 第二个位姿
 * @param out_pose 融合后的位姿
 * @deprecated 目前第二个位姿与输出位姿没有必要分开，建议使用上一个接口
 */
void fusePose(float factor,
              const geometry_msgs::PoseStamped& pose1,
              const geometry_msgs::PoseStamped& pose2,
              geometry_msgs::PoseStamped& out_pose);

/**
 * @brief 基于里程计预测位姿
 * 
 * @param tf_listener 主要是为了复用业务层的tf监听者
 * @param target_frame odom坐标系名称
 * @param source_frame footprint坐标系名称
 * @param time 期望的tf时间戳
 * @param last_tf 上一次的source_frame->target_frame转换关系
 * @param last_pose 上一次计算的位姿
 * @param out_pose 输出位姿
 * @return true 预测成功
 * @return false 预测失败
 * @deprecated 经过整体优化后，业务中没必要用旧的预测方法，而是直接转换到odom坐标系
 */
bool predictPoseWithOdom(const tf::TransformListener& tf_listener,
                         const std::string& target_frame,
                         const std::string& source_frame,
                         const ros::Time& time,
                         tf::StampedTransform& last_tf,
                         const geometry_msgs::PoseStamped& last_pose,
                         geometry_msgs::PoseStamped& out_pose);

}  // namespace basic_geometry


#endif  //BASIC_GEOMETRY_H
