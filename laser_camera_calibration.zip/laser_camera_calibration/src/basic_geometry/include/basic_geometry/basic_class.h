/**
 * @file basic_class.h
 * @author joyce.lou (joyce.lou@uditech.com.cn)
 * @brief 基本模板类，在货柜对接模块重构过程中拆分重构而来，主要用于支持几何运算（适配现有的算法代码）
 * @version 0.1
 * @date 2022-05-16
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef BASIC_GEOMETRY_CLASS_H
#define BASIC_GEOMETRY_CLASS_H

namespace basic_geometry
{

/**
 * @brief 平面内的点坐标
 * 
 * @tparam T 点坐标的数据类型，建议用float
 */
template<typename T>
struct Point
{
  T x;  ///< x轴坐标
  T y;  ///< y轴坐标
  Point()
  {
    x = 0;
    y = 0;
  }
  Point(const T x_in, const T y_in)
  {
    x = x_in;
    y = y_in;
  }
};

/**
 * @brief 平面内的位姿，用x、y、theta描述
 * 
 * @tparam T 点坐标和弧度的数据类型，建议用float
 * @deprecated 建议用ros标准的Pose
 */
template<typename T>
struct Pose
{
  T x;      ///< x轴坐标
  T y;      ///< y轴坐标
  T theta;  ///< 倾角
  Pose()
  {
    x = 0;
    y = 0;
    theta = 0;
  }
  Pose(const T x_in, const T y_in, const T theta_in)
  {
    x = x_in;
    y = y_in;
    theta = theta_in;
  }
};

/**
 * @brief 直线（线段）参数，其中 y = a*x + b
 * 
 * @tparam T 坐标和倾角弧度的数据类型，建议用float
 */
template<typename T>
struct LineParam
{
  T a;                  ///< 斜率
  T b;                  ///< 截距
  T theta;              ///< 倾角
  T length;             ///< 线段长度
  Point<T> startPoint;  ///< 起点坐标
  Point<T> endPoint;    ///< 终点坐标
};
}  // namespace basic_geometry

#endif  // BASIC_GEOMETRY_CLASS_H
