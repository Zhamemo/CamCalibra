#include <gtest/gtest.h>
#include <angles/angles.h>
#include <tf2/LinearMath/Transform.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include "basic_geometry/basic_geometry.h"

template <typename T>
struct TestPoint
{
  T x;
  T y;
};

typedef struct
{
  int x;
  int y;
} iPoint;

typedef struct
{
  double x;
  double y;
  double th;
} dPose;

inline double getSquareDistance(int x1, int x2, int y1, int y2) { return pow(x1 - x2, 2.0) + pow(y1 - y2, 2.0); }

/**
 * @brief 三点求相对角度，求三角桩相对这边的角度
 *
 * @tparam T_POINT 点类型的模板，须有x、y成员
 * @param first
 * @param cen
 * @param second
 * @return double
 * @deprecated 计算复杂，特定角度误差大
 */
template <typename T_POINT>
double getTriangleAngleOld(const T_POINT &first,
                           const T_POINT &cen,
                           const T_POINT &second)
{
  dPose A, B, C, Mid;
  A.x = static_cast<double>(first.x) / 1000.0;
  A.y = static_cast<double>(first.y) / 1000.0;
  B.x = static_cast<double>(cen.x) / 1000.0;
  B.y = static_cast<double>(cen.y) / 1000.0;
  C.x = static_cast<double>(second.x) / 1000.0;
  C.y = static_cast<double>(second.y) / 1000.0;
  A.th = 0;
  B.th = 0;
  C.th = 0;

  Mid.x = B.x;
  Mid.y = B.y;
  bool flag = false;

  if (C.y - A.y < 0.0001)
  {
    flag = true;
    //将A坐标转换成旋转后的坐标
    dPose temp = A;
    A.x = temp.x * (cos(M_PI / 4)) + temp.y * (sin(M_PI / 4));
    A.y = temp.x * (-1.0 * sin(M_PI / 4)) + temp.y * (cos(M_PI / 4));
    //将B坐标转换成旋转后的坐标
    temp = B;
    B.x = temp.x * (cos(M_PI / 4)) + temp.y * (sin(M_PI / 4));
    B.y = temp.x * (-1.0 * sin(M_PI / 4)) + temp.y * (cos(M_PI / 4));
    //将C坐标转换成旋转后的坐标
    temp = C;
    C.x = temp.x * (cos(M_PI / 4)) + temp.y * (sin(M_PI / 4));
    C.y = temp.x * (-1.0 * sin(M_PI / 4)) + temp.y * (cos(M_PI / 4));
  }

  dPose D;
  D.th = 0;
  
  //直线 AB：a1x + b1y + c1 = 0
  double a1 = A.y - B.y;
  double b1 = B.x - A.x;
  double c1 = A.x * B.y - B.x * A.y;
  //直线 BC：a2x + b2y + c2 = 0
  double a2 = B.y - C.y;
  double b2 = C.x - B.x;
  double c2 = B.x * C.y - C.x * B.y;
  //直线 AC：a3x + b3y + c3 = 0
  double a3 = C.y - A.y;
  double b3 = A.x - C.x;
  double c3 = C.x * A.y - A.x * C.y;

  double m1 = sqrt(a1 * a1 + b1 * b1);
  double m2 = sqrt(a2 * a2 + b2 * b2);

  D.y = -(c3 + a3 * (c2 * m1 - c1 * m2) / (a1 * m2 - a2 * m1)) / (a3 * (b2 * m1 - b1 * m2) / (a1 * m2 - a2 * m1) + b3);
  D.x = -(b3 * D.y + c3) / a3;

  if (flag)
  {
    dPose temp = D;
    D.x = temp.x * (cos(M_PI / 4)) + temp.y * (-1.0 * sin(M_PI / 4));
    D.y = temp.x * (sin(M_PI / 4)) + temp.y * (cos(M_PI / 4));
  }

  double angle_temp;

  double dx = D.x - Mid.x;
  double dy = D.y - Mid.y;

  if (fabs(dx) < 0.0001)
  {
    angle_temp = M_PI * 0.5;
  }
  else
  {
    angle_temp = atan(fabs(dy / dx));
  }

  if ((dx < 0.0) && (dy >= 0.0))
  {
    angle_temp = M_PI - angle_temp;
  }
  else if ((dx < 0.0) && (dy < 0.0))
  {
    angle_temp = M_PI + angle_temp;
  }
  else if ((dx >= 0.0) && (dy < 0.0))
  {
    angle_temp = -1.0 * angle_temp;
  }
  iPoint cross_pose;
  cross_pose.x = static_cast<int>(D.x * 1000.0);
  cross_pose.y = static_cast<int>(D.y * 1000.0);

  if (getSquareDistance(cross_pose.x, 0, cross_pose.y, 0) > getSquareDistance(cen.x, 0, cen.y, 0))
  {
    angle_temp = 999;
  }
  return angle_temp;
}

TEST(basic_geometry, test1)
{
  TestPoint<float> A{0, 1};
  TestPoint<float> B{2, 0};
  TestPoint<float> C{4.0 / 3, -1.0 / 3};

  TestPoint<float> D{1, 0};
  // int i = 12;
  for (int i = 0; i < 96; i++)
  {
    // std::cout << "-----------------------------------" <<  i << std::endl;
    float angle_i = M_PI / 48 * i;
    double sine, cosine;
    sincos(angle_i, &sine, &cosine);
    TestPoint<float> A1, B1, C1, D1;
    A1.x = A.x * cosine + A.y * sine;
    A1.y = A.x * (-sine) + A.y * cosine;
    //将B坐标转换成旋转后的坐标
    B1.x = B.x * cosine + B.y * sine;
    B1.y = B.x * (-sine) + B.y * cosine;
    //将C坐标转换成旋转后的坐标
    C1.x = C.x * cosine + C.y * sine;
    C1.y = C.x * (-sine) + C.y * cosine;
    D1.x = D.x * cosine + D.y * sine;
    D1.y = D.x * (-sine) + D.y * cosine;
    float result_old = getTriangleAngleOld(A1, B1, C1);
    float result_new = basic_geometry::getTriangleAngle<float>(A1, B1, C1);

    float expect_result = angles::normalize_angle(M_PI - angle_i);
    // std::cout << "Expected D point: " << D1.x << ", " << D1.y << std::endl;

    EXPECT_NEAR(angles::shortest_angular_distance(result_new, expect_result), 0, 0.00001);
    //   if (expect_result< -M_PI_2) expect_result += M_PI * 2;
    //   EXPECT_NEAR(result_old, expect_result, 0.01);
  }
  //   ROS_INFO("[%s] period: %lf, %lf, %lf", __FUNCTION__, period_old, period_new, period_new2);
}

TEST(basic_geometry, 90)
{
  TestPoint<float> A{0, 2};
  TestPoint<float> B{2, 0};
  TestPoint<float> C{0, -2};

  TestPoint<float> D{0, 0};
  // int i = 12;
  for (int i = 0; i < 96; i++)
  {
    // std::cout << "-----------------------------------" <<  i << std::endl;
    float angle_i = M_PI / 48 * i;
    TestPoint<float> A1, B1, C1, D1;
    A1.x = A.x * (cos(angle_i)) + A.y * (sin(angle_i));
    A1.y = A.x * (-1.0 * sin(angle_i)) + A.y * (cos(angle_i));
    //将B坐标转换成旋转后的坐标
    B1.x = B.x * (cos(angle_i)) + B.y * (sin(angle_i));
    B1.y = B.x * (-1.0 * sin(angle_i)) + B.y * (cos(angle_i));
    //将C坐标转换成旋转后的坐标
    C1.x = C.x * (cos(angle_i)) + C.y * (sin(angle_i));
    C1.y = C.x * (-1.0 * sin(angle_i)) + C.y * (cos(angle_i));
    D1.x = D.x * (cos(angle_i)) + D.y * (sin(angle_i));
    D1.y = D.x * (-1.0 * sin(angle_i)) + D.y * (cos(angle_i));
    float result_old = getTriangleAngleOld(A1, B1, C1);
    float result_new = basic_geometry::getTriangleAngle<float>(A1, B1, C1);

    float expect_result = angles::normalize_angle(M_PI - angle_i);
    // std::cout << "Expected D point: " << D1.x << ", " << D1.y << std::endl;
    EXPECT_NEAR(result_new, expect_result, 0.00001);
    //   if (expect_result< -M_PI_2) expect_result += M_PI * 2;
    //   EXPECT_NEAR(result_old, expect_result, 0.01);
  }
  //   ROS_INFO("[%s] period: %lf, %lf, %lf", __FUNCTION__, period_old, period_new, period_new2);
}

TEST(basic_geometry, 120)
{
  TestPoint<float> A{1, sqrt(3)};
  TestPoint<float> B{2, 0};
  TestPoint<float> C{1, -sqrt(3)};

  TestPoint<float> D{1, 0};
  // int i = 12;
  for (int i = 0; i < 96; i++)
  {
    // std::cout << "-----------------------------------" <<  i << std::endl;
    float angle_i = M_PI / 48 * i;
    TestPoint<float> A1, B1, C1, D1;
    A1.x = A.x * (cos(angle_i)) + A.y * (sin(angle_i));
    A1.y = A.x * (-1.0 * sin(angle_i)) + A.y * (cos(angle_i));
    //将B坐标转换成旋转后的坐标
    B1.x = B.x * (cos(angle_i)) + B.y * (sin(angle_i));
    B1.y = B.x * (-1.0 * sin(angle_i)) + B.y * (cos(angle_i));
    //将C坐标转换成旋转后的坐标
    C1.x = C.x * (cos(angle_i)) + C.y * (sin(angle_i));
    C1.y = C.x * (-1.0 * sin(angle_i)) + C.y * (cos(angle_i));
    D1.x = D.x * (cos(angle_i)) + D.y * (sin(angle_i));
    D1.y = D.x * (-1.0 * sin(angle_i)) + D.y * (cos(angle_i));
    float result_old = getTriangleAngleOld(A1, B1, C1);
    float result_new = basic_geometry::getTriangleAngle<float>(A1, B1, C1);

    float expect_result = angles::normalize_angle(M_PI - angle_i);
    // std::cout << "Expected D point: " << D1.x << ", " << D1.y << std::endl;
    EXPECT_NEAR(result_new, expect_result, 0.00001);
    //   if (expect_result< -M_PI_2) expect_result += M_PI * 2;
    //   EXPECT_NEAR(result_old, expect_result, 0.01);
  }
  //   ROS_INFO("[%s] period: %lf, %lf, %lf", __FUNCTION__, period_old, period_new, period_new2);
}

TEST(basic_geometry, 150)
{
  TestPoint<float> A{1, tan(angles::from_degrees(75))};
  TestPoint<float> B{2, 0};
  TestPoint<float> C{1, -tan(angles::from_degrees(75))};

  TestPoint<float> D{1, 0};
  // int i = 12;
  for (int i = 0; i < 96; i++)
  {
    // std::cout << "-----------------------------------" <<  i << std::endl;
    float angle_i = M_PI / 48 * i;
    double sine, cosine;
    sincos(angle_i, &sine, &cosine);
    TestPoint<float> A1, B1, C1, D1;
    A1.x = A.x * cosine + A.y * sine;
    A1.y = A.x * (-sine) + A.y * cosine;
    //将B坐标转换成旋转后的坐标
    B1.x = B.x * cosine + B.y * sine;
    B1.y = B.x * (-sine) + B.y * cosine;
    //将C坐标转换成旋转后的坐标
    C1.x = C.x * cosine + C.y * sine;
    C1.y = C.x * (-sine) + C.y * cosine;
    D1.x = D.x * cosine + D.y * sine;
    D1.y = D.x * (-sine) + D.y * cosine;
    float result_old = getTriangleAngleOld(A1, B1, C1);
    float result_new = basic_geometry::getTriangleAngle<float>(A1, B1, C1);

    float expect_result = angles::normalize_angle(M_PI - angle_i);
    // std::cout << "Expected D point: " << D1.x << ", " << D1.y << std::endl;
    EXPECT_NEAR(result_new, expect_result, 0.00001);
    //   if (expect_result< -M_PI_2) expect_result += M_PI * 2;
    //   EXPECT_NEAR(result_old, expect_result, 0.01);
  }
  //   ROS_INFO("[%s] period: %lf, %lf, %lf", __FUNCTION__, period_old, period_new, period_new2);
}

TEST(fusePose, angle)
{
  ros::NodeHandle private_nh;
  ros::Publisher pub_old1 = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_old1", 1);
  ros::Publisher pub_old2 = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_old2", 1);
  ros::Publisher pub_new = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_new", 1);

  float factor = 0.5;
  geometry_msgs::PoseStamped new_pose;
  geometry_msgs::PoseStamped out_pose;
  new_pose.header.frame_id = "odom_frame";
  out_pose.header.frame_id = "odom_frame";
  new_pose.header.seq = 1;
  out_pose.header.seq = 1;
  new_pose.header.stamp = ros::Time::now();
  out_pose.header.stamp = ros::Time::now();

  new_pose.pose.position.x = 1;
  new_pose.pose.position.y = 2;
  new_pose.pose.position.z = 3;
  tf::Quaternion q;
  q.setRPY(0, 0, 1);
  new_pose.pose.orientation.x = q.getX();
  new_pose.pose.orientation.y = q.getY();
  new_pose.pose.orientation.z = q.getZ();
  new_pose.pose.orientation.w = q.getW();
  out_pose.pose.position.x = 3;
  out_pose.pose.position.y = 6;
  out_pose.pose.position.z = 9;
  for (int i = 0; i < 10; i++)
  {
    pub_old1.publish(new_pose);
    pub_old2.publish(out_pose);
  }

  basic_geometry::fusePose(factor, new_pose, out_pose);
  pub_new.publish(out_pose);
  pub_new.publish(out_pose);
  pub_new.publish(out_pose);
  pub_new.publish(out_pose);
  pub_new.publish(out_pose);

  EXPECT_EQ(out_pose.pose.position.x, 2.0);
  EXPECT_EQ(out_pose.pose.position.y, 4.0);
  EXPECT_EQ(out_pose.pose.position.z, 6.0);

  ros::spinOnce();
  ros::spinOnce();
  ros::spinOnce();
  // ros::spin();
}

TEST(fusePose, quaternion)
{
  ros::NodeHandle private_nh;
  ros::Publisher pub_old1 = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_old1", 1);
  ros::Publisher pub_old2 = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_old2", 1);
  ros::Publisher pub_new = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_new", 1);

  float factor = 0.5;
  geometry_msgs::PoseStamped new_pose;
  geometry_msgs::PoseStamped out_pose_or;
  geometry_msgs::PoseStamped out_pose;
  new_pose.header.frame_id = "odom_frame";
  out_pose.header.frame_id = "odom_frame";
  new_pose.header.seq = 1;
  out_pose.header.seq = 1;
  new_pose.header.stamp = ros::Time::now();
  out_pose.header.stamp = ros::Time::now();

  new_pose.pose.position.x = 1;
  new_pose.pose.position.y = 2;
  new_pose.pose.position.z = 3;
  tf2::Quaternion q1(0,0,0.692232, 0.721675);
  // q1.setRPY(0, 0, 3.14);
  std::cout << "q1 yaw: " << q1.getAngle() << std::endl;
  new_pose.pose.orientation.x = q1.getX();
  new_pose.pose.orientation.y = q1.getY();
  new_pose.pose.orientation.z = q1.getZ();
  new_pose.pose.orientation.w = q1.getW();  
  // new_pose.pose.orientation.x = -q1.getX();
  // new_pose.pose.orientation.y = -q1.getY();
  // new_pose.pose.orientation.z = -q1.getZ();
  // new_pose.pose.orientation.w = -q1.getW();
  tf2::Transform t;
  // fromMsg(transform.transform, t);
  t.setOrigin(tf2::Vector3(0,0,0));
  tf2::Quaternion q(0,0,0.969797, 0.243913);
  std::cout << "q yaw: " << q.getAngle() << std::endl;
  // q.setRPY(0, 0, 3.14);
  t.setRotation(q);
  tf2::Vector3 v;
  v[0] = new_pose.pose.position.x;
  v[1] = new_pose.pose.position.y;
  v[2] = new_pose.pose.position.z;
  // tf2::fromMsg(new_pose.pose.position, v);
  tf2::Transform v_out = t * tf2::Transform(q1, v);
  std::cout << "t: " << t.getBasis().getColumn(0)[0] << " " << t.getBasis().getColumn(0)[1] << " " << t.getBasis().getColumn(0)[2] << std::endl;
  std::cout << "t: " << t.getBasis().getColumn(1)[0] << " " << t.getBasis().getColumn(1)[1] << " " << t.getBasis().getColumn(1)[2] << std::endl;
  std::cout << "t: " << t.getBasis().getColumn(2)[0] << " " << t.getBasis().getColumn(2)[1] << " " << t.getBasis().getColumn(2)[2] << std::endl;  
  std::cout << "t: " << tf2::Transform(q1, v).getBasis().getColumn(0)[0] << std::endl;
  std::cout << "t: " << tf2::Transform(q1, v).getBasis().getColumn(1) << std::endl;
  std::cout << "t: " << tf2::Transform(q1, v).getBasis().getColumn(2) << std::endl;

  tf2::Stamped<tf2::Transform> st(v_out, new_pose.header.stamp, "odom_frame");
  tf2::toMsg(st, new_pose);
  std::cout << "new: " << new_pose.pose << std::endl;

  tf2::Quaternion q2;
  q2.setRPY(0, 0, -4.17795);
  out_pose.pose.orientation.x = q2.getX();
  out_pose.pose.orientation.y = q2.getY();
  out_pose.pose.orientation.z = q2.getZ();
  out_pose.pose.orientation.w = q2.getW();
  out_pose.pose.position.x = 1;
  out_pose.pose.position.y = 2;
  out_pose.pose.position.z = 3;
  std::cout << "out: " << out_pose.pose  << std::endl;
  std::cout << "out: " << out_pose.pose.orientation.w  << std::endl;

  q1 = v_out.getRotation();
  q2 = q2.slerp(q1, 0.5);
  std::cout << q2.getX() << ", " << q2.getY() << ", " <<q2.getZ() << ", " <<q2.getW() << ", " << std::endl;

  for (int i = 0; i < 10; i++)
  {
    pub_old1.publish(new_pose);
    pub_old2.publish(out_pose);
  }
  // out_pose_or = out_pose;
  // basic_geometry::fusePose(0.0, new_pose, out_pose);
  // pub_new.publish(out_pose);
  // std::cout << out_pose.pose << std::endl;
  // out_pose = out_pose_or;
  // basic_geometry::fusePose(1.0, new_pose, out_pose);
  // pub_new.publish(out_pose);
  // std::cout << out_pose.pose << std::endl;
  // out_pose = out_pose_or;
  basic_geometry::fusePose(factor, new_pose, out_pose);
  pub_new.publish(out_pose);
  std::cout << out_pose.pose << std::endl;

  EXPECT_NEAR(out_pose.pose.orientation.x, 0.0, 0.0001);
  EXPECT_NEAR(out_pose.pose.orientation.y, 0.0, 0.0001);
  EXPECT_NEAR(out_pose.pose.orientation.z, 1.0, 0.0001);
  EXPECT_NEAR(out_pose.pose.orientation.w, 0.0, 0.0001);
}

int main(int argc, char **argv)
{
  testing::InitGoogleTest(&argc, argv);
  ros::init(argc, argv, "basic_geometry_utest");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");
    ros::Time::init();
  return RUN_ALL_TESTS();
}
