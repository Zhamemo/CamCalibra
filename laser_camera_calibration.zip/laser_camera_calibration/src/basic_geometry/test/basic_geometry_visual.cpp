#include <angles/angles.h>
#include "basic_geometry/basic_geometry.h"
#include "ros/ros.h"

int main(int argc, char **argv)
{
  ros::init(argc, argv, "basic_geometry_utest");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");
  ros::Rate rate(1);
  ros::Publisher pub_old1 = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_old1", 1);
  ros::Publisher pub_old2 = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_old2", 1);
  ros::Publisher pub_new = private_nh.advertise<geometry_msgs::PoseStamped>("/pose_new", 1);

  float factor = 0.5;
  geometry_msgs::PoseStamped new_pose;
  geometry_msgs::PoseStamped out_pose;
  geometry_msgs::PoseStamped out_pose2;
  new_pose.header.frame_id = "odom_frame";
  out_pose.header.frame_id = "odom_frame";
  new_pose.header.seq = 1;
  out_pose.header.seq = 1;
  new_pose.header.stamp = ros::Time::now();
  out_pose.header.stamp = ros::Time::now();

  new_pose.pose.position.x = 1;
  new_pose.pose.position.y = 2;
  new_pose.pose.position.z = 3;
  tf::Quaternion q;
  q.setRPY(0, 0, 0);
  q.normalize();
  new_pose.pose.orientation.x = q.getX();
  new_pose.pose.orientation.y = q.getY();
  new_pose.pose.orientation.z = q.getZ();
  new_pose.pose.orientation.w = q.getW();
  out_pose.pose.position.x = 3;
  out_pose.pose.position.y = 6;
  out_pose.pose.position.z = 9;
  q.setRPY(0, 0.2, 1);
  out_pose.pose.orientation.x = q.getX();
  out_pose.pose.orientation.y = q.getY();
  out_pose.pose.orientation.z = q.getZ();
  out_pose.pose.orientation.w = q.getW();
  for (int i = 0; i < 10; i++)
  {
    pub_old1.publish(new_pose);
    pub_old2.publish(out_pose);
    ROS_INFO("pose1: xyz: %f, %f, %f; Y: %f",
             new_pose.pose.position.x,
             new_pose.pose.position.y,
             new_pose.pose.position.z,
             tf::getYaw(new_pose.pose.orientation));
    ROS_INFO("pose2: xyz: %f, %f, %f; Y: %f",
             out_pose.pose.position.x,
             out_pose.pose.position.y,
             out_pose.pose.position.z,
             tf::getYaw(out_pose.pose.orientation));
    basic_geometry::fusePose(factor, new_pose, out_pose); //, out_pose2);
    ROS_INFO("out_pose2: xyz: %f, %f, %f; Y: %f",
             out_pose.pose.position.x,
             out_pose.pose.position.y,
             out_pose.pose.position.z,
             tf::getYaw(out_pose.pose.orientation));
    pub_new.publish(out_pose);
    rate.sleep();
    ros::spinOnce();
  }

  // ros::spin();
}