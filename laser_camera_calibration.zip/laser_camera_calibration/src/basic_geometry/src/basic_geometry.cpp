#include "basic_geometry/basic_geometry.h"

namespace basic_geometry{

void fusePose(float factor,
              const geometry_msgs::PoseStamped& new_pose,
              geometry_msgs::PoseStamped& out_pose)
{
  tf::Stamped<tf::Pose> last_pose_, new_pose_, out_pose_;
  tf::poseStampedMsgToTF(out_pose, last_pose_);
  tf::poseStampedMsgToTF(new_pose, new_pose_);
  tf::Quaternion rotation_fusion = last_pose_.getRotation();
  // tf内置的球面线性插值函数，可正确处理方向，避免w符号相反时的融合问题
  rotation_fusion = rotation_fusion.slerp(new_pose_.getRotation(), 1.0f - factor);
  auto origin_fusion = last_pose_.getOrigin() * factor + new_pose_.getOrigin() * (1.0f - factor);
  out_pose_.setOrigin(origin_fusion);
  out_pose_.setRotation(rotation_fusion);
  out_pose_.stamp_ = new_pose.header.stamp;
  out_pose_.frame_id_ = out_pose.header.frame_id;
  tf::poseStampedTFToMsg(out_pose_, out_pose);
}

void fusePose(float factor,
              const geometry_msgs::PoseStamped& pose1,
              const geometry_msgs::PoseStamped& pose2,
              geometry_msgs::PoseStamped& out_pose)
{
  tf::Stamped<tf::Pose> pose1_, pose2_, out_pose_;
  tf::poseStampedMsgToTF(pose1, pose1_);
  tf::poseStampedMsgToTF(pose2, pose2_);
  tf::Quaternion rotation_fusion = pose1_.getRotation();
  // tf内置的球面线性插值函数，可正确处理方向，避免w符号相反时的融合问题
  rotation_fusion = rotation_fusion.slerp(pose2_.getRotation(), 1.0f - factor);
  auto origin_fusion = pose1_.getOrigin() * factor + pose2_.getOrigin() * (1.0f - factor);
  out_pose_.setOrigin(origin_fusion);
  out_pose_.setRotation(rotation_fusion);
  out_pose_.stamp_ = pose1.header.stamp;
  out_pose_.frame_id_ = pose1.header.frame_id;
  tf::poseStampedTFToMsg(out_pose_, out_pose);
}

bool predictPoseWithOdom(const tf::TransformListener& tf_listener,
                         const std::string& target_frame,
                         const std::string& source_frame,
                         const ros::Time& time,
                         tf::StampedTransform& last_tf,
                         const geometry_msgs::PoseStamped& last_pose,
                         geometry_msgs::PoseStamped& out_pose)
{
  tf::StampedTransform odom_to_base;
  try
  {
    tf_listener.waitForTransform(target_frame, source_frame, time, ros::Duration(0.5));
    tf_listener.lookupTransform(target_frame, source_frame, time, odom_to_base);
  }
  catch (tf::TransformException &e)
  {
    ROS_WARN("[%s][%s][%d]: Transform failed during listening of %s - %s transform: %s",
             ros::this_node::getName().c_str(), __func__, __LINE__, target_frame.c_str(), source_frame.c_str(), e.what());
    return false;
  }
  tf::Stamped<tf::Pose> last_pose_, out_pose_;
  tf::poseStampedMsgToTF(last_pose, last_pose_);
  auto odom_diff = odom_to_base.inverse() * last_tf;
  out_pose_.setData(odom_diff * last_pose_);
  out_pose_.stamp_ = odom_to_base.stamp_;
  out_pose_.frame_id_ = source_frame;
  tf::poseStampedTFToMsg(out_pose_, out_pose);
  last_tf = odom_to_base;

  return true;
}
}
