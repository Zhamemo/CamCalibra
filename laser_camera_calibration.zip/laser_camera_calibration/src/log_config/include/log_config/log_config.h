#ifndef LOG_CONFIG_H
#define LOG_CONFIG_H

#define LOG_DEBUG(expression, ...)  ROS_DEBUG("[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_DEBUG_THROTTLE(period, expression, ...)   ROS_DEBUG_THROTTLE(period, "[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_DEBUG_STREAM(...)       ROS_DEBUG_STREAM("[" NODE_NAME << "][" << __func__ << "][" << __LINE__ << "]: " << __VA_ARGS__)
#define LOG_INFO(expression, ...)   ROS_INFO("[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_INFO_THROTTLE(period, expression, ...)   ROS_INFO_THROTTLE(period, "[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_INFO_STREAM(...)        ROS_INFO_STREAM("[" NODE_NAME << "][" << __func__ << "][" << __LINE__ << "]: " << __VA_ARGS__)
#define LOG_WARN(expression, ...)   ROS_WARN("[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_WARN_THROTTLE(period, expression, ...)   ROS_WARN_THROTTLE(period, "[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_WARN_STREAM(...)        ROS_WARN_STREAM("[" NODE_NAME << "][" << __func__ << "][" << __LINE__ << "]: " << __VA_ARGS__)
#define LOG_ERROR(expression, ...)  ROS_ERROR("[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_ERROR_THROTTLE(period, expression, ...)   ROS_ERROR_THROTTLE(period, "[%s][%s][%d]: " expression, NODE_NAME, __func__, __LINE__, ##__VA_ARGS__)
#define LOG_ERROR_STREAM(...)       ROS_ERROR_STREAM("[" NODE_NAME << "][" << __func__ << "][" << __LINE__ << "]: " << __VA_ARGS__)

#endif
