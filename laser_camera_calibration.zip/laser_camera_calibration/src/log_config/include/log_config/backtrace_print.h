#ifndef BACKTRACE_PRINT_H
#define BACKTRACE_PRINT_H

#include <execinfo.h>
#include <signal.h>
#include <cxxabi.h>
#include <ros/console.h>
#include "log_config.h"

#ifndef NODE_NAME
#define NODE_NAME ""
#endif

namespace backtrace_print
{
void splitString(const char* input, char startChar, char endChar, 
                std::string& lib_str, std::string& func_str, std::string& addr_str) 
{
  const char* start = strchr(input, startChar); // 查找开始字符的位置
  const char* end = strchr(input, endChar); // 查找结束字符的位置
  std::string str(input); // 将 const char* 转换为 std::string

  if (start != nullptr && end != nullptr && end > start) {
    size_t length = end - start - 1; // 计算截取的字符长度
    lib_str = str.substr(0, start-input + 1); // 截取第一个段落
    func_str = str.substr(start-input + 1, end - start - 1); // 截取第二个段落
    addr_str = str.substr(end - input); // 截取第三个段落
  }
}

void printStackTrace(const char* symbol) {
  std::string lib_str, func_str, addr_str;
  splitString(symbol, '(', '+', lib_str, func_str, addr_str);
  int status;
  char* demangled = abi::__cxa_demangle(func_str.c_str(), nullptr, nullptr, &status);
  if (status == 0) {
    LOG_INFO("%s%s%s.", lib_str.c_str(), demangled, addr_str.c_str());
  } else {
    LOG_INFO("%s.", symbol);
  }
  std::free(demangled);
}

void signalHandler(int signo) {
	int j, nptrs;
	void *buffer[128];
	char **strings;
	LOG_INFO("signo: %d.", signo);     

	nptrs = backtrace(buffer, 128);
	
	LOG_INFO("backtrace() returned %d addresses. \n", nptrs); 

	strings = backtrace_symbols(buffer, nptrs);
	if (strings == NULL)  {
		LOG_INFO("NO backtrace_symbols."); 
		exit(EXIT_FAILURE);
	}
 
	for (j = 0; j < nptrs; j++) {
    printStackTrace(strings[j]);
	}
  
	free(strings);
 
	if (SIGSEGV == signo || SIGQUIT == signo || SIGINT == signo || SIGABRT == signo) {
		exit(0);
	}
}
}

#endif