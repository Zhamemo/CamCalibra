# 日志与堆栈打印模块


## 用法

头文件包含：

```cpp

#define NODE_NAME "depth_camera_processor"
#include <log_config/backtrace_print.h>

```

在main函数或nodelet的onInit()函数中设置信号与回调：

```cpp

signal(SIGSEGV, backtrace_print::signalHandler);    // 段错误
signal(SIGABRT, backtrace_print::signalHandler);    // 异常退出
// signal(SIGINT,  backtrace_print::signalHandler);
// signal(SIGQUIT, backtrace_print::signalHandler);

```

SIGABRT（Abort）信号是由程序自身调用abort()函数或者调用assert()宏失败时发出的。它表示程序在运行时遇到了一个严重的错误，需要终止程序的执行。通常，SIGABRT是由程序员明确地发出，用于指示程序在某个点上遇到了无法继续执行的错误条件。 
 
SIGSEGV（Segmentation Violation）信号是当程序试图访问未分配给其的内存区域，或者试图在只读内存区域进行写操作时发出的。它表示程序访问了无效的内存地址，通常是由于编程错误导致的。SIGSEGV通常是由非法指针、数组越界访问或者使用已释放的内存等问题引起的。 