#include "laser_cam_calibr.hpp"
#include "log_config/log_config.h"
#include "pose_local_parameterization.h"

#define NODE_NAME node_name_str_.c_str()

namespace laser_camera_calibration
{
    LaserCamCalibr::LaserCamCalibr()
    {
        ros::NodeHandle private_nh = ros::NodeHandle("~");
        node_name_str_ = ros::this_node::getName();

        private_nh.param("scan_height", scan_height_, 0.0);

        std::string config_path = "";
        if (!private_nh.getParam("config_path", config_path))
        {
            config_path = "/home/ubuntu/ud_ws/params/ud_launch/params/common";
            LOG_WARN("Supposed to set the config directory!");
        }
        loadInitExtrinsic(config_path);
    }

    void LaserCamCalibr::loadInitExtrinsic(std::string const &file_path)
    {
        // cv::FileStorage fSettings(file_path + "/init_extrinsic.yaml", cv::FileStorage::READ);
        // if (!fSettings.isOpened())
        // {
        //     std::cerr << "Failed to open settings file at: " << file_path << std::endl;
        //     exit(-1);
        // }

        cv::Mat init_extrinsic = (cv::Mat_<double>(4, 4) << 1.0, 0.0, 0.0, 0.0,
                                  0.0, 1.0, 0.0, 0.0,
                                  0.0, 0.0, 1.0, 0.0,
                                  0.0, 0.0, 0.0, 1.0);
        // fSettings["extrinsicMat"] >> init_extrinsic;

        init_rotation_matrix_ << init_extrinsic.at<double>(0, 0),
            init_extrinsic.at<double>(0, 1), init_extrinsic.at<double>(0, 2),
            init_extrinsic.at<double>(1, 0), init_extrinsic.at<double>(1, 1),
            init_extrinsic.at<double>(1, 2), init_extrinsic.at<double>(2, 0),
            init_extrinsic.at<double>(2, 1), init_extrinsic.at<double>(2, 2);

        init_translation_vector_ << init_extrinsic.at<double>(0, 3),
            init_extrinsic.at<double>(1, 3), init_extrinsic.at<double>(2, 3);
    }

    void LaserCamCalibr::calibrateLaserCam(LineParam const &scan_line,
                                           std::vector<Eigen::Vector3d> const &cam_point,
                                           Eigen::Matrix4d &tf)
    {
        Eigen::Quaterniond qlc(init_rotation_matrix_);
        std::cout << "init_rotation_matrix_:" << std::endl << init_rotation_matrix_ << std::endl;
        std::cout << "qlc:" << std::endl << qlc.toRotationMatrix() << std::endl;
        
        Eigen::Vector3d tlc = init_translation_vector_;
        std::cout << "tlc:" << std::endl << tlc << std::endl;

        Eigen::VectorXd pose(7);
        pose << tlc(0), tlc(1), tlc(2), qlc.x(), qlc.y(), qlc.z(), qlc.w();
        std::cout << "pose:" << std::endl << pose << std::endl;
        auto const sta_pt = scan_line.start_point, end_pt = scan_line.end_point;

        std::vector<Eigen::Vector3d> scan_point{{sta_pt[0], sta_pt[1], scan_height_},
                                                {end_pt[0], end_pt[1], scan_height_}};

        double scale = cam_point.size();
        scale = 1.0 / scale;

        ceres::Problem problem;

        for (auto const pt : cam_point)
        {
            ceres::CostFunction *cost_func = PointToLineError::Create(pt, scan_point[0], scan_point[1]);
            ceres::LossFunction *loss_func = new ceres::CauchyLoss(0.05 * scale);
            problem.AddResidualBlock(cost_func, loss_func, pose.data());
        }

        // Configure solver options
        ceres::Solver::Options options;
        options.linear_solver_type = ceres::DENSE_QR;
        options.max_num_iterations = 100;

        // Solve the problem
        ceres::Solver::Summary summary;
        ceres::Solve(options, &problem, &summary);

        // Output the result
        // std::cout << summary.FullReport() << std::endl;

        qlc = Eigen::Quaterniond(pose[3], pose[4], pose[5], pose[6]);

        tf = Eigen::Matrix4d::Identity();
        tf.block<3, 3>(0, 0) = qlc.toRotationMatrix();
        tf.block<3, 1>(0, 3) << pose[0], pose[1], pose[2];

        std::cout << "tf: " << std::endl << tf << std::endl;

        return;
    }
}