#include "point_cloud_extraction.hpp"

#include <angles/angles.h>

#include <pcl_conversions/pcl_conversions.h>

#include <pcl/features/normal_3d.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/filters/extract_indices.h>

#include <pcl/sample_consensus/ransac.h>
#include <pcl/sample_consensus/sac_model_plane.h>
#include <pcl/search/kdtree.h>
#include <pcl/segmentation/sac_segmentation.h>

namespace laser_camera_calibration
{
    PointCloudExtraction::PointCloudExtraction()
    {
        initParam();
        initTopicService();
    }

    void PointCloudExtraction::initParam()
    {
        ros::NodeHandle private_nh = ros::NodeHandle("~");

        private_nh.param("test_mode", test_mode_, 0);
        private_nh.param("min_plane_theta", min_plane_theta_, 60.0);
        private_nh.param("max_plane_theta", max_plane_theta_, 120.0);
        private_nh.param("min_line_distance", min_line_distance_, 0.03);
        private_nh.param("max_line_distance", max_line_distance_, 0.06);

        private_nh.param("voxel_size", voxel_size_, 1.0);
        private_nh.param("ransac_dis_thresh", ransac_dis_thresh_, 0.02);
        private_nh.param("plane_size_thresh", plane_size_thresh_, 100.0);
    }

    void PointCloudExtraction::initTopicService()
    {
        ros::NodeHandle private_nh("~");

        if (test_mode_ > 0)
        {
            init_voxel_pub_ = private_nh.advertise<sensor_msgs::PointCloud2>("/laser_camera_calibration/init_voxel_cloud", 1);
            planner_cloud_pub_ = private_nh.advertise<sensor_msgs::PointCloud2>("/laser_camera_calibration/planner_cloud", 1);
        }

        line_cloud_pub_ = private_nh.advertise<sensor_msgs::PointCloud2>("/laser_camera_calibration/line_cloud", 1);
    }

    void PointCloudExtraction::initVoxel(pcl::PointCloud<pcl::PointXYZI>::Ptr const &input_cloud,
                                         std::unordered_map<VOXEL_LOC, Voxel *> &voxel_map,
                                         double const voxel_size)
    {
        srand((unsigned)time(NULL));
        pcl::PointCloud<pcl::PointXYZRGB> test_cloud;

        for (size_t i = 0, iend = input_cloud->size(); i < iend; i++)
        {
            pcl::PointXYZI const &p_c = input_cloud->points[i];
            double loc_xyz[3];

            for (int j = 0; j < 3; j++)
            {
                loc_xyz[j] = p_c.data[j] / voxel_size;
                if (loc_xyz[j] < 0)
                {
                    loc_xyz[j] -= 1.0;
                }
            }

            VOXEL_LOC position((int64_t)loc_xyz[0], (int64_t)loc_xyz[1], (int64_t)loc_xyz[2]);
            auto iter = voxel_map.find(position);

            if (iter != voxel_map.end())
            {
                voxel_map[position]->cloud->push_back(p_c);
                pcl::PointXYZRGB p_rgb;
                p_rgb.x = p_c.x;
                p_rgb.y = p_c.y;
                p_rgb.z = p_c.z;
                p_rgb.r = voxel_map[position]->voxel_color(0);
                p_rgb.g = voxel_map[position]->voxel_color(1);
                p_rgb.b = voxel_map[position]->voxel_color(2);
                test_cloud.push_back(p_rgb);
            }
            else
            {
                Voxel *voxel = new Voxel(voxel_size);
                voxel_map[position] = voxel;
                voxel_map[position]->voxel_origin[0] = position.x * voxel_size;
                voxel_map[position]->voxel_origin[1] = position.y * voxel_size;
                voxel_map[position]->voxel_origin[2] = position.z * voxel_size;
                voxel_map[position]->cloud->push_back(p_c);
                int r = rand() % 256;
                int g = rand() % 256;
                int b = rand() % 256;
                voxel_map[position]->voxel_color << r, g, b;
            }
        }

        if (test_mode_ > 0)
        {
            sensor_msgs::PointCloud2 pub_cloud;
            pcl::toROSMsg(test_cloud, pub_cloud);
            pub_cloud.header.frame_id = "depth_camera";
            init_voxel_pub_.publish(pub_cloud);
        }

        for (auto iter = voxel_map.begin(); iter != voxel_map.end(); iter++)
        {
            if (iter->second->cloud->size() > 20)
            {
                down_sampling_voxel(*(iter->second->cloud), 0.03);
            }
        }
    }

    void PointCloudExtraction::calcLine(std::vector<Plane> const &plane_list, double const voxel_size,
                                        Eigen::Vector3d const origin,
                                        std::vector<pcl::PointCloud<pcl::PointXYZI>> &line_cloud_list)
    {
        int num_plane = plane_list.size();
        if (num_plane < 2)
            return;

        for (size_t i = 0; i < num_plane - 1; i++)
        {
            double a1 = plane_list[i].normal[0];
            double b1 = plane_list[i].normal[1];
            double c1 = plane_list[i].normal[2];

            double x1 = plane_list[i].p_center.x;
            double y1 = plane_list[i].p_center.y;
            double z1 = plane_list[i].p_center.z;

            for (size_t j = i + 1; j < num_plane; j++)
            {
                double a2 = plane_list[j].normal[0];
                double b2 = plane_list[j].normal[1];
                double c2 = plane_list[j].normal[2];

                double x2 = plane_list[j].p_center.x;
                double y2 = plane_list[j].p_center.y;
                double z2 = plane_list[j].p_center.z;

                double cos_theta = a1 * a2 + b1 * b2 + c1 * c2;
                double point_dis_threshold = 0.00;

                // 只保留夹角[60, 120]范围平面
                if (cos_theta < cos(angles::from_degrees(max_plane_theta_)) ||
                    cos_theta > cos(angles::from_degrees(min_plane_theta_)) ||
                    plane_list[i].cloud.size() < 1 || plane_list[j].cloud.size() < 1)
                {
                    continue;
                }

                double matrix[4][5];
                matrix[1][1] = a1;
                matrix[1][2] = b1;
                matrix[1][3] = c1;
                matrix[1][4] = a1 * x1 + b1 * y1 + c1 * z1;

                matrix[2][1] = a2;
                matrix[2][2] = b2;
                matrix[2][3] = c2;
                matrix[2][4] = a2 * x2 + b2 * y2 + c2 * z2;

                // six types
                std::vector<Eigen::Vector3d> points;
                Eigen::Vector3d point;
                matrix[3][1] = 1;
                matrix[3][2] = 0;
                matrix[3][3] = 0;
                matrix[3][4] = origin[0];
                calc<double>(matrix, point);

                if (point[0] >= origin[0] - point_dis_threshold &&
                    point[0] <= origin[0] + voxel_size + point_dis_threshold &&
                    point[1] >= origin[1] - point_dis_threshold &&
                    point[1] <= origin[1] + voxel_size + point_dis_threshold &&
                    point[2] >= origin[2] - point_dis_threshold &&
                    point[2] <= origin[2] + voxel_size + point_dis_threshold)
                {
                    points.push_back(point);
                }

                matrix[3][1] = 0;
                matrix[3][2] = 1;
                matrix[3][3] = 0;
                matrix[3][4] = origin[1];
                calc<double>(matrix, point);

                if (point[0] >= origin[0] - point_dis_threshold &&
                    point[0] <= origin[0] + voxel_size + point_dis_threshold &&
                    point[1] >= origin[1] - point_dis_threshold &&
                    point[1] <= origin[1] + voxel_size + point_dis_threshold &&
                    point[2] >= origin[2] - point_dis_threshold &&
                    point[2] <= origin[2] + voxel_size + point_dis_threshold)
                {
                    points.push_back(point);
                }

                matrix[3][1] = 0;
                matrix[3][2] = 0;
                matrix[3][3] = 1;
                matrix[3][4] = origin[2];
                calc<double>(matrix, point);

                if (point[0] >= origin[0] - point_dis_threshold &&
                    point[0] <= origin[0] + voxel_size + point_dis_threshold &&
                    point[1] >= origin[1] - point_dis_threshold &&
                    point[1] <= origin[1] + voxel_size + point_dis_threshold &&
                    point[2] >= origin[2] - point_dis_threshold &&
                    point[2] <= origin[2] + voxel_size + point_dis_threshold)
                {
                    points.push_back(point);
                }

                matrix[3][1] = 1;
                matrix[3][2] = 0;
                matrix[3][3] = 0;
                matrix[3][4] = origin[0] + voxel_size;
                calc<double>(matrix, point);

                if (point[0] >= origin[0] - point_dis_threshold &&
                    point[0] <= origin[0] + voxel_size + point_dis_threshold &&
                    point[1] >= origin[1] - point_dis_threshold &&
                    point[1] <= origin[1] + voxel_size + point_dis_threshold &&
                    point[2] >= origin[2] - point_dis_threshold &&
                    point[2] <= origin[2] + voxel_size + point_dis_threshold)
                {
                    points.push_back(point);
                }

                matrix[3][1] = 0;
                matrix[3][2] = 1;
                matrix[3][3] = 0;
                matrix[3][4] = origin[1] + voxel_size;
                calc<double>(matrix, point);

                if (point[0] >= origin[0] - point_dis_threshold &&
                    point[0] <= origin[0] + voxel_size + point_dis_threshold &&
                    point[1] >= origin[1] - point_dis_threshold &&
                    point[1] <= origin[1] + voxel_size + point_dis_threshold &&
                    point[2] >= origin[2] - point_dis_threshold &&
                    point[2] <= origin[2] + voxel_size + point_dis_threshold)
                {
                    points.push_back(point);
                }

                matrix[3][1] = 0;
                matrix[3][2] = 0;
                matrix[3][3] = 1;
                matrix[3][4] = origin[2] + voxel_size;
                calc<double>(matrix, point);

                if (point[0] >= origin[0] - point_dis_threshold &&
                    point[0] <= origin[0] + voxel_size + point_dis_threshold &&
                    point[1] >= origin[1] - point_dis_threshold &&
                    point[1] <= origin[1] + voxel_size + point_dis_threshold &&
                    point[2] >= origin[2] - point_dis_threshold &&
                    point[2] <= origin[2] + voxel_size + point_dis_threshold)
                {
                    points.push_back(point);
                }

                if (points.size() == 2)
                {
                    pcl::PointCloud<pcl::PointXYZI> line_cloud;
                    pcl::PointXYZ p1(points[0][0], points[0][1], points[0][2]);
                    pcl::PointXYZ p2(points[1][0], points[1][1], points[1][2]);
                    double length = sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2) + pow(p1.z - p2.z, 2));

                    // 指定近邻个数
                    int K = 1;

                    // 创建两个向量，分别存放近邻的索引值、近邻的中心距
                    std::vector<int> pointIdxNKNSearch1(K);
                    std::vector<float> pointNKNSquaredDistance1(K);
                    std::vector<int> pointIdxNKNSearch2(K);
                    std::vector<float> pointNKNSquaredDistance2(K);
                    pcl::search::KdTree<pcl::PointXYZI>::Ptr kdtree1(new pcl::search::KdTree<pcl::PointXYZI>());
                    pcl::search::KdTree<pcl::PointXYZI>::Ptr kdtree2(new pcl::search::KdTree<pcl::PointXYZI>());
                    kdtree1->setInputCloud(plane_list[i].cloud.makeShared());
                    kdtree2->setInputCloud(plane_list[j].cloud.makeShared());

                    for (double inc = 0; inc <= length; inc += 0.005)
                    {
                        pcl::PointXYZI p;
                        p.x = p1.x + (p2.x - p1.x) * inc / length;
                        p.y = p1.y + (p2.y - p1.y) * inc / length;
                        p.z = p1.z + (p2.z - p1.z) * inc / length;
                        p.intensity = 100;

                        if ((kdtree1->nearestKSearch(p, K, pointIdxNKNSearch1, pointNKNSquaredDistance1) > 0) &&
                            (kdtree2->nearestKSearch(p, K, pointIdxNKNSearch2, pointNKNSquaredDistance2) > 0))
                        {
                            double dis1 = pow(p.x - plane_list[i].cloud.points[pointIdxNKNSearch1[0]].x, 2) +
                                          pow(p.y - plane_list[i].cloud.points[pointIdxNKNSearch1[0]].y, 2) +
                                          pow(p.z - plane_list[i].cloud.points[pointIdxNKNSearch1[0]].z, 2);

                            double dis2 = pow(p.x - plane_list[j].cloud.points[pointIdxNKNSearch2[0]].x, 2) +
                                          pow(p.y - plane_list[j].cloud.points[pointIdxNKNSearch2[0]].y, 2) +
                                          pow(p.z - plane_list[j].cloud.points[pointIdxNKNSearch2[0]].z, 2);

                            if ((dis1 < min_line_distance_ * min_line_distance_ &&
                                 dis2 < max_line_distance_ * max_line_distance_) ||
                                ((dis1 < max_line_distance_ * max_line_distance_ &&
                                  dis2 < min_line_distance_ * min_line_distance_)))
                            {
                                line_cloud.push_back(p);
                            }
                        }
                    }

                    if (line_cloud.size() > 10)
                    {
                        line_cloud_list.push_back(line_cloud);
                    }
                }
            }
        }
    }

    void PointCloudExtraction::extractLiDAREdge(std::unordered_map<VOXEL_LOC, Voxel *> const &voxel_map,
                                                double const ransac_dis_thresh, int const plane_size_thresh,
                                                std::vector<Eigen::Vector3d> &lidar_line_cloud_3d)
    {
        ros::Rate loop(5000);

        for (auto iter = voxel_map.begin(); iter != voxel_map.end(); iter++)
        {
            if (iter->second->cloud->size() > 50)
            {
                std::vector<Plane> plane_list;

                // 创建一个体素滤波器
                pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filter(new pcl::PointCloud<pcl::PointXYZI>);
                pcl::copyPointCloud(*iter->second->cloud, *cloud_filter);

                // 创建一个模型参数对象，用于记录结果
                pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);

                // inliers表示误差能容忍的点，记录点云序号
                pcl::PointIndices::Ptr inliers(new pcl::PointIndices);

                // 创建一个分割器
                pcl::SACSegmentation<pcl::PointXYZI> seg;

                // Optional,设置结果平面展示的点是分割掉的点还是分割剩下的点
                seg.setOptimizeCoefficients(true);

                // Mandatory-设置目标几何形状
                seg.setModelType(pcl::SACMODEL_PLANE);

                // 分割方法：随机采样法
                seg.setMethodType(pcl::SAC_RANSAC);

                // 设置误差容忍范围，也就是阈值
                if (iter->second->voxel_origin[0] < 10)
                {
                    seg.setDistanceThreshold(ransac_dis_thresh);
                }
                else
                {
                    seg.setDistanceThreshold(ransac_dis_thresh);
                }

                pcl::PointCloud<pcl::PointXYZRGB> color_planner_cloud;
                int plane_index = 0;

                while (cloud_filter->points.size() > 10)
                {
                    pcl::PointCloud<pcl::PointXYZI> planner_cloud;
                    pcl::ExtractIndices<pcl::PointXYZI> extract;

                    // 输入点云
                    seg.setInputCloud(cloud_filter);
                    seg.setMaxIterations(500);

                    // 分割点云
                    seg.segment(*inliers, *coefficients);
                    if (inliers->indices.size() == 0)
                    {
                        ROS_INFO_STREAM(
                            "Could not estimate a planner model for the given dataset");
                        break;
                    }

                    extract.setIndices(inliers);
                    extract.setInputCloud(cloud_filter);
                    extract.filter(planner_cloud);

                    if (planner_cloud.size() > plane_size_thresh)
                    {
                        pcl::PointCloud<pcl::PointXYZRGB> color_cloud;
                        std::vector<unsigned int> colors;
                        colors.push_back(static_cast<unsigned int>(rand() % 256));
                        colors.push_back(static_cast<unsigned int>(rand() % 256));
                        colors.push_back(static_cast<unsigned int>(rand() % 256));
                        pcl::PointXYZ p_center(0, 0, 0);

                        for (size_t i = 0; i < planner_cloud.points.size(); i++)
                        {
                            pcl::PointXYZRGB p;
                            p.x = planner_cloud.points[i].x;
                            p.y = planner_cloud.points[i].y;
                            p.z = planner_cloud.points[i].z;
                            p_center.x += p.x;
                            p_center.y += p.y;
                            p_center.z += p.z;
                            p.r = colors[0];
                            p.g = colors[1];
                            p.b = colors[2];
                            color_cloud.push_back(p);
                            color_planner_cloud.push_back(p);
                        }

                        p_center.x = p_center.x / planner_cloud.size();
                        p_center.y = p_center.y / planner_cloud.size();
                        p_center.z = p_center.z / planner_cloud.size();

                        Plane single_plane;
                        single_plane.cloud = planner_cloud;
                        single_plane.p_center = p_center;
                        single_plane.normal << coefficients->values[0], coefficients->values[1], coefficients->values[2];
                        single_plane.index = plane_index;
                        plane_list.push_back(single_plane);
                        plane_index++;
                    }

                    extract.setNegative(true);
                    pcl::PointCloud<pcl::PointXYZI> cloud_f;
                    extract.filter(cloud_f);
                    *cloud_filter = cloud_f;
                }

                if (plane_list.size() >= 2 && test_mode_ > 0)
                {
                    sensor_msgs::PointCloud2 planner_cloud2;
                    pcl::toROSMsg(color_planner_cloud, planner_cloud2);
                    planner_cloud2.header.frame_id = "depth_camera";
                    planner_cloud_pub_.publish(planner_cloud2);
                    loop.sleep();
                }

                std::vector<pcl::PointCloud<pcl::PointXYZI>> line_cloud_list;
                line_cloud_list.clear();
                line_cloud_list.reserve(500);

                calcLine(plane_list, voxel_size_, iter->second->voxel_origin, line_cloud_list);

                // ouster 5,normal 3
                if (line_cloud_list.size() > 0 && line_cloud_list.size() <= 8)
                {
                    for (size_t cloud_index = 0; cloud_index < line_cloud_list.size(); cloud_index++)
                    {
                        for (size_t i = 0; i < line_cloud_list[cloud_index].size(); i++)
                        {
                            pcl::PointXYZI p = line_cloud_list[cloud_index].points[i];
                            lidar_line_cloud_3d.push_back({p.x, p.y, p.z});

                            sensor_msgs::PointCloud2 pub_cloud;
                            pcl::toROSMsg(line_cloud_list[cloud_index], pub_cloud);
                            pub_cloud.header.frame_id = "depth_camera";
                            line_cloud_pub_.publish(pub_cloud);
                            loop.sleep();
                        }
                    }
                }
            }
        }
    }

    bool PointCloudExtraction::run(sensor_msgs::PointCloud2::ConstPtr const &input_cloud, std::vector<Eigen::Vector3d> &line_cloud)
    {
        pcl::PointCloud<pcl::PointXYZI>::Ptr raw_camera_cloud(new pcl::PointCloud<pcl::PointXYZI>);
        pcl::fromROSMsg(*input_cloud, *raw_camera_cloud);

        std::unordered_map<VOXEL_LOC, Voxel *> voxel_map;
        initVoxel(raw_camera_cloud, voxel_map, voxel_size_);
        extractLiDAREdge(voxel_map, ransac_dis_thresh_, plane_size_thresh_, line_cloud);

        if (line_cloud.empty())
        {
            return false;
        }

        return true;
    }
}