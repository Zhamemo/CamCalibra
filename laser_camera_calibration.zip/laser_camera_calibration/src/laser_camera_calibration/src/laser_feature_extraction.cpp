#include "laser_feature_extraction.hpp"

#include <tf2/utils.h>
#include <visualization_msgs/Marker.h>

namespace laser_camera_calibration
{
    LaserFeatureExtraction::LaserFeatureExtraction()
    {
        p_line_extraction_.reset();
        p_line_extraction_ = boost::make_shared<line_extraction::LineExtraction>();

        initParam();
        initTopicService();
    }

    void LaserFeatureExtraction::initParam()
    {
        ros::NodeHandle private_nh = ros::NodeHandle("~");
        private_nh.param("test_mode", test_mode_, 0);

        // Parameters used by the line extraction algorithm
        int min_line_points = 0;
        double bearing_std_dev = 0.0, range_std_dev = 0.0,
               least_sq_angle_thresh = 0.0, least_sq_radius_thresh = 0.0,
               max_line_gap = 0.0, min_line_length = 0.0,
               min_range = 0.0, max_range = 0.0,
               min_split_dist = 0.0, outlier_dist = 0.0;

        private_nh.param<double>("bearing_std_dev", bearing_std_dev, 1e-3);
        p_line_extraction_->setBearingVariance(bearing_std_dev * bearing_std_dev);

        private_nh.param<double>("range_std_dev", range_std_dev, 0.02);
        p_line_extraction_->setRangeVariance(range_std_dev * range_std_dev);

        private_nh.param<double>("least_sq_angle_thresh", least_sq_angle_thresh, 1e-4);
        p_line_extraction_->setLeastSqAngleThresh(least_sq_angle_thresh);

        private_nh.param<double>("least_sq_radius_thresh", least_sq_radius_thresh, 1e-4);
        p_line_extraction_->setLeastSqRadiusThresh(least_sq_radius_thresh);

        private_nh.param<double>("max_line_gap", max_line_gap, 0.4);
        p_line_extraction_->setMaxLineGap(max_line_gap);

        private_nh.param<double>("min_line_length", min_line_length, 0.5);
        p_line_extraction_->setMinLineLength(min_line_length);

        private_nh.param<double>("min_range", min_range, 0.4);
        p_line_extraction_->setMinRange(min_range);

        private_nh.param<double>("max_range", max_range, 10000.0);
        p_line_extraction_->setMaxRange(max_range);

        private_nh.param<double>("min_split_dist", min_split_dist, 0.05);
        p_line_extraction_->setMinSplitDist(min_split_dist);

        private_nh.param<double>("outlier_dist", outlier_dist, 0.05);
        p_line_extraction_->setOutlierDist(outlier_dist);

        private_nh.param<int>("min_line_points", min_line_points, 9);
        p_line_extraction_->setMinLinePoints(static_cast<unsigned int>(min_line_points));
    }

    void LaserFeatureExtraction::initTopicService()
    {
        ros::NodeHandle private_nh("~");
        feature_line_pub_ = private_nh.advertise<visualization_msgs::Marker>("/laser_camera_calibration/line_feature", 1);
    }

    bool LaserFeatureExtraction::cacheData(sensor_msgs::LaserScan::ConstPtr const &scan_msg,
                                           std::vector<double> &scan_ranges)
    {
        int scan_cnt = scan_msg->ranges.size();
        if ((int)scan_msg->intensities.size() != scan_cnt || scan_msg->intensities.empty())
            return false;

        std::vector<unsigned int> indices;
        std::vector<double> bearings, cos_bearings, sin_bearings;

        indices.clear();
        bearings.clear();
        cos_bearings.clear();
        sin_bearings.clear();

        indices.reserve(scan_cnt);
        bearings.reserve(scan_cnt);
        cos_bearings.reserve(scan_cnt);
        sin_bearings.reserve(scan_cnt);

        double mid_theta = (scan_msg->angle_max + scan_msg->angle_min) / 2;

        for (int i = 0; i < scan_cnt; ++i)
        {
            const double range = static_cast<double>(scan_msg->ranges[i]);
            const double angle = scan_msg->angle_min + i * scan_msg->angle_increment;

            indices.push_back(i);
            bearings.push_back(angle);
            cos_bearings.push_back(cos(angle));
            sin_bearings.push_back(sin(angle));
            scan_ranges.push_back(range);
        }

        if (indices.empty() || bearings.empty() || cos_bearings.empty() ||
            sin_bearings.empty() || scan_ranges.empty())
            return false;

        p_line_extraction_->setCachedData(bearings, cos_bearings, sin_bearings, indices);
        return true;
    }

    bool LaserFeatureExtraction::searchBestLine(std::vector<line_extraction::Line> const &lines,
                                                double const scan_increment, LineParam &line)
    {
        int best_index = -1;
        double max_score = 0.0;

        for (int i = 0, iend = lines.size(); i < iend; ++i)
        {
            // 认为最靠近 M_PI_2 为墙所在直线 M_PI_2 - (M_PI_2 - fabs(line.getAngle()))
            double const score = exp(-fabs(lines[i].getAngle()));
            if (score > max_score)
            {
                max_score = score;
                best_index = i;
            }
        }

        if (best_index == -1)
            return false;

        auto const &best_line = lines[best_index];
        line.start_point = best_line.getStart();
        line.end_point = best_line.getEnd();
        line.theta = best_line.getAngle();

        if (test_mode_ > 0)
        {
            // Eigen::Vector4d vec: vec[0]->B, vec[1]->G, vec[2]->R, vec[3]->scale
            publishFeatureLine({best_line}, Eigen::Vector4d(0.0, 1.0, 0.0, 0.02), true);
        }
        return true;
    }

    void LaserFeatureExtraction::publishFeatureLine(std::vector<line_extraction::Line> const &lines,
                                                    Eigen::Vector4d const &color,
                                                    bool const is_pub)
    {
        if (!is_pub)
            return;

        visualization_msgs::Marker marker_msg;
        marker_msg.id = 0;
        marker_msg.type = visualization_msgs::Marker::LINE_LIST;
        marker_msg.scale.x = color[3];
        marker_msg.color.r = color[2];
        marker_msg.color.g = color[1];
        marker_msg.color.b = color[0];
        marker_msg.color.a = 1.0;

        geometry_msgs::Point p_start;
        for (auto cit = lines.begin(); cit != lines.end(); ++cit)
        {
            p_start.x = cit->getStart()[0];
            p_start.y = cit->getStart()[1];
            p_start.z = 0;
            marker_msg.points.push_back(p_start);
            geometry_msgs::Point p_end;
            p_end.x = cit->getEnd()[0];
            p_end.y = cit->getEnd()[1];
            p_end.z = 0;
            marker_msg.points.push_back(p_end);
        }

        marker_msg.header.frame_id = "laser_link";
        marker_msg.header.stamp = ros::Time::now();
        feature_line_pub_.publish(marker_msg);
    }

    bool LaserFeatureExtraction::run(sensor_msgs::LaserScan::ConstPtr const &scan_msg, LineParam &line)
    {
        std::vector<double> scan_ranges;
        scan_ranges.clear();
        scan_ranges.reserve(1000);

        if (!cacheData(scan_msg, scan_ranges))
            return false;

        p_line_extraction_->setRangeData(scan_ranges);
        std::vector<line_extraction::Line> lines;
        lines.clear();
        lines.reserve(15);

        p_line_extraction_->extractLines(lines);

        const double scan_increment = scan_msg->angle_increment;

        if (!searchBestLine(lines, scan_increment, line))
            return false;

        return true;
    }
}