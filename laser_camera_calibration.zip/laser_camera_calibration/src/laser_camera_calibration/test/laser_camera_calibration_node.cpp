#include "laser_feature_extraction.hpp"
#include "point_cloud_extraction.hpp"
#include "laser_cam_calibr.hpp"
#include "log_config/log_config.h"

#include <std_msgs/Int8.h>
#include <tf2/utils.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

#define NODE_NAME node_name_str_.c_str()

class LaserCameraCalibrationNode
{
public:
    LaserCameraCalibrationNode();
    ~LaserCameraCalibrationNode() = default;

    LaserCameraCalibrationNode(LaserCameraCalibrationNode const &) = delete;
    LaserCameraCalibrationNode &operator=(LaserCameraCalibrationNode const &) = delete;

private:
    /**
     * @brief 初始化雷达与robot中心的坐标转化关系
     *
     * @return true 成功
     * @return false 失败
     */
    bool initTF();
    void initTopic(bool const switch_topic);
    void scanCB(sensor_msgs::LaserScan::ConstPtr const &scan_msg);
    void pointCloudCB(sensor_msgs::PointCloud2::ConstPtr const &camera_msg);

    // 测试指令
    void detectTestCB(std_msgs::Int8::ConstPtr const &msg);

    void run();

public:
    // 主函数中的循环函数
    void loop();

private:
    int test_mode_{0};                 // 测试模式标志位 0:关闭 1:开启
    ros::Subscriber scan_sub_;         // 订阅雷达点云
    ros::Subscriber depth_camera_sub_; // 订阅深度相机点云
    ros::Subscriber test_sub_;         // 启动检测 Debug

    std::string node_name_str_; // 节点名称
    std::string base_frame_;    // robot坐标系名称（base_footprint）
    std::string laser_frame_;   // 雷达坐标系名称
    std::string odom_frame_;    // 里程计坐标系名称

    bool got_lidar_tf_{false};                      // TF坐标初始化
    geometry_msgs::TransformStamped lidar_base_tf_; // lidar->base_footprint的坐标转换关系

    tf2_ros::Buffer tf_buffer_;                                                                    // tf缓存
    std::shared_ptr<tf2_ros::TransformListener> p_tf_listener_;                                    // 用于监听tf
    std::shared_ptr<laser_camera_calibration::LaserFeatureExtraction> p_laser_feature_extraction_; // 雷达点云提取算法
    std::shared_ptr<laser_camera_calibration::PointCloudExtraction> p_point_cloud_extraction_;     // 深度相机点云提取算法
    std::shared_ptr<laser_camera_calibration::LaserCamCalibr> p_laser_cam_calibr_;                 // 雷达相机联合标定算法

    LineParam scan_line_;
    std::vector<Eigen::Vector3d> cam_point_;
};

LaserCameraCalibrationNode::LaserCameraCalibrationNode()
{
    ros::NodeHandle private_nh = ros::NodeHandle("~");
    node_name_str_ = ros::this_node::getName();

    private_nh.param("test_mode", test_mode_, 0);
    private_nh.param("base_frame", base_frame_, std::string("base_footprint"));
    private_nh.param("laser_frame", laser_frame_, std::string("laser_link"));
    private_nh.param("odom_frame", odom_frame_, std::string("odom"));

    // Debug
    test_sub_ = private_nh.subscribe<std_msgs::Int8>("/laser_camera_calibration/detector_test",
                                                     1,
                                                     boost::bind(&LaserCameraCalibrationNode::detectTestCB,
                                                                 this, _1));

    p_tf_listener_ = std::make_shared<tf2_ros::TransformListener>(tf_buffer_);
    p_laser_feature_extraction_.reset();
    p_laser_feature_extraction_ = std::make_shared<laser_camera_calibration::LaserFeatureExtraction>();
    p_point_cloud_extraction_.reset();
    p_point_cloud_extraction_ = std::make_shared<laser_camera_calibration::PointCloudExtraction>();
    p_laser_cam_calibr_.reset();
    p_laser_cam_calibr_ = std::make_shared<laser_camera_calibration::LaserCamCalibr>();
}

bool LaserCameraCalibrationNode::initTF()
{
    if (!got_lidar_tf_)
    {
        try
        {
            lidar_base_tf_ = tf_buffer_.lookupTransform(base_frame_,
                                                        laser_frame_,
                                                        ros::Time(0),
                                                        ros::Duration(0.5));

            // LOG_INFO("lidar-base tf: %f, %f, %f",
            //          lidar_base_tf_.transform.translation.x,
            //          lidar_base_tf_.transform.translation.y,
            //          lidar_base_tf_.transform.translation.z);

            return true;
        }
        catch (tf2::TransformException &e)
        {
            LOG_ERROR("%s", e.what());
            return false;
        }
    }
}

void LaserCameraCalibrationNode::initTopic(bool const switch_topic)
{
    if (switch_topic)
    {
        ros::NodeHandle nh("~");
        scan_sub_ = nh.subscribe<sensor_msgs::LaserScan>("/scan",
                                                         1,
                                                         boost::bind(&LaserCameraCalibrationNode::scanCB,
                                                                     this, _1));

        depth_camera_sub_ = nh.subscribe<sensor_msgs::PointCloud2>("/camera/depth/points",
                                                                   1,
                                                                   boost::bind(&LaserCameraCalibrationNode::pointCloudCB,
                                                                               this, _1));
    }
    else
    {
        scan_sub_.shutdown();
        depth_camera_sub_.shutdown();
    }
}

void LaserCameraCalibrationNode::scanCB(sensor_msgs::LaserScan::ConstPtr const &scan_msg)
{
    if (scan_msg->ranges.empty())
    {
        LOG_WARN("Not get the Scan message!");
        return;
    }

    got_lidar_tf_ = initTF();

    // TF坐标系初始化不成功提前返回
    if (!got_lidar_tf_)
        return;

    if (!p_laser_feature_extraction_->run(scan_msg, scan_line_))
        return;
}

void LaserCameraCalibrationNode::pointCloudCB(sensor_msgs::PointCloud2::ConstPtr const &camera_msg)
{
    if (camera_msg->data.empty())
    {
        LOG_WARN("Not get the camera message!");
        return;
    }

    cam_point_.clear();
    cam_point_.reserve(1000);

    if (!p_point_cloud_extraction_->run(camera_msg, cam_point_))
        return;

    LOG_WARN("size: %d", cam_point_.size());
}

void LaserCameraCalibrationNode::detectTestCB(const std_msgs::Int8::ConstPtr &msg)
{
    int const result = msg->data;

    if (result == 0)
    {
        initTopic(false);
        LOG_INFO("The goal of stop is arrived!");
    }
    else if (result == 1)
    {
        initTopic(true);
        LOG_INFO("The goal of start is arrived!");
    }
    else
    {
        return;
    }
}

void LaserCameraCalibrationNode::run()
{
    Eigen::Matrix4d tf = Eigen::Matrix4d::Identity();
    p_laser_cam_calibr_->calibrateLaserCam(scan_line_, cam_point_, tf);
}

void LaserCameraCalibrationNode::loop()
{
    ros::Rate rate(1000);

    while (ros::ok)
    {
        run();
        rate.sleep();
        ros::spinOnce();
    }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "laser_camera_calibration_node");
    ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Info);

    LaserCameraCalibrationNode start_node;
    start_node.loop();
    return 0;
}