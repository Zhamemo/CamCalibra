#ifndef LASER_FEATURE_EXTRACTION_H_
#define LASER_FEATURE_EXTRACTION_H_

#include "line_feature_extraction/line.h"
#include "line_feature_extraction/line_extraction.h"
#include "common.hpp"

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>

namespace laser_camera_calibration
{
    class LaserFeatureExtraction
    {
    public:
        LaserFeatureExtraction();
        ~LaserFeatureExtraction() = default;

        LaserFeatureExtraction(LaserFeatureExtraction const &) = delete;
        LaserFeatureExtraction &operator=(LaserFeatureExtraction const &) = delete;

    public:
        void initParam();

        /**
         * @brief 初始化特征发布话题
         *
         */
        void initTopicService();

    private:
        /**
         * @brief 单帧雷达点云数据预处理
         *
         * @param[in] scan_msg 雷达消息
         * @param[out] scan_ranges 输出雷达ranges
         * @return true
         * @return false
         */
        bool cacheData(sensor_msgs::LaserScan::ConstPtr const &scan_msg,
                       std::vector<double> &scan_ranges);

        /**
         * @brief 根据得分机制确定最佳直线
         *
         * @param[in] lines 单帧雷达点云中提取到所有直线
         * @param[in] scan_increment 雷达的角分辨率
         * @param[out] line 最佳直线
         * @return true
         * @return false
         */
        bool searchBestLine(std::vector<line_extraction::Line> const &lines,
                            double const scan_increment, LineParam &line);

    private:
        /**
         * @brief 发布雷达点云中的直线特征
         *
         * @param[in] lines 单帧雷达点云中提取到所有直线
         * @param[in] color 直线显示颜色　Eigen::Vector4d vec: vec[0]->B, vec[1]->G, vec[2]->R, vec[3]->scale
         * @param[in] is_pub 发布标志位
         */
        void publishFeatureLine(std::vector<line_extraction::Line> const &lines,
                                Eigen::Vector4d const &color,
                                bool const is_pub);

    public:
        /**
         * @brief 雷达直线特征提取对外接口
         *
         * @param[in] scan_msg 单帧雷达点云
         * @param[in] line 最佳直线
         * @return true
         * @return false
         */
        bool run(sensor_msgs::LaserScan::ConstPtr const &scan_msg, LineParam &line);

    private:
        ros::Publisher feature_line_pub_; // 用于发布特征线段

        int test_mode_{0};                                                     // 测试模式标志位 0:关闭 1:开启
        boost::shared_ptr<line_extraction::LineExtraction> p_line_extraction_; // 直线提取算法
    };
}

#endif // LASER_FEATURE_EXTRACTION_H_