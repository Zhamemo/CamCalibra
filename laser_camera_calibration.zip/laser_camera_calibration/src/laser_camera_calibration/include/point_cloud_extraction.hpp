#ifndef POINT_CLOUD_EXTRACTION_H_
#define POINT_CLOUD_EXTRACTION_H_

#include "common.hpp"

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

namespace laser_camera_calibration
{
    class PointCloudExtraction
    {
    public:
        PointCloudExtraction();
        ~PointCloudExtraction() = default;

        PointCloudExtraction(PointCloudExtraction const &) = delete;
        PointCloudExtraction &operator=(PointCloudExtraction const &) = delete;

    private:
        void initParam();

        /**
         * @brief 初始化特征发布话题
         *
         */
        void initTopicService();

    private:
        void initVoxel(pcl::PointCloud<pcl::PointXYZI>::Ptr const &input_cloud,
                       std::unordered_map<VOXEL_LOC, Voxel *> &voxel_map,
                       double const voxel_size);

        void calcLine(std::vector<Plane> const &plane_list, double const voxel_size,
                      Eigen::Vector3d const origin,
                      std::vector<pcl::PointCloud<pcl::PointXYZI>> &line_cloud_list);

        void extractLiDAREdge(std::unordered_map<VOXEL_LOC, Voxel *> const &voxel_map,
                              double const ransac_dis_thresh, int const plane_size_thresh,
                              std::vector<Eigen::Vector3d> &lidar_line_cloud_3d);

    public:
        bool run(sensor_msgs::PointCloud2::ConstPtr const &input_cloud,
                 std::vector<Eigen::Vector3d> &line_cloud);

    private:
        ros::Publisher init_voxel_pub_;    // 用于初始体素分割点云
        ros::Publisher planner_cloud_pub_; // 用于发布平面特征点云
        ros::Publisher line_cloud_pub_;    // 用于发布线特征点云

        double min_plane_theta_{60.0};  // 平面间最小夹角
        double max_plane_theta_{120.0}; // 平面间最大夹角
        double min_line_distance_{0.03};
        double max_line_distance_{0.06};

        double voxel_size_{1.0};          // 初始化体素网格大小
        double ransac_dis_thresh_{0.02};  // RANSAC平面拟合中的距离阈值
        double plane_size_thresh_{100.0}; // 平面点云数量阈值

        // 存储平面交接点云
        pcl::PointCloud<pcl::PointXYZI>::Ptr plane_line_cloud_;
        std::vector<int> plane_line_number_;

        int test_mode_{0}; // 测试模式标志位 0:关闭 1:开启
    };
}

#endif // POINT_CLOUD_EXTRACTION_H_