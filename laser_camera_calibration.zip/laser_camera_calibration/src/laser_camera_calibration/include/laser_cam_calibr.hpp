#ifndef LASER_CAM_CALIBR_H_
#define LASER_CAM_CALIBR_H_

#include "common.hpp"

#include <ceres/ceres.h>

#include <ros/ros.h>
#include <Eigen/Core>
#include <opencv2/opencv.hpp>

namespace laser_camera_calibration
{
    class PointToLineError
    {
    public:
        PointToLineError(Eigen::Vector3d const &cam_point,
                         Eigen::Vector3d const &target_line_start,
                         Eigen::Vector3d const &target_line_end) : source_point_{cam_point},
                                                                   target_line_start_{target_line_start},
                                                                   target_line_end_{target_line_end} {}

        template <typename T>
        bool operator()(T const *const param, T *residual) const
        {
            std::cout << "param:" << std::endl
                      << param[0] << ", " << param[1] << ", " << param[2] << ", " << param[3] << ", "
                      << param[4] << ", " << param[5] << ", " << param[6] << std::endl;

            Eigen::Quaternion<T> rotation{param[3], param[4], param[5], param[6]};
            std::cout << "rotation:" << std::endl
                      << rotation.toRotationMatrix() << std::endl;

            Eigen::Matrix<T, 3, 1> translation{param[0], param[1], param[2]};
            std::cout << "translation:" << std::endl
                      << translation << std::endl;

            // Transform source point to target coordinate system
            Eigen::Matrix<T, 3, 1> transformed_point = rotation.toRotationMatrix() * source_point_.template cast<T>() + translation;
            std::cout << "transformed_point:" << std::endl
                      << transformed_point << std::endl;

            // Compute the distance between the transformed point and the target line
            Eigen::Matrix<T, 3, 1> line_direction = target_line_end_.template cast<T>() -
                                                    target_line_start_.template cast<T>();
            std::cout << "line_direction:" << std::endl
                      << line_direction << std::endl;

            Eigen::Matrix<T, 3, 1> point_to_line = transformed_point - target_line_start_.template cast<T>();
            std::cout << "point_to_line:" << std::endl
                      << point_to_line << std::endl;

            T distance = (point_to_line.cross(line_direction)).norm() / line_direction.norm();

            // Set residual
            residual[0] = distance;

            std::cout << "residual:" << std::endl
                      << residual[0] << std::endl;
        }

        static ceres::CostFunction *Create(Eigen::Vector3d const &source_point,
                                           Eigen::Vector3d const &target_line_start,
                                           Eigen::Vector3d const &target_line_end)
        {
            return new ceres::AutoDiffCostFunction<PointToLineError, 1, 7>(
                new PointToLineError(source_point, target_line_start, target_line_end));
        }

    private:
        const Eigen::Vector3d source_point_;
        const Eigen::Vector3d target_line_start_;
        const Eigen::Vector3d target_line_end_;
    };

    class LaserCamCalibr
    {
    public:
        LaserCamCalibr();
        ~LaserCamCalibr() = default;

        LaserCamCalibr(LaserCamCalibr const &) = delete;
        LaserCamCalibr &operator=(LaserCamCalibr const &) = delete;

    private:
        /**
         * @brief 读取配置参数
         *
         */
        void loadInitExtrinsic(std::string const &file_path);

    public:
        void calibrateLaserCam(LineParam const &scan_line,
                               std::vector<Eigen::Vector3d> const &cam_point,
                               Eigen::Matrix4d &tf);

    private:
        std::string node_name_str_; // 节点名称
        double scan_height_{0.0};   // 雷达安装高度

        Eigen::Matrix3d init_rotation_matrix_;    // 初始旋转矩阵
        Eigen::Vector3d init_translation_vector_; // 初始平移向量
    };
}

#endif // LASER_CAMERA_CALIBRATION_H_
