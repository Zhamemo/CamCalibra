#ifndef LIDAR_CAMERA_COMMON_H
#define LIDAR_CAMERA_COMMON_H

#include <Eigen/Core>
#include <cv_bridge/cv_bridge.h>
#include <pcl/common/io.h>
#include <stdio.h>
#include <string>
#include <unordered_map>

struct LineParam
{
  boost::array<double, 2> start_point{{0.0, 0.0}};
  boost::array<double, 2> end_point{{0.0, 0.0}};
  double theta{0.0};
};

struct PnPData
{
  double x, y, z, u, v;
};

struct VPnPData
{
  double x, y, z, u, v;
  Eigen::Vector2d direction;
  Eigen::Vector2d direction_lidar;
  int number;
};

typedef Eigen::Matrix<double, 6, 1> Vector6d;
// 存放每一个点的索引值和其对应的曲率
typedef struct PCURVATURE
{
  // POINT3F cPoint;
  int index;
  float curvature;
} PCURVATURE;

typedef struct Plane
{
  pcl::PointCloud<pcl::PointXYZI> cloud;
  pcl::PointXYZ p_center;
  Eigen::Vector3d normal;
  int index;
} Plane;

class VOXEL_LOC
{
public:
  int64_t x, y, z;

  VOXEL_LOC(int64_t vx = 0, int64_t vy = 0, int64_t vz = 0)
      : x(vx), y(vy), z(vz) {}

  bool operator==(const VOXEL_LOC &other) const
  {
    return (x == other.x && y == other.y && z == other.z);
  }
};

// Hash value
namespace std
{
  template <>
  struct hash<VOXEL_LOC>
  {
    size_t operator()(const VOXEL_LOC &s) const
    {
      using std::hash;
      using std::size_t;
      return ((hash<int64_t>()(s.x) ^ (hash<int64_t>()(s.y) << 1)) >> 1) ^
             (hash<int64_t>()(s.z) << 1);
    }
  };
}

struct M_POINT
{
  float xyz[3];
  float intensity;
  int count = 0;
};

using namespace std;

template <class T>
void input(T matrix[4][5])
{
  cout << "please input matrix element's data" << endl;
  for (int i = 1; i < 4; i++)
  {
    for (int j = 1; j < 5; j++)
    {
      cin >> matrix[i][j];
    }
  }
  cout << "input ok";
}

template <class T>
void calc(T matrix[4][5], Eigen::Vector3d &solution)
{
  // 计算行列式
  T base_D = matrix[1][1] * matrix[2][2] * matrix[3][3] +
             matrix[2][1] * matrix[3][2] * matrix[1][3] +
             matrix[3][1] * matrix[1][2] * matrix[2][3];

  base_D = base_D - (matrix[1][3] * matrix[2][2] * matrix[3][1] +
                     matrix[1][1] * matrix[2][3] * matrix[3][2] +
                     matrix[1][2] * matrix[2][1] * matrix[3][3]);

  if (base_D != 0)
  {
    T x_D = matrix[1][4] * matrix[2][2] * matrix[3][3] +
            matrix[2][4] * matrix[3][2] * matrix[1][3] +
            matrix[3][4] * matrix[1][2] * matrix[2][3];

    x_D = x_D - (matrix[1][3] * matrix[2][2] * matrix[3][4] +
                 matrix[1][4] * matrix[2][3] * matrix[3][2] +
                 matrix[1][2] * matrix[2][4] * matrix[3][3]);

    T y_D = matrix[1][1] * matrix[2][4] * matrix[3][3] +
            matrix[2][1] * matrix[3][4] * matrix[1][3] +
            matrix[3][1] * matrix[1][4] * matrix[2][3];

    y_D = y_D - (matrix[1][3] * matrix[2][4] * matrix[3][1] +
                 matrix[1][1] * matrix[2][3] * matrix[3][4] +
                 matrix[1][4] * matrix[2][1] * matrix[3][3]);

    T z_D = matrix[1][1] * matrix[2][2] * matrix[3][4] +
            matrix[2][1] * matrix[3][2] * matrix[1][4] +
            matrix[3][1] * matrix[1][2] * matrix[2][4];

    z_D = z_D - (matrix[1][4] * matrix[2][2] * matrix[3][1] +
                 matrix[1][1] * matrix[2][4] * matrix[3][2] +
                 matrix[1][2] * matrix[2][1] * matrix[3][4]);

    T x = x_D / base_D;
    T y = y_D / base_D;
    T z = z_D / base_D;

    solution[0] = x;
    solution[1] = y;
    solution[2] = z;
  }
  else
  {
    cout << "【无解】";
    solution[0] = 0;
    solution[1] = 0;
    solution[2] = 0;
  }
}

// Similar with PCL voxelgrid filter
void down_sampling_voxel(pcl::PointCloud<pcl::PointXYZI> &pl_feat,
                         double const voxel_size);

void rgb2grey(const cv::Mat &rgb_image, cv::Mat &grey_img);

void mapJet(double v, double vmin, double vmax,
            uint8_t &r, uint8_t &g, uint8_t &b);

typedef struct VoxelGrid
{
  float size = 0.5;
  int index;
  Eigen::Vector3d origin;
  pcl::PointCloud<pcl::PointXYZI> cloud;
} VoxelGrid;

typedef struct Voxel
{
  float size;
  Eigen::Vector3d voxel_origin;
  Eigen::Vector3d voxel_color;
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud;

  Voxel(float _size) : size(_size)
  {
    voxel_origin << 0, 0, 0;
    cloud = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>);
  };
} Voxel;

#endif