#include <vector>
#include <algorithm>
#include <string>
#include <ros/ros.h>
#include <angles/angles.h>
#include <atomic>
#include <memory>
#include <boost/thread.hpp>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <sensor_msgs/LaserScan.h>
#include "base_class/IDetector.h"

enum ModeType
    {
        ModeA,
        ModeB
    };


class DetectorA : public base_class::IDetector<sensor_msgs::LaserScan, Eigen::Vector3d>
{
public:

    // virtual bool setParams() = 0;
    DetectorA(ModeType mode_type)
    : mode_type_(mode_type),
    node_name_str_(ros::this_node::getName())
    {
        initParams();
        initTopicService();
    }

    virtual bool detect(const boost::shared_ptr<const sensor_msgs::LaserScan> &msg,
                        Eigen::Vector3d &result) override
                        {
                            std::cout << __FUNCTION__ << std::endl;
                        }

private:
    virtual void initParams() override
    {
        std::cout << __FUNCTION__ << std::endl;
    }

    virtual void initTopicService() override
    {
        std::cout << __FUNCTION__ << std::endl;
    }

    ModeType mode_type_;
    std::string node_name_str_;
};

class Module
{
public:
    Module(std::string base_frame, std::string laser_frame) 
        // : got_lidar_tf_(false)
    {
        recognizer_ = std::make_shared<DetectorA>(ModeType::ModeA);
    }

    void work(){
        ros::NodeHandle nh;//("~");
        scan_sub_ = nh.subscribe<sensor_msgs::LaserScan>("/scan", 1, boost::bind(&Module::scanCB,this, _1));
    }

    void scanCB(const sensor_msgs::LaserScan::ConstPtr& scan)
    {
        // if (!got_lidar_tf_) {
        //     try {
        //         tf_listener_.waitForTransform(base_frame_, laser_frame_, ros::Time(0), ros::Duration(0.5));
        //         tf_listener_.lookupTransform(base_frame_, laser_frame_, ros::Time(0), lidar_tf_);
        //         got_lidar_tf_ = true;
        //     }
        //     catch (tf::TransformException e) {
        //         ROS_ERROR("[%s][%s][%d]: %s", node_name_str_.c_str(), __func__, __LINE__, e.what());
        //         return;
        //     }
        // }

        Eigen::Vector3d feature_pose_raw;
        // boost::shared_ptr<sensor_msgs::LaserScan> scan_msg;
        // ScanPreprocess::scanNormalize(scan, scan_msg, 120, 240);
        find_charging_pile_ = recognizer_->detect(scan, feature_pose_raw);
        // scan_pub.publish(scan_msg);
    }

private:
    std::shared_ptr<DetectorA> recognizer_;
    ros::Subscriber scan_sub_;
    ros::Publisher result_pub_;
    std::string node_name_str_;
    bool find_charging_pile_;
    // bool got_lidar_tf_;
    // tf::StampedTransform lidar_tf_;
    // tf::TransformListener tf_listener_;
    
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "triangle_detector_node");
  ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Info);

  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");
  std::string lidar_type;
  private_nh.setParam("test_mode", 5);
  private_nh.param("lidar_type",lidar_type,std::string("ld06"));
  Module module("base_footprint", "laser_link");
  module.work();

  ros::spin();
  return 0;
}
