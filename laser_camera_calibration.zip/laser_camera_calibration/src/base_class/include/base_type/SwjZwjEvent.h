/*
 * @Author: gilbert gilbert.lai@uditech.com.cn
 * @Date: 2023-05-18
 * @LastEditors: gilbert gilbert.lai@uditech.com.cn
 * @LastEditTime: 2023-05-18
 * @FilePath:
 * @Description: 为 topic /SWJ/ApkSendWork    /SWJ/ApkReceiveResult  中的event 定义好类型，方便开发
 */
#ifndef _SWJEVENT_H_
#define _SWJEVENT_H_
/*****
** SwjZwjEvent 小于 0 为中位机内部使用，大于等于 0 为与 apk交互使用 ， 如需增加，请不要改变已有的枚举顺序及值
******/
enum class SwjZwjEvent {
  ErrorCode_186 = -186,                                //工勘上线: 深度相机跌落检测，可多次上报
  ErrorCode_150 = -150,                                //工勘上线: 顶置相机跌落检测，可多次上报
  ErrorCode_142 = -142,                                //工勘上线: 侧雷达跌落检测，可多次上报
  RemoteErrorRecovery = -5,                            //远程运维系统，自恢复成功后通知远程运维系统恢复
  RemoteControlOrderInfo = -4,                         //远程运维系统，中位机运维节点通知其他节点目前的运维状态
  ErrorRecoveryInfo = -3,                              //远程运维系统，中位机传输错误处理信息
  OpenDepthCameraPhotograph = -2,                      //远程运维系统，中位机控制深度相机拍照
  RemoteControlRotate = -1,                            //远程运维系统拍照时，中位机就发送机器人旋转
  ApkRotateControl = 0,                                //上位机控制机器人旋转
  ApkRemoteCalibrationDepthCamera = 1,                 //深度相机远程标定
  ApkUpdateDepthCameraCalibrationFile = 2,             //更新深度相机标定文件
  APKOpenAcceSpeedFunction = 3,                        //产测APK发送加速指令：深度深度相机跌落测试
  ApkBarcodeScanningGunMultiChargingPile = 4,          // 扫描枪多桩方案
  ApkTopCamera = 5,                                    //顶置相机机器人开机方案及存图
  ApkJustAccessElevator = 6,                           //顶置相机识别进出梯
  APKReplyCurrentFloor = 7,                            //中位机向上位机查询当前楼层
  ApkRobotRotateInfo = 8,                              //中位机向apk发送机器人旋转信息，apk控制灯带
  ApkInspectionOfContentsInHold = 9,                   //舱内物品检测
  ApkOpenTopCamera = 10,                               //打开二维码定位
  ApkSetRobotSpeed = 11,                                //设置机器人行驶速度
  ApkDealTRK02 = 12,                                    //5.10 电子系统 TRK02 恢复
  ApkSlopState = 13,                                    //上下坡状态: 内容值含义 //0无状态； 1 即将上坡； 2上坡中; 3即将下坡； 4下坡中;
  ApkRobotSpeak = 14,                                  //上报APK，语音播报, 1:机器人倾斜检测，语音播报,提示人不要动机器人；2:机器人快到达Goal,提示行人注意机器人压脚;3:机器人行驶途中，提示行人注意机器人通过；
  APKRobotInLift = 16,                                  //上报APK, 机器人是否在电梯内 0表示机器人不在梯内， 1表示在电梯内
  ImuCheckLiftRunHigh = 17,                              //上报APK电梯单程运行高度, dis表示上行的高度，-dis表示下行的高度
  ApkEnableZigBeeLora = 18,                                 //接收apk信息，1表示开启zigbee与梯控数据处理;  表示关闭(到达充电桩后); 
  APKZigBeeTransfromLora = 19,                               //接收apk信息, 传输梯控的Lora数据
  ApkRobotDetectState = 50,                             // Apk下发房门检测指令　0表示不启动检测，1表示启动检测
  ApkHotelDoorState = 51                                // 上报Apk, 房门的状态　0表示状态"关闭"，１表示状态"开启"，２表示状态"前方存在障碍物"
}; 

#endif
