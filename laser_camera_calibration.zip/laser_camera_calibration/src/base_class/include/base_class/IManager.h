/**
 * @file IManager.h
 * @author joyce.lou (joyce.lou@uditech.com.cn)
 * @brief 定义了业务类的基类，用于规范接口
 * @version 0.1
 * @date 2022-07-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

namespace base_class
{

class IManager
{
public:
  virtual bool work() = 0;

private:
  virtual bool initParams() = 0;
  virtual bool initTopicService() = 0;

  virtual bool workFlow() = 0;
  virtual bool toggleWorkFlow(bool enabled) = 0;

};
}
