/**
 * @file IDetector.h
 * @author joyce.lou (joyce.lou@uditech.com.cn)
 * @brief 定义了检测类的基类，用于规范接口
 * @version 0.1
 * @date 2022-05-19
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief 定义了一些基类，用于规范接口
 * 
 */
namespace base_class
{
/**
 * @brief 检测功能模块的纯虚基类，约定主要接口，不提供任何实现，具体的实现由派生类定义
 * 
 * @tparam INPUT_TYPE 输入类，建议采用ROS消息
 * @tparam OUTPUT_TYPE 输出类，根据实际需求定义，通常可用geometry_msgs::PoseStamped
 */
template <typename INPUT_TYPE, typename OUTPUT_TYPE>
class IDetector
{
public:
  /**
   * @brief 检测接口，参数与模板参数一致
   * 
   * @param msg 与INPUT_TYPE类型一致
   * @param result 与OUTPUT_TYPE类型一致
   * @return true 检测成功
   * @return false 检测失败
   */
  virtual bool detect(const boost::shared_ptr<const INPUT_TYPE> &msg,
                      OUTPUT_TYPE& result) = 0;
private:
  /**
   * @brief 初始化参数
   * 
   */
  virtual void initParams() = 0;

  /**
   * @brief 初始化话题和服务
   * 
   */
  virtual void initTopicService() = 0;

};
}