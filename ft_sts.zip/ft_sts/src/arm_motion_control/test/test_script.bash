#!/bin/bash
checkDir() {
  local DIR="$1"  # 从函数参数获取目录路径

  # 检查目录是否存在
  if [ ! -d "$DIR" ]; then
    # 目录不存在，则新建
    mkdir "$DIR"
    echo "$DIR 目录已创建。"
  else
    # 目录已经存在，跳过
    echo "$DIR 目录已存在，跳过创建。"
  fi
}

# 目录路径
DIR="build"

# # Broadcast
# cd ./Broadcast
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # CalibrationOfs
# cd ./CalibrationOfs
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # FeedBack
# cd ./FeedBack
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # Ping
# cd ./Ping
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # ProgramEprom
# cd ./ProgramEprom
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # RegWritePos
# cd ./RegWritePos
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # SyncRead
# cd ./SyncRead
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # SyncWritePos
# cd ./SyncWritePos
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # WritePos
# cd ./WritePos
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# # WriteSpe
# cd ./WriteSpe
# checkDir $DIR
# cd $DIR
# cmake ..
# make
# cd ../../

# double_motor_test
cd ./double_motor_test
checkDir $DIR
cd $DIR
cmake ..
make
cd ../../



