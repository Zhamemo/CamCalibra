/*
舵机出厂速度单位是0.0146rpm，速度改为V=2400
*/

#include <iostream>
#include <string>
#include "SCServo.h"

void feedBackResult(u8 *ID, const int IDN, SMS_STS &sm_st)
{
	int Pos = 0, Speed = 0, Load = 0, Voltage = 0;
	int Temper = 0, Move = 0, Current = 0;
	for (int i = 0; i < IDN; ++i)
	{
		const int id = static_cast<int>(ID[i]);
		// 一条指令读舵机所有反馈数据
		if (sm_st.FeedBack(ID[i]) != -1)
		{
			Pos = sm_st.ReadPos(ID[i]);
			Speed = sm_st.ReadSpeed(ID[i]);
			Load = sm_st.ReadLoad(ID[i]);
			Voltage = sm_st.ReadVoltage(ID[i]);
			Temper = sm_st.ReadTemper(ID[i]);
			Move = sm_st.ReadMove(ID[i]);
			Current = sm_st.ReadCurrent(ID[i]);
			std::cout << "pos[" << id << "]= " << Pos << " ";
			std::cout << "Speed[" << id << "] = " << Speed << " ";
			std::cout << "Load[" << id << "] = " << Load << " ";
			std::cout << "Voltage[" << id << "] = " << Voltage << " ";
			std::cout << "Temper[" << id << "] = " << Temper << " ";
			std::cout << "Move[" << id << "] = " << Move << " ";
			std::cout << "Current[" << id << "] = " << Current << std::endl;
			sleep(1);
		}
		else
		{
			std::cout << "read err" << std::endl;
			sleep(1);
		}
	}
}

void sync_read(u8 *ID, const int IND, SMS_STS &sm_st, u8 *rxPacket, const int num_rxpacket)
{
	sm_st.syncReadPacketTx(ID, IND, SMS_STS_PRESENT_POSITION_L, num_rxpacket); // 同步读指令包发送
	for (int i = 0; i < IND; i++)
	{
		const int id = static_cast<int>(ID[i]);
		// 接收ID[i]同步读返回包
		if (!sm_st.syncReadPacketRx(ID[i], rxPacket))
		{
			std::cout << "ID[" << id << "] sync read error!" << std::endl;
			continue; // 接收解码失败
		}

		int pos = sm_st.syncReadRxPacketToWrod(15); // 解码两个字节 bit15为方向位,参数=0表示无方向位
		int speed = sm_st.syncReadRxPacketToWrod(15);	 // 解码两个字节 bit15为方向位,参数=0表示无方向位
		std::cout << "pos[" << id << "]-> " << pos << " " << "speed[" << id << "]-> " << speed << std::endl;
	}
	sleep(1);
}

int main(int argc, char **argv)
{
	const int baud_rate = 1000000;
	std::string dev = "/dev/ttyUSB0";
	std::cout << "baud_rate-> " << baud_rate << ", " << "dev-> " << dev.c_str() << std::endl;

	SMS_STS sm_st;
	if (!sm_st.begin(baud_rate, dev.c_str()))
	{
		std::cout << "Failed to init sms/sts motor!" << std::endl;
		return 1;
	}

	u8 ID[1] = {1};
	const int num = sizeof(ID);

	s16 Position[1];
	u16 Speed[1] = {2400};
	u8 ACC[1] = {50};
	u8 rxPacket[4];
	const int num_rxpacket = sizeof(rxPacket);
	sm_st.syncReadBegin(num, num_rxpacket);

	while (1)
	{
		Position[0] = 2500;
		// Position[1] = 1594;
		// sm_st.WritePosEx(ID[0], Position[0], 2400, 50);
		// sm_st.WritePosEx(ID[1], Position[1], 2400, 50);
		sm_st.SyncWritePosEx(ID, num, Position, Speed, ACC);
		feedBackResult(ID, num, sm_st);
		sync_read(ID, num, sm_st, rxPacket, num_rxpacket);
		usleep(2187 * 1000); //[(P1-P0)/V]*1000+[V/(A*100)]*1000

		Position[0] = 1594;
		// Position[1] = 2500;
		// sm_st.WritePosEx(ID[0], Position[0], 2400, 50);
		// sm_st.WritePosEx(ID[1], Position[1], 2400, 50);
		sm_st.SyncWritePosEx(ID, num, Position, Speed, ACC);
		feedBackResult(ID, num, sm_st);
		sync_read(ID, num, sm_st, rxPacket, num_rxpacket);
		usleep(2187 * 1000); //[(P1-P0)/V]*1000+[V/(A*100)]*1000
	}
	sm_st.end();

	return 0;
}
