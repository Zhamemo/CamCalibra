#ifndef ARM_MOTION_CONTROL_H_
#define ARM_MOTION_CONTROL_H_

#include <string>
#include <ros/ros.h>
#include <SCServo.h>
#include <boost/thread.hpp>
#include <boost/shared_ptr.hpp>
#include <arm_pose_estimation.hpp>
#include <arm_motion_control/motor_poseConfig.h>

namespace arm_motion_control
{
    // 舵机信息
    /**
     *   motor:
     *     - id: 舵机id
     *       position:
     *           min: 最小转动值
     *           max: 最大转动值
     *           reset: 初始化值
     *       speed: 转速
     *       accelerate: 角加速度
     */
    struct MotorInfo
    {
        int id;
        struct
        {
            int min;
            int max;
            int reset;
        } position;
        int speed;
        int accelerate;
    };

    class ArmMotionControl
    {
    public:
        ArmMotionControl();
        ~ArmMotionControl() = default;

        ArmMotionControl(const ArmMotionControl &) = delete;
        ArmMotionControl &operator=(const ArmMotionControl &) = delete;

    private:
        /**
         * ************************************************************************
         * @brief: 参数服务器加载参数值
         *
         *
         * ************************************************************************
         */
        void initialParam();

        /**
         * ************************************************************************
         * @brief: ros话题订阅与发布
         *
         *
         * ************************************************************************
         */
        void initialTopic();

        /**
         * ************************************************************************
         * @brief: 初始化舵机位置
         *
         *
         * ************************************************************************
         */
        void initialMotorState();

    private:
        /**
         * ************************************************************************
         * @brief: 舵机串口连接诊断
         *
         * @param[in]: baud_rate 串口波特率
         * @param[in]: dev 舵机连接设备
         * @param[in]: sm_st 串口驱动类
         *
         * @return true 舵机串口正常打开
         * @return false
         * ************************************************************************
         */
        bool diagnosticDevice(const int baud_rate, const std::string &dev, const boost::shared_ptr<SMS_STS> &sm_st);

        /**
         * ************************************************************************
         * @brief: 读取舵机反馈位置
         *
         * @param[in]: motor_id 连接的舵机
         * @param[in]: sm_st 串口驱动类
         *
         * @return std::vector<int> 当前各舵机的位置信息
         * ************************************************************************
         */
        std::vector<int> readMotorState(const u8 *motor_id, const boost::shared_ptr<SMS_STS> &sm_st);

        /**
         * ************************************************************************
         * @brief: 读取舵机反馈位置
         *
         * @param[in]: motor_id 连接的舵机
         * @param[in]: rxpacket
         * @param[in]: sm_st 串口驱动类
         *
         * @return std::vector<int> 当前各舵机的位置信息
         * ************************************************************************
         */
        std::vector<int> readMotorState(u8 *motor_id, u8 *rxpacket, const boost::shared_ptr<SMS_STS> &sm_st);

        void reconfigureCB(const arm_motion_control::motor_poseConfig &config);

    private:
        std::vector<float> calculateInverseKinematics(const std::vector<ArmJoint> &vec_joint,
                                                      const Eigen::Vector3f &target, const int num_joint);

        /**
         * ************************************************************************
         * @brief: 根据逆向运动学计算的各关节位置控制
         *
         * @param[in]: motor_id 连接的舵机
         * @param[in]: motor_pos 目标位置
         * @param[in]: motor_speed 转动速度
         * @param[in]: motor_acc 转动角加速度
         * @param[in]: rxpacket
         * @param[in]: sm_st 串口驱动类
         *
         * ************************************************************************
         */
        void setMotorPosition(u8 *motor_id, s16 *motor_pos, u16 *motor_speed,
                              u8 *motor_acc, u8 *rxpacket, const boost::shared_ptr<SMS_STS> &sm_st);

    public:
        inline int convertAngle(const float input)
        {
            return static_cast<int>(input * 4096 / (2 * M_PI));
        }

        inline float convertAngle(const int input)
        {
            return static_cast<float>(input * 2 * M_PI / 4096.0);
        }

        inline bool isInValidRang(const MotorInfo &motor, const int pose)
        {
            return pose >= motor.position.min && pose <= motor.position.max;
        }

    public:
        void run();

    private:
        ros::NodeHandle nh_;        // ros节点句柄
        std::string node_name_str_; // 节点名称

        int baud_rate_{0};                     // 串口波特率
        int num_use_motor_{0};                 // 使用舵机数量
        std::string motor_device_;             // USB连接设备
        boost::shared_ptr<SMS_STS> sm_st_ptr_; // 串口驱动类

        std::vector<MotorInfo> vec_motor_; // 安装的舵机
        std::vector<ArmJoint> vec_joint_;  // 舵机连杆
        boost::shared_ptr<arm_motion_control::ArmPoseEstimation> arm_pose_ptr_;

        boost::mutex config_mutex_;
        bool got_pose_{false};

        int motor_pose_1_{1100};
        int motor_pose_3_{3500};
        int motor_pose_4_{2048};
    };
} // arm_motion_control

#endif // ARM_MOTION_CONTROL_H_