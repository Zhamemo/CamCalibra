#include "arm_motion_control/arm_motion_control.hpp"
#include <dynamic_reconfigure/server.h>

namespace arm_motion_control
{
    using confServer = dynamic_reconfigure::Server<arm_motion_control::motor_poseConfig>;

    ArmMotionControl::ArmMotionControl() : nh_("~")
    {
        initialParam();
        initialMotorState();
        initialTopic();
    }

    void ArmMotionControl::initialParam()
    {
        ros::NodeHandle private_nh = ros::NodeHandle("~");
        node_name_str_ = ros::this_node::getName();

        // 串口波特率
        if (!ros::param::get("~baud_rate", baud_rate_))
        {
            ROS_WARN("[%s][%s][%d] Failed to get motor baud_rate!", node_name_str_.c_str(), __func__, __LINE__);
            baud_rate_ = 1000000;
        }

        // 使用舵机数量
        if (!ros::param::get("~num_use_motor", num_use_motor_))
        {
            ROS_WARN("[%s][%s][%d] Failed to get motor number!", node_name_str_.c_str(), __func__, __LINE__);
            num_use_motor_ = 1;
        }

        // ls /dev | grep ttyUSB* 查看舵机
        if (!ros::param::get("~motor_device", motor_device_))
        {
            ROS_WARN("[%s][%s][%d] Failed to get motor_device!", node_name_str_.c_str(), __func__, __LINE__);
            motor_device_ = "/dev/ttyUSB0";
        }

        private_nh.param("motor_pose_1", motor_pose_1_, 1100);
        private_nh.param("motor_pose_3", motor_pose_3_, 3500);
        private_nh.param("motor_pose_4", motor_pose_4_, 2048);

        vec_motor_.reserve(num_use_motor_);
        vec_joint_.reserve(num_use_motor_);
        sm_st_ptr_.reset(new SMS_STS());
        arm_pose_ptr_.reset(new arm_motion_control::ArmPoseEstimation());
    }

    void ArmMotionControl::initialTopic()
    {
    }

    void ArmMotionControl::initialMotorState()
    {
        XmlRpc::XmlRpcValue motor_config;
        if (!ros::param::get("motor", motor_config))
        {
            ROS_ERROR("[%s][%s][%d] Failed to get motor motor_config!", node_name_str_.c_str(), __func__, __LINE__);
            return;
        }

        MotorInfo motor;
        for (int i = 0, iend = motor_config.size(); i < iend; ++i)
        {
            const auto &val = motor_config[i];
            motor.id = static_cast<int>(val["id"]);
            motor.position.min = static_cast<int>(val["position"]["min"]);
            motor.position.max = static_cast<int>(val["position"]["max"]);
            motor.position.reset = static_cast<int>(val["position"]["reset"]);
            motor.speed = static_cast<int>(val["speed"]);
            motor.accelerate = static_cast<int>(val["accelerate"]);
            vec_motor_.emplace_back(motor);
        }

        XmlRpc::XmlRpcValue link_config;
        if (!ros::param::get("link", link_config))
        {
            ROS_ERROR("[%s][%s][%d] Failed to get motor link_config!", node_name_str_.c_str(), __func__, __LINE__);
            return;
        }

        for (int i = 0, iend = link_config.size(); i < iend; ++i)
        {
            const auto &val = link_config[i];
            float length = static_cast<double>(val["length"]);
        }
    }

    bool ArmMotionControl::diagnosticDevice(const int baud_rate, const std::string &dev,
                                            const boost::shared_ptr<SMS_STS> &sm_st)
    {
        if (!sm_st->begin(baud_rate, dev.c_str()))
        {
            ROS_ERROR("[%s][%s][%d] Failed to init sms/sts motor!", node_name_str_.c_str(), __func__, __LINE__);
            return false;
        }
        return true;
    }

    std::vector<int> ArmMotionControl::readMotorState(const u8 *motor_id, const boost::shared_ptr<SMS_STS> &sm_st)
    {
        int pose = 0, speed = 0, load = 0, voltage = 0;
        int temper = 0, move = 0, current = 0;
        const int num_motor_id = num_use_motor_;

        std::vector<int> position;
        position.reserve(num_motor_id);

        for (int i = 0; i < num_motor_id; ++i)
        {
            const int id = static_cast<int>(motor_id[i]);
            // 读取舵机所有反馈数据
            if (sm_st->FeedBack(motor_id[i]) != -1)
            {
                pose = sm_st->ReadPos(motor_id[i]);
                speed = sm_st->ReadSpeed(motor_id[i]);
                load = sm_st->ReadLoad(motor_id[i]);
                voltage = sm_st->ReadVoltage(motor_id[i]);
                temper = sm_st->ReadTemper(motor_id[i]);
                move = sm_st->ReadMove(motor_id[i]);
                current = sm_st->ReadCurrent(motor_id[i]);
                position.emplace_back(pose);

                ROS_INFO("[%s][%s][%d] (pose, speed, load, voltage, temper, move, current)[%d]->(%d, %d, %d, %d, %d, %d, %d)",
                         node_name_str_.c_str(), __func__, __LINE__, id, pose, speed, load, voltage, temper, move, current);
                usleep(10 * 1000);
            }
            else
            {
                ROS_ERROR("[%s][%s][%d] Failed to read the state of motor!", node_name_str_.c_str(), __func__, __LINE__);
                position.clear();
                return position; // 只要发生读取舵机反馈数据失败就直接返回
            }
        }
        return position;
    }

    std::vector<int> ArmMotionControl::readMotorState(u8 *motor_id, u8 *rxpacket, const boost::shared_ptr<SMS_STS> &sm_st)
    {
        const int num_motor_id = num_use_motor_, num_rxpacket = 4 * num_use_motor_;
        std::vector<int> position;
        position.reserve(num_motor_id);
        sm_st->syncReadPacketTx(motor_id, num_motor_id, SMS_STS_PRESENT_POSITION_L, num_rxpacket); // 同步读指令包发送

        for (int i = 0; i < num_motor_id; i++)
        {
            const int id = static_cast<int>(motor_id[i]);
            // 接收ID[i]同步读返回包
            if (!sm_st->syncReadPacketRx(motor_id[i], rxpacket))
            {
                ROS_ERROR("[%s][%s][%d] Failed to sync read the state of motor!", node_name_str_.c_str(), __func__, __LINE__);
                position.clear();
                return position; // 只要发生舵机解码失败就直接返回
            }

            int pose = sm_st->syncReadRxPacketToWrod(15);  // 解码两个字节 bit15为方向位,参数=0表示无方向位
            int speed = sm_st->syncReadRxPacketToWrod(15); // 解码两个字节 bit15为方向位,参数=0表示无方向位
            position.emplace_back(pose);

            ROS_INFO("[%s][%s][%d] (pose, speed)[%d]->(%d, %d)",
                     node_name_str_.c_str(), __func__, __LINE__, id, pose, speed);
            usleep(10 * 1000);
        }
        return position;
    }

    void ArmMotionControl::reconfigureCB(const arm_motion_control::motor_poseConfig &config)
    {
        // boost::lock_guard<boost::mutex> lock(config_mutex_);
        motor_pose_1_ = config.motor_pose_1;
        motor_pose_3_ = config.motor_pose_3;
        motor_pose_4_ = config.motor_pose_4;

        // ROS_INFO("[%s][%s][%d] (motor_pose_1, motor_pose_3, motor_pose_4)->(%d, %d, %d)",
        //          node_name_str_.c_str(), __func__, __LINE__, motor_pose_1_, motor_pose_3_, motor_pose_4_);

        got_pose_ = true;
    }

    std::vector<float> ArmMotionControl::calculateInverseKinematics(const std::vector<ArmJoint> &vec_joint,
                                                                    const Eigen::Vector3f &target, const int num_joint)
    {
        std::vector<float> joint_angle;
        joint_angle.reserve(num_joint);

        if (arm_pose_ptr_->run(vec_joint, target))
        {
            joint_angle = arm_pose_ptr_->getTargetAngle();
        }
        return joint_angle;
    }

    void ArmMotionControl::setMotorPosition(u8 *motor_id, s16 *motor_pos, u16 *motor_speed,
                                            u8 *motor_acc, u8 *rxpacket, const boost::shared_ptr<SMS_STS> &sm_st)
    {
        sm_st->SyncWritePosEx(motor_id, num_use_motor_, motor_pos, motor_speed, motor_acc);
        usleep(10 * 1000);
        std::vector<int> feed_back_pose = readMotorState(motor_id, sm_st);
        std::vector<int> read_pose = readMotorState(motor_id, rxpacket, sm_st);
        usleep(2187 * 1000); //[(P1-P0)/V]*1000+[V/(A*100)]*1000
    }

    void ArmMotionControl::run()
    {
        u8 motor_id[num_use_motor_];     // 舵机ID
        s16 motor_pos[num_use_motor_];   // 舵机位置
        u16 motor_speed[num_use_motor_]; // 舵机转速
        u8 motor_acc[num_use_motor_];    // 舵机角加速度
        u8 rxpacket[num_use_motor_];

        if (diagnosticDevice(baud_rate_, motor_device_, sm_st_ptr_))
        {
            for (int i = 0; i < num_use_motor_; ++i)
            {
                const auto &motor = vec_motor_[i];
                motor_id[i] = static_cast<unsigned char>(motor.id);
                motor_pos[i] = static_cast<short>(motor.position.reset);
                motor_speed[i] = static_cast<short>(motor.speed);
                motor_acc[i] = static_cast<unsigned char>(motor.accelerate);
                rxpacket[i] = static_cast<unsigned char>(0);
            }
        }
        else
            return;

        sm_st_ptr_->syncReadBegin(num_use_motor_, 4 * num_use_motor_);
        setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
        ros::Rate rate(2);

        confServer server;
        server.setCallback(boost::bind(&ArmMotionControl::reconfigureCB, this, _1));

        // std::vector<float> joint_length{238.71, 218.29, 125.43};

        // float theta = angles::from_degrees(192);
        // float sin = joint_length[0] * std::sin(theta);
        // float cos = joint_length[0] * std::cos(theta);

        // ArmJoint joint_0({0, 0, 0}, {0, 1, 0}, 0.0);
        // ArmJoint joint_1({sin, 0, cos}, {0, 1, 0}, 0.0);
        // ArmJoint joint_2({-joint_length[1], 0, 0}, {0, 0, 1}, 0.0);

        // theta = angles::from_degrees(333);
        // sin = joint_length[2] * std::sin(theta);
        // cos = joint_length[2] * std::cos(theta);
        // ArmJoint joint_3({cos, sin, 0}, {0, 0, 1}, 0.0);

        // std::vector<ArmJoint> vec_joint{joint_0, joint_1, joint_2, joint_3};
        // Eigen::Vector3f target_pose;
        // std::vector<float> angles;
        // angles.reserve(vec_joint.size());

        // float coord_x = 0.0f;
        // float coord_y = -joint_length[2];
        // float coord_z = -190.0f;

        while (ros::ok)
        {
            // 顺时针
            // motor_pos[0] = 1100;
            // motor_pos[1] = 3000;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // ROS_WARN("[%s][%s][%d] target_pose->(%f, %f)",
            //          node_name_str_.c_str(), __func__, __LINE__, target_pose[0], target_pose[1], target_pose[2]);
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1337;
            // motor_pos[1] = 2763;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1574;
            // motor_pos[1] = 2526;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1811;
            // motor_pos[1] = 2289;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2048;
            // motor_pos[1] = 2052;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2285;
            // motor_pos[1] = 1815;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2522;
            // motor_pos[1] = 1578;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2759;
            // motor_pos[1] = 1341;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 3000;
            // motor_pos[1] = 1100;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // 逆时针
            // motor_pos[0] = 3000;
            // motor_pos[1] = 1100;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2759;
            // motor_pos[1] = 1341;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2522;
            // motor_pos[1] = 1578;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2285;
            // motor_pos[1] = 1815;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 2048;
            // motor_pos[1] = 2052;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1811;
            // motor_pos[1] = 2289;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1574;
            // motor_pos[1] = 2526;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1337;
            // motor_pos[1] = 2763;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // motor_pos[0] = 1100;
            // motor_pos[1] = 3000;
            // motor_pos[2] = 3500;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            // sleep(2);

            // if (coord_x > 300)
            //     coord_x = 0.0f;

            // if (coord_y > sin)
            //     coord_y = -joint_length[2];

            // if (coord_z > 160.0)
            //     coord_z = -190.0f;

            // target_pose = Eigen::Vector3f{-(joint_length[0] + joint_length[1] - sin) + coord_x, -cos, coord_z};
            // coord_x += 20;
            // // coord_y += 20;
            // coord_z += 20;

            // angles.clear();
            // angles = calculateInverseKinematics(vec_joint, target_pose, num_use_motor_);

            // if (!angles.empty())
            // {
            //     motor_pos[0] += convertAngle(angles[0]);
            //     motor_pos[1] -= convertAngle(angles[0]);
            //     motor_pos[2] += convertAngle(angles[1]);
            //     motor_pos[3] += convertAngle(angles[2]);

            //     if (isInValidRang(vec_motor_[0], static_cast<int>(motor_pos[0])) &&
            //         isInValidRang(vec_motor_[1], static_cast<int>(motor_pos[1])) &&
            //         isInValidRang(vec_motor_[2], static_cast<int>(motor_pos[2])) &&
            //         isInValidRang(vec_motor_[3], static_cast<int>(motor_pos[3])))
            //     {
            //         ROS_WARN("[%s][%s][%d] target_pose->(%f, %f, %f)",
            //                  node_name_str_.c_str(), __func__, __LINE__, target_pose[0], target_pose[1], target_pose[2]);
            //         setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            //     }
            //     else
            //     {
            //         ROS_ERROR("[%s][%s][%d] Beyond the setting range! motor_pos-> (%d, %d, %d, %d)",
            //                   node_name_str_.c_str(), __func__, __LINE__, motor_pos[0], motor_pos[1], motor_pos[2], motor_pos[3]);
            //     }
            // }

            // sleep(1);
            // motor_pos[0] = 1100;
            // motor_pos[1] = 3000;
            // motor_pos[2] = 3000;
            // motor_pos[3] = 3200;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);

            // target_pose = Eigen::Vector3f{sin, 0, -cos};
            // angles.clear();
            // angles = calculateInverseKinematics(vec_joint, target_pose, num_use_motor_);

            // if (!angles.empty())
            // {
            //     motor_pos[0] += convertAngle(angles[0]);
            //     motor_pos[1] -= convertAngle(angles[0]);
            //     motor_pos[2] = 3000;

            //     if (isInValidRang(vec_motor_[0], static_cast<int>(motor_pos[0])) &&
            //         isInValidRang(vec_motor_[1], static_cast<int>(motor_pos[1])))
            //     {
            //         ROS_WARN("[%s][%s][%d] target_pose->(%f, %f, %f)",
            //                  node_name_str_.c_str(), __func__, __LINE__, target_pose[0], target_pose[1], target_pose[2]);
            //         setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
            //     }
            //     else
            //     {
            //         ROS_ERROR("[%s][%s][%d] Beyond the setting range! motor_pos-> (%d, %d)",
            //                   node_name_str_.c_str(), __func__, __LINE__, motor_pos[0], motor_pos[1]);
            //     }
            // }

            // sleep(1);
            // motor_pos[0] = 1100;
            // motor_pos[1] = 3000;
            // motor_pos[2] = 3000;
            // setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);

            // boost::lock_guard<boost::mutex> lock(config_mutex_);
            if (got_pose_)
            {
                motor_pos[0] = motor_pose_1_;
                motor_pos[1] = 4094 - motor_pose_1_;
                motor_pos[2] = motor_pose_3_;
                motor_pos[3] = motor_pose_4_;

                ROS_WARN("[%s][%s][%d] (motor_pose_1, motor_pose_2, motor_pose_3, motor_pose_4)->(%d, %d, %d, %d)",
                         node_name_str_.c_str(), __func__, __LINE__, motor_pos[0], motor_pos[1], motor_pos[2], motor_pos[3]);

                if (isInValidRang(vec_motor_[0], motor_pos[0]) &&
                    isInValidRang(vec_motor_[1], motor_pos[1]) &&
                    isInValidRang(vec_motor_[2], motor_pos[2]) &&
                    isInValidRang(vec_motor_[3], motor_pos[3]))
                {
                    setMotorPosition(motor_id, motor_pos, motor_speed, motor_acc, rxpacket, sm_st_ptr_);
                }
                else
                {
                    ROS_ERROR("[%s][%s][%d] Beyond the setting range! motor_pos-> (%d, %d, %d, %d)",
                              node_name_str_.c_str(), __func__, __LINE__, motor_pos[0], motor_pos[1], motor_pos[2], motor_pos[3]);
                }

                got_pose_ = false;
            }

            rate.sleep();
            ros::spinOnce();
        }
    }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "arm_motion_control_node");
    ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Info);

    arm_motion_control::ArmMotionControl motor_motion;
    motor_motion.run();
    return 0;
}