#include "arm_pose_estimation.hpp"
#include <limits>
#include <fstream>

namespace arm_motion_control
{
    ArmPoseEstimation::ArmPoseEstimation() : nh_("~")
    {
        node_name_str_ = ros::this_node::getName();

        nh_.param("step_size", step_size_, 5.0f);
        nh_.param("descend_rate", descend_rate_, 100.0f);
        nh_.param("dis_thresh", dis_thresh_, 0.01f);
        nh_.param("max_iteration", max_iteration_, 100);

        vec_joint_.clear();
        vec_angle_.clear();
    }

    void ArmPoseEstimation::initialJointAngle(const std::vector<ArmJoint> &vec_joint)
    {
        const int num_joint = vec_joint.size();
        vec_angle_.resize(num_joint);

        for (int i = 0; i < num_joint; ++i)
        {
            vec_angle_[i] = vec_joint[i].start_angle;
        }
    }

    Eigen::Vector3f ArmPoseEstimation::forwardKinematics(const std::vector<float> &vec_angle)
    {
        Eigen::Vector3f pre_pose = vec_joint_[0].start_offset;
        Eigen::Quaternionf rot = Eigen::Quaternionf::Identity();

        for (int i = 1, iend = vec_joint_.size(); i < iend; ++i)
        {
            rot *= Eigen::Quaternionf(Eigen::AngleAxisf(vec_angle[i - 1], vec_joint_[i - 1].rot_axis));
            Eigen::Vector3f next_pose = pre_pose + rot * vec_joint_[i].start_offset;
            pre_pose = next_pose;
        }

        return pre_pose;
    }

    float ArmPoseEstimation::distanceFromTarget(const Eigen::Vector3f &target, const std::vector<float> &vec_angle)
    {
        Eigen::Vector3f arm_pose = forwardKinematics(vec_angle);
        // ROS_INFO("[%s][%s][%d] delta->(%f, %f, %f)",
        //          node_name_str_.c_str(), __func__, __LINE__, (arm_pose - target)[0], (arm_pose - target)[1], (arm_pose - target)[2]);
        return (arm_pose - target).norm();
    }

    float ArmPoseEstimation::partialGradient(const Eigen::Vector3f &target, std::vector<float> &vec_angle, const int index)
    {
        const float angle = vec_angle[index];
        float f_x = distanceFromTarget(target, vec_angle);

        const float step = angles::from_degrees(step_size_);
        vec_angle[index] += step;
        float f_x_plus = distanceFromTarget(target, vec_angle);

        // FIXME 梯度计算目前通过遍历搜索
        // float arc_length = 2 * vec_joint_[index + 1].start_offset.norm() * std::sin(step);
        // float gradient = (f_x_plus - f_x) / arc_length;
        float gradient = (f_x_plus - f_x) > 0 ? step : (-step);
        // float gradient = (f_x_plus - f_x) / step;

        vec_angle[index] = angle;

        return gradient;
    }

    bool ArmPoseEstimation::inverseKinematics(const Eigen::Vector3f &target, std::vector<float> &vec_angle,
                                              const float dis_thresh, const int max_iteration)
    {
        std::string out_path = "/home/ubuntu/Documents/Repository/motor_pose/error.txt";
        std::ofstream out_file(out_path, std::ios::app);

        float last_distance = std::numeric_limits<float>::max();
        for (int i = 0; i < max_iteration; ++i)
        {
            float distance = distanceFromTarget(target, vec_angle);
            // ROS_INFO("[%s][%s][%d] dis-> %f", node_name_str_.c_str(), __func__, __LINE__, distance);

            if (distance <= dis_thresh)
            {
                out_file << distance << std::endl;
                ROS_INFO("[%s][%s][%d] The distance to target should be less than %f, and %f now! iteration-> %d.",
                         node_name_str_.c_str(), __func__, __LINE__, dis_thresh, distance, i - 1);
                return true;
            }

            if (distance > last_distance)
            {
                ROS_ERROR("[%s][%s][%d] (iteration, last_distance, distance)->(%d, %f, %f)",
                          node_name_str_.c_str(), __func__, __LINE__, i - 1, last_distance, distance);
                return false;
            }

            for (int i = vec_joint_.size() - 1; i >= 0; --i)
            {
                float gradient = partialGradient(target, vec_angle, i);
                vec_angle[i] -= descend_rate_ * gradient;
            }
            last_distance = distance;
        }
        out_file.close();
        return false;
    }

    bool ArmPoseEstimation::run(const std::vector<ArmJoint> &vec_joint, const Eigen::Vector3f &target)
    {
        if (vec_joint.empty())
        {
            ROS_ERROR("[%s][%s][%d] Failed to load arm joint!", node_name_str_.c_str(), __func__, __LINE__);
            return false;
        }

        initialJointAngle(vec_joint);
        vec_joint_ = vec_joint;

        if (!inverseKinematics(target, vec_angle_, dis_thresh_, max_iteration_))
        {
            ROS_ERROR("[%s][%s][%d] Failed to converge!", node_name_str_.c_str(), __func__, __LINE__);
            return false;
        }

        return true;
    }

    std::vector<float> ArmPoseEstimation::getTargetAngle() const
    {
        return vec_angle_;
    }

} // namespace arm_motion_control