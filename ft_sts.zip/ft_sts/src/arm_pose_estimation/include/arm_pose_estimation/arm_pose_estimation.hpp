#ifndef ARM_POSE_ESTIMATION_H_
#define ARM_POSE_ESTIMATION_H_

#include <ros/ros.h>
#include <vector>
#include <Eigen/Dense>
#include <angles/angles.h>

namespace arm_motion_control
{
    class ArmJoint
    {
    public:
        explicit ArmJoint(const Eigen::Vector3f &offset, const Eigen::Vector3f &axis,
                          const float angle) : start_offset(offset), rot_axis(axis), start_angle(angle) {}

        ArmJoint(const ArmJoint &other)
        {
            this->start_offset = other.start_offset;
            this->rot_axis = other.rot_axis;
            this->start_angle = other.start_angle;
        }

        ArmJoint &operator=(const ArmJoint &other)
        {
            this->start_offset = other.start_offset;
            this->rot_axis = other.rot_axis;
            this->start_angle = other.start_angle;
        }

    public:
        Eigen::Vector3f start_offset; // 关节起始偏移量
        Eigen::Vector3f rot_axis;     // 关节旋转轴
        float start_angle;            // 关节起始转角
    };

    class ArmPoseEstimation
    {
    public:
        ArmPoseEstimation();
        ~ArmPoseEstimation() = default;

        ArmPoseEstimation(const ArmPoseEstimation &) = delete;
        ArmPoseEstimation &operator=(const ArmPoseEstimation &) = delete;

    private:
        void initialJointAngle(const std::vector<ArmJoint> &vec_joint);
        Eigen::Vector3f forwardKinematics(const std::vector<float> &vec_angle);
        float distanceFromTarget(const Eigen::Vector3f &target, const std::vector<float> &vec_angle);
        float partialGradient(const Eigen::Vector3f &target, std::vector<float> &vec_angle, const int index);
        bool inverseKinematics(const Eigen::Vector3f &target, std::vector<float> &vec_angle,
                               const float dis_thresh, const int max_iteration);

    public:
        bool run(const std::vector<ArmJoint> &vec_joint, const Eigen::Vector3f &target);
        std::vector<float> getTargetAngle() const;

    private:
        ros::NodeHandle nh_;        // ros节点句柄
        std::string node_name_str_; // 节点名称

        float step_size_{0.0f};    // 采样步长
        float descend_rate_{0.0f}; // 梯度下降系数
        float dis_thresh_{0.01f};  // 距离阈值
        int max_iteration_{100};   // 最大迭代次数

        std::vector<ArmJoint> vec_joint_; // 各关节
        std::vector<float> vec_angle_;    // 各关节相对自身起始位置的转动角度
    };
} // arm_motion_control

#endif // ARM_POSE_ESTIMATION_H_