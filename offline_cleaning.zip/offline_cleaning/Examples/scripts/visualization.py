from shapely.geometry import Polygon, MultiPolygon
import numpy as np

# 绘制路径
def plot_path(points, ax, step=5, scale=1, color='g'):
    xs, ys = zip(*points)
    ax.plot(xs, ys, 'go', label='Path', linewidth=1, markersize=1)
    
    # 将元组转为 numpy 数组用于数学运算
    xs_arr = np.array(xs)
    ys_arr = np.array(ys)

    # 抽样计算箭头起点和方向
    x0 = xs_arr[:-step:step]
    y0 = ys_arr[:-step:step]
    dx = xs_arr[step::step] - x0
    dy = ys_arr[step::step] - y0
    
    ax.quiver(x0, y0, dx, dy, angles='xy', scale_units='xy', scale=scale,
              width=0.003, headwidth=3, headlength=5, color=color)

# 绘制单个多边形
def plot_polygon(polygon, ax, color='blue', linewidth=3):
    x, y = polygon.exterior.xy
    ax.plot(x, y, color=color, linestyle='-', linewidth=linewidth)

    # 如果有内洞
    for interior in polygon.interiors:
        x, y = interior.xy
        ax.plot(x, y, color=color, linestyle='-', linewidth=linewidth)

# 绘制多个多边形
def plot_multipolygon(geom, ax, color='blue', linewidth=3):
    if isinstance(geom, Polygon):
        plot_polygon(geom, ax, color=color, linewidth=linewidth)
    elif isinstance(geom, MultiPolygon):
        for poly in geom.geoms:
            plot_polygon(poly, ax, color=color, linewidth=linewidth)
