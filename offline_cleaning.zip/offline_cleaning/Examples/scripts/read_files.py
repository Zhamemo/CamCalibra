import os
import json
from shapely import wkt
from shapely.errors import WKTReadingError

# 读取并解析 WKT 文件为 shapely 几何对象
def read_wkt(path):
    if not os.path.exists(path):
        print(f"[错误] 文件不存在: {path}")
        return None
    with open(path, "r") as f:
        content = f.read().strip()
        if not content:
            print(f"[警告] 文件为空: {path}")
            return None
        try:
            data = wkt.loads(content)
            return data
        except WKTReadingError as e:
            print(f"[错误] 无法解析 WKT 内容: {path}\n{e}")
            return None

# 读取 JSON 文件
def read_json(path):
    if not os.path.exists(path):
        print(f"[错误] 文件不存在: {path}")
        return None
    with open(path, "r") as f:
        try:
            data = json.load(f)
            return data
        except json.JSONDecodeError:
            print(f"[错误] JSON 解码失败，可能为空或格式错误: {path}")
            return None