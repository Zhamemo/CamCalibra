import matplotlib.pyplot as plt
from read_files import read_wkt, read_json
from visualization import plot_path, plot_multipolygon


fig, ax = plt.subplots(figsize=(8, 6))

# input_polygon_path = "/home/ubuntu/Code/offline_cleaning/Examples/general_offline_cpp/input_polygon.wkt"
# task_polygon_path = "/home/ubuntu/Code/offline_cleaning/Examples/general_offline_cpp/task_polygon.wkt"
# json_path = "/home/ubuntu/Code/offline_cleaning/Examples/general_offline_cpp/offline_non_road_path.json"
# out_img_path = "/home/ubuntu/Code/offline_cleaning/Examples/general_offline_cpp/offline_non_road_path.png"
json_path = "/home/ubuntu/Code/offline_cleaning/Examples/offline_cleaning/offline_road_path.json"
out_img_path = "/home/ubuntu/Code/offline_cleaning/Examples/offline_cleaning/offline_road_path.png"

# # 读取多边形文件
# input_polygon = read_wkt(input_polygon_path)
# task_polygon = read_wkt(task_polygon_path)

# # 绘制多边形
# if input_polygon:
#     plot_multipolygon(input_polygon, ax, color='red', linewidth=5)
# if task_polygon:
#     plot_multipolygon(task_polygon, ax)

# 读取生成离线路径
offline_path = read_json(json_path)

# 绘制路径
if offline_path:
    points = []
    for item in offline_path["path_node"]:
        x = float(item["x"])
        y = float(item["y"])
        points.append((x, y))
    plot_path(points, ax)

# 设置坐标轴比例一致
plt.axis('equal')
plt.grid(True)
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Offline_path_visualization')
plt.legend()
plt.savefig(out_img_path, dpi=300, bbox_inches='tight')

plt.show()
