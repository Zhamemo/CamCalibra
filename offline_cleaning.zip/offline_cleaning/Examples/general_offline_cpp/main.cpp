#include <opencv2/opencv.hpp>

#include "common/ros_msgs.h"
#include "jni_interface/jni_interface.hpp"

typedef boost::geometry::model::d2::point_xy<double> Point_t;

void selectArea(int event, int x, int y, int flags, void* data) {
  std::vector<cv::Point>* points = static_cast<std::vector<cv::Point>*>(data);
  if (event == cv::EVENT_LBUTTONDOWN) {
    LOG_INFO("Left mouse button clicked at (%d, %d)", x, y);
    points->emplace_back(cv::Point(x, y));
  }
}

bool savePathToJson(const std::vector<WorldLocation>& resultList,
                    const std::string& outputPath) {
  try {
    Json::Value root;
    Json::StyledWriter writer;

    // 设置路径类型
    root["path_type"] = "NavMeshPath";

    // 设置修改时间
    std::time_t now = std::time(nullptr);
    std::tm* tm_now = std::localtime(&now);
    char time_str[32];
    std::strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_now);
    root["modified_time"] = time_str;

    // 创建路径数组
    Json::Value pathsArray(Json::arrayValue);
    Json::Value pathObj;

    root["id"] = 0;
    root["nickname"] = "停车场B2人防通道";
    root["path_name"] = "NavMeshPath_0";

    // 创建节点数组
    Json::Value nodesArray(Json::arrayValue);
    for (size_t i = 0; i < resultList.size(); i++) {
      Json::Value node;
      node["id"] = static_cast<int>(i);
      node["x"] = resultList[i].x;
      node["y"] = resultList[i].y;
      node["data"] = "";
      nodesArray.append(node);
    }

    root["path_node"] = nodesArray;
    pathsArray.append(pathObj);
    root["paths"] = pathsArray;

    // 写入文件
    std::ofstream outFile(outputPath);
    if (!outFile.is_open()) {
      std::cout << "Failed to open file for writing: " << outputPath.c_str()
                << std::endl;
      return false;
    }

    outFile << writer.write(root);
    outFile.close();

    return true;
  } catch (const std::exception& e) {
    std::cout << "Exception while saving JSON: " << e.what() << std::endl;
    return false;
  }
}

int main(int argc, char** argv) {
  cv::Mat img =
      cv::imread("/home/ubuntu/Code/offline_cleaning/Examples/map/area_101.pgm",
                 cv::IMREAD_UNCHANGED);
  cv::flip(img, img, 0);

  if (img.empty()) {
    LOG_ERROR("Failed to load image!");
    return -1;
  }

  cv::namedWindow("image", cv::WINDOW_NORMAL);
  cv::resizeWindow("image", 800, 600);
  cv::imshow("image", img);

  std::vector<cv::Point> vec_points;
  vec_points.clear();
  vec_points.reserve(20);

  cv::setMouseCallback("image", selectArea, &vec_points);

  while (true) {
    int key = cv::waitKey(10);

    if (key == 13 || key == 10) {
      break;
    }
  }

  if (vec_points.size() > 2) {
    cv::Mat img_copy = img.clone();
    cv::polylines(img_copy, vec_points, true, cv::Scalar(0, 255, 0), 1);
    cv::imshow("image", img_copy);
  }

  LOG_INFO("Selected points:");
  for (const auto& point : vec_points) {
    LOG_INFO("Point: (%d, %d)", point.x, point.y);
  }

  const std::string yaml_path =
      "/home/ubuntu/Code/offline_cleaning/Examples/map/area_101.yaml";
  const std::string config_path =
      "/home/ubuntu/Code/offline_cleaning/param/offline_non_road_cleaning.yaml";

  jni_interface::JniInterface jni_interface;
  jni_interface.initParms(yaml_path, config_path);
  const auto& costmap_ptr = jni_interface.getCostMap();

  std::vector<WorldLocation> input;
  input.clear();
  input.reserve(vec_points.size());
  double wx = 0.0, wy = 0.0;

  for (const auto& point : vec_points) {
    costmap_ptr->mapToWorld(point.x, point.y, wx, wy);
    input.push_back(WorldLocation(wx, wy));
  }

  std::vector<WorldLocation> vec_offline_path;
  if (jni_interface.planNonRoadPath(input, vec_offline_path)) {
    std::cout << "success" << std::endl;
    savePathToJson(
        vec_offline_path,
        "/home/ubuntu/Code/offline_cleaning/Examples/general_offline_cpp/"
        "offline_non_road_path.json");
  } else {
    std::cout << "failed" << std::endl;
  }
  LOG_INFO("Coverage Path Planner Node is running...");

  cv::waitKey(0);
  return 0;
}