/*
 * @Author: joyce.lou joyce.lou@uditech.com.cn
 * @Date: 2025-03-28 09:43:01
 * @LastEditors: joyce.lou joyce.lou@uditech.com.cn
 * @LastEditTime: 2025-04-29 13:48:51
 * @FilePath: /offline_cleaning/src/main.cpp
 * @Description:
 *
 * Copyright (c) 2025 by ${git_name_email}, All Rights Reserved.
 */

#include "common/ros_msgs.h"
#include "jni_interface/jni_interface.hpp"

void selectArea(int event, int x, int y, int flags, void* data) {
  std::vector<cv::Point>* points = static_cast<std::vector<cv::Point>*>(data);
  if (event == cv::EVENT_LBUTTONDOWN) {
    LOG_INFO("Left mouse button clicked at (%d, %d)", x, y);
    points->emplace_back(cv::Point(x, y));
  }
}

bool savePathToJson(const std::vector<WorldLocation>& resultList,
                    const std::string& outputPath) {
  try {
    Json::Value root;
    Json::StyledWriter writer;

    // 设置路径类型
    root["path_type"] = "NavMeshPath";

    // 设置修改时间
    std::time_t now = std::time(nullptr);
    std::tm* tm_now = std::localtime(&now);
    char time_str[32];
    std::strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_now);
    root["modified_time"] = time_str;

    // 创建路径数组
    Json::Value pathsArray(Json::arrayValue);
    Json::Value pathObj;

    root["id"] = 0;
    root["nickname"] = "停车场B2人防通道";
    root["path_name"] = "NavMeshPath_0";

    // 创建节点数组
    Json::Value nodesArray(Json::arrayValue);
    for (size_t i = 0; i < resultList.size(); i++) {
      Json::Value node;
      node["id"] = static_cast<int>(i);
      node["x"] = resultList[i].x;
      node["y"] = resultList[i].y;
      node["data"] = "";
      nodesArray.append(node);
    }

    root["path_node"] = nodesArray;
    pathsArray.append(pathObj);
    root["paths"] = pathsArray;

    // 写入文件
    std::ofstream outFile(outputPath);
    if (!outFile.is_open()) {
      std::cout << "Failed to open file for writing: " << outputPath.c_str()
                << std::endl;
      return false;
    }

    outFile << writer.write(root);
    outFile.close();
    return true;
  } catch (const std::exception& e) {
    std::cout << "Exception while saving JSON: " << e.what() << std::endl;
    return false;
  }
}

int main(int argc, char** argv) {
  cv::Mat img =
      cv::imread("/home/ubuntu/Code/offline_cleaning/Examples/map/area_101.pgm",
                 cv::IMREAD_UNCHANGED);
  cv::flip(img, img, 0);

  if (img.empty()) {
    LOG_ERROR("Failed to load image!");
    return -1;
  }

  cv::namedWindow("image", cv::WINDOW_NORMAL);
  cv::resizeWindow("image", 800, 600);
  cv::imshow("image", img);

  std::vector<cv::Point> vec_points;
  vec_points.clear();
  vec_points.reserve(20);

  cv::setMouseCallback("image", selectArea, &vec_points);

  while (true) {
    int key = cv::waitKey(10);

    if (key == 13 || key == 10) {
      break;
    }
  }

  cv::Mat img_copy = img.clone();
  if (vec_points.size() == 4) {
    cv::polylines(img_copy, vec_points, true, cv::Scalar(0, 255, 0), 1);
  } else {
    LOG_ERROR("Please select 4 points!");
    return -1;
  }

  cv::Point start_point = (vec_points[0] + vec_points[3]) / 2;
  cv::Point end_point = (vec_points[1] + vec_points[2]) / 2;
  cv::line(img_copy, start_point, end_point, cv::Scalar(0, 0, 255), 1);
  cv::imshow("image", img_copy);

  vec_points.emplace_back(start_point);
  vec_points.emplace_back(end_point);

  LOG_INFO("Selected points:");
  for (const auto& point : vec_points) {
    LOG_INFO("Point: (%d, %d)", point.x, point.y);
  }

  const std::string yaml_path =
      "/home/ubuntu/Code/offline_cleaning/Examples/map/area_101.yaml";
  jni_interface::JniInterface jni_interface;
  jni_interface.initParms(yaml_path);
  const auto& costmap_ptr_ = jni_interface.getCostMap();

  std::vector<WorldLocation> input;
  input.clear();
  input.reserve(vec_points.size());
  double wx = 0.0, wy = 0.0;

  for (const auto& point : vec_points) {
    costmap_ptr_->mapToWorld(point.x, point.y, wx, wy);
    input.emplace_back(WorldLocation(wx, wy));
  }

  std::vector<WorldLocation> vec_offline_path;
  if (jni_interface.planRoadPath(input, vec_offline_path)) {
    savePathToJson(
        vec_offline_path,
        "/home/ubuntu/Code/offline_cleaning/Examples/offline_cleaning/"
        "offline_road_path.json");
    LOG_INFO("Succeed in planning the Coverage Path! vec_offline_path: %d",
             (int)vec_offline_path.size());
  } else {
    LOG_ERROR("Failed to planning the Coverage Path!");
    return -1;
  }
  cv::waitKey(0);
  return 0;
}
