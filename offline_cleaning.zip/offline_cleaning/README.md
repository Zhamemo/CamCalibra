<!--
 * @Author: joyce.lou joyce.lou@uditech.com.cn
 * @Date: 2025-04-29 13:21:24
 * @LastEditors: joyce.lou joyce.lou@uditech.com.cn
 * @LastEditTime: 2025-04-29 14:11:02
 * @FilePath: /offline_cleaning/README.md
 * @Description: 
 * 
 * Copyright (c) 2025 by ${git_name_email}, All Rights Reserved. 
-->
# 离线路径生成


## C++

### 编译

根据需要修改坐标和地图路径：

```cpp
离线路网: Examples/offline_cleaning/main.cpp
离线非路网: Examples/general_offline_cpp/main.cpp
可视化: Examples/scripts/clean_path_plot.py
注: 
1. 可通过鼠标在图像上点击，可以获取对应坐标点作为输入;
2. 离线路网默认最后两个点（E，F）作为中心线，其中E->F表示方向(6个点);
3. 离线非路网默认最后一个点为路径起点(任意点);
```

mkdir build && pushd build && cmake .. && make && popd

### 运行
```
./build/offline_cleaner_test
./build/general_offline_cpp_test
```

### 可视化

cpp代码中以下这一行取消注释可以看到

```cpp
	// map_deal_.visualTrajToMap(outer_circle_path_,offline_cleaning_path,start_point, end_point,offset_paths,map_msg);

```

## Java
### java环境配置

sudo apt install openjdk-8-jdk

### java编译

```bash 
mkdir build && pushd build && cmake .. && make && popd
mkdir classes
javac -cp "json.jar:test" -d classes test/*.java
jar cvf OfflineCleanerJni.jar -C classes .

```



### java运行

<!-- java -Djava.library.path=./build -cp bin OfflineRoadCleanerJNI -->

java -Djava.library.path=build -cp OfflineCleanerJni.jar:json.jar com.uditech.c50b.common.jni.OfflineCleanerJni



### ARM64与AMD64差异

```cpp
	jclass localClass = env->FindClass("WorldLocation");   // AMD64
    if (localClass == nullptr) {
        env->ExceptionClear();
        // 尝试带包名的方式（ARM64）
        localClass = env->FindClass("com/uditech/c50b/entity/vo/WorldLocation");
```

### 异常

```bash
Exception in thread "main" java.lang.NoSuchMethodError: Method com.uditech.c50b.common.jni.OfflineCleanerJni.planRoadPath((J[Lcom/uditech/c50b/entity/vo/WorldLocation;Ljava/util/List;)Z not found
```

javap 工具本身无法直接查看 JNI 动态库（如 .so 文件）中的符号。它只能用于反编译 Java 类文件（.class 文件）并显示其方法签名，包括本地方法（native methods）的声明。

```bash
cd classes
javap -s -p -c com.uditech.c50b.common.jni.OfflineCleanerJni | grep planRoadPath
```

输出如下：

```bash
  public native boolean planRoadPath(long, com.uditech.c50b.entity.vo.WorldLocation[], java.util.List<com.uditech.c50b.entity.vo.WorldLocation>);
     258: invokevirtual #85                 // Method planRoadPath:(J[Lcom/uditech/c50b/entity/vo/WorldLocation;Ljava/util/List;)Z
```