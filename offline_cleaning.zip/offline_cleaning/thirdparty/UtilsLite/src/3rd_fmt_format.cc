#if defined(__llvm__) || defined(__clang__)
#pragma clang diagnostic ignored "-Wc++98-compat-pedantic"
#pragma clang diagnostic ignored "-Wdocumentation-unknown-command"
#pragma clang diagnostic ignored "-Wmissing-variable-declarations"
#pragma clang diagnostic ignored "-Wduplicate-enum"
#endif

#include "Utils_fmt.hh"
#include "Utils/3rd/format.cxx"
