#!/bin/bash
###
 # @Author: joyce.lou joyce.lou@uditech.com.cn
 # @Date: 2025-04-29 13:21:24
 # @LastEditors: joyce.lou joyce.lou@uditech.com.cn
 # @LastEditTime: 2025-04-29 14:08:56
 # @FilePath: /offline_cleaning/compile.sh
 # @Description: 
 # 
 # Copyright (c) 2025 by ${git_name_email}, All Rights Reserved. 
### 

# 创建编译目录
mkdir -p classes

# 下载 org.json 依赖（如果还没有的话）
if [ ! -f "json.jar" ]; then
    wget https://repo1.maven.org/maven2/org/json/json/20231013/json-20231013.jar -O json.jar
fi

# 编译 Java 文件
echo "Compiling Java files..."
javac -cp "json.jar:test" -d classes test/*.java

# 创建 JAR 文件
echo "Creating JAR file..."
# jar cvf OfflineRoadCleaner.jar -C classes .
jar cvf RoadCleanerJni.jar -C classes .

echo "Compilation complete."
echo "To run the program, use:"
# echo "java -Djava.library.path=build -cp \"OfflineRoadCleaner.jar:json.jar\" OfflineRoadCleanerJNI"
java -Djava.library.path=build -cp RoadCleanerJni.jar:json.jar com.uditech.c50b.common.jni.RoadCleanerJni
