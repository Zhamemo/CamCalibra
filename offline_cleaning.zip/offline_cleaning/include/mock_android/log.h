// mock_android/log.h
#ifndef MOCK_ANDROID_LOG_H
#define MOCK_ANDROID_LOG_H

#include <stdarg.h>
#include <stdio.h>  // 使用标准输出

// 定义 Android 日志级别
typedef enum {
    ANDROID_LOG_UNKNOWN = 0,
    ANDROID_LOG_DEFAULT,
    ANDROID_LOG_VERBOSE,
    ANDROID_LOG_DEBUG,
    ANDROID_LOG_INFO,
    ANDROID_LOG_WARN,
    ANDROID_LOG_ERROR,
    ANDROID_LOG_FATAL,
    ANDROID_LOG_SILENT
} android_LogPriority;

// 模拟 __android_log_print
static inline int __android_log_print(int prio, const char* tag, const char* fmt, ...) {
    (void)prio;  // 忽略优先级（仅用于兼容）
    va_list args;
    va_start(args, fmt);
    printf("[%s] ", tag);  // 添加标签
    vprintf(fmt, args);
    printf("\n");          // 换行
    va_end(args);
    return 0;
}

// 其他常用 Android 日志宏（可选）
#define ALOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "DEBUG", __VA_ARGS__)
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, "INFO", __VA_ARGS__)
#define ALOGW(...) __android_log_print(ANDROID_LOG_WARN, "WARN", __VA_ARGS__)
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, "ERROR", __VA_ARGS__)

#endif // MOCK_ANDROID_LOG_H
