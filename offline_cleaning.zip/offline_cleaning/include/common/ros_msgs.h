/*
 * @Author: joyce.lou joyce.lou@uditech.com.cn
 * @Date: 2025-03-28 09:43:01
 * @LastEditors: joyce.lou joyce.lou@uditech.com.cn
 * @LastEditTime: 2025-03-28 15:52:07
 * @FilePath: /offline_cleaning/include/offline_cleaning/ros_msgs.h
 * @Description: 
 * 
 * Copyright (c) 2025 by ${git_name_email}, All Rights Reserved. 
 */
#ifndef _ROS_MSGS_H_
#define _ROS_MSGS_H_
#include <iostream>
#include <vector>


#include <stdlib.h>

#include <string>

typedef struct {
  double x;
  double y;
  double z;
} __attribute__ ((packed)) geometry_msgs_Point;

typedef struct
{
  std::string image;
  double resolution;
  geometry_msgs_Point origin;
  int negate;
  double occupied_thresh;
  double free_thresh;
} MapYamlInfo;
//__attribute__ ((packed)) ;

typedef struct {
  double x;
  double y;
  double z;
  double w;
} __attribute__ ((packed)) geometry_msgs_Quaternion;

typedef struct {
  geometry_msgs_Point position;
  geometry_msgs_Quaternion orientation;
} __attribute__ ((packed)) geometry_msgs_Pose;

typedef struct {
  uint32_t  seq;
  std::string frame_id;
} std_msgs_Header;// __attribute__ ((packed)) ;

typedef struct {
  std_msgs_Header header;
  geometry_msgs_Pose pose;
} geometry_msgs_PoseStamped; // __attribute__ ((packed))

typedef struct
{
  double resolution;
  uint32_t width;
  uint32_t height;
  geometry_msgs_Pose origin;
} __attribute__ ((packed)) nav_msgs_MapMetaData;


typedef struct
{
  std_msgs_Header header;
  nav_msgs_MapMetaData info;
  std::vector<int8_t> data;
} nav_msgs_OccupancyGrid; //__attribute__ ((packed)) 

typedef struct
{
  std::vector<geometry_msgs_Point> points;
} geometry_msgs_Polygon; //__attribute__ ((packed)) 



#endif
