#pragma once
#include <algorithm>
#include <iostream>

#include "general_offline_cpp/boundary_solver.hpp"
#include "general_offline_cpp/clothoid_tools.hpp"
#include "general_offline_cpp/dummy_tsp_solver.hpp"
#include "general_offline_cpp/geometry_misc.hpp"
#include "general_offline_cpp/parallel_solver.hpp"
#include "common/costmap_2d.h"

namespace cpp_planner {
namespace application {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;
typedef bg::model::segment<Point_t> Segment_t;

void cppInPolygon(bool generate_full_path, const Polygon_t &polygon,
                  const costmap_2d::Costmap2D *const global_costmap,
                  const double &cleaning_width, const Point_t &start_point,
                  const double &min_parallel_line_length,
                  std::vector<cpp_planner::geometry::PathPack> &path_packs);

void pathPacksToVector(
    const std::vector<cpp_planner::geometry::PathPack> &path_packs,
    std::vector<Point_t> &path_vector);
}  // namespace application
}  // namespace cpp_planner
