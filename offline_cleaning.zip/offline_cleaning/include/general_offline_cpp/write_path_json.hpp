#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <fstream>
#include "json/json.h"

namespace cpp_planner {
namespace utils {

namespace bg = boost::geometry;
typedef bg::model::d2::point_xy<double> Point_t;

bool writePathJson(const std::string &file_path, const std::vector<Point_t> &path);
}  // namespace utils
}  // namespace cpp_planner