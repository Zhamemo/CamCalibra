#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/linestring.hpp>
#include <boost/geometry/geometries/multi_point.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <iostream>
#include <tuple>
#include <vector>

namespace cpp_planner {
namespace geometry {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;
typedef bg::model::ring<Point_t, false> Ring_t;
typedef bg::model::segment<Point_t> Segment_t;

class BoundarySolver {
 public:
  std::vector<Line_t> findBoundarySegments(const Point_t &point1, const Point_t &point2, Ring_t boundary,
                                           bool short_path) const;

  std::vector<Line_t> findBoundarySegments(const Point_t &point, Ring_t boundary) const;

  Polygon_t bufferPolygon(Polygon_t polygon, double buffer_distance) const;

  Point_t closestPointOnRing(const Ring_t &ring, const Point_t &reference_point) const;

  Point_t closestPointOnLine(const Line_t &line, const Point_t &reference_point) const;

 private:
  bool pointOnLine(const Point_t &point, const Point_t &line_vertex_1, const Point_t &line_vertex_2) const;

  bool samePoint(const Point_t &point1, const Point_t &point2) const;

  void insertPointIntoRing(const Point_t &point, Ring_t &ring) const;
};
}  // namespace geometry
}  // namespace cpp_planner