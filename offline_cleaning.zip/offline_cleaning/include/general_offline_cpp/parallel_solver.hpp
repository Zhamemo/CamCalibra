#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <tuple>
#include <vector>
namespace cpp_planner {
namespace geometry {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;
class ParallelSolver {
 public:
  std::vector<Line_t> solveParallelLines(const Polygon_t &polygon, const double &cleaning_width,
                                         const double &edge_width_rate, const Point_t &direction,
                                         const double &shrink_length, const double &min_line_length) const;

  Point_t directionOfLongestEdge(const Polygon_t &polygon) const;

 private:
  Point_t verticalVector(const Point_t &direction) const;

  Point_t centerOfPolygon(const Polygon_t &polygon) const;

  Point_t normalizePoint(const Point_t &direction) const;

  std::tuple<Point_t, Point_t, double> polarOfPolygon(const Polygon_t &polygon, const Point_t &direction) const;

  std::vector<double> getParallelDistance(double total_distance, double cleaning_width, double edge_distance) const;

  std::vector<Line_t> getParallelLines(const Point_t &start, const Point_t &direction,
                                       const std::vector<double> &distance_list) const;

  std::vector<Line_t> intersectLinesWithPolygon(const std::vector<Line_t> &lines, const Polygon_t &poly) const;

  std::vector<Line_t> shrinkLines(const std::vector<Line_t> &lines, const double &shrink_length,
                                  const double &min_line_length) const;
};
}  // namespace geometry
}  // namespace cpp_planner