#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <tuple>
#include <vector>
namespace cpp_planner {
namespace utils {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::linestring<Point_t> Line_t;

class DummyTspSolver {
 public:
  void setLines(const std::vector<Line_t> &lines);
  std::vector<Line_t> dummyTspSolver(const Point_t &start_point);

 private:
  std::tuple<int, Point_t> findNearestUnvisitedPoint(const Point_t &reference_point) const;

  Point_t getAnotherVertex(const Line_t &line, const Point_t &reference_point) const;
  std::vector<Line_t> lines_;
  std::vector<bool> visited_mask_;
};
}  // namespace utils
}  // namespace cpp_planner