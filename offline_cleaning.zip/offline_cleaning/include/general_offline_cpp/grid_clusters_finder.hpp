#pragma once
#include <iostream>
#include <stack>
#include <tuple>
#include <vector>

#include "common/costmap_2d.h"

namespace cpp_planner {
namespace geometry {
// find all clusters whose grids' cost value being betweent two value limits (>=
// lowwer limit, <= upper limit) the result will be stored into clusters (index
// of cell in the costmap)
class GridClustersFinder {
 public:
  GridClustersFinder(const costmap_2d::Costmap2D *const costmap,
                     unsigned char value_limit_1, unsigned char value_limit_2)
      : costmap_(costmap) {
    visited_mask_.resize(costmap->getSizeInCellsX(),
                         std::vector<bool>(costmap->getSizeInCellsY(), false));
    upper_limit_ = std::max(value_limit_1, value_limit_2);
    lower_limit_ = std::min(value_limit_1, value_limit_2);
  };

  int findClusters(costmap_2d::Costmap2D *const clusters_map,
                   const int &area_lower_limit) const;

 private:
  bool gridValid(const unsigned int &mx, const unsigned int &my) const;

  bool dfs(unsigned int &x, unsigned int &y, unsigned int &marker,
           costmap_2d::Costmap2D *const clusters_map,
           const int &area_lower_limit) const;

  std::vector<std::pair<unsigned int, unsigned int>> neighbors(
      unsigned int &x, unsigned int &y) const;

  const costmap_2d::Costmap2D *const costmap_;
  unsigned char upper_limit_;
  unsigned char lower_limit_;
  std::vector<std::vector<bool>> visited_mask_;
};
}  // namespace geometry
}  // namespace cpp_planner