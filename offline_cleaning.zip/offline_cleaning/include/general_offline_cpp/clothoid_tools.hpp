#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <tuple>
#include <vector>

#include "Clothoids.hh"
#include "Clothoids_fmt.hh"
#include "general_offline_cpp/geometry_misc.hpp"
#include "common/costmap_2d.h"

namespace cpp_planner {
namespace geometry {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;

class ClothoidSmoother {
 public:
  ClothoidSmoother(
      const double &sampling_resolution, const Polygon_t &task_polygon,
      const costmap_2d::Costmap2D *const global_costmap = nullptr)
      : sampling_resolution_(sampling_resolution),
        task_polygon_(task_polygon) {};

  void clothoidsSmooth2Lines(const Line_t &line1, double kink_length1,
                             const Line_t &line2, double kink_length2,
                             std::vector<Point_t> &path) const;

  void clearSmoothConfigPacks();

  void appendSmoothConfigPack(
      cpp_planner::geometry::SmoothConfigsPack &&smooth_config_pack);

  bool smooth(std::vector<cpp_planner::geometry::PathPack> &path_packs) const;

 private:
  bool checkPathValid(
      const std::vector<Point_t> &path,
      const cpp_planner::geometry::ValidCriteria &valid_criteria) const;

  // return the direction and the kink point
  std::tuple<Point_t, Point_t> getKinkPoint(const Line_t &line,
                                            const double &kink_length,
                                            const Point_t &side) const;

  double sampling_resolution_;

  std::vector<cpp_planner::geometry::SmoothConfigsPack> smooth_config_packs_;

  Polygon_t task_polygon_;

  const costmap_2d::Costmap2D *const global_costmap_ = nullptr;
};
}  // namespace geometry
}  // namespace cpp_planner