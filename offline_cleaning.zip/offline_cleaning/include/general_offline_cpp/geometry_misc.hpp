#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/linestring.hpp>
#include <boost/geometry/geometries/multi_point.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <iostream>
#include <tuple>
#include <vector>

namespace cpp_planner {
namespace geometry {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;

struct KinkLengthRange {
  double limit_1;
  double limit_2;
};

enum ValidCriteria { none, in_task_polygon, collision_free, both };

struct SmoothConfig2Lines {
  Line_t line_1;
  KinkLengthRange kink_length_range_1;
  Line_t line_2;
  KinkLengthRange kink_length_range_2;
  ValidCriteria valid_criteria;
};

struct RobotWayPoint {
  Point_t pos;
  Point_t direction;
  double kappa;
};

struct SmoothConfigsPack {
  std::vector<SmoothConfig2Lines> configs;
  int kink_length_sampling_num;
  int task_id;
  RobotWayPoint replan_start;
  RobotWayPoint replan_end;
};

struct PathPack {
  std::vector<Point_t> path;
  std::vector<Point_t> replan_bridge_start;
  std::vector<Point_t> replan_bridge_end;
  RobotWayPoint replan_start;
  RobotWayPoint replan_end;
  int task_id;
  bool valid;
};

Point_t normalizePoint(const Point_t &direction);

Point_t pointsToDirection(const Point_t &start, const Point_t &end);

Point_t ratioMidOf2Points(const Point_t &p1, const Point_t &p2, const double &ratio);

Point_t ratioMidOfLine(const Line_t &line, const double &ratio);

int sampleLine(const Point_t &point1, const Point_t &point2, const double &sampling_resolution,
               std::vector<Point_t> &samples);

std::vector<double> linspace(double start, double stop, int num);

bool pointsEqual(const Point_t &p1, const Point_t &p2);

Point_t normalizePoint(const Point_t &direction);
}  // namespace geometry
}  // namespace cpp_planner