#pragma once
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/linestring.hpp>
#include <boost/geometry/geometries/multi_point.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <tuple>
#include <vector>

#include "general_offline_cpp/grid_clusters_finder.hpp"

namespace cpp_planner {
namespace geometry {
namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;
typedef bg::model::multi_polygon<Polygon_t> MultiPolygon_t;

class GridmapTools {
 public:
  GridmapTools(const costmap_2d::Costmap2D *const reference_costmap)
      : reference_costmap_(reference_costmap) {};

  std::vector<Polygon_t> calculateTaskPolygon(
      const Polygon_t &selected_polygon,
      const unsigned char &reference_included_value1,
      const unsigned char &reference_included_value2,
      const int &area_lower_limit = 100) const;

 private:
  void polygonToGrids(const Polygon_t &polygon,
                      const unsigned char &polygon_value,
                      const unsigned char &reference_included_value1,
                      const unsigned char &reference_included_value2,
                      costmap_2d::Costmap2D *costmap_result) const;

  Polygon_t clusterToPolygonCV(const costmap_2d::Costmap2D *const costmap,
                               const unsigned char &mask_value) const;

  const costmap_2d::Costmap2D *const reference_costmap_;
};
}  // namespace geometry
}  // namespace cpp_planner