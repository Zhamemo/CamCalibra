#pragma once

#include <boost/geometry/geometries/geometries.hpp>
#include <boost/geometry/geometries/linestring.hpp>
#include <boost/geometry/geometries/multi_point.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>
#include <mutex>
#include <string>

#include "common/costmap_2d.h"
#include "common/offline_log.h"
#include "common/ros_msgs.h"
#include "general_offline_cpp/cpp_in_polygon.hpp"
#include "general_offline_cpp/gridmap_tools.hpp"
#include "general_offline_cpp/write_path_json.hpp"

namespace cpp_planner {
namespace ros_interface {

namespace bg = boost::geometry;

typedef bg::model::d2::point_xy<double> Point_t;
typedef bg::model::polygon<Point_t, false> Polygon_t;
typedef bg::model::linestring<Point_t> Line_t;

class OfflineNonRoadAreaCleaningPathPlanner {
 public:
  explicit OfflineNonRoadAreaCleaningPathPlanner(
      const boost::shared_ptr<costmap_2d::Costmap2D> &costmap_ptr,
      const std::string &config_path, bool generate_full_path = true);

  ~OfflineNonRoadAreaCleaningPathPlanner() = default;

 private:
  void loadParamsFromYaml(const std::string &yaml_path);
  Polygon_t geometryMsgsToBgPolygon(
      const geometry_msgs_Polygon &gm_polygon) const;
  void writePolygonWkt(const std::string out_path, const std::string &wkt_str);

 public:
  /**
   * ************************************************************************
   * @brief: 生成非路网区域规划路径
   *
   * @param[in]: vec_point
   * @param[in]: start_point
   *
   * @return std::tuple<路径生成标志, 错误消息, 路径>
   * ************************************************************************
   */
  std::tuple<bool, std::string, std::vector<Point_t>> planCoveragePath(
      const geometry_msgs_Polygon &gm_area,
      const geometry_msgs_Point &gm_start_point);

 private:
  double cleaning_width_ = 0.5;
  unsigned char min_to_include_in_costmap_ = 0;
  unsigned char max_to_include_in_costmap_ = 5;
  int min_cluster_area_ = 100;
  double min_parallel_line_length_ = 2.0;
  std::string json_file_path_ =
      "/home/ubuntu/std_wr_demo/map/offline_non_road_path.json";
  std::string polygon_save_path_ = "/home/ubuntu/std_wr_demo/map/";

  std::string config_path_;
  bool generate_full_path_{true};
  boost::shared_ptr<costmap_2d::Costmap2D> costmap_ptr_;
};
}  // namespace ros_interface
}  // namespace cpp_planner
