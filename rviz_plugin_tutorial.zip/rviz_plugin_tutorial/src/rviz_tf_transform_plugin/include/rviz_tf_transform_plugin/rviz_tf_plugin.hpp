#ifndef RVIZ_TF_PLUGIN_H
#define RVIZ_TF_PLUGIN_H

#include <rviz/panel.h>
#include <QWidget>
#include <QPushButton>
#include <ros/ros.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include <tf2/LinearMath/Quaternion.h>
#include <rviz/visualization_manager.h>

namespace rviz_tf_transform_plugin
{
    class RvizTFPlugin : public rviz::Panel
    {
    public:
        RvizTFPlugin(QWidget *parent = 0);
        virtual ~RvizTFPlugin();

    private slots:
        void onUpdateButtonClicked();
        void onPositionChangedX(double x);
        void onPositionChangedY(double y);
        void onPositionChangedZ(double z);
        void onOrientationChangedRoll(double roll);
        void onOrientationChangedPitch(double pitch);
        void onOrientationChangedYaw(double yaw);

    private:
        void updateTFTransform();
        void displayTransform(const geometry_msgs::TransformStamped &transform);

        ros::NodeHandle nh_;
        tf2_ros::Buffer tf_buffer_;
        tf2_ros::TransformListener tf_listener_;
        geometry_msgs::TransformStamped current_transform_;
        QPushButton *update_button_;
        tf2_ros::TransformBroadcaster tf_broadcaster_;
    };
} // namespace rviz_tf_transform_plugin

#endif // RVIZ_TF_PLUGIN_H
