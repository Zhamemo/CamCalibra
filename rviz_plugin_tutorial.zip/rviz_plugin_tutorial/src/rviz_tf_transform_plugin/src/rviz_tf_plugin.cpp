#include "rviz_tf_plugin.hpp"
#include <QVBoxLayout>
#include <QDoubleSpinBox>
#include <QLabel>
#include <QPushButton>
#include <ros/ros.h>
#include <tf2/LinearMath/Quaternion.h>
#include <geometry_msgs/TransformStamped.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

namespace rviz_tf_transform_plugin
{
    RvizTFPlugin::RvizTFPlugin(QWidget *parent) : rviz::Panel(parent),
                                                  tf_listener_(tf_buffer_)
    {
        QVBoxLayout *layout = new QVBoxLayout;
        QLabel *position_label = new QLabel("Position (x, y, z):");
        layout->addWidget(position_label);

        QDoubleSpinBox *x_spin = new QDoubleSpinBox();
        QDoubleSpinBox *y_spin = new QDoubleSpinBox();
        QDoubleSpinBox *z_spin = new QDoubleSpinBox();
        layout->addWidget(x_spin);
        layout->addWidget(y_spin);
        layout->addWidget(z_spin);

        QLabel *orientation_label = new QLabel("Orientation (roll, pitch, yaw):");
        layout->addWidget(orientation_label);

        QDoubleSpinBox *roll_spin = new QDoubleSpinBox();
        QDoubleSpinBox *pitch_spin = new QDoubleSpinBox();
        QDoubleSpinBox *yaw_spin = new QDoubleSpinBox();
        layout->addWidget(roll_spin);
        layout->addWidget(pitch_spin);
        layout->addWidget(yaw_spin);

        update_button_ = new QPushButton("Update Transform");
        layout->addWidget(update_button_);

        setLayout(layout);

        connect(update_button_, &QPushButton::clicked, this, &RvizTFPlugin::onUpdateButtonClicked);
        connect(x_spin, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, &RvizTFPlugin::onPositionChangedX);
        connect(y_spin, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, &RvizTFPlugin::onPositionChangedY);
        connect(z_spin, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, &RvizTFPlugin::onPositionChangedZ);

        connect(roll_spin, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, &RvizTFPlugin::onOrientationChangedRoll);
        connect(pitch_spin, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, &RvizTFPlugin::onOrientationChangedPitch);
        connect(yaw_spin, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, &RvizTFPlugin::onOrientationChangedYaw);
    }
    RvizTFPlugin::~RvizTFPlugin()
    {
        delete update_button_;
    }

    void RvizTFPlugin::onUpdateButtonClicked()
    {
        updateTFTransform();
    }

    void RvizTFPlugin::onPositionChangedX(double x)
    {
        current_transform_.transform.translation.x = x;
    }

    void RvizTFPlugin::onPositionChangedY(double y)
    {
        current_transform_.transform.translation.y = y;
    }

    void RvizTFPlugin::onPositionChangedZ(double z)
    {
        current_transform_.transform.translation.z = z;
    }

    void RvizTFPlugin::onOrientationChangedRoll(double roll)
    {
        tf2::Quaternion q = tf2::Quaternion::getIdentity();
        q.setRPY(roll, current_transform_.transform.rotation.y, current_transform_.transform.rotation.z);
        current_transform_.transform.rotation = tf2::toMsg(q);
    }

    void RvizTFPlugin::onOrientationChangedPitch(double pitch)
    {
        tf2::Quaternion q = tf2::Quaternion::getIdentity();
        q.setRPY(current_transform_.transform.rotation.x, pitch, current_transform_.transform.rotation.z);
        current_transform_.transform.rotation = tf2::toMsg(q);
    }

    void RvizTFPlugin::onOrientationChangedYaw(double yaw)
    {
        tf2::Quaternion q = tf2::Quaternion::getIdentity();
        q.setRPY(current_transform_.transform.rotation.x, current_transform_.transform.rotation.y, yaw);
        current_transform_.transform.rotation = tf2::toMsg(q);
    }

    void RvizTFPlugin::updateTFTransform()
    {
        // 创建一个简单的 TF 变换并发布
        geometry_msgs::TransformStamped new_transform;
        new_transform.header.stamp = ros::Time::now();
        new_transform.header.frame_id = "base_link";
        new_transform.child_frame_id = "tf";

        // 使用用户输入的值更新变换
        new_transform.transform = current_transform_.transform;

        // 可选择地将 TF 发布到 ROS 系统
        tf_buffer_.setTransform(new_transform, "tf");

        // 在 RViz 中显示
        displayTransform(new_transform);
    }

    void RvizTFPlugin::displayTransform(const geometry_msgs::TransformStamped &transform)
    {
        // 在 RViz 中使用 marker 显示变换（例如通过 Visualizer）
        ROS_INFO("Displaying transform: %s -> %s", transform.header.frame_id.c_str(), transform.child_frame_id.c_str());
        tf_broadcaster_.sendTransform(transform);
    }
} // namespace rviz_tf_transform_plugin

// 声明此类是一个rviz的插件
#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(rviz_tf_transform_plugin::RvizTFPlugin, rviz::Panel)
