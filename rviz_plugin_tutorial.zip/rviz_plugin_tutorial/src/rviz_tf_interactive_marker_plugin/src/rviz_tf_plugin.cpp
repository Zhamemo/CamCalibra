#include <rviz_tf_plugin.hpp>
#include <pluginlib/class_list_macros.hpp>
#include <ros/ros.h>
#include <visualization_msgs/InteractiveMarker.h>
#include <visualization_msgs/InteractiveMarkerControl.h>
#include <visualization_msgs/Marker.h>
#include <interactive_markers/interactive_marker_server.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>

namespace rviz_tf_interactive_marker_plugin {

    RvizTFPlugin::RvizTFPlugin(QWidget *parent)
    : rviz::Panel(parent), tf_broadcaster_(), server_("tf_interactive_marker") {
        setupInteractiveMarker();
        startTimer(30);  // Periodic update
    }

    void RvizTFPlugin::updateTFTransform() {
        geometry_msgs::TransformStamped transformStamped;
        transformStamped.header.stamp = ros::Time::now();
        transformStamped.header.frame_id = "laser_link"; 
        transformStamped.child_frame_id = "tf_link"; 

        transformStamped.transform.translation.x = current_position_.x;
        transformStamped.transform.translation.y = current_position_.y;
        transformStamped.transform.translation.z = current_position_.z;

        if (current_orientation_.x == 0.0 && current_orientation_.y == 0.0 && current_orientation_.z == 0.0 && current_orientation_.w == 0.0) {
            current_orientation_.x = 0.0;
            current_orientation_.y = 0.0;
            current_orientation_.z = 0.0;
            current_orientation_.w = 1.0;
        }

        transformStamped.transform.rotation = current_orientation_;
        tf_broadcaster_.sendTransform(transformStamped);

        ROS_INFO_STREAM("Broadcasting transform from 'laser_link' to 'tf_link' : "
                        << "Position: (" << transformStamped.transform.translation.x << ", "
                        << transformStamped.transform.translation.y << ", "
                        << transformStamped.transform.translation.z << ")");
    }

    void RvizTFPlugin::setupInteractiveMarker() {
        visualization_msgs::InteractiveMarker int_marker;
        int_marker.header.frame_id = "laser_link";
        int_marker.name = "tf_link";
        int_marker.description = "Draggable TF Frame";

        int_marker.pose.position.x = 0.0;
        int_marker.pose.position.y = 0.0;
        int_marker.pose.position.z = 0.0;

        visualization_msgs::InteractiveMarkerControl control;
        control.name = "move_3d";
        control.interaction_mode = visualization_msgs::InteractiveMarkerControl::MOVE_3D;

        visualization_msgs::Marker marker;
        marker.type = visualization_msgs::Marker::SPHERE;
        marker.scale.x = 0.1;
        marker.scale.y = 0.1;
        marker.scale.z = 0.1;
        marker.color.r = 0.0;
        marker.color.g = 1.0;
        marker.color.b = 0.0;
        marker.color.a = 1.0;

        control.markers.push_back(marker);
        int_marker.controls.push_back(control);

        server_.insert(int_marker, boost::bind(&RvizTFPlugin::processFeedback, this, _1));
        server_.applyChanges();
    }

    void RvizTFPlugin::processFeedback(const visualization_msgs::InteractiveMarkerFeedbackConstPtr &feedback) {
        current_position_ = feedback->pose.position;
        current_orientation_ = feedback->pose.orientation;

        if (current_orientation_.x == 0.0 && current_orientation_.y == 0.0 && current_orientation_.z == 0.0 && current_orientation_.w == 0.0) {
            current_orientation_.x = 0.0;
            current_orientation_.y = 0.0;
            current_orientation_.z = 0.0;
            current_orientation_.w = 1.0;
        }

        updateTFTransform();
        server_.applyChanges();
    }

    void RvizTFPlugin::timerEvent(QTimerEvent *event) {
        updateTFTransform();
    }

} // namespace rviz_tf_interactive_marker_plugin

PLUGINLIB_EXPORT_CLASS(rviz_tf_interactive_marker_plugin::RvizTFPlugin, rviz::Panel);
