#ifndef RVIZ_TF_PLUGIN_HPP
#define RVIZ_TF_PLUGIN_HPP

#include <rviz/panel.h>
#include <tf2_ros/transform_broadcaster.h>
#include <interactive_markers/interactive_marker_server.h>
#include <geometry_msgs/TransformStamped.h>
#include <visualization_msgs/InteractiveMarkerFeedback.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

namespace rviz_tf_interactive_marker_plugin
{
    class RvizTFPlugin : public rviz::Panel
    {
    public:
        RvizTFPlugin(QWidget *parent = nullptr);
        ~RvizTFPlugin();

        // This method is used to broadcast the transform based on the interactive marker position
        void updateTFTransform();

        // This method sets up the interactive marker
        void setupInteractiveMarker();

        // This function is called when the marker is moved
        void processFeedback(const visualization_msgs::InteractiveMarkerFeedbackConstPtr &feedback);

    protected:
        // Timer event for periodically updating the TF transform
        void timerEvent(QTimerEvent *event) override;

    private:
        tf2_ros::TransformBroadcaster tf_broadcaster_;
        interactive_markers::InteractiveMarkerServer server_;
        geometry_msgs::Point current_position_;
        geometry_msgs::Quaternion current_orientation_;
    };

} // namespace rviz_tf_interactive_marker_plugin

#endif // RVIZ_TF_PLUGIN_HPP
