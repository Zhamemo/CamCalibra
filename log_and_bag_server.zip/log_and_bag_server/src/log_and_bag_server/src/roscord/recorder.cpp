/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, Willow Garage, Inc.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ********************************************************************/

#include "recorder.h"

// Boost filesystem v3 is default in 1.46.0 and above
// Fallback to original posix code (*nix only) if this is not true
#if BOOST_FILESYSTEM_VERSION < 3
#include <sys/statvfs.h>
#endif

#include <ros/ros.h>

#include <boost/filesystem.hpp>
#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread/xtime.hpp>
#include <set>
#include <sstream>

#include "XmlRpc.h"
#include "ros/network.h"
#include "ros/xmlrpc_manager.h"

#define foreach BOOST_FOREACH

using boost::shared_ptr;
using ros::Time;
using std::cout;
using std::endl;
using std::set;
using std::string;
using std::vector;

namespace log_and_bag_server {

OutgoingMessage::OutgoingMessage(
    string const& _topic, topic_tools::ShapeShifter::ConstPtr _msg,
    boost::shared_ptr<ros::M_string> _connection_header, Time _time)
    : topic(_topic),
      msg(_msg),
      connection_header(_connection_header),
      time(_time) {}

OutgoingQueue::OutgoingQueue(string const& _filename,
                             std::queue<OutgoingMessage>* _queue, Time _time)
    : filename(_filename), queue(_queue), time(_time) {}

RecorderOptions::RecorderOptions()
    : trigger(false),
      record_all(false),
      regex(false),
      do_exclude(false),
      quiet(false),
      append_date(false),
      snapshot(false),
      verbose(false),
      compression(compression::Uncompressed),
      prefix(""),
      name(""),
      exclude_regex(),
      buffer_size(1048576 * 256),
      chunk_size(1024 * 768),
      limit(0),
      split(true),
      max_size(0),
      max_duration(-1.0),
      node(""),
      min_space(1024 * 1024 * 1024 * 10),
      min_space_str("10G"),
      ftp_path("~/log_bag/"),
      unknow_error_path("~/unknow_log_bag/") {}

Recorder::Recorder(RecorderOptions const& options)
    : options_(options),
      num_subscribers_(0),
      exit_code_(0),
      queue_size_(0),
      split_count_(0),
      split_name_("last"),
      errorcode_happened_(false),
      engineer_happened_(false),
      engineer_happened_state_(false),
      errorcode_count_(0),
      error_code_(""),
      script_name_(""),
      unknow_error_name_("999"),
      log_out_error_name_("log_out"),
      enable_write_(true) {
  ros::NodeHandle nh("~");
  initParams();
}

void Recorder::initParams() {
  ros::NodeHandle private_nh("~");
  node_name_str_ = ros::this_node::getName();

  private_nh.param("UD_last_bag_name", last_split_name_, string("last"));
  private_nh.param("UD_current_bag_name", current_split_name_,
                   string("current"));

  private_nh.param("UD_error_log_name", log_name_,
                   string("/home/ubuntu/log_bag/ud_terminal_logs/UDLog"));
  private_nh.param("UD_tcp_cmd", tcp_cmd_,
                   string("/home/ubuntu/update/msg_sender 30 4 22 "));

  private_nh.param("UD_std_path", std_path_,
                   string("/home/ubuntu/std_wr_demo"));
  private_nh.param("UD_system_path", system_path_, string("/var/log"));

  private_nh.param("UD_errorcode_extend_record_time",
                   ud_errorcode_extend_record_time_, 8.0);

  private_nh.param("UD_var_log_tar_name", ud_var_log_tar_name_,
                   string("~/log_bag/ud_var_log.tar"));
  private_nh.param("UD_opennilog_path", ud_opennilog_path_,
                   string("/home/ubuntu/log_bag/openniLog"));
  private_nh.param("UD_depth_camera_pictures_path",
                   ud_depth_camera_pictures_path_,
                   string("/home/ubuntu/log_bag/depth_camera_picture"));
  private_nh.param("UD_shell_log_path", ud_shell_log_path_,
                   string("/home/ubuntu/log_bag/shell_log"));

  std::string ud_record_varlog_errorcode, ud_record_opennilog_errorcode;
  private_nh.param("UD_record_varlog_errorcode", ud_record_varlog_errorcode,
                   string(""));

  record_varlog_errorcode_vector_.clear();
  boost::split(record_varlog_errorcode_vector_, ud_record_varlog_errorcode,
               boost::is_any_of(","), boost::token_compress_on);

  private_nh.param("UD_record_opennilog_errorcode",
                   ud_record_opennilog_errorcode, string(""));

  record_opennilog_errorcode_vector_.clear();
  boost::split(record_opennilog_errorcode_vector_,
               ud_record_opennilog_errorcode, boost::is_any_of(","),
               boost::token_compress_on);

  ROS_INFO(
      "[%s][%d]: ud_record_varlog_errorcode: %s;ud_record_opennilog_errorcode: "
      "%s;(%d %d)",
      __func__, __LINE__, ud_record_varlog_errorcode.c_str(),
      ud_record_opennilog_errorcode.c_str(),
      record_varlog_errorcode_vector_.size(),
      record_opennilog_errorcode_vector_.size());

  if (ros::param::get("~upload_bag_script", script_name_)) {
    if (script_name_ != "") {
      ROS_INFO("[%s][%s][%d]:Get script name: %s", node_name_str_.c_str(),
               __func__, __LINE__, script_name_.c_str());
    } else {
      ROS_ERROR("[%s][%s][%d]:Bad script name, exit !", node_name_str_.c_str(),
                __func__, __LINE__);
      exit(-1);
    }
  } else {
    ROS_ERROR("[%s][%s][%d]: Not got the script!", node_name_str_.c_str(),
              __func__, __LINE__);
  }

  error_code_sub_ = private_nh.subscribe<std_msgs::String>(
      "/error_log_state", 3, &Recorder::errorcodeCB, this);
  zip_success_pub_ =
      private_nh.advertise<std_msgs::String>("/zip_successed", 1, true);
  record_change_srv_ = private_nh.advertiseService(
      "/engineer/change_record", &Recorder::changeRecordSrv, this);

  return;
}

void Recorder::doTrigger() {
  ros::NodeHandle nh;
  ros::Publisher pub =
      nh.advertise<std_msgs::Empty>("snapshot_trigger", 1, true);
  pub.publish(std_msgs::Empty());

  ros::Timer terminate_timer =
      nh.createTimer(ros::Duration(1.0), boost::bind(&ros::shutdown));
  ros::spin();
}

void Recorder::setBagNames() {
  vector<string> parts;
  parts.clear();
  parts.reserve(50);

  std::string prefix = options_.prefix;
  size_t ind = prefix.rfind(".bag");

  if (ind != std::string::npos && ind == prefix.size() - 4) {
    ROS_INFO("[%s][%s][%d]:prefix file name %s", node_name_str_.c_str(),
             __func__, __LINE__, prefix.c_str());
    prefix.erase(ind);
  }

  // ROS_INFO("[%s][%s][%d]:prefix file name %s",prefix.c_str());
  if (prefix.length() > 0) {
    parts.push_back(prefix);
  }

  if (options_.split) {
    parts.push_back(split_name_);
  }

  if (options_.append_date) {
    parts.push_back(timeToStr(ros::WallTime::now()));
  }

  if (parts.size() == 0) {
    throw BagException(
        "Bag filename is empty (neither of these was specified: prefix, "
        "append_date, split)");
  }

  target_filename_ = parts[0];
  for (unsigned int i = 1; i < parts.size(); i++) {
    target_filename_ += parts[i];
  }

  target_filename_ += string(".bag");
  write_filename_ = target_filename_ + string(".active");
  ROS_INFO("[%s][%s][%d]:file name %s", node_name_str_.c_str(), __func__,
           __LINE__, write_filename_.c_str());
}

void Recorder::startWriting() {
  bag_.setCompression(options_.compression);
  bag_.setChunkThreshold(options_.chunk_size);

  setBagNames();

  try {
    bag_.open(write_filename_, bagmode::Write);
  } catch (log_and_bag_server::BagException e) {
    ROS_ERROR("[%s][%s][%d]:Error writing: %s", node_name_str_.c_str(),
              __func__, __LINE__, e.what());
    exit_code_ = 1;
    ros::shutdown();
  }

  ROS_INFO("[%s][%s][%d]:Recording to %s.", node_name_str_.c_str(), __func__,
           __LINE__, target_filename_.c_str());
}

void Recorder::stopWriting() {
  ROS_INFO("[%s][%s][%d]:Closing %s.", node_name_str_.c_str(), __func__,
           __LINE__, target_filename_.c_str());
  bag_.close();
  rename(write_filename_.c_str(), target_filename_.c_str());
}

bool Recorder::checkDisk() {
#if BOOST_FILESYSTEM_VERSION < 3
  struct statvfs fiData;
  if ((statvfs(bag_.getFileName().c_str(), &fiData)) < 0) {
    ROS_WARN("[%s][%s][%d]:Failed to check filesystem status.");
    return true;
  }
  unsigned long long free_space = 0;
  free_space = (unsigned long long)(fiData.f_bsize) *
               (unsigned long long)(fiData.f_bavail);
  if (free_space < options_.min_space) {
    ROS_ERROR_THROTTLE(15.0,
                       "[%s][%s][%d]:Less than %s of space free on disk with "
                       "%s.  Disabling recording.",
                       options_.min_space_str.c_str(),
                       bag_.getFileName().c_str());
    enable_write_ = false;
    return false;
  } else if (free_space < 3 * options_.min_space) {
    ROS_WARN_THROTTLE(
        30.0, "[%s][%s][%d]:Less than 3 x %s of space free on disk with %s.",
        options_.min_space_str.c_str(), bag_.getFileName().c_str());
  } else {
    enable_write_ = true;
  }
#else
  boost::filesystem::path p(
      boost::filesystem::system_complete(bag_.getFileName().c_str()));
  p = p.parent_path();
  boost::filesystem::space_info info;

  try {
    info = boost::filesystem::space(p);
  } catch (boost::filesystem::filesystem_error& e) {
    ROS_WARN("[%s][%s][%d]:Failed to check filesystem status [%s].",
             node_name_str_.c_str(), __func__, __LINE__, e.what());
    enable_write_ = false;
    return false;
  }

  if (info.available < options_.min_space) {
    ROS_ERROR_THROTTLE(15.0,
                       "[%s][%s][%d]:Less than %s of space free on disk with "
                       "%s.  Disabling recording.",
                       node_name_str_.c_str(), __func__, __LINE__,
                       options_.min_space_str.c_str(),
                       bag_.getFileName().c_str());
    enable_write_ = false;
    return false;
  } else if (info.available < 5 * options_.min_space) {
    ROS_WARN_THROTTLE(
        30.0, "[%s][%s][%d]:Less than 5 x %s of space free on disk with %s.",
        node_name_str_.c_str(), __func__, __LINE__,
        options_.min_space_str.c_str(), bag_.getFileName().c_str());
    enable_write_ = true;
  } else {
    enable_write_ = true;
  }

#endif
  return true;
}

bool Recorder::checkLogging() {
  if (enable_write_) return true;

  ros::WallTime now = ros::WallTime::now();
  if (now >= warn_next_) {
    warn_next_ = now + ros::WallDuration().fromSec(5.0);
    ROS_WARN(
        "[%s][%s][%d]:Not logging message because logging disabled.  Most "
        "likely cause is a full disk.",
        node_name_str_.c_str(), __func__, __LINE__);
  }
  return false;
}

bool Recorder::scheduledCheckDisk() {
  boost::mutex::scoped_lock lock(check_disk_mutex_);
  if (ros::WallTime::now() < check_disk_next_) return true;
  check_disk_next_ += ros::WallDuration().fromSec(20.0);
  return checkDisk();
}

bool Recorder::checkDuration(const ros::Time& t) {
  if (options_.max_duration > ros::Duration(0)) {
    if (t - start_time_ > options_.max_duration) {
      if (options_.split) {
        while (start_time_ + options_.max_duration < t) {
          stopWriting();
          split_count_++;
          start_time_ += options_.max_duration;
          startWriting();
        }
      } else {
        ros::shutdown();
        return true;
      }
    }
  }
  return false;
}

bool Recorder::checkSize() {
  static int last_record_state = 0;
  static ros::Time errorcode_happen_time = ros::Time::now();
  static bool last_errorcode_happened = false;

  bool enable_record_varlog = false;
  bool enable_record_opennilog = false;
  std::string all_tar_log_info_str = "";

  if (!last_errorcode_happened && errorcode_happened_) {
    errorcode_happen_time = ros::Time::now();
    last_errorcode_happened = true;
  }

  if ((options_.max_size > 0 || errorcode_happened_) && !engineer_happened_) {
    if (last_record_state != 0) {
      last_record_state = 0;
      stopWriting();
      split_name_ = "last";
      startWriting();
    }

    if (bag_.getSize() > options_.max_size ||
        (errorcode_happened_ &&
         (ros::Time::now() - errorcode_happen_time).toSec() >
             ud_errorcode_extend_record_time_)) {
      if (options_.split) {
        stopWriting();
        if (errorcode_happened_) {
          last_errorcode_happened = false;
          errorcode_happened_ = false;
          errorcode_count_++;

          std::string bag_path = "/home/ubuntu/log_bag";
          char cmd[512];
          memset(cmd, 0, 512);
          sprintf(cmd, "find %s -name 'karto*' -delete", std_path_.c_str());
          system(cmd);
          memset(cmd, 0, 512);
          sprintf(cmd, "find %s -name 'karto*' -delete", bag_path.c_str());
          system(cmd);

          std::string current_name =
              options_.prefix + current_split_name_ + string(".bag");
          std::string last_name =
              options_.prefix + last_split_name_ + string(".bag");
          std::string unknow_last =
              options_.prefix + last_split_name_ + string("_unknow.bag");
          std::string unknow_current =
              options_.prefix + current_split_name_ + string("_unknow.bag");

          std::string log_name = log_name_ + string("*");
          std::string log_name_terminal = options_.prefix + string(".log.txt");

          std::string error_tar_name;
          if (error_code_ == unknow_error_name_ ||
              error_code_ == log_out_error_name_) {
            error_tar_name = error_code_;
          } else {
            error_tar_name =
                error_code_ + "_" + std::to_string(errorcode_count_);
          }

          std::string zip = options_.ftp_path + "error_bag" + "_" +
                            error_tar_name + string(".tar");
          std::string pack = options_.unknow_error_path;
          std::string error_log_name_ = log_name_ + "." + error_code_;

          // 系统日志及opennilog 判定是否记录 20220917 Gilbert Add
          enable_record_varlog =
              findNeedRecord(error_code_, record_varlog_errorcode_vector_);
          enable_record_opennilog =
              findNeedRecord(error_code_, record_opennilog_errorcode_vector_);

          if (enable_record_varlog) {
            memset(cmd, 0, 512);
            sprintf(cmd, "echo 123 | sudo -S tar czf %s %s",
                    ud_var_log_tar_name_.c_str(), system_path_.c_str());
            system(cmd);

            memset(cmd, 0, 512);
            sprintf(cmd, "echo 123 | sudo -S chmod 777 %s",
                    ud_var_log_tar_name_.c_str());
            system(cmd);
          }

          memset(cmd, 0, 512);
          std::fstream f1, f2;
          f1.open(current_name, std::ios::in);
          f2.open(last_name, std::ios::in);

          if (f1 && !f2) {
            ROS_INFO("[%s][%s][%d]:only %s exist!", node_name_str_.c_str(),
                     __func__, __LINE__, current_name.c_str());

            if (error_code_ == unknow_error_name_) {
              sprintf(cmd, "mv %s %s", current_name.c_str(),
                      unknow_current.c_str());
              system(cmd);
            } else if (error_code_ == log_out_error_name_) {
              sprintf(cmd, "echo 123 | sudo -S tar czf %s %s", zip.c_str(),
                      system_path_.c_str());
              system(cmd);

              memset(cmd, 0, 512);
              sprintf(cmd, "echo 123 | sudo -S chmod 777 %s", zip.c_str());
            } else {
              all_tar_log_info_str.append(zip);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(log_name);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(rename_name_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(current_name);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(std_path_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(log_name_terminal);
              all_tar_log_info_str.append(" ");

              if (enable_record_opennilog) {
                all_tar_log_info_str.append(ud_opennilog_path_);
                all_tar_log_info_str.append(" ");
              }
              if (enable_record_varlog) {
                all_tar_log_info_str.append(ud_var_log_tar_name_);
                all_tar_log_info_str.append(" ");
              }
              sprintf(cmd, "tar czf %s", all_tar_log_info_str.c_str());
            }
          } else if (!f1 && f2) {
            ROS_WARN("[%s][%s][%d]:only %s exist!", node_name_str_.c_str(),
                     __func__, __LINE__, last_name.c_str());

            if (error_code_ == unknow_error_name_) {
              sprintf(cmd, "mv %s %s ", rename_name_.c_str(),
                      unknow_last.c_str());
              system(cmd);
            } else if (error_code_ == log_out_error_name_) {
              sprintf(cmd, "echo 123 | sudo -S tar czf %s %s", zip.c_str(),
                      system_path_.c_str());
              system(cmd);

              memset(cmd, 0, 512);
              sprintf(cmd, "echo 123 | sudo -S chmod 777 %s", zip.c_str());
            } else {
              all_tar_log_info_str.append(zip);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(log_name);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(rename_name_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(current_name);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(std_path_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(log_name_terminal);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(ud_depth_camera_pictures_path_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(ud_shell_log_path_);
              all_tar_log_info_str.append(" ");

              if (enable_record_opennilog) {
                all_tar_log_info_str.append(ud_opennilog_path_);
                all_tar_log_info_str.append(" ");
              }
              if (enable_record_varlog) {
                all_tar_log_info_str.append(ud_var_log_tar_name_);
                all_tar_log_info_str.append(" ");
              }
              sprintf(cmd, "tar czf %s", all_tar_log_info_str.c_str());
            }
          } else {
            ROS_WARN("[%s][%s][%d]:%s %s exist!", node_name_str_.c_str(),
                     __func__, __LINE__, last_name.c_str(),
                     current_name.c_str());

            if (error_code_ == unknow_error_name_) {
              sprintf(cmd, "mv %s %s ", current_name.c_str(),
                      unknow_current.c_str());
              system(cmd);

              memset(cmd, 0, 512);
              sprintf(cmd, "mv %s %s ", rename_name_.c_str(),
                      unknow_last.c_str());
              system(cmd);
            } else if (error_code_ == log_out_error_name_) {
              sprintf(cmd, "echo 123 | sudo -S tar czf %s %s %s %s",
                      zip.c_str(), system_path_.c_str());
              system(cmd);

              memset(cmd, 0, 512);
              sprintf(cmd, "echo 123 | sudo -S chmod 777 %s", zip.c_str());
            } else {
              all_tar_log_info_str.append(zip);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(log_name);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(rename_name_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(current_name);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(std_path_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(log_name_terminal);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(ud_depth_camera_pictures_path_);
              all_tar_log_info_str.append(" ");
              all_tar_log_info_str.append(ud_shell_log_path_);
              all_tar_log_info_str.append(" ");

              if (enable_record_opennilog) {
                all_tar_log_info_str.append(ud_opennilog_path_);
                all_tar_log_info_str.append(" ");
              }
              if (enable_record_varlog) {
                all_tar_log_info_str.append(ud_var_log_tar_name_);
                all_tar_log_info_str.append(" ");
              }
              sprintf(cmd, "tar czf %s", all_tar_log_info_str.c_str());
            }
          }

          int zip_successed = system(cmd);
          ROS_WARN("[%s][%s][%d]:tar cmd :%s return = %d",
                   node_name_str_.c_str(), __func__, __LINE__, cmd,
                   zip_successed);

          // 清除打包的系统日志 Gilbert Add , 20220917
          if (enable_record_varlog) {
            system((std::string("rm -r ") + ud_var_log_tar_name_).c_str());
          }

          if (error_code_ != unknow_error_name_) {
            memset(cmd, 0, 512);
            string upload = script_name_ + " " + "error_bag" + "_" +
                            error_tar_name + string(".tar");
            sprintf(cmd, upload.c_str());

            ROS_INFO("[%s][%s][%d]:sh cmd :%s ", node_name_str_.c_str(),
                     __func__, __LINE__, cmd);

            if (!system(cmd)) {
              std::string tar_name =
                  "error_bag_" + error_tar_name + string(".tar");
              std_msgs::String msg;
              msg.data = tar_name;
              zip_success_pub_.publish(msg);

              memset(cmd, 0, 512);
              sprintf(cmd, "rm -r %s %s %s %s", zip.c_str(),
                      error_log_name_.c_str(), rename_name_.c_str(),
                      current_name.c_str());
              system(cmd);

              ROS_INFO("[%s][%s][%d]:remove cmd :%s ", node_name_str_.c_str(),
                       __func__, __LINE__, cmd);
            } else {
              ROS_ERROR("[%s][%s][%d]:send bag to ftp failed!",
                        node_name_str_.c_str(), __func__, __LINE__);
            }
          }
        } else {
          split_count_++;
          split_name_ = current_split_name_;
          if (split_count_ > 1) {
            if (!rename(target_filename_.c_str(), rename_name_.c_str())) {
              ROS_INFO("[%s][%s][%d]:rename %s bag success",
                       node_name_str_.c_str(), __func__, __LINE__,
                       target_filename_.c_str());
            } else {
              ROS_ERROR("[%s][%s][%d]:can't rename %s bag",
                        node_name_str_.c_str(), __func__, __LINE__,
                        target_filename_.c_str());
            }
          }
        }
        startWriting();
      } else {
        ros::shutdown();
        return true;
      }
    }
  } else {
    if (engineer_happened_ && engineer_happened_state_) {
      engineer_happened_state_ = false;
      last_record_state = 1;
      stopWriting();

      char cmd[512];
      memset(cmd, 0, 512);
      std::string bag_path = "/home/ubuntu/log_bag/*";
      std::string bag_name = "karto_map";
      sprintf(cmd, "rm -rf %s", bag_path.c_str());
      system(cmd);

      split_name_ = bag_name;
      startWriting();
      ROS_INFO("[%s][%s][%d]:record bag success", node_name_str_.c_str(),
               __func__, __LINE__);
    }
  }
  return false;
}

bool Recorder::findNeedRecord(
    const std::string& cur_error_code,
    const std::vector<std::string>& vec_errorcode) const {
  auto iter =
      std::find(vec_errorcode.begin(), vec_errorcode.end(), cur_error_code);

  if (iter != vec_errorcode.end()) {
    return true;
  }
  return false;
}

bool Recorder::isSubscribed(string const& topic) const {
  return currently_recording_.find(topic) != currently_recording_.end();
}

shared_ptr<ros::Subscriber> Recorder::subscribe(string const& topic) {
  ROS_INFO("[%s][%s][%d]:Subscribing to %s", node_name_str_.c_str(), __func__,
           __LINE__, topic.c_str());

  shared_ptr<int> count(boost::make_shared<int>(options_.limit));
  shared_ptr<ros::Subscriber> sub(boost::make_shared<ros::Subscriber>());

  ros::SubscribeOptions ops;
  ops.topic = topic;
  ops.queue_size = 10;
  ops.md5sum = ros::message_traits::md5sum<topic_tools::ShapeShifter>();
  ops.datatype = ros::message_traits::datatype<topic_tools::ShapeShifter>();
  ops.helper = boost::make_shared<ros::SubscriptionCallbackHelperT<
      const ros::MessageEvent<topic_tools::ShapeShifter const>&> >(
      boost::bind(&Recorder::doQueue, this, _1, topic, sub, count));

  ros::NodeHandle private_nh("~");
  *sub = private_nh.subscribe(ops);
  currently_recording_.insert(topic);
  num_subscribers_++;
  return sub;
}

// Callback to be invoked to save messages into a queue
void Recorder::doQueue(
    const ros::MessageEvent<topic_tools::ShapeShifter const>& msg_event,
    string const& topic, shared_ptr<ros::Subscriber> subscriber,
    shared_ptr<int> count) {
  Time rectime = Time::now();

  if (options_.verbose)
    cout << "Received message on topic " << subscriber->getTopic() << endl;

  OutgoingMessage out(topic, msg_event.getMessage(),
                      msg_event.getConnectionHeaderPtr(), rectime);

  {
    boost::mutex::scoped_lock lock(queue_mutex_);
    queue_->push(out);
    queue_size_ += out.msg->size();

    // Check to see if buffer has been exceeded
    while (options_.buffer_size > 0 && queue_size_ > options_.buffer_size) {
      OutgoingMessage drop = queue_->front();
      queue_->pop();
      queue_size_ -= drop.msg->size();

      if (!options_.snapshot) {
        Time now = Time::now();
        if (now > last_buffer_warn_ + ros::Duration(5.0)) {
          ROS_WARN(
              "[%s][%s][%d]:rosbag record buffer exceeded.  Dropping oldest "
              "queued message.",
              node_name_str_.c_str(), __func__, __LINE__);
          last_buffer_warn_ = now;
        }
      }
    }
  }

  if (!options_.snapshot) queue_condition_.notify_all();

  // If we are book-keeping count, decrement and possibly shutdown
  if ((*count) > 0) {
    (*count)--;
    if ((*count) == 0) {
      subscriber->shutdown();

      num_subscribers_--;

      if (num_subscribers_ == 0) ros::shutdown();
    }
  }
}

// Thread that actually does writing to file.
void Recorder::doRecord() {
  // Open bag file for writing
  startWriting();

  // Schedule the disk space check
  warn_next_ = ros::WallTime();
  checkDisk();
  check_disk_next_ = ros::WallTime::now() + ros::WallDuration().fromSec(20.0);

  // Technically the queue_mutex_ should be locked while checking empty.
  // Except it should only get checked if the node is not ok, and thus
  // it shouldn't be in contention.
  while (ros::ok() || !queue_->empty()) {
    boost::unique_lock<boost::mutex> lock(queue_mutex_);

    bool finished = false;
    while (queue_->empty()) {
      if (!ros::ok()) {
        lock.release()->unlock();
        finished = true;
        break;
      }
      boost::xtime xt;
#if BOOST_VERSION >= 105000
      boost::xtime_get(&xt, boost::TIME_UTC_);
#else
      boost::xtime_get(&xt, boost::TIME_UTC);
#endif
      xt.nsec += 250000000;
      queue_condition_.timed_wait(lock, xt);
      if (checkDuration(ros::Time::now())) {
        finished = true;
        break;
      }
    }

    if (finished) break;

    OutgoingMessage out = queue_->front();
    queue_->pop();
    queue_size_ -= out.msg->size();

    lock.release()->unlock();

    if (checkSize()) break;

    if (checkDuration(out.time)) break;

    if (scheduledCheckDisk() && checkLogging()) {
      bag_.write(out.topic, out.time, *out.msg, out.connection_header);
    }
  }

  ROS_INFO("[%s][%s][%d]:stop record!", node_name_str_.c_str(), __func__,
           __LINE__);
  stopWriting();
}

void Recorder::doRecordSnapshotter() {
  while (ros::ok() || !queue_queue_.empty()) {
    boost::unique_lock<boost::mutex> lock(queue_mutex_);

    while (queue_queue_.empty()) {
      if (!ros::ok()) return;
      queue_condition_.wait(lock);
    }

    OutgoingQueue out_queue = queue_queue_.front();
    queue_queue_.pop();

    lock.release()->unlock();

    string target_filename = out_queue.filename;
    string write_filename = target_filename + string(".active");

    try {
      bag_.open(write_filename, bagmode::Write);
    } catch (log_and_bag_server::BagException ex) {
      ROS_ERROR("[%s][%s][%d]:Error writing: %s", node_name_str_.c_str(),
                __func__, __LINE__, ex.what());
      return;
    }

    while (!out_queue.queue->empty()) {
      OutgoingMessage out = out_queue.queue->front();
      out_queue.queue->pop();

      bag_.write(out.topic, out.time, *out.msg);
    }

    stopWriting();
  }
}

// Callback to be invoked to actually do the recording
void Recorder::snapshotTrigger(std_msgs::Empty::ConstPtr trigger) {
  (void)trigger;
  setBagNames();

  ROS_INFO("[%s][%s][%d]:Triggered snapshot recording with name %s.",
           node_name_str_.c_str(), __func__, __LINE__,
           target_filename_.c_str());

  {
    boost::mutex::scoped_lock lock(queue_mutex_);
    queue_queue_.push(OutgoingQueue(target_filename_, queue_, Time::now()));
    queue_ = new std::queue<OutgoingMessage>;
    queue_size_ = 0;
  }

  queue_condition_.notify_all();
}

void Recorder::doCheckMaster(ros::TimerEvent const& e,
                             ros::NodeHandle& node_handle) {
  (void)e;
  (void)node_handle;
  ros::master::V_TopicInfo topics;
  if (ros::master::getTopics(topics)) {
    foreach (ros::master::TopicInfo const& t, topics) {
      if (shouldSubscribeToTopic(t.name)) subscribe(t.name);
    }
  }

  if (options_.node != std::string("")) {
    XmlRpc::XmlRpcValue req;
    req[0] = ros::this_node::getName();
    req[1] = options_.node;
    XmlRpc::XmlRpcValue resp;
    XmlRpc::XmlRpcValue payload;

    if (ros::master::execute("lookupNode", req, resp, payload, true)) {
      std::string peer_host;
      uint32_t peer_port;

      if (!ros::network::splitURI(static_cast<std::string>(resp[2]), peer_host,
                                  peer_port)) {
        ROS_ERROR(
            "[%s][%s][%d]:Bad xml-rpc URI trying to inspect node at: [%s]",
            node_name_str_.c_str(), __func__, __LINE__,
            static_cast<std::string>(resp[2]).c_str());
      } else {
        XmlRpc::XmlRpcClient c(peer_host.c_str(), peer_port, "/");
        XmlRpc::XmlRpcValue req2;
        XmlRpc::XmlRpcValue resp2;
        req2[0] = ros::this_node::getName();
        c.execute("getSubscriptions", req2, resp2);

        if (!c.isFault() && resp2.valid() && resp2.size() > 0 &&
            static_cast<int>(resp2[0]) == 1) {
          for (int i = 0; i < resp2[2].size(); i++) {
            if (shouldSubscribeToTopic(resp2[2][i][0], true))
              subscribe(resp2[2][i][0]);
          }
        } else {
          ROS_ERROR(
              "[%s][%s][%d]:Node at: [%s] failed to return subscriptions.",
              node_name_str_.c_str(), __func__, __LINE__,
              static_cast<std::string>(resp[2]).c_str());
        }
      }
    }
  }
}

bool Recorder::shouldSubscribeToTopic(std::string const& topic,
                                      bool from_node) {
  // ignore already known topics
  if (isSubscribed(topic)) {
    return false;
  }

  // subtract exclusion regex, if any
  if (options_.do_exclude &&
      boost::regex_match(topic, options_.exclude_regex)) {
    return false;
  }

  if (options_.record_all || from_node) {
    return true;
  }

  if (options_.regex) {
    // Treat the topics as regular expressions
    foreach (string const& regex_str, options_.topics) {
      boost::regex e(regex_str);
      boost::smatch what;
      if (boost::regex_match(topic, what, e, boost::match_extra)) return true;
    }
  } else {
    foreach (string const& t, options_.topics)
      if (t == topic) return true;
  }

  return false;
}

int Recorder::run() {
  if (options_.trigger) {
    doTrigger();
    return 0;
  }

  if (options_.topics.size() == 0) {
    // Make sure limit is not specified with automatic topic subscription
    if (options_.limit > 0) {
      fprintf(stderr,
              "Specifing a count is not valid with automatic topic "
              "subscription.\n");
      return 1;
    }

    // Make sure topics are specified
    if (!options_.record_all && (options_.node == std::string(""))) {
      fprintf(stderr, "No topics specified.\n");
      return 1;
    }
  }

  if (!ros::ok()) return 0;

  rename_name_ = options_.prefix + last_split_name_ + string(".bag");
  last_buffer_warn_ = Time();
  queue_ = new std::queue<OutgoingMessage>;

  // Subscribe to each topic
  sub_list_.clear();
  if (!options_.regex) {
    foreach (string const& topic, options_.topics) {
      sub_list_.push_back(subscribe(topic));
    }
  }

  if (!ros::Time::waitForValid(ros::WallDuration(2.0))) {
    ROS_WARN(
        "[%s][%s][%d]:/use_sim_time set to true and no clock published.  Still "
        "waiting for valid time...",
        node_name_str_.c_str(), __func__, __LINE__);
  }

  ros::Time::waitForValid();
  start_time_ = ros::Time::now();

  // Don't bother doing anything if we never got a valid time
  if (!ros::ok()) return 0;

  ros::NodeHandle private_nh("~");
  // Spin up a thread for writing to the file
  boost::thread record_thread;
  if (options_.snapshot) {
    record_thread =
        boost::thread(boost::bind(&Recorder::doRecordSnapshotter, this));

    // Subscribe to the snapshot trigger
    auto trigger_sub = private_nh.subscribe<std_msgs::Empty>(
        "snapshot_trigger", 100,
        boost::bind(&Recorder::snapshotTrigger, this, _1));
  } else {
    record_thread = boost::thread(boost::bind(&Recorder::doRecord, this));
  }

  if (options_.record_all || options_.regex ||
      (options_.node != std::string(""))) {
    // check for master first
    doCheckMaster(ros::TimerEvent(), private_nh);
    auto check_master_timer = private_nh.createTimer(
        ros::Duration(1.0), boost::bind(&Recorder::doCheckMaster, this, _1,
                                        boost::ref(private_nh)));
  }

  ros::spin();
  queue_condition_.notify_all();
  record_thread.join();
  delete queue_;
  return exit_code_;
}

void Recorder::errorcodeCB(const std_msgs::StringConstPtr& msg) {
  errorcode_happened_ = true;
  error_code_ = msg->data;
  ROS_INFO("[%s][%s][%d]:monitor error code = %s, backup log and bag to swj!",
           node_name_str_.c_str(), __func__, __LINE__, error_code_.c_str());
}

bool Recorder::changeRecordSrv(custom_msgs_srvs::Double::Request& req,
                               custom_msgs_srvs::Double::Response& res) {
  static double last_record_state = 0.0;
  if (req.data != last_record_state) {
    ROS_INFO("[%s][%s][%d]: get change record %f", node_name_str_.c_str(),
             __func__, __LINE__, req.data);
    last_record_state = req.data;
    if (req.data == 0.0) {  // 正常导航记录
      engineer_happened_state_ = engineer_happened_ = false;

      sub_list_.clear();
      foreach (string const& topic, options_.topics) {
        sub_list_.push_back(subscribe(topic));
      }
    } else if (req.data == 1.0) {  // 建图记录
      engineer_happened_state_ = engineer_happened_ = true;
      foreach (shared_ptr<ros::Subscriber> const& topic, sub_list_)
        topic->shutdown();
      currently_recording_.clear();
      num_subscribers_ = 0;
      subscribe("/scan");
      subscribe("odom");
      subscribe("imu_data");
      subscribe("tf");
      subscribe("/rosout");
    } else if (req.data == 2.0) {  // 清空，无记录
      foreach (shared_ptr<ros::Subscriber> const& topic, sub_list_)
        topic->shutdown();
      currently_recording_.clear();
      num_subscribers_ = 0;
      engineer_happened_state_ = engineer_happened_ = false;
    }
  }

  return true;
}

}  // namespace log_and_bag_server
