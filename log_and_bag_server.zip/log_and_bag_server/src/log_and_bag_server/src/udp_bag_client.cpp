#include <arpa/inet.h>   // for inet_aton
#include <netinet/in.h>  // for sockaddr_in
#include <pthread.h>     // thread_t, pthread_create
#include <stdio.h>       // for printf
#include <stdlib.h>      // for exit
#include <string.h>      // for bzero
#include <sys/socket.h>  // for socket
#include <sys/types.h>   // for socket
#include <unistd.h>      // for fork,getpid,close

// c++ headers
#include <ros/ros.h>
#include <std_msgs/String.h>

#include <iostream>
#include <map>
#include <vector>

#include "id_cmd_def.h"

// namespace
using namespace syscom;

#define HELLO_WORLD_SERVER_PORT 6022
#define CLIENT_PORT 6003
#define BUFFER_SIZE 128
#define DEFAULT_HOST_IP "192.168.168.110"

ros::Publisher active_acquisition_pub_;
ros::Subscriber zip_state_sub_;
bool initialed_;
bool timeout_resend_;
int swj_reply_count;
int client_socket;
unsigned char bag_buf_[BUFFER_SIZE];
std::string tar_name;
std::string node_name_str_;  // 本程序的节点名字，用于log打印
struct sockaddr_in update_client_addr;
struct sockaddr_in server_addr;
socklen_t addr_length;
socklen_t server_addr_length;

bool paramsInitize() {
  node_name_str_ = ros::this_node::getName();
  initialed_ = false;
  timeout_resend_ = true;
  swj_reply_count = 0;
  bzero(bag_buf_, BUFFER_SIZE);

  return true;
}

int readable_timeo(int fd, int sec) {
  fd_set rset;
  struct timeval tv;

  FD_ZERO(&rset);
  FD_SET(fd, &rset);

  tv.tv_sec = sec;
  tv.tv_usec = 0;

  return (select(fd + 1, &rset, NULL, NULL, &tv));
}

int calculateChecksum(unsigned char *buf, int size) {
  int checksum = 0;

  for (int i = 0; i < size; i++) {
    checksum += buf[i];
  }

  // printf("checksum[%d %d %d %d]\n", checksum & 0xff, (checksum >> 8) & 0xff,
  // (checksum >> 16) & 0xff, (checksum >> 24) & 0xff);
  return checksum;
}

// 数据转发线程体
void *data_recv(void *p) {
  int fd = *((int *)p);
  int res = 30;
  // int length;
  char buffer[BUFFER_SIZE];
  addr_length = sizeof(sockaddr_in);

  while (1) {
    int rt = readable_timeo(fd, 5);
    if (rt > 0) {
      bzero(buffer, BUFFER_SIZE);
      //        length = recv(fd, buffer, BUFFER_SIZE, 0);
      int length =
          recvfrom(fd, buffer, sizeof(buffer), 0,
                   (struct sockaddr *)&update_client_addr, &addr_length);
      timeout_resend_ = true;
      if (length <= 0) {
        ROS_ERROR("[%s][%s][%d]:Get data failed!", node_name_str_.c_str(),
                  __func__, __LINE__);
        // break;
        sleep(1);
      }

      for (int i = 0; i < length; i++) {
        printf("%d ", buffer[i]);
      }
      printf("\n");

      int head_1 = buffer[0];
      int head_2 = buffer[1];
      if (head_1 == 0x55 && head_2 == 0x55) {
        int cmd =
            buffer[2] | buffer[3] << 8 | buffer[4] << 16 | buffer[5] << 24;

        if (swj_reply_count) {
          // swj error code zip reply
          if (cmd == CMD_ACK_OK) {
            swj_reply_count = 0;
            ROS_INFO("[%s][%s][%d]:reply swj error bag ok!",
                     node_name_str_.c_str(), __func__, __LINE__);
          } else if (swj_reply_count > 2) {
            swj_reply_count = 0;
            ROS_ERROR("[%s][%s][%d]:reply swj count = %d!",
                      node_name_str_.c_str(), __func__, __LINE__,
                      swj_reply_count);
          } else {
            swj_reply_count++;
            // resend once
            ROS_WARN("[%s][%s][%d]:reply error, resend count = %d!",
                     node_name_str_.c_str(), __func__, __LINE__,
                     swj_reply_count);

            int str_len = tar_name.length();
            char data[32];
            strcpy(data, tar_name.c_str());
            buffer[6] = 4;
            buffer[10] = 22;
            memcpy(&buffer[2], &res, 4);
            memcpy(&buffer[18], &str_len, 4);
            memcpy(&buffer[22], data, str_len);
            if (!(sendto(fd, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&update_client_addr,
                         addr_length) == BUFFER_SIZE)) {
              ROS_ERROR("[%s][%s][%d]:send ack msg failed!",
                        node_name_str_.c_str(), __func__, __LINE__);
            }
          }
        } else {
          if (cmd == CMD_START_LOGGING) {
            ROS_INFO("[%s][%s][%d]:start active recording!",
                     node_name_str_.c_str(), __func__, __LINE__);
            std_msgs::String s;
            s.data = "active_record";
            active_acquisition_pub_.publish(s);

            // active_record reply to swj
            buffer[2] = CMD_ACK_OK;
            buffer[6] = 4;
            buffer[10] = 22;
            if (!(sendto(fd, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&update_client_addr,
                         addr_length) == BUFFER_SIZE)) {
              ROS_ERROR("[%s][%s][%d]:send ack msg failed!",
                        node_name_str_.c_str(), __func__, __LINE__);
            }
          } else if (cmd == CMD_SYSTEM_LOGGING) {
            ROS_INFO("[%s][%s][%d]:start system var log!",
                     node_name_str_.c_str(), __func__, __LINE__);
            std_msgs::String s;
            s.data = "log_out";
            active_acquisition_pub_.publish(s);

            // log_out reply to swj
            buffer[2] = CMD_ACK_OK;
            buffer[6] = 4;
            buffer[10] = 22;
            if (!(sendto(fd, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&update_client_addr,
                         addr_length) == BUFFER_SIZE)) {
              ROS_ERROR("[%s][%s][%d]:send ack msg failed!",
                        node_name_str_.c_str(), __func__, __LINE__);
            }

          } else {
            ROS_ERROR("[%s][%s][%d]:wrong recordding cmd = %d",
                      node_name_str_.c_str(), __func__, __LINE__, cmd);
          }
        }

        //}
      } else {
        ROS_ERROR("[%s][%s][%d]:head_1 = %d head_2 = %d!",
                  node_name_str_.c_str(), __func__, __LINE__, head_1, head_2);
      }
    } else {
      if (timeout_resend_) {
        if (swj_reply_count) {
          if (swj_reply_count > 3) {
            swj_reply_count = 0;
            timeout_resend_ = false;
          }
          // timeout resend once
          ROS_WARN("[%s][%s][%d]:timeout, resend count = %d!",
                   node_name_str_.c_str(), __func__, __LINE__, swj_reply_count);

          int str_len = tar_name.length();
          char data[32];
          buffer[6] = 4;
          buffer[10] = 22;
          strcpy(data, tar_name.c_str());
          memcpy(&buffer[2], &res, 4);
          memcpy(&buffer[18], &str_len, 4);
          memcpy(&buffer[22], data, str_len);
          if (!(sendto(fd, buffer, sizeof(buffer), 0,
                       (struct sockaddr *)&update_client_addr,
                       addr_length) == BUFFER_SIZE)) {
            ROS_ERROR("[%s][%s][%d]:send ack msg failed!",
                      node_name_str_.c_str(), __func__, __LINE__);
          }
          swj_reply_count++;
        }
      }
    }
  }

  close(fd);
  exit(-1);
}

void zipstateCB(const std_msgs::String &msg) {
  swj_reply_count += 1;
  tar_name = msg.data;
  char data[32];
  strcpy(data, tar_name.c_str());
  int str_len = tar_name.length();
  int size = 20 + str_len;

  bag_buf_[0] = 0x55;
  bag_buf_[1] = 0x55;
  bag_buf_[2] = 30;
  bag_buf_[3] = 0;
  bag_buf_[4] = 0;
  bag_buf_[5] = 0;  // cmd
  bag_buf_[6] = 4;
  bag_buf_[7] = 0;
  bag_buf_[8] = 0;
  bag_buf_[9] = 0;  // src id
  bag_buf_[10] = 22;
  bag_buf_[11] = 0;
  bag_buf_[12] = 0;
  bag_buf_[13] = 0;  // target id
  bag_buf_[14] = 0;
  bag_buf_[15] = 0;
  bag_buf_[16] = 0;
  bag_buf_[17] = 0;  // seq
  memcpy(&bag_buf_[18], &str_len, 4);
  memcpy(&bag_buf_[22], data, str_len);
  int checksum = calculateChecksum(&bag_buf_[2], size);
  memcpy(&bag_buf_[size + 2], &checksum, 4);  // checksum
  bag_buf_[size + 6] = 0xaa;
  bag_buf_[size + 7] = 0xaa;
  if (!(sendto(client_socket, bag_buf_, sizeof(bag_buf_), 0,
               (struct sockaddr *)&server_addr,
               server_addr_length) == BUFFER_SIZE)) {
    ROS_ERROR("[%s][%s][%d]:send error bag msg failed!", node_name_str_.c_str(),
              __func__, __LINE__);
  }

  return;
}

int main(int argc, char **argv) {
  ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                 ros::console::levels::Info);
  ros::init(argc, argv, "udp_bag_client");
  paramsInitize();
  ros::NodeHandle n;

  active_acquisition_pub_ =
      n.advertise<std_msgs::String>("/ZWJ_nodes_state", 3);
  zip_state_sub_ = n.subscribe("/zip_successed", 3, zipstateCB);

  // 设置一个socket地址结构client_addr,代表客户机internet地址, 端口
  struct sockaddr_in client_addr;
  bzero(&client_addr, sizeof(client_addr));  // 把一段内存区的内容全部设置为0
  client_addr.sin_family = AF_INET;          // internet协议族
  client_addr.sin_addr.s_addr =
      htons(INADDR_ANY);                      // INADDR_ANY表示自动获取本机地址
  client_addr.sin_port = htons(CLIENT_PORT);  // 0表示让系统自动分配一个空闲端口

  // 创建用于internet的流协议(UDP)socket,用client_socket代表客户机socket
  client_socket = socket(AF_INET, SOCK_DGRAM, 0);
  if (client_socket < 0) {
    ROS_ERROR("[%s][%s][%d]:Create Socket Failed!", node_name_str_.c_str(),
              __func__, __LINE__);
    exit(1);
  }

  // 把客户机的socket和客户机的socket地址结构联系起来
  if (bind(client_socket, (struct sockaddr *)&client_addr,
           sizeof(client_addr))) {
    ROS_ERROR("[%s][%s][%d]:Client Bind Port Failed!", node_name_str_.c_str(),
              __func__, __LINE__);
    exit(1);
  }

  // 设置一个socket地址结构server_addr,代表服务器的internet地址, 端口

  bzero(&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;

  if (inet_aton(DEFAULT_HOST_IP, &server_addr.sin_addr) ==
      0) {  // 服务器的IP地址来自程序的参数
    ROS_ERROR("[%s][%s][%d]:Server IP Address Error!", node_name_str_.c_str(),
              __func__, __LINE__);
    exit(1);
  }

  server_addr.sin_port = htons(HELLO_WORLD_SERVER_PORT);
  server_addr_length = sizeof(server_addr);

  // 开启监听线程
  pthread_t thread;
  // 开启数据转发进程
  pthread_create(&thread, NULL, data_recv, &client_socket);

  ros::spin();

  // 关闭socket
  close(client_socket);

  return 0;
}
