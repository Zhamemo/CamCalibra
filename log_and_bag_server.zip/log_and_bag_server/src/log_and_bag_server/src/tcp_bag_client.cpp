#include <arpa/inet.h>   // for inet_aton
#include <netinet/in.h>  // for sockaddr_in
#include <pthread.h>     // thread_t, pthread_create
#include <stdio.h>       // for printf
#include <stdlib.h>      // for exit
#include <string.h>      // for bzero
#include <sys/socket.h>  // for socket
#include <sys/types.h>   // for socket
#include <unistd.h>      // for fork,getpid,close

// c++ headers
#include <ros/ros.h>
#include <std_msgs/String.h>

#include <iostream>
#include <map>
#include <vector>

#include "id_cmd_def.h"

// namespace
using namespace syscom;

#define HELLO_WORLD_SERVER_PORT 6000
#define BUFFER_SIZE 128
#define FILE_NAME_MAX_SIZE 16
#define DEFAULT_HOST_IP "192.168.168.100"

ros::Publisher active_acquisition_pub_;
ros::Subscriber zip_state_sub_;
bool initialed_ = false;
bool timeout_resend_ = true;
int swj_reply_count = 0;
std::string tar_name;
std::string node_name_str_;  // 本程序的节点名字，用于log打印

bool paramsInitize() {
  node_name_str_ = ros::this_node::getName();
  return true;
}

int readable_timeo(int fd, int sec) {
  fd_set rset;
  struct timeval tv;

  FD_ZERO(&rset);
  FD_SET(fd, &rset);

  tv.tv_sec = sec;
  tv.tv_usec = 0;

  return (select(fd + 1, &rset, NULL, NULL, &tv));
}

// 数据转发线程体
void *data_recv(void *p) {
  int fd = *((int *)p);
  int length;
  char buffer[BUFFER_SIZE];

  while (1) {
    int rt = readable_timeo(fd, 5);
    if (rt > 0) {
      bzero(buffer, BUFFER_SIZE);
      length = recv(fd, buffer, BUFFER_SIZE, 0);
      timeout_resend_ = true;
      if (length <= 0) {
        ROS_ERROR("[%s][%s][%d]:Get data failed!", node_name_str_.c_str(),
                  __func__, __LINE__);
        // break;
        sleep(1);
      }

      for (int i = 0; i < length; i++) {
        printf("%d ", buffer[i]);
      }
      printf("\n");

      int head_1 = buffer[0];
      int head_2 = buffer[1];
      if (head_1 == 0x55 && head_2 == 0x55) {
        int cmd =
            buffer[2] | buffer[3] << 8 | buffer[4] << 16 | buffer[5] << 24;
        if (!initialed_ && cmd == CMD_ACK_OK) {
          initialed_ = true;
        } else {
          if (swj_reply_count) {
            // swj error code zip reply
            if (cmd == CMD_ACK_OK) {
              swj_reply_count = 0;
              ROS_INFO("[%s][%s][%d]:reply swj error bag ok!",
                       node_name_str_.c_str(), __func__, __LINE__);
            } else if (swj_reply_count > 2) {
              swj_reply_count = 0;
              ROS_ERROR("[%s][%s][%d]:reply swj count = %d!",
                        node_name_str_.c_str(), __func__, __LINE__,
                        swj_reply_count);
            } else {
              swj_reply_count++;
              // resend once
              ROS_WARN("[%s][%s][%d]:reply error, resend count = %d!",
                       node_name_str_.c_str(), __func__, __LINE__,
                       swj_reply_count);
              char cmd[128];
              memset(cmd, 0, 128);
              std::string tcp_cmd = "/home/ubuntu/update/msg_sender";
              sprintf(cmd, "%s 30 0 5 %s", tcp_cmd.c_str(), tar_name.c_str());
              ROS_INFO("[%s][%s][%d]: %d cmd: %s ", node_name_str_.c_str(),
                       __func__, __LINE__, swj_reply_count, cmd);
              system(cmd);
            }
          } else {
            if (cmd == CMD_START_LOGGING) {
              ROS_INFO("[%s][%s][%d]:start active recording!",
                       node_name_str_.c_str(), __func__, __LINE__);
              std_msgs::String s;
              s.data = "active_record";
              active_acquisition_pub_.publish(s);

              // active_record reply to swj
              char cmd[128];
              memset(cmd, 0, 128);
              std::string tcp_cmd = "/home/ubuntu/update/msg_sender";
              sprintf(cmd, "%s %d 0 5", tcp_cmd.c_str(), CMD_ACK_OK);
              ROS_INFO("[%s][%s][%d]: %d cmd: %s", node_name_str_.c_str(),
                       __func__, __LINE__, swj_reply_count, cmd);
              system(cmd);
            } else {
              ROS_ERROR("[%s][%s][%d]:wrong recordding cmd = %d",
                        node_name_str_.c_str(), __func__, __LINE__, cmd);
            }
          }
        }
      } else {
        ROS_ERROR("[%s][%s][%d]:head_1 = %d head_2 = %d!",
                  node_name_str_.c_str(), __func__, __LINE__, head_1, head_2);
      }
    } else {
      if (timeout_resend_) {
        if (swj_reply_count) {
          if (swj_reply_count > 3) {
            swj_reply_count = 0;
            timeout_resend_ = false;
          }
          // timeout resend once
          ROS_WARN("[%s][%s][%d]:timeout, resend count = %d!",
                   node_name_str_.c_str(), __func__, __LINE__, swj_reply_count);
          char cmd[128];
          memset(cmd, 0, 128);
          std::string tcp_cmd = "/home/ubuntu/update/msg_sender";
          sprintf(cmd, "%s 30 0 5 %s", tcp_cmd.c_str(), tar_name.c_str());
          ROS_INFO(" [%s][%s][%d]: %d cmd: %s", node_name_str_.c_str(),
                   __func__, __LINE__, swj_reply_count, cmd);
          system(cmd);
          swj_reply_count++;
        }
      }
    }
  }

  close(fd);
  exit(-1);
}

void zipstateCB(const std_msgs::String &msg) {
  swj_reply_count += 1;
  tar_name = msg.data;
  return;
}

int main(int argc, char **argv) {
  ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                 ros::console::levels::Info);
  ros::init(argc, argv, "tcp_bag_client");
  paramsInitize();
  ros::NodeHandle n;

  active_acquisition_pub_ =
      n.advertise<std_msgs::String>("/ZWJ_nodes_state", 3);
  zip_state_sub_ = n.subscribe("/zip_successed", 3, zipstateCB);

  // 设置一个socket地址结构client_addr,代表客户机internet地址, 端口
  struct sockaddr_in client_addr;
  bzero(&client_addr, sizeof(client_addr));  // 把一段内存区的内容全部设置为0
  client_addr.sin_family = AF_INET;          // internet协议族
  client_addr.sin_addr.s_addr =
      htons(INADDR_ANY);            // INADDR_ANY表示自动获取本机地址
  client_addr.sin_port = htons(0);  // 0表示让系统自动分配一个空闲端口

  // 创建用于internet的流协议(TCP)socket,用client_socket代表客户机socket
  int client_socket = socket(AF_INET, SOCK_STREAM, 0);
  if (client_socket < 0) {
    ROS_ERROR("[%s][%s][%d]:Create Socket Failed!", node_name_str_.c_str(),
              __func__, __LINE__);
    exit(1);
  }

  // 把客户机的socket和客户机的socket地址结构联系起来
  if (bind(client_socket, (struct sockaddr *)&client_addr,
           sizeof(client_addr))) {
    ROS_ERROR("[%s][%s][%d]:Client Bind Port Failed!", node_name_str_.c_str(),
              __func__, __LINE__);
    exit(1);
  }

  // 设置一个socket地址结构server_addr,代表服务器的internet地址, 端口
  struct sockaddr_in server_addr;
  bzero(&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;

  if (inet_aton(DEFAULT_HOST_IP, &server_addr.sin_addr) ==
      0) {  // 服务器的IP地址来自程序的参数
    ROS_ERROR("[%s][%s][%d]:Server IP Address Error!", node_name_str_.c_str(),
              __func__, __LINE__);
    exit(1);
  }

  server_addr.sin_port = htons(HELLO_WORLD_SERVER_PORT);
  socklen_t server_addr_length = sizeof(server_addr);
  // 向服务器发起连接,连接成功后client_socket代表了客户机和服务器的一个socket连接
  if (connect(client_socket, (struct sockaddr *)&server_addr,
              server_addr_length) < 0) {
    ROS_ERROR("[%s][%s][%d]:Can Not Connect To %s!", node_name_str_.c_str(),
              __func__, __LINE__, DEFAULT_HOST_IP);
    exit(1);
  }

  // Register node
  char buffer[BUFFER_SIZE];
  bzero(buffer, BUFFER_SIZE);
  // set client
  buffer[0] = 0x55;
  buffer[1] = 0x55;
  buffer[2] = 1;
  buffer[3] = 0;
  buffer[4] = 0;
  buffer[5] = 0;  // cmd
  buffer[6] = 4;
  buffer[7] = 0;
  buffer[8] = 0;
  buffer[9] = 0;  // src id
  buffer[10] = 0;
  buffer[11] = 0;
  buffer[12] = 0;
  buffer[13] = 0;  // target id
  buffer[14] = 0;
  buffer[15] = 0;
  buffer[16] = 0;
  buffer[17] = 0;  // seq
  buffer[18] = 0;
  buffer[19] = 0;
  buffer[20] = 0;
  buffer[21] = 0;  // length
  buffer[22] = 5;
  buffer[23] = 0;
  buffer[24] = 0;
  buffer[25] = 0;  // checksum
  buffer[26] = 0xaa;
  buffer[27] = 0xaa;
  // 向服务器发送buffer中的数据
  int length = send(client_socket, buffer, 28, 0);
  if (length <= 0) {
    ROS_ERROR("[%s][%s][%d]:Send error !", node_name_str_.c_str(), __func__,
              __LINE__);
    exit(-1);
  }

  // 开启监听线程
  pthread_t thread;
  // 开启数据转发进程
  pthread_create(&thread, NULL, data_recv, &client_socket);

  ros::spin();

  // 关闭socket
  close(client_socket);

  return 0;
}
