#include "log_server.hpp"

#include <boost/algorithm/string.hpp>

namespace log_and_bag_server {

LogServer::LogServer() {
  ros::NodeHandle nh("~");
  initParam();
  initTopic();
}

LogServer::~LogServer() {
  rosout_sub_.shutdown();

  {
    boost::mutex::scoped_lock lock(log_write_mutex_);
    std::stringstream ss;
    ss << "\n\n"
       << getSystemTime()
       << " UD Log record END because the log_server shutdown!";
    log_write_deque_.emplace_back(ss.str());
  }

  log_write_cv_.notify_one();
  log_write_thread_.join();

  if (handle_) {
    if (fclose(handle_)) {
      ROS_ERROR("[%s][%s][%d]:Error closing the log file %s : %s",
                node_name_str_.c_str(), __func__, __LINE__,
                current_log_file_name_.c_str(), strerror(errno));
    }
    handle_ = NULL;
  }
}

void LogServer::initParam() {
  node_name_str_ = ros::this_node::getName();

  std::string check_bag_script;
  if (ros::param::get("~check_bag_file_script", check_bag_script)) {
    if (check_bag_script != "") {
      ROS_INFO("[%s][%s][%d]:Get script name: %s", node_name_str_.c_str(),
               __func__, __LINE__, check_bag_script.c_str());

      std::string cmd = "bash " + check_bag_script;
      system(cmd.c_str());
    } else {
      ROS_ERROR("[%s][%s][%d]:Bad script name, exit !", node_name_str_.c_str(),
                __func__, __LINE__);
      exit(-1);
    }
  } else {
    ROS_ERROR("[%s][%s][%d]: Not got the script!", node_name_str_.c_str(),
              __func__, __LINE__);
  }

  if (!ros::param::get("UD_error_code_record", error_code_str_)) {
    if (!ros::param::get("~UD_error_code", error_code_str_)) {
      ROS_WARN("[%s][%s][%d]: Not get UD_error_code !", node_name_str_.c_str(),
               __func__, __LINE__);
      error_code_str_ = std::string(
          "active_record 102 103 104 105 106 118 129 139 153 158 107 113 119 "
          "120 123 126 127 130 131 132 133 134 135 137 138 139 140 141 142 143 "
          "150 154 999 145 157 163 log_out");
    }
    target_str_.clear();
    boost::split(target_str_, error_code_str_, boost::is_any_of(" "),
                 boost::token_compress_on);
  } else {
    target_str_.clear();
    boost::split(target_str_, error_code_str_, boost::is_any_of(","),
                 boost::token_compress_on);
  }

  int ud_error_bag_size = 10;
  if (!ros::param::get("UD_error_bag_size", ud_error_bag_size)) {
    if (!ros::param::get("~UD_error_bag_size", ud_error_bag_size)) {
      ROS_WARN("[%s][%s][%d]: Not get UD_error_bag_size!",
               node_name_str_.c_str(), __func__, __LINE__);
      ud_error_bag_size = 10;
    }
  }
  ud_error_bag_size = ud_error_bag_size < 5 ? 5 : ud_error_bag_size;
  ud_error_bag_size = ud_error_bag_size > 300 ? 300 : ud_error_bag_size;
  max_file_size_ = ud_error_bag_size * 1024 * 1024;

  ros::NodeHandle private_nh("~");
  private_nh.param("UD_log_file_name", log_file_name_,
                   std::string("/home/ubuntu/log_bag/ud_terminal_logs/UDLog"));
  private_nh.param("UD_error_code_period", error_code_period_, 180.0);

  int ud_max_log_file_cnt = 2;
  private_nh.param("UD_max_log_file_cnt", ud_max_log_file_cnt, 2);
  max_backup_index_ = ud_max_log_file_cnt;

  log_name_str_.clear();
  return;
}

void LogServer::initTopic() {
  const char *disable_file_logging_env = getenv("ROSOUT_DISABLE_FILE_LOGGING");
  std::string disable_file_logging(
      disable_file_logging_env ? disable_file_logging_env : "");
  std::transform(disable_file_logging.begin(), disable_file_logging.end(),
                 disable_file_logging.begin(),
                 [](char c) { return std::tolower(c); });

  if (disable_file_logging.empty() || disable_file_logging == "0" ||
      disable_file_logging == "false" || disable_file_logging == "off" ||
      disable_file_logging == "no") {
    std::stringstream current_file_name;
    current_file_name << log_file_name_ << "_0_" << getSystemTime() << ".txt";
    current_log_file_name_ = current_file_name.str();
    log_name_str_.emplace_back(current_log_file_name_);
    handle_ = fopen(current_log_file_name_.c_str(), "w+");

    if (handle_ != NULL) {
      ROS_INFO("[%s][%s][%d]:Logging to %s", node_name_str_.c_str(), __func__,
               __LINE__, current_log_file_name_.c_str());

      std::stringstream ss;
      ss << getSystemTime() << " Ready to record the terminal logs!\n\n";
      int written = fprintf(handle_, "%s", ss.str().c_str());

      if (written > 0) {
        current_file_size_ += written;
        if (fflush(handle_)) {
          ROS_ERROR("[%s][%s][%d]: Error flushing the rosout log file %s : %s ",
                    node_name_str_.c_str(), __func__, __LINE__,
                    current_log_file_name_.c_str(), strerror(errno));
        }
      } else if (written < 0) {
        ROS_ERROR("[%s][%s][%d]:Error writting to the rosout log file %s : %s ",
                  node_name_str_.c_str(), __func__, __LINE__,
                  current_log_file_name_.c_str(), strerror(errno));
      }
    } else {
      ROS_ERROR("[%s][%s][%d]:Error opening the rosout log file %s : %s ",
                node_name_str_.c_str(), __func__, __LINE__,
                current_log_file_name_.c_str(), strerror(errno));
    }
  }

  ros::NodeHandle private_nh("~");
  rosout_sub_ = private_nh.subscribe<rosgraph_msgs::Log>(
      "/rosout", 1, boost::bind(&LogServer::resoutCB, this, _1));

  error_code_sub_ = private_nh.subscribe("/ZWJ_nodes_state", 1,
                                         &LogServer::errorCodeCB, this);
  error_log_pub_ =
      private_nh.advertise<std_msgs::String>("/error_log_state", 1);

  log_write_thread_ =
      boost::thread(boost::bind(&LogServer::writeLogThread, this));

  // 导航包版本信息写入日志文件
  FILE *fp;
  char buffer[256] = {0};
  std::string buff_str = "";
  std::string version_commond_str = "rosrun version version3 1";
  fp = popen(version_commond_str.c_str(), "r");
  fgets(buffer, sizeof(buffer), fp);
  buff_str = buffer;
  pclose(fp);
  ROS_INFO("[%s][%s][%d]]:%s", node_name_str_.c_str(), __func__, __LINE__,
           buff_str.c_str());
  return;
}

void LogServer::resoutCB(const rosgraph_msgs::Log::ConstPtr &msg) {
  if (!handle_) {
    ROS_WARN_THROTTLE(1.0, "handle is error");
    return;
  }

  std::stringstream ss;
  ss << msg->header.stamp << " ";

  // 过滤不同等级的log信息
  switch (msg->level) {
    case rosgraph_msgs::Log::FATAL:
      ss << "[ FATAL] ";
      break;
    case rosgraph_msgs::Log::ERROR:
      ss << "[ ERROR] ";
      break;
    case rosgraph_msgs::Log::WARN:
      ss << "[ WARN] ";
      break;
    case rosgraph_msgs::Log::DEBUG:
      ss << "[ DEBUG] ";
      break;
    case rosgraph_msgs::Log::INFO:
      ss << "[ INFO] ";
      break;
    default:
      ss << msg->level << " ";
      return;
  }

  ss << msg->msg;
  ss << "\n";

  {
    boost::mutex::scoped_lock lock(log_write_mutex_);
    log_write_deque_.emplace_back(ss.str());
  }
  log_write_cv_.notify_one();

  return;
}

void LogServer::writeLogThread() {
  while (ros::ok() && enable_log_write_) {
    boost::unique_lock<boost::mutex> lock(log_write_mutex_);
    log_write_cv_.wait(lock, [this] {
      return !log_write_deque_.empty() || !enable_log_write_;
    });

    while (!log_write_deque_.empty()) {
      std::string log_str = log_write_deque_.front();
      log_write_deque_.pop_front();
      int written = fprintf(handle_, "%s", log_str.c_str());

      if (written > 0) {
        current_file_size_ += written;
        if (fflush(handle_)) {
          ROS_ERROR("[%s][%s][%d]:Error flushing the rosout log file %s : %s!",
                    node_name_str_.c_str(), __func__, __LINE__,
                    current_log_file_name_.c_str(), strerror(errno));
        }

        if (current_file_size_ > max_file_size_) {
          ROS_INFO(
              "[%s][%s][%d] The log file %s reached the max size, rotating the "
              "log "
              "files",
              node_name_str_.c_str(), __func__, __LINE__,
              current_log_file_name_.c_str());

          if (fclose(handle_)) {
            ROS_ERROR("[%s][%s][%d]:Error closing the log file %s : %s!",
                      node_name_str_.c_str(), __func__, __LINE__,
                      current_log_file_name_.c_str(), strerror(errno));
          }

          // 如果存在超过最大备份数量的日志文件，则删除最旧的日志文件
          if (log_name_str_.size() > max_backup_index_) {
            std::string log_name = log_name_str_.front();
            log_name_str_.pop_front();
            if (remove(log_name.c_str()) != 0) {
              ROS_ERROR(
                  "[%s][%s][%d]:Error deleting the oldest log file %s : %s!",
                  node_name_str_.c_str(), __func__, __LINE__, log_name.c_str(),
                  strerror(errno));
            }
          }

          static size_t cur_backup_index = 1;
          std::stringstream rotated_file_name;
          rotated_file_name << log_file_name_ << "_" << cur_backup_index++
                            << "_" << getSystemTime() << ".txt";
          log_name_str_.emplace_back(rotated_file_name.str());
          current_log_file_name_ = rotated_file_name.str();
          handle_ = fopen(current_log_file_name_.c_str(), "w+");

          if (handle_ == NULL) {
            ROS_ERROR("[%s][%s][%d]:Error opening the log file %s : %s ",
                      node_name_str_.c_str(), __func__, __LINE__,
                      current_log_file_name_.c_str(), strerror(errno));
          }

          if (cur_backup_index > 1000) {
            cur_backup_index = 0;
          }
          current_file_size_ = 0;
        }
      } else if (written < 0) {
        ROS_ERROR("[%s][%s][%d]:Error writting to rosout log file %s : %s!",
                  node_name_str_.c_str(), __func__, __LINE__,
                  current_log_file_name_.c_str(), strerror(errno));
      }
    }
  }
  return;
}

void LogServer::errorCodeCB(const std_msgs::String &msg) {
  int index = 0;
  std::string c;
  std::string error_level = "D";
  std::istringstream iss(msg.data);

  while (iss >> c) {
    index++;
    if (index == 2 && c == "A") {
      ROS_ERROR("[%s][%s][%d]]: Exist A error!", node_name_str_.c_str(),
                __func__, __LINE__);

      error_level = "A";
      // TODO:上报A类错误后是否需要急停, 待定
      break;
    }
  }

  static std::string error_code{""};
  if (error_code == msg.data && error_code != "active_record" &&
      error_level == "A" && error_code != "log_out") {
    return;
  }

  static bool last_A_error = false;
  if (last_A_error && error_code != "active_record") {
    return;
  }

  if (error_level == "A") {
    last_A_error = true;
  }

  // 首次发生错误或者两次发生错误间隔大于180s时，才记录bag
  static bool enable_record_bag = true;
  static ros::Time error_last_time = ros::Time::now();

  if (ros::Time::now() > error_last_time + ros::Duration(error_code_period_)) {
    enable_record_bag = true;
  }

  int start_pos = 0;
  char tmp[128] = {0};
  error_code = msg.data;
  size_t pos = error_code.find(" ");
  error_code.copy(tmp, pos - start_pos, start_pos);
  std::string error_name = tmp;

  if (enable_record_bag) {
    ROS_INFO("[%s][%s][%d]:%s", node_name_str_.c_str(), __func__, __LINE__,
             error_name.c_str());

    auto iter = std::find(target_str_.begin(), target_str_.end(), error_name);
    if (iter != target_str_.end()) {
      error_last_time = ros::Time::now();
      enable_record_bag = false;

      time_t tmNow = time(NULL);
      char ctm[26] = {0};
      tm *ptmNow = localtime(&tmNow);
      std::strftime(ctm, 26, "%Y-%m-%d %H:%M:%S", ptmNow);
      ROS_ERROR("[%s][%s][%d]: exist error code %s, current time is %s!",
                node_name_str_.c_str(), __func__, __LINE__, error_name.c_str(),
                ctm);

      std_msgs::String error_code;
      error_code.data = error_name;
      error_log_pub_.publish(error_code);
    } else {
      ROS_ERROR("[%s][%s][%d]:error code is %s, don't need pack!",
                node_name_str_.c_str(), __func__, __LINE__, error_code.c_str());
    }
  }
  return;
}
}  // namespace log_and_bag_server

int main(int argc, char **argv) {
  ros::init(argc, argv, "log_server");
  ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                 ros::console::levels::Info);
  ros::console::notifyLoggerLevelsChanged();

  int pro_priority = 2;
  ros::param::get("~pro_priority", pro_priority);
  int ret = nice(pro_priority);

  if (ret == -1) {
    ROS_ERROR("[%s] [%d] Can not set %s priority, the error is %s", __func__,
              __LINE__, ros::this_node::getName().c_str(), strerror(errno));
  }

  system("nice");
  log_and_bag_server::LogServer log_server;
  ros::spin();
  return 0;
}