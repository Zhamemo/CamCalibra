#!/bin/bash
BACKUP_BAG_PATH=/home/ubuntu/log_bag/ud_terminal_logs
BACKUP_OPENNILOG_PATH=/home/ubuntu/log_bag/openniLog
BAG_PATH=/home/ubuntu
BAG_NAME="log_bag"
DEPTH_CAMERA_FILE="depth_camera_picture"
STD="std_wr_demo"
suffix=".tar"
unknow="error_bag_999"
files=${unknow}_$RANDOM$suffix

#printf
function print_msg() {
	local cmd="echo -e"
	if [ "$1" == "-w" ]; then
		echo -e "\033[0;33;1m[Warn] $2\033[0m"
	elif [ "$1" == "-e" ]; then
		echo -e "\033[0;31;1m[ Err] $2\033[0m"
	elif [ "$1" == "-g" ]; then
		echo -e "\033[0;32;1m$2\033[0m"
	elif [ "$1" == "-r" ]; then
		echo -e "\033[0;31;1m$2\033[0m"
	elif [ "$1" == "-b" ]; then
		echo -e "\033[0;34;1m$2\033[0m"
	elif [ "$1" == "-n" ]; then
		echo -ne "\033[0;34;1m[Info] $2\033[0m"
	else
		echo -e "\033[0;34;1m[Info] $1\033[0m"
	fi
}

function check_file() {
     checked_file=$1
     bool_have_=false
     all_file_list=`ls`
     for i in $all_file_list
        do
           # print_msg $i
           head_tag=`echo $i | awk -F ' ' '{print $1}'`
           if [ -d $head_tag ]; then
              if [ "$head_tag" == "$checked_file" ]; then
              bool_have_=true
              fi
           fi
        done
      if [ "$bool_have_" == true ]; then
          echo "1"
      else
          echo "0"
      fi
}

function removeFile() {

  backup_log=$2
  type=$3
  test -d $backup_log
  if [ $? -eq 0 ]; then
    print_msg -g  "Exist $backup_log"
  else
    mkdir $backup_log
    print_msg -r "Mkdir $backup_log"
  fi


  ReservedNum=$1                      #保留文件数量
  cd $backup_log                #进入文件夹
  RootDir=$backup_log           #$(cd $(dirname $0); pwd)      #当前文件路径
  FileNum=$(ls -l |grep "$type"|wc -l)    #查找文件数量
  OldFile=$(ls -rt *|head -1)         #找出gz最先文件
  #OldFile=${OldFile%?}
  print_msg -g $OldFile

 # echo $OldFile
  if [ $RootDir == $backup_log ];then   #判断所在目录是否正确
    print_msg -g $RootDir
    print_msg -g $backup_log
    while (($FileNum>$ReservedNum))  #文件数超过设置变量才执行
    do
    print_msg -g "Delete File:"$RootDir'/'$OldFile   #打印要删除的文件名称
    rm -rf $RootDir'/'$OldFile                       #删除文件
    let "FileNum--"                                      #变量自减操做
    OldFile=$(ls -rt *|head -1)         #更新gz最先文件
    #OldFile=${OldFile%?}
    done
  else
    print_msg -g $RootDir
    print_msg -g $backup_log
    print_msg -r "error file path "                         #所在目录不对打印出路径错误
  fi
}



#start run
cd $BAG_PATH
check_file_result=$(check_file $BAG_NAME)
if [ "$check_file_result" == "0" ]; then
  mkdir $BAG_NAME
  print_msg -g " Mkdir $BAG_NAME ok!"
fi

cd $BAG_PATH/$BAG_NAME
check_file_result=$(check_file $DEPTH_CAMERA_FILE)
if [ "$check_file_result" == "0" ]; then
  mkdir $DEPTH_CAMERA_FILE
  print_msg -g " Mkdir $DEPTH_CAMERA_FILE ok!"
else
  rm -rf $BAG_PATH/$BAG_NAME/$DEPTH_CAMERA_FILE/*
   print_msg -r "Delete $DEPTH_CAMERA_FILE"
fi

cd $BAG_PATH
check_file_result=$(check_file $BAG_NAME)
if [ "$check_file_result" == "0" ]; then
  mkdir $BAG_NAME
  print_msg -g " Mkdir $BAG_NAME ok!"
else
  cd  $BAG_PATH/$BAG_NAME
  rm -rf last.bag current.bag
  print_msg -g " delete bag ok!"

  test -f /home/ubuntu/log_bag/.log.txt
  if [ $? -eq 0 ]; then
    ls "last_unknow.bag"
    if [ $? -eq 0 ]; then
      ls "current_unknow.bag"
      if [ $? -eq 0 ]; then
        tar czf $files $BAG_PATH/$STD $BAG_PATH/$BAG_NAME/last_unknow.bag $BAG_PATH/$BAG_NAME/current_unknow.bag $BAG_PATH/$BAG_NAME/.log.txt $BAG_PATH/$BAG_NAME/UDLog*
      else
        tar czf $files $BAG_PATH/$STD $BAG_PATH/$BAG_NAME/last_unknow.bag $BAG_PATH/$BAG_NAME/.log.txt $BAG_PATH/$BAG_NAME/UDLog*
      fi
    else
      ls "current_unknow.bag"
      if [ $? -eq 0 ]; then
        tar czf $files $BAG_PATH/$STD $BAG_PATH/$BAG_NAME/current_unknow.bag $BAG_PATH/$BAG_NAME/.log.txt $BAG_PATH/$BAG_NAME/UDLog*
      fi
    fi
    rm -rf .log.txt
  else
    ls "last_unknow.bag"
    if [ $? -eq 0 ]; then
      ls "current_unknow.bag"
      if [ $? -eq 0 ]; then
        tar czf $files $BAG_PATH/$STD $BAG_PATH/$BAG_NAME/last_unknow.bag $BAG_PATH/$BAG_NAME/current_unknow.bag $BAG_PATH/$BAG_NAME/UDLog*
      else
        tar czf $files $BAG_PATH/$STD $BAG_PATH/$BAG_NAME/last_unknow.bag $BAG_PATH/$BAG_NAME/UDLog*
      fi
    else
      ls "current_unknow.bag"
      if [ $? -eq 0 ]; then
        tar czf $files $BAG_PATH/$STD $BAG_PATH/$BAG_NAME/current_unknow.bag $BAG_PATH/$BAG_NAME/UDLog*
      fi
    fi
  fi
  
  


  ls "$files"
  if [ $? -eq 0 ]; then
     /home/ubuntu/ud_ws/install/lib/log_and_bag_server/scripts/upload_bag.sh $files
     if [ $? -eq 0 ]; then
        print_msg -g "upload successed"
        rm -rf $files last_unknow.bag current_unknow.bag
     else
        print_msg -e "upload unknow error bag failed"
     fi
  fi
fi
# 确保log_bag目录下不超过5个文件
removeFile 4 $BACKUP_BAG_PATH txt

# 2
removeFile 0 $BACKUP_OPENNILOG_PATH log

