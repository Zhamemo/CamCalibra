#!/bin/bash

export HOST_IP=192.168.168.100
TAR_NAME=$1

BAG_PATH=/home/ubuntu
BAG_NAME="log_bag"
DEPTH_CAMERA_FILE="depth_camera_picture"
OVERHEAD_CAMERA_FILE="overhead_camera_picture"

function print_msg() {
	local cmd="echo -e"
	if [ "$1" == "-w" ]; then
		echo -e "\033[0;33;1m[Warn] $2\033[0m"
	elif [ "$1" == "-e" ]; then
		echo -e "\033[0;31;1m[ Err] $2\033[0m"
	elif [ "$1" == "-g" ]; then
		echo -e "\033[0;32;1m$2\033[0m"
	elif [ "$1" == "-r" ]; then
		echo -e "\033[0;31;1m$2\033[0m"
	elif [ "$1" == "-b" ]; then
		echo -e "\033[0;34;1m$2\033[0m"
	elif [ "$1" == "-n" ]; then
		echo -ne "\033[0;34;1m[Info] $2\033[0m"
	else
		echo -e "\033[0;34;1m[Info] $1\033[0m"
	fi
}

function clear_ftp() {
	ftp -i -n <<FTPIT
	open $HOST_IP
	user uftp 123
	bin
	mdelete ftp/log/*
	quit
FTPIT
}

function send_file_to_ftp() {
	# File must in current directory.
	local file_name=$1
	
	if [ "$file_name" == "" ] || [ ! -e $file_name ]; then
		print_msg -e "File name is empty or file not exist - $file_name, exit!"
		return
	fi
	ftp -i -n <<FTPIT
	open $HOST_IP
	user uftp 123
	bin
          put $file_name ftp/log/$TAR_NAME
	quit
FTPIT
}

function update_bag_to_ftp() {
	#send_file_to_ftp /dev/shm/error_bag.tar
	send_file_to_ftp ~/log_bag/$TAR_NAME
}

        cd $HOME
        ## Clear ftp
        #clear_ftp
        ## Update version to ftp
        update_bag_to_ftp 
        


rm -rf $BAG_PATH/$BAG_NAME/$DEPTH_CAMERA_FILE/*
rm -rf $BAG_PATH/$BAG_NAME/$OVERHEAD_CAMERA_FILE/*

