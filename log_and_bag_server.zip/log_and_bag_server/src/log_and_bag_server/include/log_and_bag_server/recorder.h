/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, Willow Garage, Inc.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ********************************************************************/

#ifndef ROSBAG_RECORDER_H
#define ROSBAG_RECORDER_H

#include <sys/stat.h>

#if !defined(_MSC_VER)
#include <termios.h>
#include <unistd.h>
#endif

#include <ros/ros.h>
#include <ros/time.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Empty.h>
#include <std_msgs/Int8.h>
#include <std_msgs/String.h>
#include <time.h>
#include <topic_tools/shape_shifter.h>

#include <algorithm>
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/date_time/local_time/local_time.hpp>
#include <boost/regex.hpp>
#include <boost/thread.hpp>
#include <boost/thread/condition.hpp>
#include <boost/thread/mutex.hpp>
#include <fstream>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

#include "bag.h"
#include "custom_msgs_srvs/Double.h"
#include "macros.h"
#include "stream.h"

namespace log_and_bag_server {
class ROSBAG_DECL OutgoingMessage {
 public:
  OutgoingMessage(std::string const &_topic,
                  topic_tools::ShapeShifter::ConstPtr _msg,
                  boost::shared_ptr<ros::M_string> _connection_header,
                  ros::Time _time);

  std::string topic;
  topic_tools::ShapeShifter::ConstPtr msg;
  boost::shared_ptr<ros::M_string> connection_header;
  ros::Time time;
};

class ROSBAG_DECL OutgoingQueue {
 public:
  OutgoingQueue(std::string const &_filename,
                std::queue<OutgoingMessage> *_queue, ros::Time _time);

  std::string filename;
  std::queue<OutgoingMessage> *queue;
  ros::Time time;
};

struct ROSBAG_DECL RecorderOptions {
  RecorderOptions();

  bool trigger;
  bool record_all;
  bool regex;
  bool do_exclude;
  bool quiet;
  bool append_date;
  bool snapshot;
  bool verbose;
  CompressionType compression;
  std::string prefix;
  std::string name;
  boost::regex exclude_regex;
  uint32_t buffer_size;
  uint32_t chunk_size;
  uint32_t limit;
  bool split;
  uint32_t max_size;
  ros::Duration max_duration;
  std::string node;
  unsigned long long min_space;
  std::string min_space_str;
  std::string ftp_path;
  std::string unknow_error_path;
  std::vector<std::string> topics;
};

class ROSBAG_DECL Recorder {
 public:
  explicit Recorder(RecorderOptions const &options);
  ~Recorder() = default;

  Recorder(Recorder const &) = delete;
  Recorder &operator=(Recorder const &) = delete;

 public:
  int run();

 private:
  void initParams();
  void doTrigger();

 private:
  void setBagNames();
  void startWriting();
  void stopWriting();

 private:
  bool checkDisk();
  bool checkLogging();
  bool scheduledCheckDisk();
  bool checkDuration(const ros::Time &);

 private:
  bool checkSize();
  bool findNeedRecord(const std::string &cur_error_code,
                      const std::vector<std::string> &vec_errorcode) const;

 private:
  bool isSubscribed(std::string const &topic) const;
  boost::shared_ptr<ros::Subscriber> subscribe(std::string const &topic);
  void doQueue(
      const ros::MessageEvent<topic_tools::ShapeShifter const> &msg_event,
      std::string const &topic, boost::shared_ptr<ros::Subscriber> subscriber,
      boost::shared_ptr<int> count);

 private:
  void doRecord();
  void doRecordSnapshotter();
  void snapshotTrigger(std_msgs::Empty::ConstPtr trigger);

 private:
  void doCheckMaster(ros::TimerEvent const &e, ros::NodeHandle &node_handle);
  bool shouldSubscribeToTopic(std::string const &topic, bool from_node = false);

 private:
  template <class T>
  static std::string timeToStr(T ros_t) {
    (void)ros_t;
    std::stringstream msg;
    const boost::posix_time::ptime now =
        boost::posix_time::second_clock::local_time();
    boost::posix_time::time_facet *const f =
        new boost::posix_time::time_facet("%Y-%m-%d-%H-%M-%S");
    msg.imbue(std::locale(msg.getloc(), f));
    msg << now;
    return msg.str();
  }

 private:
  void errorcodeCB(const std_msgs::StringConstPtr &msg);
  bool changeRecordSrv(custom_msgs_srvs::Double::Request &req,
                       custom_msgs_srvs::Double::Response &res);

 private:
  std::vector<boost::shared_ptr<ros::Subscriber>> sub_list_;
  ros::Subscriber error_code_sub_;

  ros::Publisher zip_success_pub_;
  ros::ServiceServer record_change_srv_;

  RecorderOptions options_;
  Bag bag_;

  std::string target_filename_;
  std::string write_filename_;

  std::set<std::string>
      currently_recording_;  // set of currenly recording topics
  int num_subscribers_;  // used for book-keeping of our number of subscribers
  int exit_code_;        // eventual exit code

  boost::condition_variable_any
      queue_condition_;                 // conditional variable for queue
  boost::mutex queue_mutex_;            // mutex for queue
  std::queue<OutgoingMessage> *queue_;  // queue for storing
  uint64_t queue_size_;                 // queue size
  uint64_t max_queue_size_;             // max queue size

  uint64_t split_count_;
  std::string split_name_;
  std::string last_split_name_;
  std::string current_split_name_;
  std::string log_name_;
  std::string tcp_cmd_;
  std::string error_code_;
  std::string rename_name_;
  std::string script_name_;
  std::string std_path_;
  std::string system_path_;
  std::string unknow_error_name_;
  std::string log_out_error_name_;
  bool errorcode_happened_;
  bool localization_alarm_happened_;
  bool engineer_happened_;
  bool engineer_happened_state_;
  int errorcode_count_;
  uint16_t err_185_cnt = 0;
  std::queue<OutgoingQueue>
      queue_queue_;  // queue of queues to be used by the snapshot recorders

  ros::Time last_buffer_warn_;
  ros::Time start_time_;

  bool enable_write_;
  boost::mutex check_disk_mutex_;
  ros::WallTime check_disk_next_;
  ros::WallTime warn_next_;
  std::string node_name_str_;

  // gilbert
  double ud_errorcode_extend_record_time_;
  std::string ud_var_log_tar_name_;
  std::string ud_opennilog_path_;              // openni log 路径
  std::string ud_depth_camera_pictures_path_;  // 深度相机存图
  std::string ud_shell_log_path_;              // shell 脚本运行日志
  std::vector<std::string>
      record_varlog_errorcode_vector_;  // 需要上传系统日志的error code
  std::vector<std::string>
      record_opennilog_errorcode_vector_;  // 需要上传openni log的error code
};
}  // namespace log_and_bag_server

#endif  // RECORDER_H_
