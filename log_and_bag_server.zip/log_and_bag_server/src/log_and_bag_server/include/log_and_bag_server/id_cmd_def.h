#ifndef _ID_CMD_DEF_H_
#define _ID_CMD_DEF_H_

namespace syscom {
typedef enum {
  ID_MIN = 0,
  ID_SERVER,
  ID_SWJ,
  ID_UPDATER,
  ID_LOG_SERVER,

  ID_MAX
} MODEL_ID;

typedef enum {
  CMD_MIN = 0,
  CMD_REG,  // 节点注册

  // Updater swj
  CMD_GET_VERSION = 2,  // 获取ZWJ版本号
  CMD_GET_CUR_VERSION,  // Get current version only (Do not update)
  CMD_UPDATING,         // 包正在更新
  CMD_LOCAL_VERSION,    // 返回版本号
  CMD_RECOVERY,         // 回退到上一个版本

  // Mode
  CMD_MODE = 10,  // 模式

  // 抓取包
  CMD_PKG_GET = 20,
  CMD_UPLOAD_PKG_OK,
  CMD_UPLOAD_PKG_FAIL,

  // Log server
  CMD_LOG_UPLOADED = 30,  // 上传BAG包成功
  CMD_START_LOGGING,      // 开始录制Bag包即Log

  // Response
  CMD_ACK_OK = 40,  // Ack ok
  CMD_ACK_FAIL,     // Ack failed

  CMD_SYSTEM_LOGGING = 50,  // 开始录制system Log

  // ...
  CMD_MAX
} CMD;

}  // namespace syscom

#endif
