#ifndef LOG_SERVER_H_
#define LOG_SERVER_H_

#include <ros/ros.h>
#include <rosgraph_msgs/Log.h>
#include <std_msgs/String.h>

#include <boost/thread.hpp>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <deque>

namespace log_and_bag_server {
class LogServer {
 public:
  LogServer();
  ~LogServer();

  LogServer(const LogServer &) = delete;
  LogServer &operator=(const LogServer &) = delete;

 private:
  void initParam();
  void initTopic();

 private:
  void resoutCB(const rosgraph_msgs::Log::ConstPtr &msg);
  void writeLogThread();

 private:
  void errorCodeCB(const std_msgs::String &msg);

 private:
  std::string getSystemTime() {
    time_t tmNow = time(NULL);
    char ctm[26] = {0};
    tm *ptmNow = localtime(&tmNow);
    std::strftime(ctm, 26, "%Y-%m-%d-%H:%M:%S", ptmNow);
    std::string time = ctm;
    return time;
  }

 private:
  ros::Subscriber rosout_sub_;      // 订阅ROS日志记录
  ros::Subscriber error_code_sub_;  // 订阅发生的错误码
  ros::Publisher error_log_pub_;    // 发布错误码记录

  std::string node_name_str_;
  std::string log_file_name_;
  std::string current_log_file_name_;
  std::deque<std::string> log_name_str_;
  std::string error_code_str_;
  std::vector<std::string> target_str_;

  size_t max_file_size_;
  size_t max_backup_index_;
  size_t current_file_size_{0};

  double error_code_period_{0.0};
  bool enable_log_write_{true};

  std::deque<std::string> log_write_deque_;  // 日志队列
  boost::condition_variable log_write_cv_;
  boost::thread log_write_thread_;
  boost::mutex log_write_mutex_;

  FILE *handle_;
};
}  // namespace log_and_bag_server

#endif  // LOG_SERVER_H_
