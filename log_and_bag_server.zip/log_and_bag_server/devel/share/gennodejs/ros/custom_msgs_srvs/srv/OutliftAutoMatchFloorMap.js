// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class OutliftAutoMatchFloorMapRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.current_floor_id = null;
      this.target_floor_id = null;
      this.current_floor_in_lift_goal = null;
      this.current_floor_out_lift_goal = null;
      this.target_floor_in_lift_goal = null;
      this.target_floor_out_lift_goal = null;
      this.target_floor_initialpose = null;
      this.match_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('current_floor_id')) {
        this.current_floor_id = initObj.current_floor_id
      }
      else {
        this.current_floor_id = 0;
      }
      if (initObj.hasOwnProperty('target_floor_id')) {
        this.target_floor_id = initObj.target_floor_id
      }
      else {
        this.target_floor_id = 0;
      }
      if (initObj.hasOwnProperty('current_floor_in_lift_goal')) {
        this.current_floor_in_lift_goal = initObj.current_floor_in_lift_goal
      }
      else {
        this.current_floor_in_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped();
      }
      if (initObj.hasOwnProperty('current_floor_out_lift_goal')) {
        this.current_floor_out_lift_goal = initObj.current_floor_out_lift_goal
      }
      else {
        this.current_floor_out_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped();
      }
      if (initObj.hasOwnProperty('target_floor_in_lift_goal')) {
        this.target_floor_in_lift_goal = initObj.target_floor_in_lift_goal
      }
      else {
        this.target_floor_in_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped();
      }
      if (initObj.hasOwnProperty('target_floor_out_lift_goal')) {
        this.target_floor_out_lift_goal = initObj.target_floor_out_lift_goal
      }
      else {
        this.target_floor_out_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped();
      }
      if (initObj.hasOwnProperty('target_floor_initialpose')) {
        this.target_floor_initialpose = initObj.target_floor_initialpose
      }
      else {
        this.target_floor_initialpose = new geometry_msgs.msg.PoseWithCovarianceStamped();
      }
      if (initObj.hasOwnProperty('match_mode')) {
        this.match_mode = initObj.match_mode
      }
      else {
        this.match_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type OutliftAutoMatchFloorMapRequest
    // Serialize message field [current_floor_id]
    bufferOffset = _serializer.int32(obj.current_floor_id, buffer, bufferOffset);
    // Serialize message field [target_floor_id]
    bufferOffset = _serializer.int32(obj.target_floor_id, buffer, bufferOffset);
    // Serialize message field [current_floor_in_lift_goal]
    bufferOffset = geometry_msgs.msg.PoseWithCovarianceStamped.serialize(obj.current_floor_in_lift_goal, buffer, bufferOffset);
    // Serialize message field [current_floor_out_lift_goal]
    bufferOffset = geometry_msgs.msg.PoseWithCovarianceStamped.serialize(obj.current_floor_out_lift_goal, buffer, bufferOffset);
    // Serialize message field [target_floor_in_lift_goal]
    bufferOffset = geometry_msgs.msg.PoseWithCovarianceStamped.serialize(obj.target_floor_in_lift_goal, buffer, bufferOffset);
    // Serialize message field [target_floor_out_lift_goal]
    bufferOffset = geometry_msgs.msg.PoseWithCovarianceStamped.serialize(obj.target_floor_out_lift_goal, buffer, bufferOffset);
    // Serialize message field [target_floor_initialpose]
    bufferOffset = geometry_msgs.msg.PoseWithCovarianceStamped.serialize(obj.target_floor_initialpose, buffer, bufferOffset);
    // Serialize message field [match_mode]
    bufferOffset = _serializer.int32(obj.match_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type OutliftAutoMatchFloorMapRequest
    let len;
    let data = new OutliftAutoMatchFloorMapRequest(null);
    // Deserialize message field [current_floor_id]
    data.current_floor_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [target_floor_id]
    data.target_floor_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [current_floor_in_lift_goal]
    data.current_floor_in_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [current_floor_out_lift_goal]
    data.current_floor_out_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [target_floor_in_lift_goal]
    data.target_floor_in_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [target_floor_out_lift_goal]
    data.target_floor_out_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [target_floor_initialpose]
    data.target_floor_initialpose = geometry_msgs.msg.PoseWithCovarianceStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [match_mode]
    data.match_mode = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseWithCovarianceStamped.getMessageSize(object.current_floor_in_lift_goal);
    length += geometry_msgs.msg.PoseWithCovarianceStamped.getMessageSize(object.current_floor_out_lift_goal);
    length += geometry_msgs.msg.PoseWithCovarianceStamped.getMessageSize(object.target_floor_in_lift_goal);
    length += geometry_msgs.msg.PoseWithCovarianceStamped.getMessageSize(object.target_floor_out_lift_goal);
    length += geometry_msgs.msg.PoseWithCovarianceStamped.getMessageSize(object.target_floor_initialpose);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/OutliftAutoMatchFloorMapRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '57bf5208a2d46e9823031001b2f13523';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 current_floor_id  
    int32 target_floor_id
    geometry_msgs/PoseWithCovarianceStamped current_floor_in_lift_goal
    geometry_msgs/PoseWithCovarianceStamped current_floor_out_lift_goal
    geometry_msgs/PoseWithCovarianceStamped target_floor_in_lift_goal
    geometry_msgs/PoseWithCovarianceStamped target_floor_out_lift_goal
    geometry_msgs/PoseWithCovarianceStamped target_floor_initialpose
    
    
    int32 match_mode 
    
    ================================================================================
    MSG: geometry_msgs/PoseWithCovarianceStamped
    # This expresses an estimated pose with a reference coordinate frame and timestamp
    
    Header header
    PoseWithCovariance pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseWithCovariance
    # This represents a pose in free space with uncertainty.
    
    Pose pose
    
    # Row-major representation of the 6x6 covariance matrix
    # The orientation parameters use a fixed-axis representation.
    # In order, the parameters are:
    # (x, y, z, rotation about X axis, rotation about Y axis, rotation about Z axis)
    float64[36] covariance
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new OutliftAutoMatchFloorMapRequest(null);
    if (msg.current_floor_id !== undefined) {
      resolved.current_floor_id = msg.current_floor_id;
    }
    else {
      resolved.current_floor_id = 0
    }

    if (msg.target_floor_id !== undefined) {
      resolved.target_floor_id = msg.target_floor_id;
    }
    else {
      resolved.target_floor_id = 0
    }

    if (msg.current_floor_in_lift_goal !== undefined) {
      resolved.current_floor_in_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.Resolve(msg.current_floor_in_lift_goal)
    }
    else {
      resolved.current_floor_in_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped()
    }

    if (msg.current_floor_out_lift_goal !== undefined) {
      resolved.current_floor_out_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.Resolve(msg.current_floor_out_lift_goal)
    }
    else {
      resolved.current_floor_out_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped()
    }

    if (msg.target_floor_in_lift_goal !== undefined) {
      resolved.target_floor_in_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.Resolve(msg.target_floor_in_lift_goal)
    }
    else {
      resolved.target_floor_in_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped()
    }

    if (msg.target_floor_out_lift_goal !== undefined) {
      resolved.target_floor_out_lift_goal = geometry_msgs.msg.PoseWithCovarianceStamped.Resolve(msg.target_floor_out_lift_goal)
    }
    else {
      resolved.target_floor_out_lift_goal = new geometry_msgs.msg.PoseWithCovarianceStamped()
    }

    if (msg.target_floor_initialpose !== undefined) {
      resolved.target_floor_initialpose = geometry_msgs.msg.PoseWithCovarianceStamped.Resolve(msg.target_floor_initialpose)
    }
    else {
      resolved.target_floor_initialpose = new geometry_msgs.msg.PoseWithCovarianceStamped()
    }

    if (msg.match_mode !== undefined) {
      resolved.match_mode = msg.match_mode;
    }
    else {
      resolved.match_mode = 0
    }

    return resolved;
    }
};

class OutliftAutoMatchFloorMapResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_in_elevator_switch_map = null;
      this.res = null;
    }
    else {
      if (initObj.hasOwnProperty('is_in_elevator_switch_map')) {
        this.is_in_elevator_switch_map = initObj.is_in_elevator_switch_map
      }
      else {
        this.is_in_elevator_switch_map = false;
      }
      if (initObj.hasOwnProperty('res')) {
        this.res = initObj.res
      }
      else {
        this.res = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type OutliftAutoMatchFloorMapResponse
    // Serialize message field [is_in_elevator_switch_map]
    bufferOffset = _serializer.bool(obj.is_in_elevator_switch_map, buffer, bufferOffset);
    // Serialize message field [res]
    bufferOffset = _serializer.int32(obj.res, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type OutliftAutoMatchFloorMapResponse
    let len;
    let data = new OutliftAutoMatchFloorMapResponse(null);
    // Deserialize message field [is_in_elevator_switch_map]
    data.is_in_elevator_switch_map = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [res]
    data.res = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/OutliftAutoMatchFloorMapResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5a7c235470dbf38577243901b2ac5d50';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool  is_in_elevator_switch_map
    int32 res
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new OutliftAutoMatchFloorMapResponse(null);
    if (msg.is_in_elevator_switch_map !== undefined) {
      resolved.is_in_elevator_switch_map = msg.is_in_elevator_switch_map;
    }
    else {
      resolved.is_in_elevator_switch_map = false
    }

    if (msg.res !== undefined) {
      resolved.res = msg.res;
    }
    else {
      resolved.res = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: OutliftAutoMatchFloorMapRequest,
  Response: OutliftAutoMatchFloorMapResponse,
  md5sum() { return '51db8ba9a387982ea694302109c955b7'; },
  datatype() { return 'custom_msgs_srvs/OutliftAutoMatchFloorMap'; }
};
