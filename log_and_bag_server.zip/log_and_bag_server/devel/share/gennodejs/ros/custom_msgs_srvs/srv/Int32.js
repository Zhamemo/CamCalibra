// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class Int32Request {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data = null;
      this.match_data = null;
    }
    else {
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('match_data')) {
        this.match_data = initObj.match_data
      }
      else {
        this.match_data = new std_msgs.msg.Int32();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Int32Request
    // Serialize message field [data]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.data, buffer, bufferOffset);
    // Serialize message field [match_data]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.match_data, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Int32Request
    let len;
    let data = new Int32Request(null);
    // Deserialize message field [data]
    data.data = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [match_data]
    data.match_data = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/Int32Request';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '44eb825f825316eeb7ea40ef7cffb622';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Int32 data
    std_msgs/Int32 match_data
    
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Int32Request(null);
    if (msg.data !== undefined) {
      resolved.data = std_msgs.msg.Int32.Resolve(msg.data)
    }
    else {
      resolved.data = new std_msgs.msg.Int32()
    }

    if (msg.match_data !== undefined) {
      resolved.match_data = std_msgs.msg.Int32.Resolve(msg.match_data)
    }
    else {
      resolved.match_data = new std_msgs.msg.Int32()
    }

    return resolved;
    }
};

class Int32Response {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data = null;
      this.res = null;
    }
    else {
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('res')) {
        this.res = initObj.res
      }
      else {
        this.res = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Int32Response
    // Serialize message field [data]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.data, buffer, bufferOffset);
    // Serialize message field [res]
    bufferOffset = _serializer.bool(obj.res, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Int32Response
    let len;
    let data = new Int32Response(null);
    // Deserialize message field [data]
    data.data = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [res]
    data.res = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/Int32Response';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '90f10034d227f23d6e7114c5e7a1c836';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Int32 data
    bool res
    
    
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Int32Response(null);
    if (msg.data !== undefined) {
      resolved.data = std_msgs.msg.Int32.Resolve(msg.data)
    }
    else {
      resolved.data = new std_msgs.msg.Int32()
    }

    if (msg.res !== undefined) {
      resolved.res = msg.res;
    }
    else {
      resolved.res = false
    }

    return resolved;
    }
};

module.exports = {
  Request: Int32Request,
  Response: Int32Response,
  md5sum() { return '5262fb9a9c93d5cc36dae1eabe6e44bf'; },
  datatype() { return 'custom_msgs_srvs/Int32'; }
};
