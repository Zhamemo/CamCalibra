// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class RobotStateInfoRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data = null;
    }
    else {
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = new std_msgs.msg.Bool();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RobotStateInfoRequest
    // Serialize message field [data]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.data, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RobotStateInfoRequest
    let len;
    let data = new RobotStateInfoRequest(null);
    // Deserialize message field [data]
    data.data = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/RobotStateInfoRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b5717fbd1e926acc7d0f3fedd0c81793';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Bool data
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RobotStateInfoRequest(null);
    if (msg.data !== undefined) {
      resolved.data = std_msgs.msg.Bool.Resolve(msg.data)
    }
    else {
      resolved.data = new std_msgs.msg.Bool()
    }

    return resolved;
    }
};

class RobotStateInfoResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.res = null;
      this.state_imu = null;
      this.state_laser = null;
      this.state_emer = null;
      this.state_bumper = null;
      this.zigbee_state = null;
      this.is_safe_stop = null;
      this.is_open_bumper = null;
      this.is_open_emer = null;
    }
    else {
      if (initObj.hasOwnProperty('res')) {
        this.res = initObj.res
      }
      else {
        this.res = false;
      }
      if (initObj.hasOwnProperty('state_imu')) {
        this.state_imu = initObj.state_imu
      }
      else {
        this.state_imu = false;
      }
      if (initObj.hasOwnProperty('state_laser')) {
        this.state_laser = initObj.state_laser
      }
      else {
        this.state_laser = false;
      }
      if (initObj.hasOwnProperty('state_emer')) {
        this.state_emer = initObj.state_emer
      }
      else {
        this.state_emer = false;
      }
      if (initObj.hasOwnProperty('state_bumper')) {
        this.state_bumper = initObj.state_bumper
      }
      else {
        this.state_bumper = 0;
      }
      if (initObj.hasOwnProperty('zigbee_state')) {
        this.zigbee_state = initObj.zigbee_state
      }
      else {
        this.zigbee_state = false;
      }
      if (initObj.hasOwnProperty('is_safe_stop')) {
        this.is_safe_stop = initObj.is_safe_stop
      }
      else {
        this.is_safe_stop = false;
      }
      if (initObj.hasOwnProperty('is_open_bumper')) {
        this.is_open_bumper = initObj.is_open_bumper
      }
      else {
        this.is_open_bumper = false;
      }
      if (initObj.hasOwnProperty('is_open_emer')) {
        this.is_open_emer = initObj.is_open_emer
      }
      else {
        this.is_open_emer = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RobotStateInfoResponse
    // Serialize message field [res]
    bufferOffset = _serializer.bool(obj.res, buffer, bufferOffset);
    // Serialize message field [state_imu]
    bufferOffset = _serializer.bool(obj.state_imu, buffer, bufferOffset);
    // Serialize message field [state_laser]
    bufferOffset = _serializer.bool(obj.state_laser, buffer, bufferOffset);
    // Serialize message field [state_emer]
    bufferOffset = _serializer.bool(obj.state_emer, buffer, bufferOffset);
    // Serialize message field [state_bumper]
    bufferOffset = _serializer.int16(obj.state_bumper, buffer, bufferOffset);
    // Serialize message field [zigbee_state]
    bufferOffset = _serializer.bool(obj.zigbee_state, buffer, bufferOffset);
    // Serialize message field [is_safe_stop]
    bufferOffset = _serializer.bool(obj.is_safe_stop, buffer, bufferOffset);
    // Serialize message field [is_open_bumper]
    bufferOffset = _serializer.bool(obj.is_open_bumper, buffer, bufferOffset);
    // Serialize message field [is_open_emer]
    bufferOffset = _serializer.bool(obj.is_open_emer, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RobotStateInfoResponse
    let len;
    let data = new RobotStateInfoResponse(null);
    // Deserialize message field [res]
    data.res = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_imu]
    data.state_imu = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_laser]
    data.state_laser = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_emer]
    data.state_emer = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_bumper]
    data.state_bumper = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [zigbee_state]
    data.zigbee_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_safe_stop]
    data.is_safe_stop = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_open_bumper]
    data.is_open_bumper = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_open_emer]
    data.is_open_emer = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 10;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/RobotStateInfoResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd3093114059bba33aeea623e638b4b50';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool res
    bool state_imu
    bool state_laser
    bool state_emer
    int16 state_bumper
    bool zigbee_state
    bool is_safe_stop
    bool is_open_bumper
    bool is_open_emer
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RobotStateInfoResponse(null);
    if (msg.res !== undefined) {
      resolved.res = msg.res;
    }
    else {
      resolved.res = false
    }

    if (msg.state_imu !== undefined) {
      resolved.state_imu = msg.state_imu;
    }
    else {
      resolved.state_imu = false
    }

    if (msg.state_laser !== undefined) {
      resolved.state_laser = msg.state_laser;
    }
    else {
      resolved.state_laser = false
    }

    if (msg.state_emer !== undefined) {
      resolved.state_emer = msg.state_emer;
    }
    else {
      resolved.state_emer = false
    }

    if (msg.state_bumper !== undefined) {
      resolved.state_bumper = msg.state_bumper;
    }
    else {
      resolved.state_bumper = 0
    }

    if (msg.zigbee_state !== undefined) {
      resolved.zigbee_state = msg.zigbee_state;
    }
    else {
      resolved.zigbee_state = false
    }

    if (msg.is_safe_stop !== undefined) {
      resolved.is_safe_stop = msg.is_safe_stop;
    }
    else {
      resolved.is_safe_stop = false
    }

    if (msg.is_open_bumper !== undefined) {
      resolved.is_open_bumper = msg.is_open_bumper;
    }
    else {
      resolved.is_open_bumper = false
    }

    if (msg.is_open_emer !== undefined) {
      resolved.is_open_emer = msg.is_open_emer;
    }
    else {
      resolved.is_open_emer = false
    }

    return resolved;
    }
};

module.exports = {
  Request: RobotStateInfoRequest,
  Response: RobotStateInfoResponse,
  md5sum() { return 'd02e8e78d245772d0856a8dc6e13a51b'; },
  datatype() { return 'custom_msgs_srvs/RobotStateInfo'; }
};
