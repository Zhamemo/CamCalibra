// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let nav_msgs = _finder('nav_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class GetPlanRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.use_start = null;
      this.start = null;
      this.goal = null;
    }
    else {
      if (initObj.hasOwnProperty('use_start')) {
        this.use_start = initObj.use_start
      }
      else {
        this.use_start = false;
      }
      if (initObj.hasOwnProperty('start')) {
        this.start = initObj.start
      }
      else {
        this.start = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('goal')) {
        this.goal = initObj.goal
      }
      else {
        this.goal = new geometry_msgs.msg.PoseStamped();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetPlanRequest
    // Serialize message field [use_start]
    bufferOffset = _serializer.bool(obj.use_start, buffer, bufferOffset);
    // Serialize message field [start]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.start, buffer, bufferOffset);
    // Serialize message field [goal]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.goal, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetPlanRequest
    let len;
    let data = new GetPlanRequest(null);
    // Deserialize message field [use_start]
    data.use_start = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [start]
    data.start = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [goal]
    data.goal = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.start);
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.goal);
    return length + 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/GetPlanRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'adb85b50028b4e63e39b7144568ac686';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # use start pose or use robot pose
    bool use_start
    # The start pose for the plan
    geometry_msgs/PoseStamped start
    # The final pose of the goal position
    geometry_msgs/PoseStamped goal
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetPlanRequest(null);
    if (msg.use_start !== undefined) {
      resolved.use_start = msg.use_start;
    }
    else {
      resolved.use_start = false
    }

    if (msg.start !== undefined) {
      resolved.start = geometry_msgs.msg.PoseStamped.Resolve(msg.start)
    }
    else {
      resolved.start = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.goal !== undefined) {
      resolved.goal = geometry_msgs.msg.PoseStamped.Resolve(msg.goal)
    }
    else {
      resolved.goal = new geometry_msgs.msg.PoseStamped()
    }

    return resolved;
    }
};

class GetPlanResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan_found = null;
      this.plan = null;
      this.path_lenght = null;
    }
    else {
      if (initObj.hasOwnProperty('plan_found')) {
        this.plan_found = initObj.plan_found
      }
      else {
        this.plan_found = false;
      }
      if (initObj.hasOwnProperty('plan')) {
        this.plan = initObj.plan
      }
      else {
        this.plan = new nav_msgs.msg.Path();
      }
      if (initObj.hasOwnProperty('path_lenght')) {
        this.path_lenght = initObj.path_lenght
      }
      else {
        this.path_lenght = new std_msgs.msg.Float32();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetPlanResponse
    // Serialize message field [plan_found]
    bufferOffset = _serializer.bool(obj.plan_found, buffer, bufferOffset);
    // Serialize message field [plan]
    bufferOffset = nav_msgs.msg.Path.serialize(obj.plan, buffer, bufferOffset);
    // Serialize message field [path_lenght]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.path_lenght, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetPlanResponse
    let len;
    let data = new GetPlanResponse(null);
    // Deserialize message field [plan_found]
    data.plan_found = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [plan]
    data.plan = nav_msgs.msg.Path.deserialize(buffer, bufferOffset);
    // Deserialize message field [path_lenght]
    data.path_lenght = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += nav_msgs.msg.Path.getMessageSize(object.plan);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/GetPlanResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '50f3aa4dc348b8b8600a6f64d360a448';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    bool plan_found
    nav_msgs/Path plan
    std_msgs/Float32 path_lenght
    
    
    ================================================================================
    MSG: nav_msgs/Path
    #An array of poses that represents a Path for a robot to follow
    Header header
    geometry_msgs/PoseStamped[] poses
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: std_msgs/Float32
    float32 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetPlanResponse(null);
    if (msg.plan_found !== undefined) {
      resolved.plan_found = msg.plan_found;
    }
    else {
      resolved.plan_found = false
    }

    if (msg.plan !== undefined) {
      resolved.plan = nav_msgs.msg.Path.Resolve(msg.plan)
    }
    else {
      resolved.plan = new nav_msgs.msg.Path()
    }

    if (msg.path_lenght !== undefined) {
      resolved.path_lenght = std_msgs.msg.Float32.Resolve(msg.path_lenght)
    }
    else {
      resolved.path_lenght = new std_msgs.msg.Float32()
    }

    return resolved;
    }
};

module.exports = {
  Request: GetPlanRequest,
  Response: GetPlanResponse,
  md5sum() { return '00420edb813bb860c4d45c1525f04d3d'; },
  datatype() { return 'custom_msgs_srvs/GetPlan'; }
};
