// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class PlanBuildingPathRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.start_floor = null;
      this.target_floor = null;
      this.start = null;
      this.target = null;
      this.data = null;
    }
    else {
      if (initObj.hasOwnProperty('start_floor')) {
        this.start_floor = initObj.start_floor
      }
      else {
        this.start_floor = 0;
      }
      if (initObj.hasOwnProperty('target_floor')) {
        this.target_floor = initObj.target_floor
      }
      else {
        this.target_floor = 0;
      }
      if (initObj.hasOwnProperty('start')) {
        this.start = initObj.start
      }
      else {
        this.start = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('target')) {
        this.target = initObj.target
      }
      else {
        this.target = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlanBuildingPathRequest
    // Serialize message field [start_floor]
    bufferOffset = _serializer.int32(obj.start_floor, buffer, bufferOffset);
    // Serialize message field [target_floor]
    bufferOffset = _serializer.int32(obj.target_floor, buffer, bufferOffset);
    // Serialize message field [start]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.start, buffer, bufferOffset);
    // Serialize message field [target]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.target, buffer, bufferOffset);
    // Serialize message field [data]
    bufferOffset = _serializer.string(obj.data, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlanBuildingPathRequest
    let len;
    let data = new PlanBuildingPathRequest(null);
    // Deserialize message field [start_floor]
    data.start_floor = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [target_floor]
    data.target_floor = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [start]
    data.start = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [target]
    data.target = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [data]
    data.data = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.start);
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.target);
    length += object.data.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/PlanBuildingPathRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a7e30cb07ec42d114555cb57dd104500';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 start_floor 
    int32 target_floor
    geometry_msgs/PoseStamped start
    geometry_msgs/PoseStamped target
    string data
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlanBuildingPathRequest(null);
    if (msg.start_floor !== undefined) {
      resolved.start_floor = msg.start_floor;
    }
    else {
      resolved.start_floor = 0
    }

    if (msg.target_floor !== undefined) {
      resolved.target_floor = msg.target_floor;
    }
    else {
      resolved.target_floor = 0
    }

    if (msg.start !== undefined) {
      resolved.start = geometry_msgs.msg.PoseStamped.Resolve(msg.start)
    }
    else {
      resolved.start = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.target !== undefined) {
      resolved.target = geometry_msgs.msg.PoseStamped.Resolve(msg.target)
    }
    else {
      resolved.target = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = ''
    }

    return resolved;
    }
};

class PlanBuildingPathResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan_result = null;
      this.res = null;
    }
    else {
      if (initObj.hasOwnProperty('plan_result')) {
        this.plan_result = initObj.plan_result
      }
      else {
        this.plan_result = '';
      }
      if (initObj.hasOwnProperty('res')) {
        this.res = initObj.res
      }
      else {
        this.res = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlanBuildingPathResponse
    // Serialize message field [plan_result]
    bufferOffset = _serializer.string(obj.plan_result, buffer, bufferOffset);
    // Serialize message field [res]
    bufferOffset = _serializer.int32(obj.res, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlanBuildingPathResponse
    let len;
    let data = new PlanBuildingPathResponse(null);
    // Deserialize message field [plan_result]
    data.plan_result = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [res]
    data.res = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.plan_result.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'custom_msgs_srvs/PlanBuildingPathResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e52558241aba31ebd268aefeae826a77';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string plan_result
    int32 res
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlanBuildingPathResponse(null);
    if (msg.plan_result !== undefined) {
      resolved.plan_result = msg.plan_result;
    }
    else {
      resolved.plan_result = ''
    }

    if (msg.res !== undefined) {
      resolved.res = msg.res;
    }
    else {
      resolved.res = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: PlanBuildingPathRequest,
  Response: PlanBuildingPathResponse,
  md5sum() { return 'dea00c24791e385ed4808d10fbf4e47c'; },
  datatype() { return 'custom_msgs_srvs/PlanBuildingPath'; }
};
