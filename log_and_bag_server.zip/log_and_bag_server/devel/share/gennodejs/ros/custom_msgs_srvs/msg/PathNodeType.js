// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PathNodeType {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_id = null;
      this.node_name = null;
      this.neighbor_node_id = null;
      this.virtue_one = null;
      this.virtue_two = null;
      this.virtue_three = null;
      this.road_width = null;
      this.setting_nodes = null;
    }
    else {
      if (initObj.hasOwnProperty('node_id')) {
        this.node_id = initObj.node_id
      }
      else {
        this.node_id = 0;
      }
      if (initObj.hasOwnProperty('node_name')) {
        this.node_name = initObj.node_name
      }
      else {
        this.node_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('neighbor_node_id')) {
        this.neighbor_node_id = initObj.neighbor_node_id
      }
      else {
        this.neighbor_node_id = [];
      }
      if (initObj.hasOwnProperty('virtue_one')) {
        this.virtue_one = initObj.virtue_one
      }
      else {
        this.virtue_one = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('virtue_two')) {
        this.virtue_two = initObj.virtue_two
      }
      else {
        this.virtue_two = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('virtue_three')) {
        this.virtue_three = initObj.virtue_three
      }
      else {
        this.virtue_three = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('road_width')) {
        this.road_width = initObj.road_width
      }
      else {
        this.road_width = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('setting_nodes')) {
        this.setting_nodes = initObj.setting_nodes
      }
      else {
        this.setting_nodes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PathNodeType
    // Serialize message field [node_id]
    bufferOffset = _serializer.int16(obj.node_id, buffer, bufferOffset);
    // Serialize message field [node_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.node_name, buffer, bufferOffset);
    // Serialize message field [neighbor_node_id]
    bufferOffset = _arraySerializer.int16(obj.neighbor_node_id, buffer, bufferOffset, null);
    // Serialize message field [virtue_one]
    bufferOffset = std_msgs.msg.String.serialize(obj.virtue_one, buffer, bufferOffset);
    // Serialize message field [virtue_two]
    bufferOffset = std_msgs.msg.String.serialize(obj.virtue_two, buffer, bufferOffset);
    // Serialize message field [virtue_three]
    bufferOffset = std_msgs.msg.String.serialize(obj.virtue_three, buffer, bufferOffset);
    // Serialize message field [road_width]
    bufferOffset = std_msgs.msg.String.serialize(obj.road_width, buffer, bufferOffset);
    // Serialize message field [setting_nodes]
    bufferOffset = _arraySerializer.int16(obj.setting_nodes, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PathNodeType
    let len;
    let data = new PathNodeType(null);
    // Deserialize message field [node_id]
    data.node_id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [node_name]
    data.node_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [neighbor_node_id]
    data.neighbor_node_id = _arrayDeserializer.int16(buffer, bufferOffset, null)
    // Deserialize message field [virtue_one]
    data.virtue_one = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [virtue_two]
    data.virtue_two = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [virtue_three]
    data.virtue_three = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [road_width]
    data.road_width = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [setting_nodes]
    data.setting_nodes = _arrayDeserializer.int16(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.node_name);
    length += 2 * object.neighbor_node_id.length;
    length += std_msgs.msg.String.getMessageSize(object.virtue_one);
    length += std_msgs.msg.String.getMessageSize(object.virtue_two);
    length += std_msgs.msg.String.getMessageSize(object.virtue_three);
    length += std_msgs.msg.String.getMessageSize(object.road_width);
    length += 2 * object.setting_nodes.length;
    return length + 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/PathNodeType';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '030381feb9fb6e50f37fe4dad0e9cecf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 node_id
    std_msgs/String node_name
    int16[] neighbor_node_id
    std_msgs/String virtue_one
    std_msgs/String virtue_two
    std_msgs/String virtue_three
    std_msgs/String road_width
    int16[] setting_nodes
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PathNodeType(null);
    if (msg.node_id !== undefined) {
      resolved.node_id = msg.node_id;
    }
    else {
      resolved.node_id = 0
    }

    if (msg.node_name !== undefined) {
      resolved.node_name = std_msgs.msg.String.Resolve(msg.node_name)
    }
    else {
      resolved.node_name = new std_msgs.msg.String()
    }

    if (msg.neighbor_node_id !== undefined) {
      resolved.neighbor_node_id = msg.neighbor_node_id;
    }
    else {
      resolved.neighbor_node_id = []
    }

    if (msg.virtue_one !== undefined) {
      resolved.virtue_one = std_msgs.msg.String.Resolve(msg.virtue_one)
    }
    else {
      resolved.virtue_one = new std_msgs.msg.String()
    }

    if (msg.virtue_two !== undefined) {
      resolved.virtue_two = std_msgs.msg.String.Resolve(msg.virtue_two)
    }
    else {
      resolved.virtue_two = new std_msgs.msg.String()
    }

    if (msg.virtue_three !== undefined) {
      resolved.virtue_three = std_msgs.msg.String.Resolve(msg.virtue_three)
    }
    else {
      resolved.virtue_three = new std_msgs.msg.String()
    }

    if (msg.road_width !== undefined) {
      resolved.road_width = std_msgs.msg.String.Resolve(msg.road_width)
    }
    else {
      resolved.road_width = new std_msgs.msg.String()
    }

    if (msg.setting_nodes !== undefined) {
      resolved.setting_nodes = msg.setting_nodes;
    }
    else {
      resolved.setting_nodes = []
    }

    return resolved;
    }
};

module.exports = PathNodeType;
