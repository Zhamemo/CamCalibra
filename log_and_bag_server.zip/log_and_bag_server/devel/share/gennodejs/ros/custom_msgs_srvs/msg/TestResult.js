// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TestResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.test_item = null;
      this.result = null;
      this.extra = null;
    }
    else {
      if (initObj.hasOwnProperty('test_item')) {
        this.test_item = initObj.test_item
      }
      else {
        this.test_item = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = false;
      }
      if (initObj.hasOwnProperty('extra')) {
        this.extra = initObj.extra
      }
      else {
        this.extra = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TestResult
    // Serialize message field [test_item]
    bufferOffset = std_msgs.msg.String.serialize(obj.test_item, buffer, bufferOffset);
    // Serialize message field [result]
    bufferOffset = _serializer.bool(obj.result, buffer, bufferOffset);
    // Serialize message field [extra]
    bufferOffset = std_msgs.msg.String.serialize(obj.extra, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TestResult
    let len;
    let data = new TestResult(null);
    // Deserialize message field [test_item]
    data.test_item = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [result]
    data.result = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [extra]
    data.extra = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.test_item);
    length += std_msgs.msg.String.getMessageSize(object.extra);
    return length + 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/TestResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4ce229a596d0e5b3ea3389b69d5e5bdb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String test_item
    bool result
    std_msgs/String extra
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TestResult(null);
    if (msg.test_item !== undefined) {
      resolved.test_item = std_msgs.msg.String.Resolve(msg.test_item)
    }
    else {
      resolved.test_item = new std_msgs.msg.String()
    }

    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = false
    }

    if (msg.extra !== undefined) {
      resolved.extra = std_msgs.msg.String.Resolve(msg.extra)
    }
    else {
      resolved.extra = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = TestResult;
