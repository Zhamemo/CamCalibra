// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ApkReceiveResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.event = null;
      this.work_result = null;
    }
    else {
      if (initObj.hasOwnProperty('event')) {
        this.event = initObj.event
      }
      else {
        this.event = 0;
      }
      if (initObj.hasOwnProperty('work_result')) {
        this.work_result = initObj.work_result
      }
      else {
        this.work_result = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ApkReceiveResult
    // Serialize message field [event]
    bufferOffset = _serializer.int32(obj.event, buffer, bufferOffset);
    // Serialize message field [work_result]
    bufferOffset = std_msgs.msg.String.serialize(obj.work_result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ApkReceiveResult
    let len;
    let data = new ApkReceiveResult(null);
    // Deserialize message field [event]
    data.event = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [work_result]
    data.work_result = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.work_result);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/ApkReceiveResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '83d7f75a62ad7183b06df2dd7cae7d20';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 event
    std_msgs/String work_result
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ApkReceiveResult(null);
    if (msg.event !== undefined) {
      resolved.event = msg.event;
    }
    else {
      resolved.event = 0
    }

    if (msg.work_result !== undefined) {
      resolved.work_result = std_msgs.msg.String.Resolve(msg.work_result)
    }
    else {
      resolved.work_result = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = ApkReceiveResult;
