// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class InOutLiftState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.robot_lift_state = null;
      this.continue_run_size = null;
      this.start_elevator_dis = null;
      this.end_elevator_dis = null;
      this.robot_elevator_dis = null;
      this.robot_start_dis = null;
      this.ud_elevator_enter_residual = null;
      this.robot_end_dis = null;
      this.ud_elevator_out_residual = null;
    }
    else {
      if (initObj.hasOwnProperty('robot_lift_state')) {
        this.robot_lift_state = initObj.robot_lift_state
      }
      else {
        this.robot_lift_state = 0;
      }
      if (initObj.hasOwnProperty('continue_run_size')) {
        this.continue_run_size = initObj.continue_run_size
      }
      else {
        this.continue_run_size = 0;
      }
      if (initObj.hasOwnProperty('start_elevator_dis')) {
        this.start_elevator_dis = initObj.start_elevator_dis
      }
      else {
        this.start_elevator_dis = 0;
      }
      if (initObj.hasOwnProperty('end_elevator_dis')) {
        this.end_elevator_dis = initObj.end_elevator_dis
      }
      else {
        this.end_elevator_dis = 0;
      }
      if (initObj.hasOwnProperty('robot_elevator_dis')) {
        this.robot_elevator_dis = initObj.robot_elevator_dis
      }
      else {
        this.robot_elevator_dis = 0;
      }
      if (initObj.hasOwnProperty('robot_start_dis')) {
        this.robot_start_dis = initObj.robot_start_dis
      }
      else {
        this.robot_start_dis = 0;
      }
      if (initObj.hasOwnProperty('ud_elevator_enter_residual')) {
        this.ud_elevator_enter_residual = initObj.ud_elevator_enter_residual
      }
      else {
        this.ud_elevator_enter_residual = 0;
      }
      if (initObj.hasOwnProperty('robot_end_dis')) {
        this.robot_end_dis = initObj.robot_end_dis
      }
      else {
        this.robot_end_dis = 0;
      }
      if (initObj.hasOwnProperty('ud_elevator_out_residual')) {
        this.ud_elevator_out_residual = initObj.ud_elevator_out_residual
      }
      else {
        this.ud_elevator_out_residual = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type InOutLiftState
    // Serialize message field [robot_lift_state]
    bufferOffset = _serializer.int32(obj.robot_lift_state, buffer, bufferOffset);
    // Serialize message field [continue_run_size]
    bufferOffset = _serializer.int32(obj.continue_run_size, buffer, bufferOffset);
    // Serialize message field [start_elevator_dis]
    bufferOffset = _serializer.int32(obj.start_elevator_dis, buffer, bufferOffset);
    // Serialize message field [end_elevator_dis]
    bufferOffset = _serializer.int32(obj.end_elevator_dis, buffer, bufferOffset);
    // Serialize message field [robot_elevator_dis]
    bufferOffset = _serializer.int32(obj.robot_elevator_dis, buffer, bufferOffset);
    // Serialize message field [robot_start_dis]
    bufferOffset = _serializer.int32(obj.robot_start_dis, buffer, bufferOffset);
    // Serialize message field [ud_elevator_enter_residual]
    bufferOffset = _serializer.int32(obj.ud_elevator_enter_residual, buffer, bufferOffset);
    // Serialize message field [robot_end_dis]
    bufferOffset = _serializer.int32(obj.robot_end_dis, buffer, bufferOffset);
    // Serialize message field [ud_elevator_out_residual]
    bufferOffset = _serializer.int32(obj.ud_elevator_out_residual, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type InOutLiftState
    let len;
    let data = new InOutLiftState(null);
    // Deserialize message field [robot_lift_state]
    data.robot_lift_state = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [continue_run_size]
    data.continue_run_size = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [start_elevator_dis]
    data.start_elevator_dis = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [end_elevator_dis]
    data.end_elevator_dis = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [robot_elevator_dis]
    data.robot_elevator_dis = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [robot_start_dis]
    data.robot_start_dis = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [ud_elevator_enter_residual]
    data.ud_elevator_enter_residual = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [robot_end_dis]
    data.robot_end_dis = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [ud_elevator_out_residual]
    data.ud_elevator_out_residual = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/InOutLiftState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8883a1efb4175cd0d9963096dcae123b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
      #机器人与梯中间点的关系， 0 机器人在电梯外，且距离坎小于 ud_elevator_out_residual_;1 机器人在电梯外，且距离坎大于 ud_elevator_out_residual_;
      #2 机器人在电梯内，且距离坎小于 ud_elevator_enter_residual_;3 机器人在电梯内，且距离坎大于 ud_elevator_enter_residual_; -1无效
      int32 robot_lift_state
      #进梯时是需要继续行驶多少可完成进梯, robot_lift_state处于0 1时， continue_run_size = ud_elevator_enter_residual+robot_elevator_dis, 
                                    #robot_lift_state处于2 3 时， continue_run_size = ud_elevator_enter_residual-robot_elevator_dis, 如果为负数说明已经过了;
      #出梯时需要继续行驶多少完成进梯,  robot_lift_state处于2 3 时， continue_run_size = ud_elevator_out_residual+robot_elevator_dis, 
                                    #robot_lift_state处于0 1 时， continue_run_size = ud_elevator_out_residual-robot_elevator_dis, 如果为负数说明已经过了; 默认100
      int32 continue_run_size   
      int32 start_elevator_dis  #梯外点与梯中间点(坎)的index, 梯外点到梯内点的连线 都需要*0.05
      int32 end_elevator_dis    #梯内点与梯中间点(坎)的index , 梯外点到梯内点的连线
      int32 robot_elevator_dis  #机器人与梯中间点(坎)的index , 梯外点到梯内点的连线
      int32 robot_start_dis     #机器人与梯外点的index , 梯外点到梯内点的连线
      int32 ud_elevator_enter_residual
      int32 robot_end_dis       #机器人与梯内点的index , 梯外点到梯内点的连线
      int32 ud_elevator_out_residual   
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new InOutLiftState(null);
    if (msg.robot_lift_state !== undefined) {
      resolved.robot_lift_state = msg.robot_lift_state;
    }
    else {
      resolved.robot_lift_state = 0
    }

    if (msg.continue_run_size !== undefined) {
      resolved.continue_run_size = msg.continue_run_size;
    }
    else {
      resolved.continue_run_size = 0
    }

    if (msg.start_elevator_dis !== undefined) {
      resolved.start_elevator_dis = msg.start_elevator_dis;
    }
    else {
      resolved.start_elevator_dis = 0
    }

    if (msg.end_elevator_dis !== undefined) {
      resolved.end_elevator_dis = msg.end_elevator_dis;
    }
    else {
      resolved.end_elevator_dis = 0
    }

    if (msg.robot_elevator_dis !== undefined) {
      resolved.robot_elevator_dis = msg.robot_elevator_dis;
    }
    else {
      resolved.robot_elevator_dis = 0
    }

    if (msg.robot_start_dis !== undefined) {
      resolved.robot_start_dis = msg.robot_start_dis;
    }
    else {
      resolved.robot_start_dis = 0
    }

    if (msg.ud_elevator_enter_residual !== undefined) {
      resolved.ud_elevator_enter_residual = msg.ud_elevator_enter_residual;
    }
    else {
      resolved.ud_elevator_enter_residual = 0
    }

    if (msg.robot_end_dis !== undefined) {
      resolved.robot_end_dis = msg.robot_end_dis;
    }
    else {
      resolved.robot_end_dis = 0
    }

    if (msg.ud_elevator_out_residual !== undefined) {
      resolved.ud_elevator_out_residual = msg.ud_elevator_out_residual;
    }
    else {
      resolved.ud_elevator_out_residual = 0
    }

    return resolved;
    }
};

module.exports = InOutLiftState;
