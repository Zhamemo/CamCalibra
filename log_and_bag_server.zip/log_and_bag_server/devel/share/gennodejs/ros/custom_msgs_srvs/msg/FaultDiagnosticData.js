// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FaultDiagnosticData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.state = null;
      this.fault_level = null;
      this.recovery_cnt = null;
      this.fault_style = null;
      this.fault_messge = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
      if (initObj.hasOwnProperty('fault_level')) {
        this.fault_level = initObj.fault_level
      }
      else {
        this.fault_level = 0;
      }
      if (initObj.hasOwnProperty('recovery_cnt')) {
        this.recovery_cnt = initObj.recovery_cnt
      }
      else {
        this.recovery_cnt = 0;
      }
      if (initObj.hasOwnProperty('fault_style')) {
        this.fault_style = initObj.fault_style
      }
      else {
        this.fault_style = '';
      }
      if (initObj.hasOwnProperty('fault_messge')) {
        this.fault_messge = initObj.fault_messge
      }
      else {
        this.fault_messge = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FaultDiagnosticData
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = _serializer.int8(obj.state, buffer, bufferOffset);
    // Serialize message field [fault_level]
    bufferOffset = _serializer.int8(obj.fault_level, buffer, bufferOffset);
    // Serialize message field [recovery_cnt]
    bufferOffset = _serializer.int8(obj.recovery_cnt, buffer, bufferOffset);
    // Serialize message field [fault_style]
    bufferOffset = _serializer.string(obj.fault_style, buffer, bufferOffset);
    // Serialize message field [fault_messge]
    bufferOffset = _serializer.string(obj.fault_messge, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FaultDiagnosticData
    let len;
    let data = new FaultDiagnosticData(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [fault_level]
    data.fault_level = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [recovery_cnt]
    data.recovery_cnt = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [fault_style]
    data.fault_style = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [fault_messge]
    data.fault_messge = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.fault_style.length;
    length += object.fault_messge.length;
    return length + 19;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/FaultDiagnosticData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd5ac4a1e71f0c20ab75e40ebe6df5e84';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp                                                          
    int8 state                                             
    int8 fault_level
    int8 recovery_cnt                                 
    string fault_style                         
    string fault_messge 
                
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FaultDiagnosticData(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    if (msg.fault_level !== undefined) {
      resolved.fault_level = msg.fault_level;
    }
    else {
      resolved.fault_level = 0
    }

    if (msg.recovery_cnt !== undefined) {
      resolved.recovery_cnt = msg.recovery_cnt;
    }
    else {
      resolved.recovery_cnt = 0
    }

    if (msg.fault_style !== undefined) {
      resolved.fault_style = msg.fault_style;
    }
    else {
      resolved.fault_style = ''
    }

    if (msg.fault_messge !== undefined) {
      resolved.fault_messge = msg.fault_messge;
    }
    else {
      resolved.fault_messge = ''
    }

    return resolved;
    }
};

module.exports = FaultDiagnosticData;
