// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FaultRecoveryData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.is_recovery = null;
      this.full_recovery = null;
      this.fault_style = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('is_recovery')) {
        this.is_recovery = initObj.is_recovery
      }
      else {
        this.is_recovery = false;
      }
      if (initObj.hasOwnProperty('full_recovery')) {
        this.full_recovery = initObj.full_recovery
      }
      else {
        this.full_recovery = false;
      }
      if (initObj.hasOwnProperty('fault_style')) {
        this.fault_style = initObj.fault_style
      }
      else {
        this.fault_style = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FaultRecoveryData
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [is_recovery]
    bufferOffset = _serializer.bool(obj.is_recovery, buffer, bufferOffset);
    // Serialize message field [full_recovery]
    bufferOffset = _serializer.bool(obj.full_recovery, buffer, bufferOffset);
    // Serialize message field [fault_style]
    bufferOffset = _serializer.string(obj.fault_style, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FaultRecoveryData
    let len;
    let data = new FaultRecoveryData(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [is_recovery]
    data.is_recovery = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [full_recovery]
    data.full_recovery = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [fault_style]
    data.fault_style = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.fault_style.length;
    return length + 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/FaultRecoveryData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '78a18dc5ea7278e71ce50018029ae566';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp                                            
    bool  is_recovery
    bool full_recovery           
    string fault_style                    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FaultRecoveryData(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.is_recovery !== undefined) {
      resolved.is_recovery = msg.is_recovery;
    }
    else {
      resolved.is_recovery = false
    }

    if (msg.full_recovery !== undefined) {
      resolved.full_recovery = msg.full_recovery;
    }
    else {
      resolved.full_recovery = false
    }

    if (msg.fault_style !== undefined) {
      resolved.fault_style = msg.fault_style;
    }
    else {
      resolved.fault_style = ''
    }

    return resolved;
    }
};

module.exports = FaultRecoveryData;
