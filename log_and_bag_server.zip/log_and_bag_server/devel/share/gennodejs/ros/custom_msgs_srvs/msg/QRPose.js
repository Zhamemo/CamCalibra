// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class QRPose {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.id = null;
      this.pose_x = null;
      this.pose_y = null;
      this.pose_z = null;
      this.pose_roll = null;
      this.pose_pitch = null;
      this.pose_yaw = null;
      this.flags = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('pose_x')) {
        this.pose_x = initObj.pose_x
      }
      else {
        this.pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('pose_y')) {
        this.pose_y = initObj.pose_y
      }
      else {
        this.pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('pose_z')) {
        this.pose_z = initObj.pose_z
      }
      else {
        this.pose_z = 0.0;
      }
      if (initObj.hasOwnProperty('pose_roll')) {
        this.pose_roll = initObj.pose_roll
      }
      else {
        this.pose_roll = 0.0;
      }
      if (initObj.hasOwnProperty('pose_pitch')) {
        this.pose_pitch = initObj.pose_pitch
      }
      else {
        this.pose_pitch = 0.0;
      }
      if (initObj.hasOwnProperty('pose_yaw')) {
        this.pose_yaw = initObj.pose_yaw
      }
      else {
        this.pose_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('flags')) {
        this.flags = initObj.flags
      }
      else {
        this.flags = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type QRPose
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    // Serialize message field [pose_x]
    bufferOffset = _serializer.float32(obj.pose_x, buffer, bufferOffset);
    // Serialize message field [pose_y]
    bufferOffset = _serializer.float32(obj.pose_y, buffer, bufferOffset);
    // Serialize message field [pose_z]
    bufferOffset = _serializer.float32(obj.pose_z, buffer, bufferOffset);
    // Serialize message field [pose_roll]
    bufferOffset = _serializer.float32(obj.pose_roll, buffer, bufferOffset);
    // Serialize message field [pose_pitch]
    bufferOffset = _serializer.float32(obj.pose_pitch, buffer, bufferOffset);
    // Serialize message field [pose_yaw]
    bufferOffset = _serializer.float32(obj.pose_yaw, buffer, bufferOffset);
    // Serialize message field [flags]
    bufferOffset = _serializer.int32(obj.flags, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type QRPose
    let len;
    let data = new QRPose(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [pose_x]
    data.pose_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_y]
    data.pose_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_z]
    data.pose_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_roll]
    data.pose_roll = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_pitch]
    data.pose_pitch = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_yaw]
    data.pose_yaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [flags]
    data.flags = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/QRPose';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2935f2bc835fbab709dd5561c0572458';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    int32 id
    float32 pose_x
    float32 pose_y
    float32 pose_z
    float32 pose_roll
    float32 pose_pitch
    float32 pose_yaw
    int32 flags
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new QRPose(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.pose_x !== undefined) {
      resolved.pose_x = msg.pose_x;
    }
    else {
      resolved.pose_x = 0.0
    }

    if (msg.pose_y !== undefined) {
      resolved.pose_y = msg.pose_y;
    }
    else {
      resolved.pose_y = 0.0
    }

    if (msg.pose_z !== undefined) {
      resolved.pose_z = msg.pose_z;
    }
    else {
      resolved.pose_z = 0.0
    }

    if (msg.pose_roll !== undefined) {
      resolved.pose_roll = msg.pose_roll;
    }
    else {
      resolved.pose_roll = 0.0
    }

    if (msg.pose_pitch !== undefined) {
      resolved.pose_pitch = msg.pose_pitch;
    }
    else {
      resolved.pose_pitch = 0.0
    }

    if (msg.pose_yaw !== undefined) {
      resolved.pose_yaw = msg.pose_yaw;
    }
    else {
      resolved.pose_yaw = 0.0
    }

    if (msg.flags !== undefined) {
      resolved.flags = msg.flags;
    }
    else {
      resolved.flags = 0
    }

    return resolved;
    }
};

module.exports = QRPose;
