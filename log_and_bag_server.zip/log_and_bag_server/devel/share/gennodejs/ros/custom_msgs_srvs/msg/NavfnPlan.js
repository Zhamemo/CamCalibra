// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class NavfnPlan {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan_mode = null;
      this.conflict_nodes = null;
      this.pose = null;
    }
    else {
      if (initObj.hasOwnProperty('plan_mode')) {
        this.plan_mode = initObj.plan_mode
      }
      else {
        this.plan_mode = 0;
      }
      if (initObj.hasOwnProperty('conflict_nodes')) {
        this.conflict_nodes = initObj.conflict_nodes
      }
      else {
        this.conflict_nodes = [];
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.PoseStamped();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NavfnPlan
    // Serialize message field [plan_mode]
    bufferOffset = _serializer.int16(obj.plan_mode, buffer, bufferOffset);
    // Serialize message field [conflict_nodes]
    bufferOffset = _arraySerializer.int16(obj.conflict_nodes, buffer, bufferOffset, null);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.pose, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NavfnPlan
    let len;
    let data = new NavfnPlan(null);
    // Deserialize message field [plan_mode]
    data.plan_mode = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [conflict_nodes]
    data.conflict_nodes = _arrayDeserializer.int16(buffer, bufferOffset, null)
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 2 * object.conflict_nodes.length;
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.pose);
    return length + 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/NavfnPlan';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7235a7c2f62beb2339b6b77f5f6a1977';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 plan_mode
    int16[] conflict_nodes
    geometry_msgs/PoseStamped  pose
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NavfnPlan(null);
    if (msg.plan_mode !== undefined) {
      resolved.plan_mode = msg.plan_mode;
    }
    else {
      resolved.plan_mode = 0
    }

    if (msg.conflict_nodes !== undefined) {
      resolved.conflict_nodes = msg.conflict_nodes;
    }
    else {
      resolved.conflict_nodes = []
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.PoseStamped.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.PoseStamped()
    }

    return resolved;
    }
};

module.exports = NavfnPlan;
