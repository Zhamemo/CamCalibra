// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class RobotInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.ip = null;
      this.robot_style = null;
      this.prior = null;
      this.build_id = null;
      this.floor_id = null;
      this.multi_state = null;
      this.state = null;
      this.pose_x = null;
      this.pose_y = null;
      this.pose_yaw = null;
      this.goal_x = null;
      this.goal_y = null;
      this.sport_state = null;
      this.overtake = null;
      this.node_list = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('ip')) {
        this.ip = initObj.ip
      }
      else {
        this.ip = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('robot_style')) {
        this.robot_style = initObj.robot_style
      }
      else {
        this.robot_style = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('prior')) {
        this.prior = initObj.prior
      }
      else {
        this.prior = 0;
      }
      if (initObj.hasOwnProperty('build_id')) {
        this.build_id = initObj.build_id
      }
      else {
        this.build_id = 0;
      }
      if (initObj.hasOwnProperty('floor_id')) {
        this.floor_id = initObj.floor_id
      }
      else {
        this.floor_id = 0;
      }
      if (initObj.hasOwnProperty('multi_state')) {
        this.multi_state = initObj.multi_state
      }
      else {
        this.multi_state = 0;
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('pose_x')) {
        this.pose_x = initObj.pose_x
      }
      else {
        this.pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('pose_y')) {
        this.pose_y = initObj.pose_y
      }
      else {
        this.pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('pose_yaw')) {
        this.pose_yaw = initObj.pose_yaw
      }
      else {
        this.pose_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('goal_x')) {
        this.goal_x = initObj.goal_x
      }
      else {
        this.goal_x = 0.0;
      }
      if (initObj.hasOwnProperty('goal_y')) {
        this.goal_y = initObj.goal_y
      }
      else {
        this.goal_y = 0.0;
      }
      if (initObj.hasOwnProperty('sport_state')) {
        this.sport_state = initObj.sport_state
      }
      else {
        this.sport_state = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('overtake')) {
        this.overtake = initObj.overtake
      }
      else {
        this.overtake = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('node_list')) {
        this.node_list = initObj.node_list
      }
      else {
        this.node_list = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RobotInfo
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [ip]
    bufferOffset = std_msgs.msg.String.serialize(obj.ip, buffer, bufferOffset);
    // Serialize message field [robot_style]
    bufferOffset = std_msgs.msg.String.serialize(obj.robot_style, buffer, bufferOffset);
    // Serialize message field [prior]
    bufferOffset = _serializer.int16(obj.prior, buffer, bufferOffset);
    // Serialize message field [build_id]
    bufferOffset = _serializer.int16(obj.build_id, buffer, bufferOffset);
    // Serialize message field [floor_id]
    bufferOffset = _serializer.int16(obj.floor_id, buffer, bufferOffset);
    // Serialize message field [multi_state]
    bufferOffset = _serializer.int16(obj.multi_state, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = std_msgs.msg.String.serialize(obj.state, buffer, bufferOffset);
    // Serialize message field [pose_x]
    bufferOffset = _serializer.float64(obj.pose_x, buffer, bufferOffset);
    // Serialize message field [pose_y]
    bufferOffset = _serializer.float64(obj.pose_y, buffer, bufferOffset);
    // Serialize message field [pose_yaw]
    bufferOffset = _serializer.float64(obj.pose_yaw, buffer, bufferOffset);
    // Serialize message field [goal_x]
    bufferOffset = _serializer.float64(obj.goal_x, buffer, bufferOffset);
    // Serialize message field [goal_y]
    bufferOffset = _serializer.float64(obj.goal_y, buffer, bufferOffset);
    // Serialize message field [sport_state]
    bufferOffset = std_msgs.msg.String.serialize(obj.sport_state, buffer, bufferOffset);
    // Serialize message field [overtake]
    bufferOffset = std_msgs.msg.String.serialize(obj.overtake, buffer, bufferOffset);
    // Serialize message field [node_list]
    bufferOffset = std_msgs.msg.String.serialize(obj.node_list, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RobotInfo
    let len;
    let data = new RobotInfo(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [ip]
    data.ip = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [robot_style]
    data.robot_style = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [prior]
    data.prior = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [build_id]
    data.build_id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [floor_id]
    data.floor_id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [multi_state]
    data.multi_state = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose_x]
    data.pose_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pose_y]
    data.pose_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pose_yaw]
    data.pose_yaw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [goal_x]
    data.goal_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [goal_y]
    data.goal_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sport_state]
    data.sport_state = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [overtake]
    data.overtake = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [node_list]
    data.node_list = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += std_msgs.msg.String.getMessageSize(object.ip);
    length += std_msgs.msg.String.getMessageSize(object.robot_style);
    length += std_msgs.msg.String.getMessageSize(object.state);
    length += std_msgs.msg.String.getMessageSize(object.sport_state);
    length += std_msgs.msg.String.getMessageSize(object.overtake);
    length += std_msgs.msg.String.getMessageSize(object.node_list);
    return length + 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/RobotInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e7b566df08d339a9ff156c453d4b4938';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    std_msgs/String ip
    std_msgs/String robot_style
    int16 prior
    int16 build_id
    int16 floor_id
    int16 multi_state
    std_msgs/String state
    float64 pose_x
    float64 pose_y
    float64 pose_yaw	
    float64 goal_x		
    float64 goal_y		
    std_msgs/String sport_state
    std_msgs/String overtake
    std_msgs/String node_list
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RobotInfo(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.ip !== undefined) {
      resolved.ip = std_msgs.msg.String.Resolve(msg.ip)
    }
    else {
      resolved.ip = new std_msgs.msg.String()
    }

    if (msg.robot_style !== undefined) {
      resolved.robot_style = std_msgs.msg.String.Resolve(msg.robot_style)
    }
    else {
      resolved.robot_style = new std_msgs.msg.String()
    }

    if (msg.prior !== undefined) {
      resolved.prior = msg.prior;
    }
    else {
      resolved.prior = 0
    }

    if (msg.build_id !== undefined) {
      resolved.build_id = msg.build_id;
    }
    else {
      resolved.build_id = 0
    }

    if (msg.floor_id !== undefined) {
      resolved.floor_id = msg.floor_id;
    }
    else {
      resolved.floor_id = 0
    }

    if (msg.multi_state !== undefined) {
      resolved.multi_state = msg.multi_state;
    }
    else {
      resolved.multi_state = 0
    }

    if (msg.state !== undefined) {
      resolved.state = std_msgs.msg.String.Resolve(msg.state)
    }
    else {
      resolved.state = new std_msgs.msg.String()
    }

    if (msg.pose_x !== undefined) {
      resolved.pose_x = msg.pose_x;
    }
    else {
      resolved.pose_x = 0.0
    }

    if (msg.pose_y !== undefined) {
      resolved.pose_y = msg.pose_y;
    }
    else {
      resolved.pose_y = 0.0
    }

    if (msg.pose_yaw !== undefined) {
      resolved.pose_yaw = msg.pose_yaw;
    }
    else {
      resolved.pose_yaw = 0.0
    }

    if (msg.goal_x !== undefined) {
      resolved.goal_x = msg.goal_x;
    }
    else {
      resolved.goal_x = 0.0
    }

    if (msg.goal_y !== undefined) {
      resolved.goal_y = msg.goal_y;
    }
    else {
      resolved.goal_y = 0.0
    }

    if (msg.sport_state !== undefined) {
      resolved.sport_state = std_msgs.msg.String.Resolve(msg.sport_state)
    }
    else {
      resolved.sport_state = new std_msgs.msg.String()
    }

    if (msg.overtake !== undefined) {
      resolved.overtake = std_msgs.msg.String.Resolve(msg.overtake)
    }
    else {
      resolved.overtake = new std_msgs.msg.String()
    }

    if (msg.node_list !== undefined) {
      resolved.node_list = std_msgs.msg.String.Resolve(msg.node_list)
    }
    else {
      resolved.node_list = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = RobotInfo;
