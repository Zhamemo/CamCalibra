// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class AllStateInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.state_imu_ = null;
      this.state_laser_ = null;
      this.state_emer_ = null;
      this.state_bumper_ = null;
      this.chassis_state_ = null;
      this.is_open_bumper_ = null;
      this.is_open_emer_ = null;
      this.battery_ = null;
      this.left_dist_ = null;
      this.right_dist_ = null;
      this.robot_pose_ = null;
      this.zigbee_state_ = null;
      this.is_safe_stop_ = null;
      this.work_state_ = null;
      this.is_wait_cross_ = null;
      this.left_motor_state_ = null;
      this.right_motor_state_ = null;
      this.recoverying_state_ = null;
      this.update_odom_ok_ = null;
      this.dis_odom_ = null;
      this.state_depthcamera_ = null;
    }
    else {
      if (initObj.hasOwnProperty('state_imu_')) {
        this.state_imu_ = initObj.state_imu_
      }
      else {
        this.state_imu_ = false;
      }
      if (initObj.hasOwnProperty('state_laser_')) {
        this.state_laser_ = initObj.state_laser_
      }
      else {
        this.state_laser_ = false;
      }
      if (initObj.hasOwnProperty('state_emer_')) {
        this.state_emer_ = initObj.state_emer_
      }
      else {
        this.state_emer_ = false;
      }
      if (initObj.hasOwnProperty('state_bumper_')) {
        this.state_bumper_ = initObj.state_bumper_
      }
      else {
        this.state_bumper_ = 0;
      }
      if (initObj.hasOwnProperty('chassis_state_')) {
        this.chassis_state_ = initObj.chassis_state_
      }
      else {
        this.chassis_state_ = false;
      }
      if (initObj.hasOwnProperty('is_open_bumper_')) {
        this.is_open_bumper_ = initObj.is_open_bumper_
      }
      else {
        this.is_open_bumper_ = false;
      }
      if (initObj.hasOwnProperty('is_open_emer_')) {
        this.is_open_emer_ = initObj.is_open_emer_
      }
      else {
        this.is_open_emer_ = false;
      }
      if (initObj.hasOwnProperty('battery_')) {
        this.battery_ = initObj.battery_
      }
      else {
        this.battery_ = new std_msgs.msg.Float64();
      }
      if (initObj.hasOwnProperty('left_dist_')) {
        this.left_dist_ = initObj.left_dist_
      }
      else {
        this.left_dist_ = new std_msgs.msg.UInt32();
      }
      if (initObj.hasOwnProperty('right_dist_')) {
        this.right_dist_ = initObj.right_dist_
      }
      else {
        this.right_dist_ = new std_msgs.msg.UInt32();
      }
      if (initObj.hasOwnProperty('robot_pose_')) {
        this.robot_pose_ = initObj.robot_pose_
      }
      else {
        this.robot_pose_ = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('zigbee_state_')) {
        this.zigbee_state_ = initObj.zigbee_state_
      }
      else {
        this.zigbee_state_ = false;
      }
      if (initObj.hasOwnProperty('is_safe_stop_')) {
        this.is_safe_stop_ = initObj.is_safe_stop_
      }
      else {
        this.is_safe_stop_ = false;
      }
      if (initObj.hasOwnProperty('work_state_')) {
        this.work_state_ = initObj.work_state_
      }
      else {
        this.work_state_ = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('is_wait_cross_')) {
        this.is_wait_cross_ = initObj.is_wait_cross_
      }
      else {
        this.is_wait_cross_ = false;
      }
      if (initObj.hasOwnProperty('left_motor_state_')) {
        this.left_motor_state_ = initObj.left_motor_state_
      }
      else {
        this.left_motor_state_ = 0;
      }
      if (initObj.hasOwnProperty('right_motor_state_')) {
        this.right_motor_state_ = initObj.right_motor_state_
      }
      else {
        this.right_motor_state_ = 0;
      }
      if (initObj.hasOwnProperty('recoverying_state_')) {
        this.recoverying_state_ = initObj.recoverying_state_
      }
      else {
        this.recoverying_state_ = 0;
      }
      if (initObj.hasOwnProperty('update_odom_ok_')) {
        this.update_odom_ok_ = initObj.update_odom_ok_
      }
      else {
        this.update_odom_ok_ = false;
      }
      if (initObj.hasOwnProperty('dis_odom_')) {
        this.dis_odom_ = initObj.dis_odom_
      }
      else {
        this.dis_odom_ = 0.0;
      }
      if (initObj.hasOwnProperty('state_depthcamera_')) {
        this.state_depthcamera_ = initObj.state_depthcamera_
      }
      else {
        this.state_depthcamera_ = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AllStateInfo
    // Serialize message field [state_imu_]
    bufferOffset = _serializer.bool(obj.state_imu_, buffer, bufferOffset);
    // Serialize message field [state_laser_]
    bufferOffset = _serializer.bool(obj.state_laser_, buffer, bufferOffset);
    // Serialize message field [state_emer_]
    bufferOffset = _serializer.bool(obj.state_emer_, buffer, bufferOffset);
    // Serialize message field [state_bumper_]
    bufferOffset = _serializer.int16(obj.state_bumper_, buffer, bufferOffset);
    // Serialize message field [chassis_state_]
    bufferOffset = _serializer.bool(obj.chassis_state_, buffer, bufferOffset);
    // Serialize message field [is_open_bumper_]
    bufferOffset = _serializer.bool(obj.is_open_bumper_, buffer, bufferOffset);
    // Serialize message field [is_open_emer_]
    bufferOffset = _serializer.bool(obj.is_open_emer_, buffer, bufferOffset);
    // Serialize message field [battery_]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.battery_, buffer, bufferOffset);
    // Serialize message field [left_dist_]
    bufferOffset = std_msgs.msg.UInt32.serialize(obj.left_dist_, buffer, bufferOffset);
    // Serialize message field [right_dist_]
    bufferOffset = std_msgs.msg.UInt32.serialize(obj.right_dist_, buffer, bufferOffset);
    // Serialize message field [robot_pose_]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.robot_pose_, buffer, bufferOffset);
    // Serialize message field [zigbee_state_]
    bufferOffset = _serializer.bool(obj.zigbee_state_, buffer, bufferOffset);
    // Serialize message field [is_safe_stop_]
    bufferOffset = _serializer.bool(obj.is_safe_stop_, buffer, bufferOffset);
    // Serialize message field [work_state_]
    bufferOffset = std_msgs.msg.String.serialize(obj.work_state_, buffer, bufferOffset);
    // Serialize message field [is_wait_cross_]
    bufferOffset = _serializer.bool(obj.is_wait_cross_, buffer, bufferOffset);
    // Serialize message field [left_motor_state_]
    bufferOffset = _serializer.int8(obj.left_motor_state_, buffer, bufferOffset);
    // Serialize message field [right_motor_state_]
    bufferOffset = _serializer.int8(obj.right_motor_state_, buffer, bufferOffset);
    // Serialize message field [recoverying_state_]
    bufferOffset = _serializer.int8(obj.recoverying_state_, buffer, bufferOffset);
    // Serialize message field [update_odom_ok_]
    bufferOffset = _serializer.bool(obj.update_odom_ok_, buffer, bufferOffset);
    // Serialize message field [dis_odom_]
    bufferOffset = _serializer.float64(obj.dis_odom_, buffer, bufferOffset);
    // Serialize message field [state_depthcamera_]
    bufferOffset = _serializer.int16(obj.state_depthcamera_, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AllStateInfo
    let len;
    let data = new AllStateInfo(null);
    // Deserialize message field [state_imu_]
    data.state_imu_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_laser_]
    data.state_laser_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_emer_]
    data.state_emer_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [state_bumper_]
    data.state_bumper_ = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [chassis_state_]
    data.chassis_state_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_open_bumper_]
    data.is_open_bumper_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_open_emer_]
    data.is_open_emer_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [battery_]
    data.battery_ = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    // Deserialize message field [left_dist_]
    data.left_dist_ = std_msgs.msg.UInt32.deserialize(buffer, bufferOffset);
    // Deserialize message field [right_dist_]
    data.right_dist_ = std_msgs.msg.UInt32.deserialize(buffer, bufferOffset);
    // Deserialize message field [robot_pose_]
    data.robot_pose_ = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [zigbee_state_]
    data.zigbee_state_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_safe_stop_]
    data.is_safe_stop_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [work_state_]
    data.work_state_ = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [is_wait_cross_]
    data.is_wait_cross_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [left_motor_state_]
    data.left_motor_state_ = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [right_motor_state_]
    data.right_motor_state_ = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [recoverying_state_]
    data.recoverying_state_ = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [update_odom_ok_]
    data.update_odom_ok_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dis_odom_]
    data.dis_odom_ = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [state_depthcamera_]
    data.state_depthcamera_ = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.robot_pose_);
    length += std_msgs.msg.String.getMessageSize(object.work_state_);
    return length + 41;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/AllStateInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c3898a841a0883e6c1de9bc10dfa4614';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool state_imu_
    bool state_laser_
    bool state_emer_
    int16 state_bumper_
    bool chassis_state_
    bool is_open_bumper_
    bool is_open_emer_
    std_msgs/Float64 battery_
    std_msgs/UInt32 left_dist_
    std_msgs/UInt32 right_dist_
    geometry_msgs/PoseStamped robot_pose_
    bool zigbee_state_
    bool is_safe_stop_
    std_msgs/String  work_state_
    bool is_wait_cross_
    int8 left_motor_state_
    int8 right_motor_state_
    int8 recoverying_state_
    bool update_odom_ok_
    float64 dis_odom_
    int16 state_depthcamera_
    
    
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: std_msgs/UInt32
    uint32 data
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AllStateInfo(null);
    if (msg.state_imu_ !== undefined) {
      resolved.state_imu_ = msg.state_imu_;
    }
    else {
      resolved.state_imu_ = false
    }

    if (msg.state_laser_ !== undefined) {
      resolved.state_laser_ = msg.state_laser_;
    }
    else {
      resolved.state_laser_ = false
    }

    if (msg.state_emer_ !== undefined) {
      resolved.state_emer_ = msg.state_emer_;
    }
    else {
      resolved.state_emer_ = false
    }

    if (msg.state_bumper_ !== undefined) {
      resolved.state_bumper_ = msg.state_bumper_;
    }
    else {
      resolved.state_bumper_ = 0
    }

    if (msg.chassis_state_ !== undefined) {
      resolved.chassis_state_ = msg.chassis_state_;
    }
    else {
      resolved.chassis_state_ = false
    }

    if (msg.is_open_bumper_ !== undefined) {
      resolved.is_open_bumper_ = msg.is_open_bumper_;
    }
    else {
      resolved.is_open_bumper_ = false
    }

    if (msg.is_open_emer_ !== undefined) {
      resolved.is_open_emer_ = msg.is_open_emer_;
    }
    else {
      resolved.is_open_emer_ = false
    }

    if (msg.battery_ !== undefined) {
      resolved.battery_ = std_msgs.msg.Float64.Resolve(msg.battery_)
    }
    else {
      resolved.battery_ = new std_msgs.msg.Float64()
    }

    if (msg.left_dist_ !== undefined) {
      resolved.left_dist_ = std_msgs.msg.UInt32.Resolve(msg.left_dist_)
    }
    else {
      resolved.left_dist_ = new std_msgs.msg.UInt32()
    }

    if (msg.right_dist_ !== undefined) {
      resolved.right_dist_ = std_msgs.msg.UInt32.Resolve(msg.right_dist_)
    }
    else {
      resolved.right_dist_ = new std_msgs.msg.UInt32()
    }

    if (msg.robot_pose_ !== undefined) {
      resolved.robot_pose_ = geometry_msgs.msg.PoseStamped.Resolve(msg.robot_pose_)
    }
    else {
      resolved.robot_pose_ = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.zigbee_state_ !== undefined) {
      resolved.zigbee_state_ = msg.zigbee_state_;
    }
    else {
      resolved.zigbee_state_ = false
    }

    if (msg.is_safe_stop_ !== undefined) {
      resolved.is_safe_stop_ = msg.is_safe_stop_;
    }
    else {
      resolved.is_safe_stop_ = false
    }

    if (msg.work_state_ !== undefined) {
      resolved.work_state_ = std_msgs.msg.String.Resolve(msg.work_state_)
    }
    else {
      resolved.work_state_ = new std_msgs.msg.String()
    }

    if (msg.is_wait_cross_ !== undefined) {
      resolved.is_wait_cross_ = msg.is_wait_cross_;
    }
    else {
      resolved.is_wait_cross_ = false
    }

    if (msg.left_motor_state_ !== undefined) {
      resolved.left_motor_state_ = msg.left_motor_state_;
    }
    else {
      resolved.left_motor_state_ = 0
    }

    if (msg.right_motor_state_ !== undefined) {
      resolved.right_motor_state_ = msg.right_motor_state_;
    }
    else {
      resolved.right_motor_state_ = 0
    }

    if (msg.recoverying_state_ !== undefined) {
      resolved.recoverying_state_ = msg.recoverying_state_;
    }
    else {
      resolved.recoverying_state_ = 0
    }

    if (msg.update_odom_ok_ !== undefined) {
      resolved.update_odom_ok_ = msg.update_odom_ok_;
    }
    else {
      resolved.update_odom_ok_ = false
    }

    if (msg.dis_odom_ !== undefined) {
      resolved.dis_odom_ = msg.dis_odom_;
    }
    else {
      resolved.dis_odom_ = 0.0
    }

    if (msg.state_depthcamera_ !== undefined) {
      resolved.state_depthcamera_ = msg.state_depthcamera_;
    }
    else {
      resolved.state_depthcamera_ = 0
    }

    return resolved;
    }
};

module.exports = AllStateInfo;
