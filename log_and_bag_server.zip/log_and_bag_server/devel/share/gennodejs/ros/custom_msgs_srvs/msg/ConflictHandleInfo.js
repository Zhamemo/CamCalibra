// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class ConflictHandleInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.conflict_type_ = null;
      this.safe_stop_ = null;
      this.width_cross_ = null;
      this.stop_tasking_goal_ = null;
      this.sos_ = null;
      this.is_1_6_bool_ = null;
      this.is_1_6_num_ = null;
      this.is_1_8_num_ = null;
      this.is_wait_cross_ = null;
      this.first_node_ = null;
      this.avoid_node_ = null;
      this.overtake_ = null;
      this.side_dis_ = null;
      this.goal = null;
      this.overtaked_robot_pose_ = null;
    }
    else {
      if (initObj.hasOwnProperty('conflict_type_')) {
        this.conflict_type_ = initObj.conflict_type_
      }
      else {
        this.conflict_type_ = 0;
      }
      if (initObj.hasOwnProperty('safe_stop_')) {
        this.safe_stop_ = initObj.safe_stop_
      }
      else {
        this.safe_stop_ = false;
      }
      if (initObj.hasOwnProperty('width_cross_')) {
        this.width_cross_ = initObj.width_cross_
      }
      else {
        this.width_cross_ = false;
      }
      if (initObj.hasOwnProperty('stop_tasking_goal_')) {
        this.stop_tasking_goal_ = initObj.stop_tasking_goal_
      }
      else {
        this.stop_tasking_goal_ = false;
      }
      if (initObj.hasOwnProperty('sos_')) {
        this.sos_ = initObj.sos_
      }
      else {
        this.sos_ = false;
      }
      if (initObj.hasOwnProperty('is_1_6_bool_')) {
        this.is_1_6_bool_ = initObj.is_1_6_bool_
      }
      else {
        this.is_1_6_bool_ = false;
      }
      if (initObj.hasOwnProperty('is_1_6_num_')) {
        this.is_1_6_num_ = initObj.is_1_6_num_
      }
      else {
        this.is_1_6_num_ = 0;
      }
      if (initObj.hasOwnProperty('is_1_8_num_')) {
        this.is_1_8_num_ = initObj.is_1_8_num_
      }
      else {
        this.is_1_8_num_ = 0;
      }
      if (initObj.hasOwnProperty('is_wait_cross_')) {
        this.is_wait_cross_ = initObj.is_wait_cross_
      }
      else {
        this.is_wait_cross_ = false;
      }
      if (initObj.hasOwnProperty('first_node_')) {
        this.first_node_ = initObj.first_node_
      }
      else {
        this.first_node_ = 0;
      }
      if (initObj.hasOwnProperty('avoid_node_')) {
        this.avoid_node_ = initObj.avoid_node_
      }
      else {
        this.avoid_node_ = 0;
      }
      if (initObj.hasOwnProperty('overtake_')) {
        this.overtake_ = initObj.overtake_
      }
      else {
        this.overtake_ = 0;
      }
      if (initObj.hasOwnProperty('side_dis_')) {
        this.side_dis_ = initObj.side_dis_
      }
      else {
        this.side_dis_ = 0.0;
      }
      if (initObj.hasOwnProperty('goal')) {
        this.goal = initObj.goal
      }
      else {
        this.goal = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('overtaked_robot_pose_')) {
        this.overtaked_robot_pose_ = initObj.overtaked_robot_pose_
      }
      else {
        this.overtaked_robot_pose_ = new geometry_msgs.msg.Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ConflictHandleInfo
    // Serialize message field [conflict_type_]
    bufferOffset = _serializer.int32(obj.conflict_type_, buffer, bufferOffset);
    // Serialize message field [safe_stop_]
    bufferOffset = _serializer.bool(obj.safe_stop_, buffer, bufferOffset);
    // Serialize message field [width_cross_]
    bufferOffset = _serializer.bool(obj.width_cross_, buffer, bufferOffset);
    // Serialize message field [stop_tasking_goal_]
    bufferOffset = _serializer.bool(obj.stop_tasking_goal_, buffer, bufferOffset);
    // Serialize message field [sos_]
    bufferOffset = _serializer.bool(obj.sos_, buffer, bufferOffset);
    // Serialize message field [is_1_6_bool_]
    bufferOffset = _serializer.bool(obj.is_1_6_bool_, buffer, bufferOffset);
    // Serialize message field [is_1_6_num_]
    bufferOffset = _serializer.int32(obj.is_1_6_num_, buffer, bufferOffset);
    // Serialize message field [is_1_8_num_]
    bufferOffset = _serializer.int32(obj.is_1_8_num_, buffer, bufferOffset);
    // Serialize message field [is_wait_cross_]
    bufferOffset = _serializer.bool(obj.is_wait_cross_, buffer, bufferOffset);
    // Serialize message field [first_node_]
    bufferOffset = _serializer.int32(obj.first_node_, buffer, bufferOffset);
    // Serialize message field [avoid_node_]
    bufferOffset = _serializer.int32(obj.avoid_node_, buffer, bufferOffset);
    // Serialize message field [overtake_]
    bufferOffset = _serializer.int32(obj.overtake_, buffer, bufferOffset);
    // Serialize message field [side_dis_]
    bufferOffset = _serializer.float64(obj.side_dis_, buffer, bufferOffset);
    // Serialize message field [goal]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.goal, buffer, bufferOffset);
    // Serialize message field [overtaked_robot_pose_]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.overtaked_robot_pose_, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ConflictHandleInfo
    let len;
    let data = new ConflictHandleInfo(null);
    // Deserialize message field [conflict_type_]
    data.conflict_type_ = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [safe_stop_]
    data.safe_stop_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [width_cross_]
    data.width_cross_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [stop_tasking_goal_]
    data.stop_tasking_goal_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [sos_]
    data.sos_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_1_6_bool_]
    data.is_1_6_bool_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_1_6_num_]
    data.is_1_6_num_ = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [is_1_8_num_]
    data.is_1_8_num_ = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [is_wait_cross_]
    data.is_wait_cross_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [first_node_]
    data.first_node_ = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [avoid_node_]
    data.avoid_node_ = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [overtake_]
    data.overtake_ = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [side_dis_]
    data.side_dis_ = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [goal]
    data.goal = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [overtaked_robot_pose_]
    data.overtaked_robot_pose_ = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.goal);
    return length + 94;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/ConflictHandleInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '98e9d4d67489ae047caabf230f87f221';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 conflict_type_
    bool safe_stop_
    bool width_cross_
    bool stop_tasking_goal_
    bool sos_
    bool is_1_6_bool_
    int32 is_1_6_num_
    int32 is_1_8_num_
    bool is_wait_cross_
    int32 first_node_
    int32 avoid_node_
    int32 overtake_
    float64 side_dis_
    geometry_msgs/PoseStamped goal
    geometry_msgs/Pose overtaked_robot_pose_
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ConflictHandleInfo(null);
    if (msg.conflict_type_ !== undefined) {
      resolved.conflict_type_ = msg.conflict_type_;
    }
    else {
      resolved.conflict_type_ = 0
    }

    if (msg.safe_stop_ !== undefined) {
      resolved.safe_stop_ = msg.safe_stop_;
    }
    else {
      resolved.safe_stop_ = false
    }

    if (msg.width_cross_ !== undefined) {
      resolved.width_cross_ = msg.width_cross_;
    }
    else {
      resolved.width_cross_ = false
    }

    if (msg.stop_tasking_goal_ !== undefined) {
      resolved.stop_tasking_goal_ = msg.stop_tasking_goal_;
    }
    else {
      resolved.stop_tasking_goal_ = false
    }

    if (msg.sos_ !== undefined) {
      resolved.sos_ = msg.sos_;
    }
    else {
      resolved.sos_ = false
    }

    if (msg.is_1_6_bool_ !== undefined) {
      resolved.is_1_6_bool_ = msg.is_1_6_bool_;
    }
    else {
      resolved.is_1_6_bool_ = false
    }

    if (msg.is_1_6_num_ !== undefined) {
      resolved.is_1_6_num_ = msg.is_1_6_num_;
    }
    else {
      resolved.is_1_6_num_ = 0
    }

    if (msg.is_1_8_num_ !== undefined) {
      resolved.is_1_8_num_ = msg.is_1_8_num_;
    }
    else {
      resolved.is_1_8_num_ = 0
    }

    if (msg.is_wait_cross_ !== undefined) {
      resolved.is_wait_cross_ = msg.is_wait_cross_;
    }
    else {
      resolved.is_wait_cross_ = false
    }

    if (msg.first_node_ !== undefined) {
      resolved.first_node_ = msg.first_node_;
    }
    else {
      resolved.first_node_ = 0
    }

    if (msg.avoid_node_ !== undefined) {
      resolved.avoid_node_ = msg.avoid_node_;
    }
    else {
      resolved.avoid_node_ = 0
    }

    if (msg.overtake_ !== undefined) {
      resolved.overtake_ = msg.overtake_;
    }
    else {
      resolved.overtake_ = 0
    }

    if (msg.side_dis_ !== undefined) {
      resolved.side_dis_ = msg.side_dis_;
    }
    else {
      resolved.side_dis_ = 0.0
    }

    if (msg.goal !== undefined) {
      resolved.goal = geometry_msgs.msg.PoseStamped.Resolve(msg.goal)
    }
    else {
      resolved.goal = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.overtaked_robot_pose_ !== undefined) {
      resolved.overtaked_robot_pose_ = geometry_msgs.msg.Pose.Resolve(msg.overtaked_robot_pose_)
    }
    else {
      resolved.overtaked_robot_pose_ = new geometry_msgs.msg.Pose()
    }

    return resolved;
    }
};

module.exports = ConflictHandleInfo;
