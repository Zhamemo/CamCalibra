// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TestMode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.test_item = null;
      this.on_off = null;
    }
    else {
      if (initObj.hasOwnProperty('test_item')) {
        this.test_item = initObj.test_item
      }
      else {
        this.test_item = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('on_off')) {
        this.on_off = initObj.on_off
      }
      else {
        this.on_off = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TestMode
    // Serialize message field [test_item]
    bufferOffset = std_msgs.msg.String.serialize(obj.test_item, buffer, bufferOffset);
    // Serialize message field [on_off]
    bufferOffset = _serializer.bool(obj.on_off, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TestMode
    let len;
    let data = new TestMode(null);
    // Deserialize message field [test_item]
    data.test_item = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [on_off]
    data.on_off = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.test_item);
    return length + 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/TestMode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7aef53d11cd8cbabd41549948531b046';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String test_item
    bool on_off
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TestMode(null);
    if (msg.test_item !== undefined) {
      resolved.test_item = std_msgs.msg.String.Resolve(msg.test_item)
    }
    else {
      resolved.test_item = new std_msgs.msg.String()
    }

    if (msg.on_off !== undefined) {
      resolved.on_off = msg.on_off;
    }
    else {
      resolved.on_off = false
    }

    return resolved;
    }
};

module.exports = TestMode;
