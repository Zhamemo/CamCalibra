// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class MotorState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.left_motor_state = null;
      this.right_motor_state = null;
      this.recoverying_state = null;
    }
    else {
      if (initObj.hasOwnProperty('left_motor_state')) {
        this.left_motor_state = initObj.left_motor_state
      }
      else {
        this.left_motor_state = 0;
      }
      if (initObj.hasOwnProperty('right_motor_state')) {
        this.right_motor_state = initObj.right_motor_state
      }
      else {
        this.right_motor_state = 0;
      }
      if (initObj.hasOwnProperty('recoverying_state')) {
        this.recoverying_state = initObj.recoverying_state
      }
      else {
        this.recoverying_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorState
    // Serialize message field [left_motor_state]
    bufferOffset = _serializer.int8(obj.left_motor_state, buffer, bufferOffset);
    // Serialize message field [right_motor_state]
    bufferOffset = _serializer.int8(obj.right_motor_state, buffer, bufferOffset);
    // Serialize message field [recoverying_state]
    bufferOffset = _serializer.int8(obj.recoverying_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorState
    let len;
    let data = new MotorState(null);
    // Deserialize message field [left_motor_state]
    data.left_motor_state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [right_motor_state]
    data.right_motor_state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [recoverying_state]
    data.recoverying_state = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/MotorState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8848af39a2c0ba3d2d89c67021504e8a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8 left_motor_state
    int8 right_motor_state
    int8 recoverying_state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorState(null);
    if (msg.left_motor_state !== undefined) {
      resolved.left_motor_state = msg.left_motor_state;
    }
    else {
      resolved.left_motor_state = 0
    }

    if (msg.right_motor_state !== undefined) {
      resolved.right_motor_state = msg.right_motor_state;
    }
    else {
      resolved.right_motor_state = 0
    }

    if (msg.recoverying_state !== undefined) {
      resolved.recoverying_state = msg.recoverying_state;
    }
    else {
      resolved.recoverying_state = 0
    }

    return resolved;
    }
};

module.exports = MotorState;
