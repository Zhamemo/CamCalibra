// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ImuCheckEnterLiftInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.enable_imu_check_lift = null;
      this.imu_check_lift_current_state = null;
      this.request_swj_stop_robot_sport = null;
      this.dis_stop_robot_sport_timeout = null;
      this.is_send_sos_to_swj = null;
      this.send_apk_robot_in_lift_state = null;
    }
    else {
      if (initObj.hasOwnProperty('enable_imu_check_lift')) {
        this.enable_imu_check_lift = initObj.enable_imu_check_lift
      }
      else {
        this.enable_imu_check_lift = '';
      }
      if (initObj.hasOwnProperty('imu_check_lift_current_state')) {
        this.imu_check_lift_current_state = initObj.imu_check_lift_current_state
      }
      else {
        this.imu_check_lift_current_state = '';
      }
      if (initObj.hasOwnProperty('request_swj_stop_robot_sport')) {
        this.request_swj_stop_robot_sport = initObj.request_swj_stop_robot_sport
      }
      else {
        this.request_swj_stop_robot_sport = false;
      }
      if (initObj.hasOwnProperty('dis_stop_robot_sport_timeout')) {
        this.dis_stop_robot_sport_timeout = initObj.dis_stop_robot_sport_timeout
      }
      else {
        this.dis_stop_robot_sport_timeout = 0.0;
      }
      if (initObj.hasOwnProperty('is_send_sos_to_swj')) {
        this.is_send_sos_to_swj = initObj.is_send_sos_to_swj
      }
      else {
        this.is_send_sos_to_swj = false;
      }
      if (initObj.hasOwnProperty('send_apk_robot_in_lift_state')) {
        this.send_apk_robot_in_lift_state = initObj.send_apk_robot_in_lift_state
      }
      else {
        this.send_apk_robot_in_lift_state = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ImuCheckEnterLiftInfo
    // Serialize message field [enable_imu_check_lift]
    bufferOffset = _serializer.string(obj.enable_imu_check_lift, buffer, bufferOffset);
    // Serialize message field [imu_check_lift_current_state]
    bufferOffset = _serializer.string(obj.imu_check_lift_current_state, buffer, bufferOffset);
    // Serialize message field [request_swj_stop_robot_sport]
    bufferOffset = _serializer.bool(obj.request_swj_stop_robot_sport, buffer, bufferOffset);
    // Serialize message field [dis_stop_robot_sport_timeout]
    bufferOffset = _serializer.float64(obj.dis_stop_robot_sport_timeout, buffer, bufferOffset);
    // Serialize message field [is_send_sos_to_swj]
    bufferOffset = _serializer.bool(obj.is_send_sos_to_swj, buffer, bufferOffset);
    // Serialize message field [send_apk_robot_in_lift_state]
    bufferOffset = _serializer.string(obj.send_apk_robot_in_lift_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ImuCheckEnterLiftInfo
    let len;
    let data = new ImuCheckEnterLiftInfo(null);
    // Deserialize message field [enable_imu_check_lift]
    data.enable_imu_check_lift = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [imu_check_lift_current_state]
    data.imu_check_lift_current_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [request_swj_stop_robot_sport]
    data.request_swj_stop_robot_sport = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dis_stop_robot_sport_timeout]
    data.dis_stop_robot_sport_timeout = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [is_send_sos_to_swj]
    data.is_send_sos_to_swj = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [send_apk_robot_in_lift_state]
    data.send_apk_robot_in_lift_state = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.enable_imu_check_lift.length;
    length += object.imu_check_lift_current_state.length;
    length += object.send_apk_robot_in_lift_state.length;
    return length + 22;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/ImuCheckEnterLiftInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5e04ea3c7171b43c035671dc3fc39062';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string enable_imu_check_lift
    string imu_check_lift_current_state
    bool request_swj_stop_robot_sport
    float64 dis_stop_robot_sport_timeout
    bool is_send_sos_to_swj
    string send_apk_robot_in_lift_state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ImuCheckEnterLiftInfo(null);
    if (msg.enable_imu_check_lift !== undefined) {
      resolved.enable_imu_check_lift = msg.enable_imu_check_lift;
    }
    else {
      resolved.enable_imu_check_lift = ''
    }

    if (msg.imu_check_lift_current_state !== undefined) {
      resolved.imu_check_lift_current_state = msg.imu_check_lift_current_state;
    }
    else {
      resolved.imu_check_lift_current_state = ''
    }

    if (msg.request_swj_stop_robot_sport !== undefined) {
      resolved.request_swj_stop_robot_sport = msg.request_swj_stop_robot_sport;
    }
    else {
      resolved.request_swj_stop_robot_sport = false
    }

    if (msg.dis_stop_robot_sport_timeout !== undefined) {
      resolved.dis_stop_robot_sport_timeout = msg.dis_stop_robot_sport_timeout;
    }
    else {
      resolved.dis_stop_robot_sport_timeout = 0.0
    }

    if (msg.is_send_sos_to_swj !== undefined) {
      resolved.is_send_sos_to_swj = msg.is_send_sos_to_swj;
    }
    else {
      resolved.is_send_sos_to_swj = false
    }

    if (msg.send_apk_robot_in_lift_state !== undefined) {
      resolved.send_apk_robot_in_lift_state = msg.send_apk_robot_in_lift_state;
    }
    else {
      resolved.send_apk_robot_in_lift_state = ''
    }

    return resolved;
    }
};

module.exports = ImuCheckEnterLiftInfo;
