// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LocalPlanEnterLiftState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frenet_error = null;
      this.update_frenet_error = null;
      this.frenet_size = null;
      this.elevator_allow_dist = null;
      this.result_local_plan = null;
      this.local_plan_err = null;
    }
    else {
      if (initObj.hasOwnProperty('frenet_error')) {
        this.frenet_error = initObj.frenet_error
      }
      else {
        this.frenet_error = 0;
      }
      if (initObj.hasOwnProperty('update_frenet_error')) {
        this.update_frenet_error = initObj.update_frenet_error
      }
      else {
        this.update_frenet_error = 0;
      }
      if (initObj.hasOwnProperty('frenet_size')) {
        this.frenet_size = initObj.frenet_size
      }
      else {
        this.frenet_size = 0;
      }
      if (initObj.hasOwnProperty('elevator_allow_dist')) {
        this.elevator_allow_dist = initObj.elevator_allow_dist
      }
      else {
        this.elevator_allow_dist = 0.0;
      }
      if (initObj.hasOwnProperty('result_local_plan')) {
        this.result_local_plan = initObj.result_local_plan
      }
      else {
        this.result_local_plan = 0;
      }
      if (initObj.hasOwnProperty('local_plan_err')) {
        this.local_plan_err = initObj.local_plan_err
      }
      else {
        this.local_plan_err = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocalPlanEnterLiftState
    // Serialize message field [frenet_error]
    bufferOffset = _serializer.int32(obj.frenet_error, buffer, bufferOffset);
    // Serialize message field [update_frenet_error]
    bufferOffset = _serializer.int32(obj.update_frenet_error, buffer, bufferOffset);
    // Serialize message field [frenet_size]
    bufferOffset = _serializer.int32(obj.frenet_size, buffer, bufferOffset);
    // Serialize message field [elevator_allow_dist]
    bufferOffset = _serializer.float64(obj.elevator_allow_dist, buffer, bufferOffset);
    // Serialize message field [result_local_plan]
    bufferOffset = _serializer.int32(obj.result_local_plan, buffer, bufferOffset);
    // Serialize message field [local_plan_err]
    bufferOffset = _serializer.int32(obj.local_plan_err, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocalPlanEnterLiftState
    let len;
    let data = new LocalPlanEnterLiftState(null);
    // Deserialize message field [frenet_error]
    data.frenet_error = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [update_frenet_error]
    data.update_frenet_error = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [frenet_size]
    data.frenet_size = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [elevator_allow_dist]
    data.elevator_allow_dist = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [result_local_plan]
    data.result_local_plan = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [local_plan_err]
    data.local_plan_err = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/LocalPlanEnterLiftState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4fb64529af5c27d6e5b572bec1afc096';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
      #int32 robot_nav_mode
      int32 frenet_error
      int32 update_frenet_error
      int32 frenet_size
      #float64 dis_frenet
      #float64 dis_robot_run
      #bool allow_elevator
      #bool is_obs
      #float64 last_frenet_time
      float64 elevator_allow_dist
      int32 result_local_plan
      int32 local_plan_err
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocalPlanEnterLiftState(null);
    if (msg.frenet_error !== undefined) {
      resolved.frenet_error = msg.frenet_error;
    }
    else {
      resolved.frenet_error = 0
    }

    if (msg.update_frenet_error !== undefined) {
      resolved.update_frenet_error = msg.update_frenet_error;
    }
    else {
      resolved.update_frenet_error = 0
    }

    if (msg.frenet_size !== undefined) {
      resolved.frenet_size = msg.frenet_size;
    }
    else {
      resolved.frenet_size = 0
    }

    if (msg.elevator_allow_dist !== undefined) {
      resolved.elevator_allow_dist = msg.elevator_allow_dist;
    }
    else {
      resolved.elevator_allow_dist = 0.0
    }

    if (msg.result_local_plan !== undefined) {
      resolved.result_local_plan = msg.result_local_plan;
    }
    else {
      resolved.result_local_plan = 0
    }

    if (msg.local_plan_err !== undefined) {
      resolved.local_plan_err = msg.local_plan_err;
    }
    else {
      resolved.local_plan_err = 0
    }

    return resolved;
    }
};

module.exports = LocalPlanEnterLiftState;
