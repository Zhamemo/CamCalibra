// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class QRPoseRefined {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.pose_x = null;
      this.pose_y = null;
      this.pose_z = null;
      this.pose_roll = null;
      this.pose_pitch = null;
      this.pose_yaw = null;
      this.yaw = null;
      this.center = null;
      this.corners = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('pose_x')) {
        this.pose_x = initObj.pose_x
      }
      else {
        this.pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('pose_y')) {
        this.pose_y = initObj.pose_y
      }
      else {
        this.pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('pose_z')) {
        this.pose_z = initObj.pose_z
      }
      else {
        this.pose_z = 0.0;
      }
      if (initObj.hasOwnProperty('pose_roll')) {
        this.pose_roll = initObj.pose_roll
      }
      else {
        this.pose_roll = 0.0;
      }
      if (initObj.hasOwnProperty('pose_pitch')) {
        this.pose_pitch = initObj.pose_pitch
      }
      else {
        this.pose_pitch = 0.0;
      }
      if (initObj.hasOwnProperty('pose_yaw')) {
        this.pose_yaw = initObj.pose_yaw
      }
      else {
        this.pose_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('yaw')) {
        this.yaw = initObj.yaw
      }
      else {
        this.yaw = 0.0;
      }
      if (initObj.hasOwnProperty('center')) {
        this.center = initObj.center
      }
      else {
        this.center = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('corners')) {
        this.corners = initObj.corners
      }
      else {
        this.corners = new Array(4).fill(new geometry_msgs.msg.Point());
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type QRPoseRefined
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    // Serialize message field [pose_x]
    bufferOffset = _serializer.float32(obj.pose_x, buffer, bufferOffset);
    // Serialize message field [pose_y]
    bufferOffset = _serializer.float32(obj.pose_y, buffer, bufferOffset);
    // Serialize message field [pose_z]
    bufferOffset = _serializer.float32(obj.pose_z, buffer, bufferOffset);
    // Serialize message field [pose_roll]
    bufferOffset = _serializer.float32(obj.pose_roll, buffer, bufferOffset);
    // Serialize message field [pose_pitch]
    bufferOffset = _serializer.float32(obj.pose_pitch, buffer, bufferOffset);
    // Serialize message field [pose_yaw]
    bufferOffset = _serializer.float32(obj.pose_yaw, buffer, bufferOffset);
    // Serialize message field [yaw]
    bufferOffset = _serializer.float64(obj.yaw, buffer, bufferOffset);
    // Serialize message field [center]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.center, buffer, bufferOffset);
    // Check that the constant length array field [corners] has the right length
    if (obj.corners.length !== 4) {
      throw new Error('Unable to serialize array field corners - length must be 4')
    }
    // Serialize message field [corners]
    obj.corners.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type QRPoseRefined
    let len;
    let data = new QRPoseRefined(null);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [pose_x]
    data.pose_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_y]
    data.pose_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_z]
    data.pose_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_roll]
    data.pose_roll = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_pitch]
    data.pose_pitch = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_yaw]
    data.pose_yaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [yaw]
    data.yaw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [center]
    data.center = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [corners]
    len = 4;
    data.corners = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.corners[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    return 84;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/QRPoseRefined';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '30a103fd4fd72f6b04ad69564460b53f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 id
    float32 pose_x
    float32 pose_y
    float32 pose_z
    float32 pose_roll
    float32 pose_pitch
    float32 pose_yaw
    float64 yaw
    geometry_msgs/Point center     # Center 
    geometry_msgs/Point[4] corners # Tag's corner in order of x axis and y axis
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new QRPoseRefined(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.pose_x !== undefined) {
      resolved.pose_x = msg.pose_x;
    }
    else {
      resolved.pose_x = 0.0
    }

    if (msg.pose_y !== undefined) {
      resolved.pose_y = msg.pose_y;
    }
    else {
      resolved.pose_y = 0.0
    }

    if (msg.pose_z !== undefined) {
      resolved.pose_z = msg.pose_z;
    }
    else {
      resolved.pose_z = 0.0
    }

    if (msg.pose_roll !== undefined) {
      resolved.pose_roll = msg.pose_roll;
    }
    else {
      resolved.pose_roll = 0.0
    }

    if (msg.pose_pitch !== undefined) {
      resolved.pose_pitch = msg.pose_pitch;
    }
    else {
      resolved.pose_pitch = 0.0
    }

    if (msg.pose_yaw !== undefined) {
      resolved.pose_yaw = msg.pose_yaw;
    }
    else {
      resolved.pose_yaw = 0.0
    }

    if (msg.yaw !== undefined) {
      resolved.yaw = msg.yaw;
    }
    else {
      resolved.yaw = 0.0
    }

    if (msg.center !== undefined) {
      resolved.center = geometry_msgs.msg.Point.Resolve(msg.center)
    }
    else {
      resolved.center = new geometry_msgs.msg.Point()
    }

    if (msg.corners !== undefined) {
      resolved.corners = new Array(4)
      for (let i = 0; i < resolved.corners.length; ++i) {
        if (msg.corners.length > i) {
          resolved.corners[i] = geometry_msgs.msg.Point.Resolve(msg.corners[i]);
        }
        else {
          resolved.corners[i] = new geometry_msgs.msg.Point();
        }
      }
    }
    else {
      resolved.corners = new Array(4).fill(new geometry_msgs.msg.Point())
    }

    return resolved;
    }
};

module.exports = QRPoseRefined;
