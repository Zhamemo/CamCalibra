// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ChargeState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.charge_signal_ = null;
      this.infrared_signal_ = null;
      this.infrared_lost_ = null;
      this.sonar_obstacle_ = null;
      this.spiling_timeout_ = null;
      this.is_real_charging_ = null;
      this.has_new_charging_state_ = null;
    }
    else {
      if (initObj.hasOwnProperty('charge_signal_')) {
        this.charge_signal_ = initObj.charge_signal_
      }
      else {
        this.charge_signal_ = false;
      }
      if (initObj.hasOwnProperty('infrared_signal_')) {
        this.infrared_signal_ = initObj.infrared_signal_
      }
      else {
        this.infrared_signal_ = false;
      }
      if (initObj.hasOwnProperty('infrared_lost_')) {
        this.infrared_lost_ = initObj.infrared_lost_
      }
      else {
        this.infrared_lost_ = false;
      }
      if (initObj.hasOwnProperty('sonar_obstacle_')) {
        this.sonar_obstacle_ = initObj.sonar_obstacle_
      }
      else {
        this.sonar_obstacle_ = false;
      }
      if (initObj.hasOwnProperty('spiling_timeout_')) {
        this.spiling_timeout_ = initObj.spiling_timeout_
      }
      else {
        this.spiling_timeout_ = false;
      }
      if (initObj.hasOwnProperty('is_real_charging_')) {
        this.is_real_charging_ = initObj.is_real_charging_
      }
      else {
        this.is_real_charging_ = false;
      }
      if (initObj.hasOwnProperty('has_new_charging_state_')) {
        this.has_new_charging_state_ = initObj.has_new_charging_state_
      }
      else {
        this.has_new_charging_state_ = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChargeState
    // Serialize message field [charge_signal_]
    bufferOffset = _serializer.bool(obj.charge_signal_, buffer, bufferOffset);
    // Serialize message field [infrared_signal_]
    bufferOffset = _serializer.bool(obj.infrared_signal_, buffer, bufferOffset);
    // Serialize message field [infrared_lost_]
    bufferOffset = _serializer.bool(obj.infrared_lost_, buffer, bufferOffset);
    // Serialize message field [sonar_obstacle_]
    bufferOffset = _serializer.bool(obj.sonar_obstacle_, buffer, bufferOffset);
    // Serialize message field [spiling_timeout_]
    bufferOffset = _serializer.bool(obj.spiling_timeout_, buffer, bufferOffset);
    // Serialize message field [is_real_charging_]
    bufferOffset = _serializer.bool(obj.is_real_charging_, buffer, bufferOffset);
    // Serialize message field [has_new_charging_state_]
    bufferOffset = _serializer.bool(obj.has_new_charging_state_, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChargeState
    let len;
    let data = new ChargeState(null);
    // Deserialize message field [charge_signal_]
    data.charge_signal_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [infrared_signal_]
    data.infrared_signal_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [infrared_lost_]
    data.infrared_lost_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [sonar_obstacle_]
    data.sonar_obstacle_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [spiling_timeout_]
    data.spiling_timeout_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_real_charging_]
    data.is_real_charging_ = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [has_new_charging_state_]
    data.has_new_charging_state_ = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 7;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/ChargeState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9e6c8c777618b37b01da1bdae37949dc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool charge_signal_
    bool infrared_signal_
    bool infrared_lost_
    bool sonar_obstacle_
    bool spiling_timeout_
    bool is_real_charging_
    bool has_new_charging_state_
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChargeState(null);
    if (msg.charge_signal_ !== undefined) {
      resolved.charge_signal_ = msg.charge_signal_;
    }
    else {
      resolved.charge_signal_ = false
    }

    if (msg.infrared_signal_ !== undefined) {
      resolved.infrared_signal_ = msg.infrared_signal_;
    }
    else {
      resolved.infrared_signal_ = false
    }

    if (msg.infrared_lost_ !== undefined) {
      resolved.infrared_lost_ = msg.infrared_lost_;
    }
    else {
      resolved.infrared_lost_ = false
    }

    if (msg.sonar_obstacle_ !== undefined) {
      resolved.sonar_obstacle_ = msg.sonar_obstacle_;
    }
    else {
      resolved.sonar_obstacle_ = false
    }

    if (msg.spiling_timeout_ !== undefined) {
      resolved.spiling_timeout_ = msg.spiling_timeout_;
    }
    else {
      resolved.spiling_timeout_ = false
    }

    if (msg.is_real_charging_ !== undefined) {
      resolved.is_real_charging_ = msg.is_real_charging_;
    }
    else {
      resolved.is_real_charging_ = false
    }

    if (msg.has_new_charging_state_ !== undefined) {
      resolved.has_new_charging_state_ = msg.has_new_charging_state_;
    }
    else {
      resolved.has_new_charging_state_ = false
    }

    return resolved;
    }
};

module.exports = ChargeState;
