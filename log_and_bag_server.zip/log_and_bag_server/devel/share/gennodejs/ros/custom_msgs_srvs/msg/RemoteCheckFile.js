// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LocalCheckFile = require('./LocalCheckFile.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class RemoteCheckFile {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.check_info = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('check_info')) {
        this.check_info = initObj.check_info
      }
      else {
        this.check_info = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RemoteCheckFile
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [check_info]
    // Serialize the length for message field [check_info]
    bufferOffset = _serializer.uint32(obj.check_info.length, buffer, bufferOffset);
    obj.check_info.forEach((val) => {
      bufferOffset = LocalCheckFile.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RemoteCheckFile
    let len;
    let data = new RemoteCheckFile(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [check_info]
    // Deserialize array length for message field [check_info]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.check_info = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.check_info[i] = LocalCheckFile.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.check_info.forEach((val) => {
      length += LocalCheckFile.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/RemoteCheckFile';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5439298657d1d26e5985825b91519990';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    LocalCheckFile[] check_info
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: custom_msgs_srvs/LocalCheckFile
    std_msgs/Header header
    std_msgs/String ip
    int16 build_id
    int16 floor_id
    int32 zwj_verson_1
    int32 zwj_verson_2
    int32 zwj_verson_3
    std_msgs/String path_node_md5
    std_msgs/String map_pgm_md5
    std_msgs/String map_yaml_md5
    int16 prior
    int16 lift_id
    int16 lift_state
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RemoteCheckFile(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.check_info !== undefined) {
      resolved.check_info = new Array(msg.check_info.length);
      for (let i = 0; i < resolved.check_info.length; ++i) {
        resolved.check_info[i] = LocalCheckFile.Resolve(msg.check_info[i]);
      }
    }
    else {
      resolved.check_info = []
    }

    return resolved;
    }
};

module.exports = RemoteCheckFile;
