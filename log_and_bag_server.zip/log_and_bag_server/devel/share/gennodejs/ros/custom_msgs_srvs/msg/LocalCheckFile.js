// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class LocalCheckFile {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.ip = null;
      this.build_id = null;
      this.floor_id = null;
      this.zwj_verson_1 = null;
      this.zwj_verson_2 = null;
      this.zwj_verson_3 = null;
      this.path_node_md5 = null;
      this.map_pgm_md5 = null;
      this.map_yaml_md5 = null;
      this.prior = null;
      this.lift_id = null;
      this.lift_state = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('ip')) {
        this.ip = initObj.ip
      }
      else {
        this.ip = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('build_id')) {
        this.build_id = initObj.build_id
      }
      else {
        this.build_id = 0;
      }
      if (initObj.hasOwnProperty('floor_id')) {
        this.floor_id = initObj.floor_id
      }
      else {
        this.floor_id = 0;
      }
      if (initObj.hasOwnProperty('zwj_verson_1')) {
        this.zwj_verson_1 = initObj.zwj_verson_1
      }
      else {
        this.zwj_verson_1 = 0;
      }
      if (initObj.hasOwnProperty('zwj_verson_2')) {
        this.zwj_verson_2 = initObj.zwj_verson_2
      }
      else {
        this.zwj_verson_2 = 0;
      }
      if (initObj.hasOwnProperty('zwj_verson_3')) {
        this.zwj_verson_3 = initObj.zwj_verson_3
      }
      else {
        this.zwj_verson_3 = 0;
      }
      if (initObj.hasOwnProperty('path_node_md5')) {
        this.path_node_md5 = initObj.path_node_md5
      }
      else {
        this.path_node_md5 = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('map_pgm_md5')) {
        this.map_pgm_md5 = initObj.map_pgm_md5
      }
      else {
        this.map_pgm_md5 = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('map_yaml_md5')) {
        this.map_yaml_md5 = initObj.map_yaml_md5
      }
      else {
        this.map_yaml_md5 = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('prior')) {
        this.prior = initObj.prior
      }
      else {
        this.prior = 0;
      }
      if (initObj.hasOwnProperty('lift_id')) {
        this.lift_id = initObj.lift_id
      }
      else {
        this.lift_id = 0;
      }
      if (initObj.hasOwnProperty('lift_state')) {
        this.lift_state = initObj.lift_state
      }
      else {
        this.lift_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocalCheckFile
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [ip]
    bufferOffset = std_msgs.msg.String.serialize(obj.ip, buffer, bufferOffset);
    // Serialize message field [build_id]
    bufferOffset = _serializer.int16(obj.build_id, buffer, bufferOffset);
    // Serialize message field [floor_id]
    bufferOffset = _serializer.int16(obj.floor_id, buffer, bufferOffset);
    // Serialize message field [zwj_verson_1]
    bufferOffset = _serializer.int32(obj.zwj_verson_1, buffer, bufferOffset);
    // Serialize message field [zwj_verson_2]
    bufferOffset = _serializer.int32(obj.zwj_verson_2, buffer, bufferOffset);
    // Serialize message field [zwj_verson_3]
    bufferOffset = _serializer.int32(obj.zwj_verson_3, buffer, bufferOffset);
    // Serialize message field [path_node_md5]
    bufferOffset = std_msgs.msg.String.serialize(obj.path_node_md5, buffer, bufferOffset);
    // Serialize message field [map_pgm_md5]
    bufferOffset = std_msgs.msg.String.serialize(obj.map_pgm_md5, buffer, bufferOffset);
    // Serialize message field [map_yaml_md5]
    bufferOffset = std_msgs.msg.String.serialize(obj.map_yaml_md5, buffer, bufferOffset);
    // Serialize message field [prior]
    bufferOffset = _serializer.int16(obj.prior, buffer, bufferOffset);
    // Serialize message field [lift_id]
    bufferOffset = _serializer.int16(obj.lift_id, buffer, bufferOffset);
    // Serialize message field [lift_state]
    bufferOffset = _serializer.int16(obj.lift_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocalCheckFile
    let len;
    let data = new LocalCheckFile(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [ip]
    data.ip = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [build_id]
    data.build_id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [floor_id]
    data.floor_id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [zwj_verson_1]
    data.zwj_verson_1 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [zwj_verson_2]
    data.zwj_verson_2 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [zwj_verson_3]
    data.zwj_verson_3 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [path_node_md5]
    data.path_node_md5 = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [map_pgm_md5]
    data.map_pgm_md5 = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [map_yaml_md5]
    data.map_yaml_md5 = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [prior]
    data.prior = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [lift_id]
    data.lift_id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [lift_state]
    data.lift_state = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += std_msgs.msg.String.getMessageSize(object.ip);
    length += std_msgs.msg.String.getMessageSize(object.path_node_md5);
    length += std_msgs.msg.String.getMessageSize(object.map_pgm_md5);
    length += std_msgs.msg.String.getMessageSize(object.map_yaml_md5);
    return length + 22;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/LocalCheckFile';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b0728a7d304cec3e5ff5127ea39b8db9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    std_msgs/String ip
    int16 build_id
    int16 floor_id
    int32 zwj_verson_1
    int32 zwj_verson_2
    int32 zwj_verson_3
    std_msgs/String path_node_md5
    std_msgs/String map_pgm_md5
    std_msgs/String map_yaml_md5
    int16 prior
    int16 lift_id
    int16 lift_state
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocalCheckFile(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.ip !== undefined) {
      resolved.ip = std_msgs.msg.String.Resolve(msg.ip)
    }
    else {
      resolved.ip = new std_msgs.msg.String()
    }

    if (msg.build_id !== undefined) {
      resolved.build_id = msg.build_id;
    }
    else {
      resolved.build_id = 0
    }

    if (msg.floor_id !== undefined) {
      resolved.floor_id = msg.floor_id;
    }
    else {
      resolved.floor_id = 0
    }

    if (msg.zwj_verson_1 !== undefined) {
      resolved.zwj_verson_1 = msg.zwj_verson_1;
    }
    else {
      resolved.zwj_verson_1 = 0
    }

    if (msg.zwj_verson_2 !== undefined) {
      resolved.zwj_verson_2 = msg.zwj_verson_2;
    }
    else {
      resolved.zwj_verson_2 = 0
    }

    if (msg.zwj_verson_3 !== undefined) {
      resolved.zwj_verson_3 = msg.zwj_verson_3;
    }
    else {
      resolved.zwj_verson_3 = 0
    }

    if (msg.path_node_md5 !== undefined) {
      resolved.path_node_md5 = std_msgs.msg.String.Resolve(msg.path_node_md5)
    }
    else {
      resolved.path_node_md5 = new std_msgs.msg.String()
    }

    if (msg.map_pgm_md5 !== undefined) {
      resolved.map_pgm_md5 = std_msgs.msg.String.Resolve(msg.map_pgm_md5)
    }
    else {
      resolved.map_pgm_md5 = new std_msgs.msg.String()
    }

    if (msg.map_yaml_md5 !== undefined) {
      resolved.map_yaml_md5 = std_msgs.msg.String.Resolve(msg.map_yaml_md5)
    }
    else {
      resolved.map_yaml_md5 = new std_msgs.msg.String()
    }

    if (msg.prior !== undefined) {
      resolved.prior = msg.prior;
    }
    else {
      resolved.prior = 0
    }

    if (msg.lift_id !== undefined) {
      resolved.lift_id = msg.lift_id;
    }
    else {
      resolved.lift_id = 0
    }

    if (msg.lift_state !== undefined) {
      resolved.lift_state = msg.lift_state;
    }
    else {
      resolved.lift_state = 0
    }

    return resolved;
    }
};

module.exports = LocalCheckFile;
