// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class DisLiftInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_have_LiftAllInfo = null;
      this.pose_int = null;
      this.dis_robot_to_in_mid_lift_pose = null;
      this.dis_robot_to_out_mid_lift_pose = null;
      this.dis_in_out_mid_pose = null;
      this.is_have_SlowPathInfo = null;
      this.slowpoint_pose_int = null;
      this.dis_robot_to_slowpoint_mid_lift_pose = null;
      this.dis_robot_to_slowpoint_in_lift_pose = null;
      this.dis_robot_to_slowpoint_mid_lift_pose2 = null;
    }
    else {
      if (initObj.hasOwnProperty('is_have_LiftAllInfo')) {
        this.is_have_LiftAllInfo = initObj.is_have_LiftAllInfo
      }
      else {
        this.is_have_LiftAllInfo = false;
      }
      if (initObj.hasOwnProperty('pose_int')) {
        this.pose_int = initObj.pose_int
      }
      else {
        this.pose_int = 0;
      }
      if (initObj.hasOwnProperty('dis_robot_to_in_mid_lift_pose')) {
        this.dis_robot_to_in_mid_lift_pose = initObj.dis_robot_to_in_mid_lift_pose
      }
      else {
        this.dis_robot_to_in_mid_lift_pose = 0.0;
      }
      if (initObj.hasOwnProperty('dis_robot_to_out_mid_lift_pose')) {
        this.dis_robot_to_out_mid_lift_pose = initObj.dis_robot_to_out_mid_lift_pose
      }
      else {
        this.dis_robot_to_out_mid_lift_pose = 0.0;
      }
      if (initObj.hasOwnProperty('dis_in_out_mid_pose')) {
        this.dis_in_out_mid_pose = initObj.dis_in_out_mid_pose
      }
      else {
        this.dis_in_out_mid_pose = 0.0;
      }
      if (initObj.hasOwnProperty('is_have_SlowPathInfo')) {
        this.is_have_SlowPathInfo = initObj.is_have_SlowPathInfo
      }
      else {
        this.is_have_SlowPathInfo = false;
      }
      if (initObj.hasOwnProperty('slowpoint_pose_int')) {
        this.slowpoint_pose_int = initObj.slowpoint_pose_int
      }
      else {
        this.slowpoint_pose_int = 0;
      }
      if (initObj.hasOwnProperty('dis_robot_to_slowpoint_mid_lift_pose')) {
        this.dis_robot_to_slowpoint_mid_lift_pose = initObj.dis_robot_to_slowpoint_mid_lift_pose
      }
      else {
        this.dis_robot_to_slowpoint_mid_lift_pose = 0.0;
      }
      if (initObj.hasOwnProperty('dis_robot_to_slowpoint_in_lift_pose')) {
        this.dis_robot_to_slowpoint_in_lift_pose = initObj.dis_robot_to_slowpoint_in_lift_pose
      }
      else {
        this.dis_robot_to_slowpoint_in_lift_pose = 0.0;
      }
      if (initObj.hasOwnProperty('dis_robot_to_slowpoint_mid_lift_pose2')) {
        this.dis_robot_to_slowpoint_mid_lift_pose2 = initObj.dis_robot_to_slowpoint_mid_lift_pose2
      }
      else {
        this.dis_robot_to_slowpoint_mid_lift_pose2 = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DisLiftInfo
    // Serialize message field [is_have_LiftAllInfo]
    bufferOffset = _serializer.bool(obj.is_have_LiftAllInfo, buffer, bufferOffset);
    // Serialize message field [pose_int]
    bufferOffset = _serializer.int32(obj.pose_int, buffer, bufferOffset);
    // Serialize message field [dis_robot_to_in_mid_lift_pose]
    bufferOffset = _serializer.float64(obj.dis_robot_to_in_mid_lift_pose, buffer, bufferOffset);
    // Serialize message field [dis_robot_to_out_mid_lift_pose]
    bufferOffset = _serializer.float64(obj.dis_robot_to_out_mid_lift_pose, buffer, bufferOffset);
    // Serialize message field [dis_in_out_mid_pose]
    bufferOffset = _serializer.float64(obj.dis_in_out_mid_pose, buffer, bufferOffset);
    // Serialize message field [is_have_SlowPathInfo]
    bufferOffset = _serializer.bool(obj.is_have_SlowPathInfo, buffer, bufferOffset);
    // Serialize message field [slowpoint_pose_int]
    bufferOffset = _serializer.int32(obj.slowpoint_pose_int, buffer, bufferOffset);
    // Serialize message field [dis_robot_to_slowpoint_mid_lift_pose]
    bufferOffset = _serializer.float64(obj.dis_robot_to_slowpoint_mid_lift_pose, buffer, bufferOffset);
    // Serialize message field [dis_robot_to_slowpoint_in_lift_pose]
    bufferOffset = _serializer.float64(obj.dis_robot_to_slowpoint_in_lift_pose, buffer, bufferOffset);
    // Serialize message field [dis_robot_to_slowpoint_mid_lift_pose2]
    bufferOffset = _serializer.float64(obj.dis_robot_to_slowpoint_mid_lift_pose2, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DisLiftInfo
    let len;
    let data = new DisLiftInfo(null);
    // Deserialize message field [is_have_LiftAllInfo]
    data.is_have_LiftAllInfo = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [pose_int]
    data.pose_int = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [dis_robot_to_in_mid_lift_pose]
    data.dis_robot_to_in_mid_lift_pose = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dis_robot_to_out_mid_lift_pose]
    data.dis_robot_to_out_mid_lift_pose = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dis_in_out_mid_pose]
    data.dis_in_out_mid_pose = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [is_have_SlowPathInfo]
    data.is_have_SlowPathInfo = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [slowpoint_pose_int]
    data.slowpoint_pose_int = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [dis_robot_to_slowpoint_mid_lift_pose]
    data.dis_robot_to_slowpoint_mid_lift_pose = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dis_robot_to_slowpoint_in_lift_pose]
    data.dis_robot_to_slowpoint_in_lift_pose = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dis_robot_to_slowpoint_mid_lift_pose2]
    data.dis_robot_to_slowpoint_mid_lift_pose2 = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 58;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/DisLiftInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0dc64767fc000dc983a0a8c42aad2b1a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool is_have_LiftAllInfo
    int32 pose_int  #0 表示在电梯外 1 表示在电梯中 2表示在电梯内,-1不生效
    float64 dis_robot_to_in_mid_lift_pose
    float64 dis_robot_to_out_mid_lift_pose
    float64 dis_in_out_mid_pose
    bool is_have_SlowPathInfo
    int32 slowpoint_pose_int    #0表示在梯中间(坎)外 1 表示在梯中间节点与梯内点之间 2表示在电梯内节点外,-1不生效
    float64 dis_robot_to_slowpoint_mid_lift_pose
    float64 dis_robot_to_slowpoint_in_lift_pose
    float64 dis_robot_to_slowpoint_mid_lift_pose2 #机器人距离梯坎点的相对位置，梯外点与体内点方向，由正到负
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DisLiftInfo(null);
    if (msg.is_have_LiftAllInfo !== undefined) {
      resolved.is_have_LiftAllInfo = msg.is_have_LiftAllInfo;
    }
    else {
      resolved.is_have_LiftAllInfo = false
    }

    if (msg.pose_int !== undefined) {
      resolved.pose_int = msg.pose_int;
    }
    else {
      resolved.pose_int = 0
    }

    if (msg.dis_robot_to_in_mid_lift_pose !== undefined) {
      resolved.dis_robot_to_in_mid_lift_pose = msg.dis_robot_to_in_mid_lift_pose;
    }
    else {
      resolved.dis_robot_to_in_mid_lift_pose = 0.0
    }

    if (msg.dis_robot_to_out_mid_lift_pose !== undefined) {
      resolved.dis_robot_to_out_mid_lift_pose = msg.dis_robot_to_out_mid_lift_pose;
    }
    else {
      resolved.dis_robot_to_out_mid_lift_pose = 0.0
    }

    if (msg.dis_in_out_mid_pose !== undefined) {
      resolved.dis_in_out_mid_pose = msg.dis_in_out_mid_pose;
    }
    else {
      resolved.dis_in_out_mid_pose = 0.0
    }

    if (msg.is_have_SlowPathInfo !== undefined) {
      resolved.is_have_SlowPathInfo = msg.is_have_SlowPathInfo;
    }
    else {
      resolved.is_have_SlowPathInfo = false
    }

    if (msg.slowpoint_pose_int !== undefined) {
      resolved.slowpoint_pose_int = msg.slowpoint_pose_int;
    }
    else {
      resolved.slowpoint_pose_int = 0
    }

    if (msg.dis_robot_to_slowpoint_mid_lift_pose !== undefined) {
      resolved.dis_robot_to_slowpoint_mid_lift_pose = msg.dis_robot_to_slowpoint_mid_lift_pose;
    }
    else {
      resolved.dis_robot_to_slowpoint_mid_lift_pose = 0.0
    }

    if (msg.dis_robot_to_slowpoint_in_lift_pose !== undefined) {
      resolved.dis_robot_to_slowpoint_in_lift_pose = msg.dis_robot_to_slowpoint_in_lift_pose;
    }
    else {
      resolved.dis_robot_to_slowpoint_in_lift_pose = 0.0
    }

    if (msg.dis_robot_to_slowpoint_mid_lift_pose2 !== undefined) {
      resolved.dis_robot_to_slowpoint_mid_lift_pose2 = msg.dis_robot_to_slowpoint_mid_lift_pose2;
    }
    else {
      resolved.dis_robot_to_slowpoint_mid_lift_pose2 = 0.0
    }

    return resolved;
    }
};

module.exports = DisLiftInfo;
