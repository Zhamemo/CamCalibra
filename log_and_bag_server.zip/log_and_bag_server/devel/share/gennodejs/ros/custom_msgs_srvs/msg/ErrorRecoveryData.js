// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ErrorRecoveryData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_id = null;
      this.error_level = null;
      this.error_recovery = null;
      this.all_error_recovery = null;
      this.other_error_id = null;
    }
    else {
      if (initObj.hasOwnProperty('error_id')) {
        this.error_id = initObj.error_id
      }
      else {
        this.error_id = '';
      }
      if (initObj.hasOwnProperty('error_level')) {
        this.error_level = initObj.error_level
      }
      else {
        this.error_level = '';
      }
      if (initObj.hasOwnProperty('error_recovery')) {
        this.error_recovery = initObj.error_recovery
      }
      else {
        this.error_recovery = false;
      }
      if (initObj.hasOwnProperty('all_error_recovery')) {
        this.all_error_recovery = initObj.all_error_recovery
      }
      else {
        this.all_error_recovery = false;
      }
      if (initObj.hasOwnProperty('other_error_id')) {
        this.other_error_id = initObj.other_error_id
      }
      else {
        this.other_error_id = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ErrorRecoveryData
    // Serialize message field [error_id]
    bufferOffset = _serializer.string(obj.error_id, buffer, bufferOffset);
    // Serialize message field [error_level]
    bufferOffset = _serializer.string(obj.error_level, buffer, bufferOffset);
    // Serialize message field [error_recovery]
    bufferOffset = _serializer.bool(obj.error_recovery, buffer, bufferOffset);
    // Serialize message field [all_error_recovery]
    bufferOffset = _serializer.bool(obj.all_error_recovery, buffer, bufferOffset);
    // Serialize message field [other_error_id]
    bufferOffset = _serializer.string(obj.other_error_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ErrorRecoveryData
    let len;
    let data = new ErrorRecoveryData(null);
    // Deserialize message field [error_id]
    data.error_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_level]
    data.error_level = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_recovery]
    data.error_recovery = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [all_error_recovery]
    data.all_error_recovery = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [other_error_id]
    data.other_error_id = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_id.length;
    length += object.error_level.length;
    length += object.other_error_id.length;
    return length + 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/ErrorRecoveryData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '30ef08f9eafbb7ed015ededbee66c985';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_id 
    string error_level
    bool error_recovery                   
    bool all_error_recovery
    string other_error_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ErrorRecoveryData(null);
    if (msg.error_id !== undefined) {
      resolved.error_id = msg.error_id;
    }
    else {
      resolved.error_id = ''
    }

    if (msg.error_level !== undefined) {
      resolved.error_level = msg.error_level;
    }
    else {
      resolved.error_level = ''
    }

    if (msg.error_recovery !== undefined) {
      resolved.error_recovery = msg.error_recovery;
    }
    else {
      resolved.error_recovery = false
    }

    if (msg.all_error_recovery !== undefined) {
      resolved.all_error_recovery = msg.all_error_recovery;
    }
    else {
      resolved.all_error_recovery = false
    }

    if (msg.other_error_id !== undefined) {
      resolved.other_error_id = msg.other_error_id;
    }
    else {
      resolved.other_error_id = ''
    }

    return resolved;
    }
};

module.exports = ErrorRecoveryData;
