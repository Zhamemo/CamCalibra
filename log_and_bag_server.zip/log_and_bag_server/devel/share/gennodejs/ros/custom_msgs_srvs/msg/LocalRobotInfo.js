// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let RobotInfo = require('./RobotInfo.js');

//-----------------------------------------------------------

class LocalRobotInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.robot_info = null;
    }
    else {
      if (initObj.hasOwnProperty('robot_info')) {
        this.robot_info = initObj.robot_info
      }
      else {
        this.robot_info = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocalRobotInfo
    // Serialize message field [robot_info]
    // Serialize the length for message field [robot_info]
    bufferOffset = _serializer.uint32(obj.robot_info.length, buffer, bufferOffset);
    obj.robot_info.forEach((val) => {
      bufferOffset = RobotInfo.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocalRobotInfo
    let len;
    let data = new LocalRobotInfo(null);
    // Deserialize message field [robot_info]
    // Deserialize array length for message field [robot_info]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.robot_info = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.robot_info[i] = RobotInfo.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.robot_info.forEach((val) => {
      length += RobotInfo.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/LocalRobotInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ccdd3a6cd69eabdfb9fc678b29889f2e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    RobotInfo[] robot_info
    
    ================================================================================
    MSG: custom_msgs_srvs/RobotInfo
    std_msgs/Header header
    std_msgs/String ip
    std_msgs/String robot_style
    int16 prior
    int16 build_id
    int16 floor_id
    int16 multi_state
    std_msgs/String state
    float64 pose_x
    float64 pose_y
    float64 pose_yaw	
    float64 goal_x		
    float64 goal_y		
    std_msgs/String sport_state
    std_msgs/String overtake
    std_msgs/String node_list
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocalRobotInfo(null);
    if (msg.robot_info !== undefined) {
      resolved.robot_info = new Array(msg.robot_info.length);
      for (let i = 0; i < resolved.robot_info.length; ++i) {
        resolved.robot_info[i] = RobotInfo.Resolve(msg.robot_info[i]);
      }
    }
    else {
      resolved.robot_info = []
    }

    return resolved;
    }
};

module.exports = LocalRobotInfo;
