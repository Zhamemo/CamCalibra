// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let DisLiftInfo = require('./DisLiftInfo.js');
let ImuCheckEnterLiftInfo = require('./ImuCheckEnterLiftInfo.js');
let LocalPlanEnterLiftState = require('./LocalPlanEnterLiftState.js');
let InOutLiftState = require('./InOutLiftState.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class EnterOutLiftState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.current_robot_pose = null;
      this.robot_nav_mode = null;
      this.current_floor = null;
      this.enter_lift_fail_num = null;
      this.current_enter_lift_time = null;
      this.max_enter_lift_time = null;
      this.need_back_nav = null;
      this.is_finsh_switch_map = null;
      this.dis_lift_info = null;
      this.imu_check_enter_lift_info = null;
      this.local_plan_enter_lift_info = null;
      this.in_out_lift_state = null;
      this.out_lift_fail_num = null;
      this.current_out_lift_time = null;
      this.need_pause_in_lift = null;
      this.robot_state = null;
      this.apk_pause_robot_sport = null;
    }
    else {
      if (initObj.hasOwnProperty('current_robot_pose')) {
        this.current_robot_pose = initObj.current_robot_pose
      }
      else {
        this.current_robot_pose = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('robot_nav_mode')) {
        this.robot_nav_mode = initObj.robot_nav_mode
      }
      else {
        this.robot_nav_mode = 0;
      }
      if (initObj.hasOwnProperty('current_floor')) {
        this.current_floor = initObj.current_floor
      }
      else {
        this.current_floor = 0;
      }
      if (initObj.hasOwnProperty('enter_lift_fail_num')) {
        this.enter_lift_fail_num = initObj.enter_lift_fail_num
      }
      else {
        this.enter_lift_fail_num = 0;
      }
      if (initObj.hasOwnProperty('current_enter_lift_time')) {
        this.current_enter_lift_time = initObj.current_enter_lift_time
      }
      else {
        this.current_enter_lift_time = 0.0;
      }
      if (initObj.hasOwnProperty('max_enter_lift_time')) {
        this.max_enter_lift_time = initObj.max_enter_lift_time
      }
      else {
        this.max_enter_lift_time = 0.0;
      }
      if (initObj.hasOwnProperty('need_back_nav')) {
        this.need_back_nav = initObj.need_back_nav
      }
      else {
        this.need_back_nav = false;
      }
      if (initObj.hasOwnProperty('is_finsh_switch_map')) {
        this.is_finsh_switch_map = initObj.is_finsh_switch_map
      }
      else {
        this.is_finsh_switch_map = false;
      }
      if (initObj.hasOwnProperty('dis_lift_info')) {
        this.dis_lift_info = initObj.dis_lift_info
      }
      else {
        this.dis_lift_info = new DisLiftInfo();
      }
      if (initObj.hasOwnProperty('imu_check_enter_lift_info')) {
        this.imu_check_enter_lift_info = initObj.imu_check_enter_lift_info
      }
      else {
        this.imu_check_enter_lift_info = new ImuCheckEnterLiftInfo();
      }
      if (initObj.hasOwnProperty('local_plan_enter_lift_info')) {
        this.local_plan_enter_lift_info = initObj.local_plan_enter_lift_info
      }
      else {
        this.local_plan_enter_lift_info = new LocalPlanEnterLiftState();
      }
      if (initObj.hasOwnProperty('in_out_lift_state')) {
        this.in_out_lift_state = initObj.in_out_lift_state
      }
      else {
        this.in_out_lift_state = new InOutLiftState();
      }
      if (initObj.hasOwnProperty('out_lift_fail_num')) {
        this.out_lift_fail_num = initObj.out_lift_fail_num
      }
      else {
        this.out_lift_fail_num = 0;
      }
      if (initObj.hasOwnProperty('current_out_lift_time')) {
        this.current_out_lift_time = initObj.current_out_lift_time
      }
      else {
        this.current_out_lift_time = 0.0;
      }
      if (initObj.hasOwnProperty('need_pause_in_lift')) {
        this.need_pause_in_lift = initObj.need_pause_in_lift
      }
      else {
        this.need_pause_in_lift = false;
      }
      if (initObj.hasOwnProperty('robot_state')) {
        this.robot_state = initObj.robot_state
      }
      else {
        this.robot_state = 0;
      }
      if (initObj.hasOwnProperty('apk_pause_robot_sport')) {
        this.apk_pause_robot_sport = initObj.apk_pause_robot_sport
      }
      else {
        this.apk_pause_robot_sport = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EnterOutLiftState
    // Serialize message field [current_robot_pose]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.current_robot_pose, buffer, bufferOffset);
    // Serialize message field [robot_nav_mode]
    bufferOffset = _serializer.int32(obj.robot_nav_mode, buffer, bufferOffset);
    // Serialize message field [current_floor]
    bufferOffset = _serializer.int32(obj.current_floor, buffer, bufferOffset);
    // Serialize message field [enter_lift_fail_num]
    bufferOffset = _serializer.int32(obj.enter_lift_fail_num, buffer, bufferOffset);
    // Serialize message field [current_enter_lift_time]
    bufferOffset = _serializer.float64(obj.current_enter_lift_time, buffer, bufferOffset);
    // Serialize message field [max_enter_lift_time]
    bufferOffset = _serializer.float64(obj.max_enter_lift_time, buffer, bufferOffset);
    // Serialize message field [need_back_nav]
    bufferOffset = _serializer.bool(obj.need_back_nav, buffer, bufferOffset);
    // Serialize message field [is_finsh_switch_map]
    bufferOffset = _serializer.bool(obj.is_finsh_switch_map, buffer, bufferOffset);
    // Serialize message field [dis_lift_info]
    bufferOffset = DisLiftInfo.serialize(obj.dis_lift_info, buffer, bufferOffset);
    // Serialize message field [imu_check_enter_lift_info]
    bufferOffset = ImuCheckEnterLiftInfo.serialize(obj.imu_check_enter_lift_info, buffer, bufferOffset);
    // Serialize message field [local_plan_enter_lift_info]
    bufferOffset = LocalPlanEnterLiftState.serialize(obj.local_plan_enter_lift_info, buffer, bufferOffset);
    // Serialize message field [in_out_lift_state]
    bufferOffset = InOutLiftState.serialize(obj.in_out_lift_state, buffer, bufferOffset);
    // Serialize message field [out_lift_fail_num]
    bufferOffset = _serializer.int32(obj.out_lift_fail_num, buffer, bufferOffset);
    // Serialize message field [current_out_lift_time]
    bufferOffset = _serializer.float64(obj.current_out_lift_time, buffer, bufferOffset);
    // Serialize message field [need_pause_in_lift]
    bufferOffset = _serializer.bool(obj.need_pause_in_lift, buffer, bufferOffset);
    // Serialize message field [robot_state]
    bufferOffset = _serializer.int32(obj.robot_state, buffer, bufferOffset);
    // Serialize message field [apk_pause_robot_sport]
    bufferOffset = _serializer.bool(obj.apk_pause_robot_sport, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EnterOutLiftState
    let len;
    let data = new EnterOutLiftState(null);
    // Deserialize message field [current_robot_pose]
    data.current_robot_pose = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [robot_nav_mode]
    data.robot_nav_mode = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [current_floor]
    data.current_floor = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [enter_lift_fail_num]
    data.enter_lift_fail_num = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [current_enter_lift_time]
    data.current_enter_lift_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [max_enter_lift_time]
    data.max_enter_lift_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [need_back_nav]
    data.need_back_nav = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [is_finsh_switch_map]
    data.is_finsh_switch_map = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dis_lift_info]
    data.dis_lift_info = DisLiftInfo.deserialize(buffer, bufferOffset);
    // Deserialize message field [imu_check_enter_lift_info]
    data.imu_check_enter_lift_info = ImuCheckEnterLiftInfo.deserialize(buffer, bufferOffset);
    // Deserialize message field [local_plan_enter_lift_info]
    data.local_plan_enter_lift_info = LocalPlanEnterLiftState.deserialize(buffer, bufferOffset);
    // Deserialize message field [in_out_lift_state]
    data.in_out_lift_state = InOutLiftState.deserialize(buffer, bufferOffset);
    // Deserialize message field [out_lift_fail_num]
    data.out_lift_fail_num = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [current_out_lift_time]
    data.current_out_lift_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [need_pause_in_lift]
    data.need_pause_in_lift = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [robot_state]
    data.robot_state = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [apk_pause_robot_sport]
    data.apk_pause_robot_sport = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.current_robot_pose);
    length += ImuCheckEnterLiftInfo.getMessageSize(object.imu_check_enter_lift_info);
    return length + 170;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/EnterOutLiftState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3259b8250b77d13a83a2b839755a2447';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/PoseStamped current_robot_pose
    int32 robot_nav_mode
    int32 current_floor
    int32 enter_lift_fail_num
    float64 current_enter_lift_time
    float64 max_enter_lift_time
    bool need_back_nav
    bool is_finsh_switch_map
    DisLiftInfo dis_lift_info
    ImuCheckEnterLiftInfo imu_check_enter_lift_info
    LocalPlanEnterLiftState local_plan_enter_lift_info
    InOutLiftState in_out_lift_state
    int32 out_lift_fail_num
    float64 current_out_lift_time
    bool need_pause_in_lift
    int32 robot_state
    bool apk_pause_robot_sport
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: custom_msgs_srvs/DisLiftInfo
    bool is_have_LiftAllInfo
    int32 pose_int  #0 表示在电梯外 1 表示在电梯中 2表示在电梯内,-1不生效
    float64 dis_robot_to_in_mid_lift_pose
    float64 dis_robot_to_out_mid_lift_pose
    float64 dis_in_out_mid_pose
    bool is_have_SlowPathInfo
    int32 slowpoint_pose_int    #0表示在梯中间(坎)外 1 表示在梯中间节点与梯内点之间 2表示在电梯内节点外,-1不生效
    float64 dis_robot_to_slowpoint_mid_lift_pose
    float64 dis_robot_to_slowpoint_in_lift_pose
    float64 dis_robot_to_slowpoint_mid_lift_pose2 #机器人距离梯坎点的相对位置，梯外点与体内点方向，由正到负
    
    ================================================================================
    MSG: custom_msgs_srvs/ImuCheckEnterLiftInfo
    string enable_imu_check_lift
    string imu_check_lift_current_state
    bool request_swj_stop_robot_sport
    float64 dis_stop_robot_sport_timeout
    bool is_send_sos_to_swj
    string send_apk_robot_in_lift_state
    
    ================================================================================
    MSG: custom_msgs_srvs/LocalPlanEnterLiftState
      #int32 robot_nav_mode
      int32 frenet_error
      int32 update_frenet_error
      int32 frenet_size
      #float64 dis_frenet
      #float64 dis_robot_run
      #bool allow_elevator
      #bool is_obs
      #float64 last_frenet_time
      float64 elevator_allow_dist
      int32 result_local_plan
      int32 local_plan_err
    
    ================================================================================
    MSG: custom_msgs_srvs/InOutLiftState
      #机器人与梯中间点的关系， 0 机器人在电梯外，且距离坎小于 ud_elevator_out_residual_;1 机器人在电梯外，且距离坎大于 ud_elevator_out_residual_;
      #2 机器人在电梯内，且距离坎小于 ud_elevator_enter_residual_;3 机器人在电梯内，且距离坎大于 ud_elevator_enter_residual_; -1无效
      int32 robot_lift_state
      #进梯时是需要继续行驶多少可完成进梯, robot_lift_state处于0 1时， continue_run_size = ud_elevator_enter_residual+robot_elevator_dis, 
                                    #robot_lift_state处于2 3 时， continue_run_size = ud_elevator_enter_residual-robot_elevator_dis, 如果为负数说明已经过了;
      #出梯时需要继续行驶多少完成进梯,  robot_lift_state处于2 3 时， continue_run_size = ud_elevator_out_residual+robot_elevator_dis, 
                                    #robot_lift_state处于0 1 时， continue_run_size = ud_elevator_out_residual-robot_elevator_dis, 如果为负数说明已经过了; 默认100
      int32 continue_run_size   
      int32 start_elevator_dis  #梯外点与梯中间点(坎)的index, 梯外点到梯内点的连线 都需要*0.05
      int32 end_elevator_dis    #梯内点与梯中间点(坎)的index , 梯外点到梯内点的连线
      int32 robot_elevator_dis  #机器人与梯中间点(坎)的index , 梯外点到梯内点的连线
      int32 robot_start_dis     #机器人与梯外点的index , 梯外点到梯内点的连线
      int32 ud_elevator_enter_residual
      int32 robot_end_dis       #机器人与梯内点的index , 梯外点到梯内点的连线
      int32 ud_elevator_out_residual   
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EnterOutLiftState(null);
    if (msg.current_robot_pose !== undefined) {
      resolved.current_robot_pose = geometry_msgs.msg.PoseStamped.Resolve(msg.current_robot_pose)
    }
    else {
      resolved.current_robot_pose = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.robot_nav_mode !== undefined) {
      resolved.robot_nav_mode = msg.robot_nav_mode;
    }
    else {
      resolved.robot_nav_mode = 0
    }

    if (msg.current_floor !== undefined) {
      resolved.current_floor = msg.current_floor;
    }
    else {
      resolved.current_floor = 0
    }

    if (msg.enter_lift_fail_num !== undefined) {
      resolved.enter_lift_fail_num = msg.enter_lift_fail_num;
    }
    else {
      resolved.enter_lift_fail_num = 0
    }

    if (msg.current_enter_lift_time !== undefined) {
      resolved.current_enter_lift_time = msg.current_enter_lift_time;
    }
    else {
      resolved.current_enter_lift_time = 0.0
    }

    if (msg.max_enter_lift_time !== undefined) {
      resolved.max_enter_lift_time = msg.max_enter_lift_time;
    }
    else {
      resolved.max_enter_lift_time = 0.0
    }

    if (msg.need_back_nav !== undefined) {
      resolved.need_back_nav = msg.need_back_nav;
    }
    else {
      resolved.need_back_nav = false
    }

    if (msg.is_finsh_switch_map !== undefined) {
      resolved.is_finsh_switch_map = msg.is_finsh_switch_map;
    }
    else {
      resolved.is_finsh_switch_map = false
    }

    if (msg.dis_lift_info !== undefined) {
      resolved.dis_lift_info = DisLiftInfo.Resolve(msg.dis_lift_info)
    }
    else {
      resolved.dis_lift_info = new DisLiftInfo()
    }

    if (msg.imu_check_enter_lift_info !== undefined) {
      resolved.imu_check_enter_lift_info = ImuCheckEnterLiftInfo.Resolve(msg.imu_check_enter_lift_info)
    }
    else {
      resolved.imu_check_enter_lift_info = new ImuCheckEnterLiftInfo()
    }

    if (msg.local_plan_enter_lift_info !== undefined) {
      resolved.local_plan_enter_lift_info = LocalPlanEnterLiftState.Resolve(msg.local_plan_enter_lift_info)
    }
    else {
      resolved.local_plan_enter_lift_info = new LocalPlanEnterLiftState()
    }

    if (msg.in_out_lift_state !== undefined) {
      resolved.in_out_lift_state = InOutLiftState.Resolve(msg.in_out_lift_state)
    }
    else {
      resolved.in_out_lift_state = new InOutLiftState()
    }

    if (msg.out_lift_fail_num !== undefined) {
      resolved.out_lift_fail_num = msg.out_lift_fail_num;
    }
    else {
      resolved.out_lift_fail_num = 0
    }

    if (msg.current_out_lift_time !== undefined) {
      resolved.current_out_lift_time = msg.current_out_lift_time;
    }
    else {
      resolved.current_out_lift_time = 0.0
    }

    if (msg.need_pause_in_lift !== undefined) {
      resolved.need_pause_in_lift = msg.need_pause_in_lift;
    }
    else {
      resolved.need_pause_in_lift = false
    }

    if (msg.robot_state !== undefined) {
      resolved.robot_state = msg.robot_state;
    }
    else {
      resolved.robot_state = 0
    }

    if (msg.apk_pause_robot_sport !== undefined) {
      resolved.apk_pause_robot_sport = msg.apk_pause_robot_sport;
    }
    else {
      resolved.apk_pause_robot_sport = false
    }

    return resolved;
    }
};

module.exports = EnterOutLiftState;
