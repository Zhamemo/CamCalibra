// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class AdminParam {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.str_vec = null;
    }
    else {
      if (initObj.hasOwnProperty('str_vec')) {
        this.str_vec = initObj.str_vec
      }
      else {
        this.str_vec = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AdminParam
    // Serialize message field [str_vec]
    // Serialize the length for message field [str_vec]
    bufferOffset = _serializer.uint32(obj.str_vec.length, buffer, bufferOffset);
    obj.str_vec.forEach((val) => {
      bufferOffset = std_msgs.msg.String.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AdminParam
    let len;
    let data = new AdminParam(null);
    // Deserialize message field [str_vec]
    // Deserialize array length for message field [str_vec]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.str_vec = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.str_vec[i] = std_msgs.msg.String.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.str_vec.forEach((val) => {
      length += std_msgs.msg.String.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/AdminParam';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '80ab96cf9f3ea2d4e66a344484d60731';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String[] str_vec
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AdminParam(null);
    if (msg.str_vec !== undefined) {
      resolved.str_vec = new Array(msg.str_vec.length);
      for (let i = 0; i < resolved.str_vec.length; ++i) {
        resolved.str_vec[i] = std_msgs.msg.String.Resolve(msg.str_vec[i]);
      }
    }
    else {
      resolved.str_vec = []
    }

    return resolved;
    }
};

module.exports = AdminParam;
