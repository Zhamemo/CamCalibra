// Auto-generated. Do not edit!

// (in-package custom_msgs_srvs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class EngineeringSurveyInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.engineering_style = null;
      this.current_use_map_name = null;
      this.reuse_map_and_path_name = null;
      this.check_map_name = null;
    }
    else {
      if (initObj.hasOwnProperty('engineering_style')) {
        this.engineering_style = initObj.engineering_style
      }
      else {
        this.engineering_style = 0;
      }
      if (initObj.hasOwnProperty('current_use_map_name')) {
        this.current_use_map_name = initObj.current_use_map_name
      }
      else {
        this.current_use_map_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('reuse_map_and_path_name')) {
        this.reuse_map_and_path_name = initObj.reuse_map_and_path_name
      }
      else {
        this.reuse_map_and_path_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('check_map_name')) {
        this.check_map_name = initObj.check_map_name
      }
      else {
        this.check_map_name = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EngineeringSurveyInfo
    // Serialize message field [engineering_style]
    bufferOffset = _serializer.int16(obj.engineering_style, buffer, bufferOffset);
    // Serialize message field [current_use_map_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.current_use_map_name, buffer, bufferOffset);
    // Serialize message field [reuse_map_and_path_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.reuse_map_and_path_name, buffer, bufferOffset);
    // Serialize message field [check_map_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.check_map_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EngineeringSurveyInfo
    let len;
    let data = new EngineeringSurveyInfo(null);
    // Deserialize message field [engineering_style]
    data.engineering_style = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [current_use_map_name]
    data.current_use_map_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [reuse_map_and_path_name]
    data.reuse_map_and_path_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [check_map_name]
    data.check_map_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.current_use_map_name);
    length += std_msgs.msg.String.getMessageSize(object.reuse_map_and_path_name);
    length += std_msgs.msg.String.getMessageSize(object.check_map_name);
    return length + 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs_srvs/EngineeringSurveyInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '16747ba51ca2600359c480550098e29c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 engineering_style
    std_msgs/String current_use_map_name
    std_msgs/String reuse_map_and_path_name
    std_msgs/String check_map_name
    
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EngineeringSurveyInfo(null);
    if (msg.engineering_style !== undefined) {
      resolved.engineering_style = msg.engineering_style;
    }
    else {
      resolved.engineering_style = 0
    }

    if (msg.current_use_map_name !== undefined) {
      resolved.current_use_map_name = std_msgs.msg.String.Resolve(msg.current_use_map_name)
    }
    else {
      resolved.current_use_map_name = new std_msgs.msg.String()
    }

    if (msg.reuse_map_and_path_name !== undefined) {
      resolved.reuse_map_and_path_name = std_msgs.msg.String.Resolve(msg.reuse_map_and_path_name)
    }
    else {
      resolved.reuse_map_and_path_name = new std_msgs.msg.String()
    }

    if (msg.check_map_name !== undefined) {
      resolved.check_map_name = std_msgs.msg.String.Resolve(msg.check_map_name)
    }
    else {
      resolved.check_map_name = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = EngineeringSurveyInfo;
